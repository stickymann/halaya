-- MySQL dump 10.13  Distrib 5.5.32, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: hndshkif
-- ------------------------------------------------------
-- Server version	5.5.32-0ubuntu0.12.10.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `_adi_automenus`
--

DROP TABLE IF EXISTS `_adi_automenus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `_adi_automenus` (
  `id` varchar(50) NOT NULL,
  `module` varchar(50) NOT NULL,
  `root_id` varchar(255) NOT NULL,
  `menu_layout` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `_adi_automenus`
--

LOCK TABLES `_adi_automenus` WRITE;
/*!40000 ALTER TABLE `_adi_automenus` DISABLE KEYS */;
INSERT INTO `_adi_automenus` VALUES ('businessadmin_menus','businessadmin','Business Administration,5020','ROOT;Business Administration;N;businessadmin;;;;-1\r\nBusiness Administration;Support Services;N;businessadmin;;;;-1\r\nBusiness Administration;Batches;N;businessadmin;;;;-1\r\nBatches;Batch Invoices;L;businessadmin;core_businessadmin_batchinvoice;if,vw,nw,cp,in,ao,as,rj,hd,va;ls,is,hs,ex;-1\r\nBatches;Charge Invoices (Monthly);L;businessadmin;core_businessadmin_bicrmonthly;if,vw,nw,in,ao,as,rj,hd,va;ls,is,hs,ex;428\r\nBatches;Charge Invoices (Period);L;businessadmin;core_businessadmin_bicrperiod;if,vw,nw,in,ao,as,rj,hd,va;ls,is,hs,ex;429'),('customer_menus','customer','Customers,5010','ROOT;Customers;N;customers;;;;-1\r\nCustomers;Customer;L;customer;core_customer_customer;if,vw,nw,cp,in,ao,as,rj,hd,va;ls,is,hs,ex;-1\r\nCustomers;Charge Account;L;customer;core_customer_chargeaccount;if,vw,nw,cp,in,ao,as,rj,hd,va;ls,is,hs,ex;426'),('developer_menus','developer','Developer,25','ROOT;Developer;N;developer;;;;-1\r\nDeveloper;Definition;N;developer;;;;-1\r\nDefinition;Param;L;developer;param;if,vw,nw,cp,in,ao,as,rj,hd,va;ls,is,hs,ex;-1\r\nDefinition;Form;L;developer;formdef;if,vw,nw,cp,in,ao,as,rj,hd,va;ls,is,hs,ex;-1\r\nDefinition;Menu;L;developer;menudef;if,vw,nw,cp,in,ao,as,rj,hd,va;ls,is,hs,ex;-1\r\nDefinition;Enquiry;L;developer;enquirydef;if,vw,nw,cp,in,ao,as,rj,hd,va;ls,is,hs,ex;-1\r\nDefinition;Report;L;developer;reportdef;if,vw,nw,cp,in,ao,as,rj,hd,va;ls,is,hs,ex;-1\r\nDefinition;PDF Template;L;developer;pdftemplate;if,vw,nw,cp,in,ao,as,rj,hd,va;ls,is,hs,ex;-1\r\nDefinition;Auto Definitions;L;developer;core_developer_autodef;if,vw,nw,cp,in,ao,as,rj,hd,va;ls,is,hs,ex;63\r\nDeveloper;Enquiry Administration;N;developer;;;;-1\r\nEnquiry Administration;Fixed Selection;L;developer;fixedselection;if,vw,nw,cp,in,ao,as,rj,hd,va;ls,is,hs,ex;-1\r\nDeveloper;Report Administration;N;developer;;;;-1\r\nReport Administration;Run Report Refresh;L;developer;runreportrefresh;if,vw,nw,cp,in,ao,as,rj,hd,va;ls,is,hs,ex;-1\r\nReport Administration;Report Refresh Configuration;L;developer;reportrefreshconfig;if,vw,nw,cp,in,ao,as,rj,hd,va;ls,is,hs,ex;-1\r\nReport Administration;Jasper Compile;L;developer;jaspercompile;if,vw,nw,cp,in,ao,as,rj,hd,va;ls,is,hs,ex;-1\r\nDeveloper;Table Administration;N;developer;;;;-1\r\nTable Administration;Run Table Reset;L;developer;runtablereset;if,vw,nw,cp,in,ao,as,rj,hd,va;ls,is,hs,ex;-1\r\nTable Administration;Table Reset Configuration;L;developer;tableresetconfig;if,vw,nw,cp,in,ao,as,rj,hd,va;ls,is,hs,ex;-1'),('hndshkif_menus','hndshkif','Handshake Interface,6000','ROOT;Handshake Interface;N;hndshkif;;;;1000\r\nHandshake Interface;Notifications;N;hndshkif;;;;1010\r\nNotifications;Summary;L;hndshkif;hndshkif_notifications_summary;if,vw,nw,cp,in,ao,as,rj,hd,va;ls,is,hs,ex;1011\r\nNotifications;Errors;L;hndshkif;hndshkif_notifications_summary;if,vw,nw,cp,in,ao,as,rj,hd,va;ls,is,hs,ex;1012\r\nHandshake Interface;Orders;N;hndshkif;;;;1020\r\nOrders;Downloaded Orders;L;hndshkif;hndshkif_orders_dlorder;if,vw,nw,cp,in,ao,as,rj,hd,va;ls,is,hs,ex;1021\r\nOrders;Downloaded Order Batches;L;hndshkif;hndshkif_orders_dlorderbatch;if,vw,nw,cp,in,ao,as,rj,hd,va;ls,is,hs,ex;1022\r\nOrders;Downloaded Orders Report;L;hndshkif;hndshkif_orders_dlorderreport;if,vw,nw,cp,in,ao,as,rj,hd,va;ls,is,hs,ex;1023\r\nOrders;Last Download Report;L;hndshkif;hndshkif_orders_dlorderlastreport;if,vw,nw,cp,in,ao,as,rj,hd,va;ls,is,hs,ex;1024\r\nOrders;Get Handshake Orders;L;hndshkif;hndshkif_orders_gethandshakeorders;if,vw,nw,cp,in,ao,as,rj,hd,va;ls,is,hs,ex;1025\r\nOrders;Orders Import File;L;hndshkif;hndshkif_orders_ordersimportfile;if,vw,nw,cp,in,ao,as,rj,hd,va;ls,is,hs,ex;1026\r\nHandshake Interface;Customers;N;hndshkif;;;;1040\r\nCustomers;Customer Mapping;L;hndshkif;hndshkif_customers_customermapping;if,vw,nw,cp,in,ao,as,rj,hd,va;ls,is,hs,ex;1041\r\nCustomers;Customer Batches;L;hndshkif;hndshkif_customers_customerbatch;if,vw,nw,cp,in,ao,as,rj,hd,va;ls,is,hs,ex;1042\r\nCustomers;Customer Changelog;L;hndshkif;hndshkif_customers_customerchangelog;if,vw,nw,cp,in,ao,as,rj,hd,va;ls,is,hs,ex;1043\r\nCustomers;Get Dac Easy Customers;L;hndshkif;hndshkif_customers_getdaceasycustomers;if,vw,nw,cp,in,ao,as,rj,hd,va;ls,is,hs,ex;1044\r\nCustomers;Push Handshake Customers;L;hndshkif;hndshkif_customers_pushhandshakecustomers;if,vw,nw,cp,in,ao,as,rj,hd,va;ls,is,hs,ex;1045\r\nHandshake Interface;Inventory;N;hndshkif;;;;1050\r\nInventory;Inventory Mapping;L;hndshkif;hndshkif_inventory_inventorymapping;if,vw,nw,cp,in,ao,as,rj,hd,va;ls,is,hs,ex;1051\r\nInventory;Inventory Batches;L;hndshkif;hndshkif_inventory_inventorybatch;if,vw,nw,cp,in,ao,as,rj,hd,va;ls,is,hs,ex;1052\r\nInventory;Inventory Changelog;L;hndshkif;hndshkif_inventory_inventorychangelog;if,vw,nw,cp,in,ao,as,rj,hd,va;ls,is,hs,ex;1053\r\nInventory;Get Dac Easy Inventory;L;hndshkif;hndshkif_inventory_getdaceasyinventory;if,vw,nw,cp,in,ao,as,rj,hd,va;ls,is,hs,ex;1054\r\nInventory;Push Handshake Inventory;L;hndshkif;hndshkif_inventory_pushhandshakeinventory;if,vw,nw,cp,in,ao,as,rj,hd,va;ls,is,hs,ex;1055\r\nHandshake Interface;Settings;N;hndshkif;;;;1060\r\nSettings;Handshake API;L;hndshkif;hndshkif_settings_handshakeapi;if,vw,nw,cp,in,ao,as,rj,hd,va;ls,is,hs,ex;1061\r\nSettings;Scheduling;L;hndshkif;hndshkif_settings_scheduling;if,vw,nw,cp,in,ao,as,rj,hd,va;ls,is,hs,ex;1062\r\nSettings;Folders;L;hndshkif;hndshkif_settings_folders;if,vw,nw,cp,in,ao,as,rj,hd,va;ls,is,hs,ex;1063\r\nSettings;Interface Status;L;hndshkif;hndshkif_settings_ifstatus;if,vw,nw,cp,in,ao,as,rj,hd,va;ls,is,hs,ex;1064'),('sales_menu','sales','Sales,5040','ROOT;Sales;N;sales;;;;-1\r\nSales;Products;N;sales;;;;-1\r\nProducts;Product;L;sales;core_sales_product;if,vw,nw,cp,in,ao,as,rj,hd,va;ls,is,hs,ex;-1\r\nProducts;Inventory;L;sales;core_sales_inventory;if,vw,nw,cp,in,ao,as,rj,hd,va;ls,is,hs,ex;-1\r\nProducts;Inventory Update Type;L;sales;core_sales_inventupdtype;if,vw,nw,cp,in,ao,as,rj,hd,va;ls,is,hs,ex;-1\r\nProducts;Inventory Sale Log;L;sales;core_sales_inventorysalelog;if,vw;ls,is,ex;427\r\nSales;Orders & Payments;N;sales;;;;-1\r\nOrders & Payments;Estimator;L;sales;core_sales_estimator;if,vw,nw,cp,in,ao,as,rj,hd,va;ls,is,hs,ex;-1\r\nOrders & Payments;Order;L;sales;core_sales_order;if,vw,nw,cp,in,ao,as,rj,hd,va;ls,is,hs,ex;-1\r\nOrders & Payments;Payment;L;sales;core_sales_payment;if,vw,nw,cp,in,ao,as,rj,hd,va;ls,is,hs,ex;-1\r\nOrders & Payments;Inventory Checkout;L;sales;core_sales_inventchkout;if,vw,nw,cp,in,ao,as,rj,hd,va;ls,is,hs,ex;-1\r\nOrders & Payments;Delivery Note;L;sales;core_sales_deliverynote;if,vw,nw,cp,in,ao,as,rj,hd,va;ls,is,hs,ex;-1\r\nSales;Tills;N;sales;;;;-1\r\nTills;User Till;L;sales;core_sales_tilluser;if,vw,nw,cp,in,ao,as,rj,hd,va;ls,is,hs,ex;-1\r\nTills;Manage Till;L;sales;tillmanage;if,vw,nw,cp,in,ao,as,rj,hd,va;ls,is,hs,ex;-1\r\nTills;Till Transaction;L;sales;core_sales_tilltransaction;if,vw,nw,cp,in,ao,as,rj,hd,va;ls,is,hs,ex;-1\r\nSales;Sales Admin;N;sales;;;;-1\r\nSales Admin;Order Cancel;L;sales;core_sales_ordercancel;if,vw,nw,cp,in,ao,as,rj,hd,va;ls,is,hs,ex;-1\r\nSales Admin;Payment Cancel;L;sales;core_sales_paymentcancel;if,vw,nw,cp,in,ao,as,rj,hd,va;ls,is,hs,ex;-1\r\nSales Admin;Order Re-Open;L;sales;core_sales_orderopen;if,vw,nw,cp,in,ao,as,rj,hd,va;ls,is,hs,ex;-1');
/*!40000 ALTER TABLE `_adi_automenus` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `_adi_autotables`
--

DROP TABLE IF EXISTS `_adi_autotables`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `_adi_autotables` (
  `id` varchar(50) NOT NULL,
  `module` varchar(50) NOT NULL,
  `tablename` varchar(255) NOT NULL,
  `tablefields` text NOT NULL,
  `uniquefield` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `_adi_autotables`
--

LOCK TABLES `_adi_autotables` WRITE;
/*!40000 ALTER TABLE `_adi_autotables` DISABLE KEYS */;
INSERT INTO `_adi_autotables` VALUES ('core_businessadmin_bicr','businessadmin','bicrs','id;int(11);unsigned NOT NULL\r\nbatchrequest_id;varchar(30);NOT NULL\r\nrequesttype;varchar(20);NOT NULL\r\ncc_id;varchar(8);DEFAULT NULL\r\ndescription;varchar(255);NOT NULL\r\nstart_date;date;NOT NULL DEFAULT  \"0000-00-00\"\r\nend_date;date;NOT NULL DEFAULT  \"0000-00-00\"\r\nrun;enum(\"N\",\"Y\");NOT NULL DEFAULT \"N\"\r\ncomments;text;DEFAULT NULL','batchrequest_id'),('core_customer_chargeaccount','customer','chargeaccounts','id;int(11);unsigned NOT NULL\r\ncustomer_id;varchar(8);NOT NULL\r\nactivation_date;date;NOT NULL DEFAULT  \"1901-12-14\"\r\nstatus_change_date;date;NOT NULL DEFAULT  \"1901-12-14\"\r\nactive;enum(\"Y\",\"N\");NOT NULL DEFAULT \"N\"\r\nspecial_instructions;text;DEFAULT NULL\r\ncomments;text;DEFAULT NULL','customer_id'),('core_customer_chargeaccounts','customer','chargeaccounts','id;int(11);unsigned NOT NULL\r\ncustomer_id;varchar(8);NOT NULL\r\nactivation_date;date;NOT NULL DEFAULT  \"1901-12-14\"\r\nstatus_change_date;date;NOT NULL DEFAULT  \"1901-12-14\"\r\nactive;enum(\"Y\",\"N\");NOT NULL DEFAULT \"N\"\r\nspecial_instructions;text;DEFAULT NULL\r\ncomments;text;DEFAULT NULL','customer_id'),('core_sales_ordercancel','sales','ordercancels','id;int(11);unsigned;NOT NULL\r\nordercancel_id;varchar(16);NOT NULL    \r\norder_id;varchar(16);NOT NULL       \r\npre_cancel_status;varchar(20);NOT NULL                \r\nreason;varchar(255);NOT NULL        \r\ncomments;text;DEFAULT NULL','ordercancel_id'),('core_sales_orderopen','sales','orderopens','id;int(11);unsigned;NOT NULL\r\norderopen_id;varchar(16);NOT NULL    \r\norder_id;varchar(16);NOT NULL       \r\npre_open_status;varchar(20);NOT NULL                \r\nreason;varchar(255);NOT NULL        \r\ncomments;text;DEFAULT NULL','orderopen_id'),('hndshkif_orders_dlorder','hndshkif','dlorders','id;int(11);unsigned NOT NULL\r\norder_id;varchar(12);NOT NULL\r\nbatch_id;varchar(20);NOT NULL\r\ncustomer_id;varchar(14);NOT NULL\r\ntax_id;varchar(10);NOT NULL\r\nname;varchar(50);NOT NULL\r\ncontact;varchar(50);NOT NULL\r\nstreet;varchar(50);NOT NULL\r\ncity;varchar(50);NOT NULL\r\ncountry;varchar(50);NOT NULL\r\nphone;varchar(21);NOT NULL\r\npaymentterms;varchar(20);NOT NULL\r\ncdate;date;NOT NULL\r\nctime;time;NOT NULL\r\norderlines;text;DEFAULT NULL;','order_id'),('hndshkif_orders_gethandshakeorders','hndshkif','dlors','id;int(11);unsigned NOT NULL\r\nrequest_id;varchar(30);NOT NULL\r\ndescription;varchar(255);NOT NULL\r\nrun;enum(\"N\",\"Y\");NOT NULL DEFAULT \"N\"\r\ncomments;text;DEFAULT NULL','request_id'),('hndshkif_settings_interfaceconfiguration','hndshkif','interfaceconfigurations','id;int(11);unsigned NOT NULL\r\nconfig_id;varchar(30);NOT NULL\r\ndb_server;varchar(30);NOT NULL\r\ndb_name;varchar(30);NOT NULL\r\ndb_user;varchar(30);NOT NULL\r\ndb_password;varchar(30);NOT NULL\r\nhs_apikey;varchar(64);NOT NULL\r\nfolderc_import;varchar(256);NOT NULL\r\nfolderc_export;varchar(256);NOT NULL\r\nfoldera_import;varchar(256);NOT NULL\r\nfoldera_export;varchar(256);NOT NULL\r\ncomments;text;DEFAULT NULL','config_id');
/*!40000 ALTER TABLE `_adi_autotables` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `_adi_configs`
--

DROP TABLE IF EXISTS `_adi_configs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `_adi_configs` (
  `id` varchar(50) NOT NULL,
  `autogendir` varchar(1024) DEFAULT NULL,
  `defdir` varchar(1024) DEFAULT NULL,
  `approotdir` varchar(1024) DEFAULT NULL,
  `module` varchar(1024) DEFAULT NULL,
  `activedef` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `_adi_configs`
--

LOCK TABLES `_adi_configs` WRITE;
/*!40000 ALTER TABLE `_adi_configs` DISABLE KEYS */;
INSERT INTO `_adi_configs` VALUES ('system','/zipstore/www/hndshkif/autodefs/autogen','/zipstore/www/hndshkif/autodefs/defs','/zipstore/www/hndshkif','hndshkif','hndshkif_orders_dlorder');
/*!40000 ALTER TABLE `_adi_configs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `_adi_formdefs`
--

DROP TABLE IF EXISTS `_adi_formdefs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `_adi_formdefs` (
  `id` varchar(50) NOT NULL,
  `controller` varchar(255) DEFAULT NULL,
  `module` varchar(50) DEFAULT NULL,
  `sql_code` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `_adi_formdefs`
--

LOCK TABLES `_adi_formdefs` WRITE;
/*!40000 ALTER TABLE `_adi_formdefs` DISABLE KEYS */;
INSERT INTO `_adi_formdefs` VALUES ('insert_inau','hndshkif_orders_dlorder','hndshkif','UPDATE params_is SET formfields=\"%XMLHEADER%\n<formfields>\n	<field><name>id</name><label>Id</label><type>hidden</type><value></value><options></options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>order_id</name><label>Order Id</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>batch_id</name><label>Batch Id</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>customer_id</name><label>Customer Id</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>tax_id</name><label>Tax Id</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>name</name><label>Name</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>contact</name><label>Contact</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>street</name><label>Street</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>city</name><label>City</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>country</name><label>Country</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>phone</name><label>Phone</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>paymentterms</name><label>Paymentterms</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>cdate</name><label>Cdate</label><type>date</type><value></value><options>size=12 maxlength=10</options><onnew>enabled_po</onnew><onedit>enabled_po</onedit></field>\n	<field><name>ctime</name><label>Ctime</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>orderlines</name><label>Orderlines</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n</formfields>\n\",inputter=\"IMPLEMENTATION\",input_date=\"2013-09-14 05:09:56\",record_status=\"INAU\",current_no=\"0\" where param_id=\"hndshkif_orders_dlorder\";');
/*!40000 ALTER TABLE `_adi_formdefs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `_adi_menudefs`
--

DROP TABLE IF EXISTS `_adi_menudefs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `_adi_menudefs` (
  `id` varchar(255) NOT NULL,
  `sql_code` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `_adi_menudefs`
--

LOCK TABLES `_adi_menudefs` WRITE;
/*!40000 ALTER TABLE `_adi_menudefs` DISABLE KEYS */;
INSERT INTO `_adi_menudefs` VALUES ('insert_inau','INSERT INTO `menudefs_is` (`id`, `menu_id`, `parent_id`, `sortpos`, `node_or_leaf`, `module`, `label_input`, `label_enquiry`, `url_input`, `url_enquiry`, `controls_input`, `controls_enquiry`,`inputter`, `input_date`, `record_status`, `current_no`)  VALUES (\"1000\", \"6000\", \"0\", \"60.00000\", \"N\", \"hndshkif\", \"Handshake Interface\", \"\", \"\", \"\", \"\", \"\", \"IMPLEMENTATION\", \"2013-09-13 16:09:29\", \"INAU\", \"0\"),(\"1010\", \"600000\", \"6000\", \"6000.00000\", \"N\", \"hndshkif\", \"Notifications\", \"\", \"\", \"\", \"\", \"\", \"IMPLEMENTATION\", \"2013-09-13 16:09:29\", \"INAU\", \"0\"),(\"1011\", \"60000050\", \"600000\", \"600000.50000\", \"L\", \"hndshkif\", \"Summary\", \"magicon016.png%IMG%\", \"hndshkif_notifications_summary\", \"hndshkif_notifications_summary/enquirydefault\", \"if,vw,nw,cp,in,ao,as,rj,hd,va\", \"ls,is,hs,ex\", \"IMPLEMENTATION\", \"2013-09-13 16:09:29\", \"INAU\", \"0\"),(\"1012\", \"60000051\", \"600000\", \"600000.50000\", \"L\", \"hndshkif\", \"Errors\", \"magicon016.png%IMG%\", \"hndshkif_notifications_summary\", \"hndshkif_notifications_summary/enquirydefault\", \"if,vw,nw,cp,in,ao,as,rj,hd,va\", \"ls,is,hs,ex\", \"IMPLEMENTATION\", \"2013-09-13 16:09:29\", \"INAU\", \"0\"),(\"1020\", \"600001\", \"6000\", \"6000.00977\", \"N\", \"hndshkif\", \"Orders\", \"\", \"\", \"\", \"\", \"\", \"IMPLEMENTATION\", \"2013-09-13 16:09:29\", \"INAU\", \"0\"),(\"1021\", \"60000150\", \"600001\", \"600001.50000\", \"L\", \"hndshkif\", \"Downloaded Orders\", \"magicon016.png%IMG%\", \"hndshkif_orders_dlorder\", \"hndshkif_orders_dlorder/enquirydefault\", \"if,vw,nw,cp,in,ao,as,rj,hd,va\", \"ls,is,hs,ex\", \"IMPLEMENTATION\", \"2013-09-13 16:09:29\", \"INAU\", \"0\"),(\"1022\", \"60000151\", \"600001\", \"600001.50000\", \"L\", \"hndshkif\", \"Downloaded Order Batches\", \"magicon016.png%IMG%\", \"hndshkif_orders_dlorderbatch\", \"hndshkif_orders_dlorderbatch/enquirydefault\", \"if,vw,nw,cp,in,ao,as,rj,hd,va\", \"ls,is,hs,ex\", \"IMPLEMENTATION\", \"2013-09-13 16:09:29\", \"INAU\", \"0\"),(\"1023\", \"60000152\", \"600001\", \"600001.50000\", \"L\", \"hndshkif\", \"Downloaded Orders Report\", \"magicon016.png%IMG%\", \"hndshkif_orders_dlorderreport\", \"hndshkif_orders_dlorderreport/enquirydefault\", \"if,vw,nw,cp,in,ao,as,rj,hd,va\", \"ls,is,hs,ex\", \"IMPLEMENTATION\", \"2013-09-13 16:09:29\", \"INAU\", \"0\"),(\"1024\", \"60000153\", \"600001\", \"600001.50000\", \"L\", \"hndshkif\", \"Last Download Report\", \"magicon016.png%IMG%\", \"hndshkif_orders_dlorderlastreport\", \"hndshkif_orders_dlorderlastreport/enquirydefault\", \"if,vw,nw,cp,in,ao,as,rj,hd,va\", \"ls,is,hs,ex\", \"IMPLEMENTATION\", \"2013-09-13 16:09:29\", \"INAU\", \"0\"),(\"1025\", \"60000154\", \"600001\", \"600001.56250\", \"L\", \"hndshkif\", \"Get Handshake Orders\", \"magicon016.png%IMG%\", \"hndshkif_orders_gethandshakeorders\", \"hndshkif_orders_gethandshakeorders/enquirydefault\", \"if,vw,nw,cp,in,ao,as,rj,hd,va\", \"ls,is,hs,ex\", \"IMPLEMENTATION\", \"2013-09-13 16:09:29\", \"INAU\", \"0\"),(\"1026\", \"60000155\", \"600001\", \"600001.56250\", \"L\", \"hndshkif\", \"Orders Import File\", \"magicon016.png%IMG%\", \"hndshkif_orders_ordersimportfile\", \"hndshkif_orders_ordersimportfile/enquirydefault\", \"if,vw,nw,cp,in,ao,as,rj,hd,va\", \"ls,is,hs,ex\", \"IMPLEMENTATION\", \"2013-09-13 16:09:29\", \"INAU\", \"0\"),(\"1040\", \"600002\", \"6000\", \"6000.02002\", \"N\", \"hndshkif\", \"Customers\", \"\", \"\", \"\", \"\", \"\", \"IMPLEMENTATION\", \"2013-09-13 16:09:29\", \"INAU\", \"0\"),(\"1041\", \"60000250\", \"600002\", \"600002.50000\", \"L\", \"hndshkif\", \"Customer Mapping\", \"magicon016.png%IMG%\", \"hndshkif_customers_customermapping\", \"hndshkif_customers_customermapping/enquirydefault\", \"if,vw,nw,cp,in,ao,as,rj,hd,va\", \"ls,is,hs,ex\", \"IMPLEMENTATION\", \"2013-09-13 16:09:29\", \"INAU\", \"0\"),(\"1042\", \"60000251\", \"600002\", \"600002.50000\", \"L\", \"hndshkif\", \"Customer Batches\", \"magicon016.png%IMG%\", \"hndshkif_customers_customerbatch\", \"hndshkif_customers_customerbatch/enquirydefault\", \"if,vw,nw,cp,in,ao,as,rj,hd,va\", \"ls,is,hs,ex\", \"IMPLEMENTATION\", \"2013-09-13 16:09:29\", \"INAU\", \"0\"),(\"1043\", \"60000252\", \"600002\", \"600002.50000\", \"L\", \"hndshkif\", \"Customer Changelog\", \"magicon016.png%IMG%\", \"hndshkif_customers_customerchangelog\", \"hndshkif_customers_customerchangelog/enquirydefault\", \"if,vw,nw,cp,in,ao,as,rj,hd,va\", \"ls,is,hs,ex\", \"IMPLEMENTATION\", \"2013-09-13 16:09:29\", \"INAU\", \"0\"),(\"1044\", \"60000253\", \"600002\", \"600002.50000\", \"L\", \"hndshkif\", \"Get Dac Easy Customers\", \"magicon016.png%IMG%\", \"hndshkif_customers_getdaceasycustomers\", \"hndshkif_customers_getdaceasycustomers/enquirydefault\", \"if,vw,nw,cp,in,ao,as,rj,hd,va\", \"ls,is,hs,ex\", \"IMPLEMENTATION\", \"2013-09-13 16:09:29\", \"INAU\", \"0\"),(\"1045\", \"60000254\", \"600002\", \"600002.56250\", \"L\", \"hndshkif\", \"Push Handshake Customers\", \"magicon016.png%IMG%\", \"hndshkif_customers_pushhandshakecustomers\", \"hndshkif_customers_pushhandshakecustomers/enquirydefault\", \"if,vw,nw,cp,in,ao,as,rj,hd,va\", \"ls,is,hs,ex\", \"IMPLEMENTATION\", \"2013-09-13 16:09:29\", \"INAU\", \"0\"),(\"1050\", \"600003\", \"6000\", \"6000.02979\", \"N\", \"hndshkif\", \"Inventory\", \"\", \"\", \"\", \"\", \"\", \"IMPLEMENTATION\", \"2013-09-13 16:09:29\", \"INAU\", \"0\"),(\"1051\", \"60000350\", \"600003\", \"600003.50000\", \"L\", \"hndshkif\", \"Inventory Mapping\", \"magicon016.png%IMG%\", \"hndshkif_inventory_inventorymapping\", \"hndshkif_inventory_inventorymapping/enquirydefault\", \"if,vw,nw,cp,in,ao,as,rj,hd,va\", \"ls,is,hs,ex\", \"IMPLEMENTATION\", \"2013-09-13 16:09:29\", \"INAU\", \"0\"),(\"1052\", \"60000351\", \"600003\", \"600003.50000\", \"L\", \"hndshkif\", \"Inventory Batches\", \"magicon016.png%IMG%\", \"hndshkif_inventory_inventorybatch\", \"hndshkif_inventory_inventorybatch/enquirydefault\", \"if,vw,nw,cp,in,ao,as,rj,hd,va\", \"ls,is,hs,ex\", \"IMPLEMENTATION\", \"2013-09-13 16:09:29\", \"INAU\", \"0\"),(\"1053\", \"60000352\", \"600003\", \"600003.50000\", \"L\", \"hndshkif\", \"Inventory Changelog\", \"magicon016.png%IMG%\", \"hndshkif_inventory_inventorychangelog\", \"hndshkif_inventory_inventorychangelog/enquirydefault\", \"if,vw,nw,cp,in,ao,as,rj,hd,va\", \"ls,is,hs,ex\", \"IMPLEMENTATION\", \"2013-09-13 16:09:29\", \"INAU\", \"0\"),(\"1054\", \"60000353\", \"600003\", \"600003.50000\", \"L\", \"hndshkif\", \"Get Dac Easy Inventory\", \"magicon016.png%IMG%\", \"hndshkif_inventory_getdaceasyinventory\", \"hndshkif_inventory_getdaceasyinventory/enquirydefault\", \"if,vw,nw,cp,in,ao,as,rj,hd,va\", \"ls,is,hs,ex\", \"IMPLEMENTATION\", \"2013-09-13 16:09:29\", \"INAU\", \"0\"),(\"1055\", \"60000354\", \"600003\", \"600003.56250\", \"L\", \"hndshkif\", \"Push Handshake Inventory\", \"magicon016.png%IMG%\", \"hndshkif_inventory_pushhandshakeinventory\", \"hndshkif_inventory_pushhandshakeinventory/enquirydefault\", \"if,vw,nw,cp,in,ao,as,rj,hd,va\", \"ls,is,hs,ex\", \"IMPLEMENTATION\", \"2013-09-13 16:09:29\", \"INAU\", \"0\"),(\"1060\", \"600004\", \"6000\", \"6000.04004\", \"N\", \"hndshkif\", \"Settings\", \"\", \"\", \"\", \"\", \"\", \"IMPLEMENTATION\", \"2013-09-13 16:09:29\", \"INAU\", \"0\"),(\"1061\", \"60000450\", \"600004\", \"600004.50000\", \"L\", \"hndshkif\", \"Handshake API\", \"magicon016.png%IMG%\", \"hndshkif_settings_handshakeapi\", \"hndshkif_settings_handshakeapi/enquirydefault\", \"if,vw,nw,cp,in,ao,as,rj,hd,va\", \"ls,is,hs,ex\", \"IMPLEMENTATION\", \"2013-09-13 16:09:29\", \"INAU\", \"0\"),(\"1062\", \"60000451\", \"600004\", \"600004.50000\", \"L\", \"hndshkif\", \"Scheduling\", \"magicon016.png%IMG%\", \"hndshkif_settings_scheduling\", \"hndshkif_settings_scheduling/enquirydefault\", \"if,vw,nw,cp,in,ao,as,rj,hd,va\", \"ls,is,hs,ex\", \"IMPLEMENTATION\", \"2013-09-13 16:09:29\", \"INAU\", \"0\"),(\"1063\", \"60000452\", \"600004\", \"600004.50000\", \"L\", \"hndshkif\", \"Folders\", \"magicon016.png%IMG%\", \"hndshkif_settings_folders\", \"hndshkif_settings_folders/enquirydefault\", \"if,vw,nw,cp,in,ao,as,rj,hd,va\", \"ls,is,hs,ex\", \"IMPLEMENTATION\", \"2013-09-13 16:09:29\", \"INAU\", \"0\"),(\"1064\", \"60000453\", \"600004\", \"600004.50000\", \"L\", \"hndshkif\", \"Interface Status\", \"magicon016.png%IMG%\", \"hndshkif_settings_ifstatus\", \"hndshkif_settings_ifstatus/enquirydefault\", \"if,vw,nw,cp,in,ao,as,rj,hd,va\", \"ls,is,hs,ex\", \"IMPLEMENTATION\", \"2013-09-13 16:09:29\", \"INAU\", \"0\");');
/*!40000 ALTER TABLE `_adi_menudefs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `_adi_menutrees`
--

DROP TABLE IF EXISTS `_adi_menutrees`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `_adi_menutrees` (
  `menu_id` int(20) DEFAULT NULL,
  `parent_id` int(20) DEFAULT NULL,
  `sortpos` float(20,5) DEFAULT NULL,
  `lft` int(20) DEFAULT NULL,
  `rgt` int(20) DEFAULT NULL,
  `node_or_leaf` char(1) DEFAULT NULL,
  `module` varchar(20) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `url_input` varchar(255) DEFAULT NULL,
  `parent` varchar(255) DEFAULT NULL,
  `control_input` varchar(255) DEFAULT NULL,
  `control_enquiry` varchar(255) DEFAULT NULL,
  `id_opt` int(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `_adi_menutrees`
--

LOCK TABLES `_adi_menutrees` WRITE;
/*!40000 ALTER TABLE `_adi_menutrees` DISABLE KEYS */;
INSERT INTO `_adi_menutrees` VALUES (6000,0,60.00000,1,56,'N','hndshkif','Handshake Interface','','ROOT','','',1000),(600000,6000,6000.00000,2,7,'N','hndshkif','Notifications','','Handshake Interface','','',1010),(60000050,600000,600000.50000,3,4,'L','hndshkif','Summary','hndshkif_notifications_summary','Notifications','if,vw,nw,cp,in,ao,as,rj,hd,va','ls,is,hs,ex',1011),(60000051,600000,600000.50000,5,6,'L','hndshkif','Errors','hndshkif_notifications_summary','Notifications','if,vw,nw,cp,in,ao,as,rj,hd,va','ls,is,hs,ex',1012),(600001,6000,6000.00977,8,21,'N','hndshkif','Orders','','Handshake Interface','','',1020),(60000150,600001,600001.50000,9,10,'L','hndshkif','Downloaded Orders','hndshkif_orders_dlorder','Orders','if,vw,nw,cp,in,ao,as,rj,hd,va','ls,is,hs,ex',1021),(60000151,600001,600001.50000,11,12,'L','hndshkif','Downloaded Order Batches','hndshkif_orders_dlorderbatch','Orders','if,vw,nw,cp,in,ao,as,rj,hd,va','ls,is,hs,ex',1022),(60000152,600001,600001.50000,13,14,'L','hndshkif','Downloaded Orders Report','hndshkif_orders_dlorderreport','Orders','if,vw,nw,cp,in,ao,as,rj,hd,va','ls,is,hs,ex',1023),(60000153,600001,600001.50000,15,16,'L','hndshkif','Last Download Report','hndshkif_orders_dlorderlastreport','Orders','if,vw,nw,cp,in,ao,as,rj,hd,va','ls,is,hs,ex',1024),(60000154,600001,600001.56250,17,18,'L','hndshkif','Get Handshake Orders','hndshkif_orders_gethandshakeorders','Orders','if,vw,nw,cp,in,ao,as,rj,hd,va','ls,is,hs,ex',1025),(60000155,600001,600001.56250,19,20,'L','hndshkif','Orders Import File','hndshkif_orders_ordersimportfile','Orders','if,vw,nw,cp,in,ao,as,rj,hd,va','ls,is,hs,ex',1026),(600002,6000,6000.02002,22,33,'N','hndshkif','Customers','','Handshake Interface','','',1040),(60000250,600002,600002.50000,23,24,'L','hndshkif','Customer Mapping','hndshkif_customers_customermapping','Customers','if,vw,nw,cp,in,ao,as,rj,hd,va','ls,is,hs,ex',1041),(60000251,600002,600002.50000,25,26,'L','hndshkif','Customer Batches','hndshkif_customers_customerbatch','Customers','if,vw,nw,cp,in,ao,as,rj,hd,va','ls,is,hs,ex',1042),(60000252,600002,600002.50000,27,28,'L','hndshkif','Customer Changelog','hndshkif_customers_customerchangelog','Customers','if,vw,nw,cp,in,ao,as,rj,hd,va','ls,is,hs,ex',1043),(60000253,600002,600002.50000,29,30,'L','hndshkif','Get Dac Easy Customers','hndshkif_customers_getdaceasycustomers','Customers','if,vw,nw,cp,in,ao,as,rj,hd,va','ls,is,hs,ex',1044),(60000254,600002,600002.56250,31,32,'L','hndshkif','Push Handshake Customers','hndshkif_customers_pushhandshakecustomers','Customers','if,vw,nw,cp,in,ao,as,rj,hd,va','ls,is,hs,ex',1045),(600003,6000,6000.02979,34,45,'N','hndshkif','Inventory','','Handshake Interface','','',1050),(60000350,600003,600003.50000,35,36,'L','hndshkif','Inventory Mapping','hndshkif_inventory_inventorymapping','Inventory','if,vw,nw,cp,in,ao,as,rj,hd,va','ls,is,hs,ex',1051),(60000351,600003,600003.50000,37,38,'L','hndshkif','Inventory Batches','hndshkif_inventory_inventorybatch','Inventory','if,vw,nw,cp,in,ao,as,rj,hd,va','ls,is,hs,ex',1052),(60000352,600003,600003.50000,39,40,'L','hndshkif','Inventory Changelog','hndshkif_inventory_inventorychangelog','Inventory','if,vw,nw,cp,in,ao,as,rj,hd,va','ls,is,hs,ex',1053),(60000353,600003,600003.50000,41,42,'L','hndshkif','Get Dac Easy Inventory','hndshkif_inventory_getdaceasyinventory','Inventory','if,vw,nw,cp,in,ao,as,rj,hd,va','ls,is,hs,ex',1054),(60000354,600003,600003.56250,43,44,'L','hndshkif','Push Handshake Inventory','hndshkif_inventory_pushhandshakeinventory','Inventory','if,vw,nw,cp,in,ao,as,rj,hd,va','ls,is,hs,ex',1055),(600004,6000,6000.04004,46,55,'N','hndshkif','Settings','','Handshake Interface','','',1060),(60000450,600004,600004.50000,47,48,'L','hndshkif','Handshake API','hndshkif_settings_handshakeapi','Settings','if,vw,nw,cp,in,ao,as,rj,hd,va','ls,is,hs,ex',1061),(60000451,600004,600004.50000,49,50,'L','hndshkif','Scheduling','hndshkif_settings_scheduling','Settings','if,vw,nw,cp,in,ao,as,rj,hd,va','ls,is,hs,ex',1062),(60000452,600004,600004.50000,51,52,'L','hndshkif','Folders','hndshkif_settings_folders','Settings','if,vw,nw,cp,in,ao,as,rj,hd,va','ls,is,hs,ex',1063),(60000453,600004,600004.50000,53,54,'L','hndshkif','Interface Status','hndshkif_settings_ifstatus','Settings','if,vw,nw,cp,in,ao,as,rj,hd,va','ls,is,hs,ex',1064);
/*!40000 ALTER TABLE `_adi_menutrees` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `_adi_mvcdefs`
--

DROP TABLE IF EXISTS `_adi_mvcdefs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `_adi_mvcdefs` (
  `id` varchar(1024) NOT NULL,
  `src` varchar(1024) NOT NULL,
  `target` varchar(1024) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `_adi_mvcdefs`
--

LOCK TABLES `_adi_mvcdefs` WRITE;
/*!40000 ALTER TABLE `_adi_mvcdefs` DISABLE KEYS */;
INSERT INTO `_adi_mvcdefs` VALUES ('/zipstore/www/hndshkif/autodefs/autogen/controllers/hndshkif_orders_dlorder.controller.php','/zipstore/www/hndshkif/autodefs/autogen/controllers/hndshkif_orders_dlorder.controller.php','/zipstore/www/hndshkif/application/classes/Controller/Hndshkif/Orders/Dlorder.php');
/*!40000 ALTER TABLE `_adi_mvcdefs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `_adi_paramdefs`
--

DROP TABLE IF EXISTS `_adi_paramdefs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `_adi_paramdefs` (
  `id` varchar(255) NOT NULL,
  `sql_code` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `_adi_paramdefs`
--

LOCK TABLES `_adi_paramdefs` WRITE;
/*!40000 ALTER TABLE `_adi_paramdefs` DISABLE KEYS */;
INSERT INTO `_adi_paramdefs` VALUES ('insert_inau','INSERT INTO params_is (id, param_id, controller, dflag, module, auth_mode_on, index_field_on, indexview, viewview, inputview, authorizeview, deleteview, enquiryview, indexfield, indexfieldvalue, indexlabel, appheader, primarymodel, tb_live, tb_inau, tb_hist, errormsgfile, inputter,input_date,record_status,current_no) VALUES(\"0\", \"hndshkif_orders_dlorder\", \"dlorder\", \"Y\", \"hndshkif\", \"1\", \"1\", \"default_index\", \"default_view\", \"default_input\", \"default_authorize\", \"default_delete\", \"default_enquiry\", \"dlorder_id\", \"\", \"Dlorder Id\", \"Dlorder\", \"Model_SiteDB\", \"dlorders\", \"dlorders_is\", \"dlorders_hs\", \"dlorder_error\", \"IMPLEMENTATION\", \"2013-09-14 05:09:56\", \"INAU\", \"0\");');
/*!40000 ALTER TABLE `_adi_paramdefs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `_adi_tabledefs`
--

DROP TABLE IF EXISTS `_adi_tabledefs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `_adi_tabledefs` (
  `id` varchar(4) NOT NULL,
  `tab_create` varchar(3) DEFAULT NULL,
  `sql_drop` text,
  `sql_create` text,
  `sql_show` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `_adi_tabledefs`
--

LOCK TABLES `_adi_tabledefs` WRITE;
/*!40000 ALTER TABLE `_adi_tabledefs` DISABLE KEYS */;
INSERT INTO `_adi_tabledefs` VALUES ('live','yes','DROP TABLE IF EXISTS `dlorders`;\n','CREATE TABLE `dlorders` (`id` int(11) unsigned NOT NULL\n,`order_id` varchar(12) NOT NULL\n,`batch_id` varchar(20) NOT NULL\n,`customer_id` varchar(14) NOT NULL\n,`tax_id` varchar(10) NOT NULL\n,`name` varchar(50) NOT NULL\n,`contact` varchar(50) NOT NULL\n,`street` varchar(50) NOT NULL\n,`city` varchar(50) NOT NULL\n,`country` varchar(50) NOT NULL\n,`phone` varchar(21) NOT NULL\n,`paymentterms` varchar(20) NOT NULL\n,`cdate` date NOT NULL\n,`ctime` time NOT NULL\n,`orderlines` text DEFAULT NULL,`inputter` varchar(50) NOT NULL,`input_date` datetime NOT NULL,`authorizer` varchar(50) NOT NULL,`auth_date` datetime NOT NULL,`record_status` char(4) NOT NULL,`current_no` int(11) NOT NULL,PRIMARY KEY (`id`),UNIQUE KEY `uniq_order_id` (`order_id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8;\n','SHOW TABLES WHERE tables_in_hndshkif LIKE \"dlorders%\";\n'),('inau','yes','DROP TABLE IF EXISTS `dlorders_is`;\n','CREATE TABLE `dlorders_is` (`id` int(11) unsigned NOT NULL AUTO_INCREMENT\n,`order_id` varchar(12) DEFAULT NULL\n,`batch_id` varchar(20) DEFAULT NULL\n,`customer_id` varchar(14) DEFAULT NULL\n,`tax_id` varchar(10) DEFAULT NULL\n,`name` varchar(50) DEFAULT NULL\n,`contact` varchar(50) DEFAULT NULL\n,`street` varchar(50) DEFAULT NULL\n,`city` varchar(50) DEFAULT NULL\n,`country` varchar(50) DEFAULT NULL\n,`phone` varchar(21) DEFAULT NULL\n,`paymentterms` varchar(20) DEFAULT NULL\n,`cdate` date DEFAULT NULL\n,`ctime` time DEFAULT NULL\n,`orderlines` text DEFAULT NULL,`inputter` varchar(50) DEFAULT NULL,`input_date` datetime DEFAULT NULL,`authorizer` varchar(50) DEFAULT NULL,`auth_date` datetime DEFAULT NULL,`record_status` char(4) DEFAULT NULL,`current_no` int(11) DEFAULT NULL,PRIMARY KEY (`id`),UNIQUE KEY `uniq_order_id` (`order_id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8;\n','SHOW TABLES WHERE tables_in_hndshkif LIKE \"dlorders_is%\";\n'),('hist','yes','DROP TABLE IF EXISTS `dlorders_hs`;\n','CREATE TABLE `dlorders_hs` (`id` int(11) unsigned NOT NULL\n,`order_id` varchar(12) NOT NULL\n,`batch_id` varchar(20) NOT NULL\n,`customer_id` varchar(14) NOT NULL\n,`tax_id` varchar(10) NOT NULL\n,`name` varchar(50) NOT NULL\n,`contact` varchar(50) NOT NULL\n,`street` varchar(50) NOT NULL\n,`city` varchar(50) NOT NULL\n,`country` varchar(50) NOT NULL\n,`phone` varchar(21) NOT NULL\n,`paymentterms` varchar(20) NOT NULL\n,`cdate` date NOT NULL\n,`ctime` time NOT NULL\n,`orderlines` text DEFAULT NULL,`inputter` varchar(50) NOT NULL,`input_date` datetime NOT NULL,`authorizer` varchar(50) NOT NULL,`auth_date` datetime NOT NULL,`record_status` char(4) NOT NULL,`current_no` int(11) NOT NULL,PRIMARY KEY (`id`,`current_no`)) ENGINE=InnoDB DEFAULT CHARSET=utf8;\n','SHOW TABLES WHERE tables_in_hndshkif LIKE \"dlorders_hs%\";\n');
/*!40000 ALTER TABLE `_adi_tabledefs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `_adi_updatedefs`
--

DROP TABLE IF EXISTS `_adi_updatedefs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `_adi_updatedefs` (
  `id` varchar(255) NOT NULL,
  `sql_code` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `_adi_updatedefs`
--

LOCK TABLES `_adi_updatedefs` WRITE;
/*!40000 ALTER TABLE `_adi_updatedefs` DISABLE KEYS */;
/*!40000 ALTER TABLE `_adi_updatedefs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `_sys_autoids`
--

DROP TABLE IF EXISTS `_sys_autoids`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `_sys_autoids` (
  `tb_inau` varchar(255) NOT NULL,
  `counter` int(11) unsigned NOT NULL DEFAULT '1',
  `lock` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`tb_inau`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `_sys_autoids`
--

LOCK TABLES `_sys_autoids` WRITE;
/*!40000 ALTER TABLE `_sys_autoids` DISABLE KEYS */;
INSERT INTO `_sys_autoids` VALUES ('messages_is',1001,0),('users_is',1003,0),('userroles_is',1001,0),('params_is',501,0),('menudefs_is',520,0),('recordlocks',1,0),('roles_is',1008,0),('countrys_is',271,0),('weekdays_is',11,0),('daytimes_is',96,0),('recurrences_is',22,0),('branches_is',1,0),('regions_is',623,0),('departments_is',1001,0),('enquirydefs_is',1001,0),('pdfs_is',1,0),('csvs_is',1,0),('fixedselections_is',1001,0),('tableresetconfigs_is',1001,0),('tableresetruns_is',1001,0),('sysconfigs_is',1,0),('customers_is',1001,0),('dlorders_is',1001,0),('dlors_is',1001,0),('products_is',1001,0),('inventorys_is',1001,0),('inventupdtypes_is',1001,0),('orders_is',1001,0),('orderdetails_is',1001,0),('inventchkouts_is',1001,0),('deliverynotes_is',1001,0),('tills_is',1001,0),('tilltransactions_is',1001,0),('payments_is',1001,0),('pdftemplates_is',1001,0),('reportdefs_is',1001,0),('batchinvoices_is',1042,0),('batchinvoicedetails_is',1425,0),('interfaceconfigurations_is',1001,0),('paymentcancels_is',1001,0),('chargeaccounts_is',1001,0),('ordercancels_is',1001,0),('orderopens_is',1001,0),('bicrs_is',1017,0);
/*!40000 ALTER TABLE `_sys_autoids` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `_sys_orderstatus`
--

DROP TABLE IF EXISTS `_sys_orderstatus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `_sys_orderstatus` (
  `id` int(2) NOT NULL,
  `order_status_id` varchar(20) NOT NULL,
  `progession_id` int(2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `_sys_orderstatus`
--

LOCK TABLES `_sys_orderstatus` WRITE;
/*!40000 ALTER TABLE `_sys_orderstatus` DISABLE KEYS */;
INSERT INTO `_sys_orderstatus` VALUES (1,'NEW',1),(2,'QUOTATION',2),(3,'ORDER.CONFIRMED',3),(4,'JOB.COMPLETED',4),(5,'INVOICE.ISSUED',5),(7,'INVOICE.PART.PAID',7),(8,'INVOICE.FULL.PAID',8),(9,'ZERO.CHARGE',9),(10,'QUOTATION.EXPIRED',10),(11,'REOPENED',11),(12,'ORDER.CANCELLED',12);
/*!40000 ALTER TABLE `_sys_orderstatus` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `_sys_pagesizes`
--

DROP TABLE IF EXISTS `_sys_pagesizes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `_sys_pagesizes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `format_id` varchar(50) NOT NULL,
  `dip_width` float(10,3) NOT NULL,
  `dip_height` float(10,3) NOT NULL,
  `inch_width` float(10,3) NOT NULL,
  `inch_height` float(10,3) NOT NULL,
  `mm_width` float(10,3) NOT NULL,
  `mm_height` float(10,3) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=191 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `_sys_pagesizes`
--

LOCK TABLES `_sys_pagesizes` WRITE;
/*!40000 ALTER TABLE `_sys_pagesizes` DISABLE KEYS */;
INSERT INTO `_sys_pagesizes` VALUES (1,'A0',2383.937,3370.394,33.110,46.811,841.000,1189.000),(2,'A1',1683.780,2383.937,23.386,33.110,594.000,841.000),(3,'A2',1190.551,1683.780,16.535,23.386,420.000,594.000),(4,'A3',841.890,1190.551,11.693,16.535,297.000,420.000),(5,'A4',595.276,841.890,8.268,11.693,210.000,297.000),(6,'A5',419.528,595.276,5.827,8.268,148.000,210.000),(7,'A6',297.638,419.528,4.134,5.827,105.000,148.000),(8,'A7',209.764,297.638,2.913,4.134,74.000,105.000),(9,'A8',147.402,209.764,2.047,2.913,52.000,74.000),(10,'A9',104.882,147.402,1.457,2.047,37.000,52.000),(11,'A10',73.701,104.882,1.024,1.457,26.000,37.000),(12,'A11',51.024,73.701,0.709,1.024,18.000,26.000),(13,'A12',36.850,51.024,0.512,0.709,13.000,18.000),(14,'B0',2834.646,4008.189,39.370,55.669,1000.000,1414.000),(15,'B1',2004.094,2834.646,27.835,39.370,707.000,1000.000),(16,'B2',1417.323,2004.094,19.685,27.835,500.000,707.000),(17,'B3',1000.630,1417.323,13.898,19.685,353.000,500.000),(18,'B4',708.661,1000.630,9.843,13.898,250.000,353.000),(19,'B5',498.898,708.661,6.929,9.843,176.000,250.000),(20,'B6',354.331,498.898,4.921,6.929,125.000,176.000),(21,'B7',249.449,354.331,3.465,4.921,88.000,125.000),(22,'B8',175.748,249.449,2.441,3.465,62.000,88.000),(23,'B9',124.724,175.748,1.732,2.441,44.000,62.000),(24,'B10',87.874,124.724,1.220,1.732,31.000,44.000),(25,'B11',62.362,87.874,0.866,1.220,22.000,31.000),(26,'B12',42.520,62.362,0.591,0.866,15.000,22.000),(27,'C0',2599.370,3676.535,36.102,51.063,917.000,1297.000),(28,'C1',1836.850,2599.370,25.512,36.102,648.000,917.000),(29,'C2',1298.268,1836.850,18.032,25.512,458.000,648.000),(30,'C3',918.425,1298.268,12.756,18.032,324.000,458.000),(31,'C4',649.134,918.425,9.016,12.756,229.000,324.000),(32,'C5',459.213,649.134,6.378,9.016,162.000,229.000),(33,'C6',323.150,459.213,4.488,6.378,114.000,162.000),(34,'C7',229.606,323.150,3.189,4.488,81.000,114.000),(35,'C8',161.575,229.606,2.244,3.189,57.000,81.000),(36,'C9',113.386,161.575,1.575,2.244,40.000,57.000),(37,'C10',79.370,113.386,1.102,1.575,28.000,40.000),(38,'C11',56.693,79.370,0.787,1.102,20.000,28.000),(39,'C12',39.685,56.693,0.551,0.787,14.000,20.000),(40,'C76',229.606,459.213,3.189,6.378,81.000,162.000),(41,'DL',311.811,623.622,4.331,8.661,110.000,220.000),(42,'E0',2491.654,3517.795,34.606,48.858,879.000,1241.000),(43,'E1',1757.480,2491.654,24.409,34.606,620.000,879.000),(44,'E2',1247.244,1757.480,17.323,24.409,440.000,620.000),(45,'E3',878.740,1247.244,12.205,17.323,310.000,440.000),(46,'E4',623.622,878.740,8.661,12.205,220.000,310.000),(47,'E5',439.370,623.622,6.102,8.661,155.000,220.000),(48,'E6',311.811,439.370,4.331,6.102,110.000,155.000),(49,'E7',221.102,311.811,3.071,4.331,78.000,110.000),(50,'E8',155.906,221.102,2.165,3.071,55.000,78.000),(51,'E9',110.551,155.906,1.535,2.165,39.000,55.000),(52,'E10',76.535,110.551,1.063,1.535,27.000,39.000),(53,'E11',53.858,76.535,0.748,1.063,19.000,27.000),(54,'E12',36.850,53.858,0.512,0.748,13.000,19.000),(55,'G0',2715.591,3838.110,37.717,53.307,958.000,1354.000),(56,'G1',1919.055,2715.591,26.654,37.717,677.000,958.000),(57,'G2',1357.795,1919.055,18.858,26.654,479.000,677.000),(58,'G3',958.110,1357.795,13.307,18.858,338.000,479.000),(59,'G4',677.480,958.110,9.409,13.307,239.000,338.000),(60,'G5',479.055,677.480,6.654,9.409,169.000,239.000),(61,'G6',337.323,479.055,4.685,6.654,119.000,169.000),(62,'G7',238.110,337.323,3.307,4.685,84.000,119.000),(63,'G8',167.244,238.110,2.323,3.307,59.000,84.000),(64,'G9',119.055,167.244,1.654,2.323,42.000,59.000),(65,'G10',82.205,119.055,1.142,1.654,29.000,42.000),(66,'G11',59.528,82.205,0.827,1.142,21.000,29.000),(67,'G12',39.685,59.528,0.551,0.827,14.000,21.000),(68,'RA0',2437.795,3458.268,33.858,48.032,860.000,1220.000),(69,'RA1',1729.134,2437.795,24.016,33.858,610.000,860.000),(70,'RA2',1218.898,1729.134,16.929,24.016,430.000,610.000),(71,'RA3',864.567,1218.898,12.008,16.929,305.000,430.000),(72,'RA4',609.449,864.567,8.465,12.008,215.000,305.000),(73,'SRA0',2551.181,3628.346,35.433,50.394,900.000,1280.000),(74,'SRA1',1814.173,2551.181,25.197,35.433,640.000,900.000),(75,'SRA2',1275.591,1814.173,17.717,25.197,450.000,640.000),(76,'SRA3',907.087,1275.591,12.598,17.717,320.000,450.000),(77,'SRA4',637.795,907.087,8.858,12.598,225.000,320.000),(78,'4A0',4767.874,6740.787,66.220,93.622,1682.000,2378.000),(79,'2A0',3370.394,4767.874,46.811,66.220,1189.000,1682.000),(80,'A2_EXTRA',1261.417,1754.646,17.520,24.370,445.000,619.000),(81,'A3+',932.598,1369.134,12.953,19.016,329.000,483.000),(82,'A3_EXTRA',912.756,1261.417,12.677,17.520,322.000,445.000),(83,'A3_SUPER',864.567,1440.000,12.008,20.000,305.000,508.000),(84,'SUPER_A3',864.567,1380.472,12.008,19.173,305.000,487.000),(85,'A4_EXTRA',666.142,912.756,9.252,12.677,235.000,322.000),(86,'A4_SUPER',649.134,912.756,9.016,12.677,229.000,322.000),(87,'SUPER_A4',643.465,1009.134,8.937,14.016,227.000,356.000),(88,'A4_LONG',595.276,986.457,8.268,13.701,210.000,348.000),(89,'F4',595.276,935.433,8.268,12.992,210.000,330.000),(90,'SO_B5_EXTRA',572.598,782.362,7.953,10.866,202.000,276.000),(91,'A5_EXTRA',490.394,666.142,6.811,9.252,173.000,235.000),(92,'ANSI_E',2448.000,3168.000,34.000,44.000,863.600,1117.600),(93,'ANSI_D',1584.000,2448.000,22.000,34.000,558.800,863.600),(94,'ANSI_C',1224.000,1584.000,17.000,22.000,431.800,558.800),(95,'ANSI_B',792.000,1224.000,11.000,17.000,279.400,431.800),(96,'ANSI_A',612.000,792.000,8.500,11.000,215.900,279.400),(97,'LEDGER',1224.000,792.000,17.000,11.000,431.800,279.400),(98,'TABLOID',792.000,1224.000,11.000,17.000,279.400,431.800),(99,'LETTER',612.000,792.000,8.500,11.000,215.900,279.400),(100,'LEGAL',612.000,1008.000,8.500,14.000,215.900,355.600),(101,'GLETTER',576.000,756.000,8.000,10.500,203.200,266.700),(102,'JLEGAL',576.000,360.000,8.000,5.000,203.200,127.000),(103,'QUADDEMY',2520.000,3240.000,35.000,45.000,889.000,1143.000),(104,'SUPER_B',936.000,1368.000,13.000,19.000,330.200,482.600),(105,'QUARTO',648.000,792.000,9.000,11.000,228.600,279.400),(106,'FOLIO',612.000,936.000,8.500,13.000,215.900,330.200),(107,'EXECUTIVE',522.000,756.000,7.250,10.500,184.150,266.700),(108,'MEMO',396.000,612.000,5.500,8.500,139.700,215.900),(109,'FOOLSCAP',595.440,936.000,8.270,13.000,210.058,330.200),(110,'COMPACT',306.000,486.000,4.250,6.750,107.950,171.450),(111,'ORGANIZERJ',198.000,360.000,2.750,5.000,69.850,127.000),(112,'ARCH_E',2592.000,3456.000,36.000,48.000,914.400,1219.200),(113,'ARCH_E1',2160.000,3024.000,30.000,42.000,762.000,1066.800),(114,'ARCH_D',1728.000,2592.000,24.000,36.000,609.600,914.400),(115,'ARCH_C',1296.000,1728.000,18.000,24.000,457.200,609.600),(116,'ARCH_B',864.000,1296.000,12.000,18.000,304.800,457.200),(117,'ARCH_A',648.000,864.000,9.000,12.000,228.600,304.800),(118,'ANNENV_A2',314.640,414.000,4.370,5.750,110.998,146.050),(119,'ANNENV_A6',342.000,468.000,4.750,6.500,120.650,165.100),(120,'ANNENV_A7',378.000,522.000,5.250,7.250,133.350,184.150),(121,'ANNENV_A8',396.000,584.640,5.500,8.120,139.700,206.248),(122,'ANNENV_A10',450.000,692.640,6.250,9.620,158.750,244.348),(123,'ANNENV_SLIM',278.640,638.640,3.870,8.870,98.298,225.298),(124,'COMMENV_N6_1/4',252.000,432.000,3.500,6.000,88.900,152.400),(125,'COMMENV_N6_3/4',260.640,468.000,3.620,6.500,91.948,165.100),(126,'COMMENV_N8',278.640,540.000,3.870,7.500,98.298,190.500),(127,'COMMENV_N9',278.640,638.640,3.870,8.870,98.298,225.298),(128,'COMMENV_N10',296.640,684.000,4.120,9.500,104.648,241.300),(129,'COMMENV_N11',324.000,746.640,4.500,10.370,114.300,263.398),(130,'COMMENV_N12',342.000,792.000,4.750,11.000,120.650,279.400),(131,'COMMENV_N14',360.000,828.000,5.000,11.500,127.000,292.100),(132,'CATENV_N1',432.000,648.000,6.000,9.000,152.400,228.600),(133,'CATENV_N1_3/4',468.000,684.000,6.500,9.500,165.100,241.300),(134,'CATENV_N2',468.000,720.000,6.500,10.000,165.100,254.000),(135,'CATENV_N3',504.000,720.000,7.000,10.000,177.800,254.000),(136,'CATENV_N6',540.000,756.000,7.500,10.500,190.500,266.700),(137,'CATENV_N7',576.000,792.000,8.000,11.000,203.200,279.400),(138,'CATENV_N8',594.000,810.000,8.250,11.250,209.550,285.750),(139,'CATENV_N9_1/2',612.000,756.000,8.500,10.500,215.900,266.700),(140,'CATENV_N9_3/4',630.000,810.000,8.750,11.250,222.250,285.750),(141,'CATENV_N10_1/2',648.000,864.000,9.000,12.000,228.600,304.800),(142,'CATENV_N12_1/2',684.000,900.000,9.500,12.500,241.300,317.500),(143,'CATENV_N13_1/2',720.000,936.000,10.000,13.000,254.000,330.200),(144,'CATENV_N14_1/4',810.000,882.000,11.250,12.250,285.750,311.150),(145,'CATENV_N14_1/2',828.000,1044.000,11.500,14.500,292.100,368.300),(146,'PA0',2381.102,3174.803,33.071,44.094,840.000,1120.000),(147,'PA1',1587.402,2381.102,22.047,33.071,560.000,840.000),(148,'PA2',1190.551,1587.402,16.535,22.047,420.000,560.000),(149,'PA3',793.701,1190.551,11.024,16.535,280.000,420.000),(150,'PA4',595.276,793.701,8.268,11.024,210.000,280.000),(151,'PA5',396.850,595.276,5.512,8.268,140.000,210.000),(152,'PA6',297.638,396.850,4.134,5.512,105.000,140.000),(153,'PA7',198.425,297.638,2.756,4.134,70.000,105.000),(154,'PA8',147.402,198.425,2.047,2.756,52.000,70.000),(155,'PA9',99.213,147.402,1.378,2.047,35.000,52.000),(156,'PA1073.701',99.213,0.000,1.378,0.000,35.000,0.000),(157,'PASSPORT_PHOTO',99.213,127.559,1.378,1.772,35.000,45.000),(158,'E',233.858,340.157,3.248,4.724,82.500,120.000),(159,'3R',252.283,360.000,3.504,5.000,89.000,127.000),(160,'4R',289.134,430.866,4.016,5.984,102.000,152.000),(161,'4D',340.157,430.866,4.724,5.984,120.000,152.000),(162,'5R',360.000,504.567,5.000,7.008,127.000,178.000),(163,'6R',430.866,575.433,5.984,7.992,152.000,203.000),(164,'8R',575.433,720.000,7.992,10.000,203.000,254.000),(165,'S8R',575.433,864.567,7.992,12.008,203.000,305.000),(166,'10R',720.000,864.567,10.000,12.008,254.000,305.000),(167,'S10R720.000',1080.000,0.000,15.000,0.000,381.000,0.000),(168,'11R',790.866,1009.134,10.984,14.016,279.000,356.000),(169,'S11R',790.866,1224.567,10.984,17.008,279.000,432.000),(170,'12R',864.567,1080.000,12.008,15.000,305.000,381.000),(171,'S12R',864.567,1292.598,12.008,17.953,305.000,456.000),(172,'NEWSPAPER_BROADSHEET',2125.984,1700.787,29.528,23.622,750.000,600.000),(173,'NEWSPAPER_BERLINER',1332.283,892.913,18.504,12.402,470.000,315.000),(174,'NEWSPAPER_COMPACT',1218.898,793.701,16.929,11.024,430.000,280.000),(175,'BUSINESS_CARD_ISO7810',153.014,242.646,2.125,3.370,53.980,85.600),(176,'BUSINESS_CARD_ISO216',147.402,209.764,2.047,2.913,52.000,74.000),(177,'BUSINESS_CARD_ES',155.906,240.945,2.165,3.346,55.000,85.000),(178,'BUSINESS_CARD_US',144.567,252.283,2.008,3.504,51.000,89.000),(179,'BUSINESS_CARD_JP',155.906,257.953,2.165,3.583,55.000,91.000),(180,'BUSINESS_CARD_HK',153.071,255.118,2.126,3.543,54.000,90.000),(181,'BUSINESS_CARD_SE',155.906,255.118,2.165,3.543,55.000,90.000),(182,'BUSINESS_CARD_IL',141.732,255.118,1.968,3.543,50.000,90.000),(183,'4SHEET',2880.000,4320.000,40.000,60.000,1016.000,1524.000),(184,'6SHEET',3401.575,5102.362,47.244,70.866,1200.000,1800.000),(185,'12SHEET',8640.000,4320.000,120.000,60.000,3048.000,1524.000),(186,'16SHEET',5760.000,8640.000,80.000,120.000,2032.000,3048.000),(187,'32SHEET',11520.000,8640.000,160.000,120.000,4064.000,3048.000),(188,'48SHEET',17280.000,8640.000,240.000,120.000,6096.000,3048.000),(189,'64SHEET',23040.000,8640.000,320.000,120.000,8128.000,3048.000),(190,'96SHEET',34560.000,8640.000,480.000,120.000,12192.000,3048.000);
/*!40000 ALTER TABLE `_sys_pagesizes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `_sys_rrcs`
--

DROP TABLE IF EXISTS `_sys_rrcs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `_sys_rrcs` (
  `order_id` varchar(16) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `_sys_rrcs`
--

LOCK TABLES `_sys_rrcs` WRITE;
/*!40000 ALTER TABLE `_sys_rrcs` DISABLE KEYS */;
/*!40000 ALTER TABLE `_sys_rrcs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `batchinvoicedetails`
--

DROP TABLE IF EXISTS `batchinvoicedetails`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `batchinvoicedetails` (
  `id` int(11) unsigned NOT NULL,
  `batch_id` varchar(50) NOT NULL,
  `invoice_id` int(11) unsigned NOT NULL,
  `alt_invoice_id` int(11) unsigned NOT NULL,
  `order_id` varchar(16) NOT NULL,
  `order_date` date NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `order_details` longtext NOT NULL,
  `extended_total` float(16,2) NOT NULL,
  `tax_total` float(16,2) NOT NULL,
  `order_total` float(16,2) NOT NULL,
  `payment_total` float(16,2) NOT NULL,
  `balance` float(16,2) NOT NULL,
  `payment_type` varchar(255) NOT NULL,
  `inputter` varchar(50) NOT NULL,
  `input_date` datetime NOT NULL,
  `authorizer` varchar(50) NOT NULL,
  `auth_date` datetime NOT NULL,
  `record_status` char(4) NOT NULL,
  `current_no` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `batchinvoicedetails`
--

LOCK TABLES `batchinvoicedetails` WRITE;
/*!40000 ALTER TABLE `batchinvoicedetails` DISABLE KEYS */;
/*!40000 ALTER TABLE `batchinvoicedetails` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `batchinvoicedetails_hs`
--

DROP TABLE IF EXISTS `batchinvoicedetails_hs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `batchinvoicedetails_hs` (
  `id` int(11) unsigned NOT NULL,
  `batch_id` varchar(50) NOT NULL,
  `invoice_id` int(11) unsigned NOT NULL,
  `alt_invoice_id` int(11) unsigned NOT NULL,
  `order_id` varchar(16) NOT NULL,
  `order_date` date NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `order_details` longtext NOT NULL,
  `extended_total` float(16,2) NOT NULL,
  `tax_total` float(16,2) NOT NULL,
  `order_total` float(16,2) NOT NULL,
  `payment_total` float(16,2) NOT NULL,
  `balance` float(16,2) NOT NULL,
  `payment_type` varchar(255) NOT NULL,
  `inputter` varchar(50) NOT NULL,
  `input_date` datetime NOT NULL,
  `authorizer` varchar(50) NOT NULL,
  `auth_date` datetime NOT NULL,
  `record_status` char(4) NOT NULL,
  `current_no` int(11) NOT NULL,
  PRIMARY KEY (`id`,`current_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `batchinvoicedetails_hs`
--

LOCK TABLES `batchinvoicedetails_hs` WRITE;
/*!40000 ALTER TABLE `batchinvoicedetails_hs` DISABLE KEYS */;
/*!40000 ALTER TABLE `batchinvoicedetails_hs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `batchinvoicedetails_is`
--

DROP TABLE IF EXISTS `batchinvoicedetails_is`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `batchinvoicedetails_is` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `batch_id` varchar(50) DEFAULT NULL,
  `invoice_id` int(11) unsigned DEFAULT NULL,
  `alt_invoice_id` int(11) unsigned DEFAULT NULL,
  `order_id` varchar(16) DEFAULT NULL,
  `order_date` date DEFAULT NULL,
  `first_name` varchar(50) DEFAULT NULL,
  `last_name` varchar(50) DEFAULT NULL,
  `order_details` longtext,
  `extended_total` float(16,2) DEFAULT NULL,
  `tax_total` float(16,2) DEFAULT NULL,
  `order_total` float(16,2) DEFAULT NULL,
  `payment_total` float(16,2) DEFAULT NULL,
  `balance` float(16,2) DEFAULT NULL,
  `payment_type` varchar(255) DEFAULT NULL,
  `inputter` varchar(50) DEFAULT NULL,
  `input_date` datetime DEFAULT NULL,
  `authorizer` varchar(50) DEFAULT NULL,
  `auth_date` datetime DEFAULT NULL,
  `record_status` char(4) DEFAULT NULL,
  `current_no` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `batchinvoicedetails_is`
--

LOCK TABLES `batchinvoicedetails_is` WRITE;
/*!40000 ALTER TABLE `batchinvoicedetails_is` DISABLE KEYS */;
/*!40000 ALTER TABLE `batchinvoicedetails_is` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `batchinvoices`
--

DROP TABLE IF EXISTS `batchinvoices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `batchinvoices` (
  `id` int(11) unsigned NOT NULL,
  `batch_id` varchar(50) NOT NULL,
  `batch_date` date NOT NULL,
  `batch_description` varchar(255) NOT NULL,
  `batch_type` varchar(50) NOT NULL,
  `batch_details` longtext NOT NULL,
  `comments` text NOT NULL,
  `inputter` varchar(50) NOT NULL,
  `input_date` datetime NOT NULL,
  `authorizer` varchar(50) NOT NULL,
  `auth_date` datetime NOT NULL,
  `record_status` char(4) NOT NULL,
  `current_no` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_batch_id` (`batch_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `batchinvoices`
--

LOCK TABLES `batchinvoices` WRITE;
/*!40000 ALTER TABLE `batchinvoices` DISABLE KEYS */;
/*!40000 ALTER TABLE `batchinvoices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `batchinvoices_hs`
--

DROP TABLE IF EXISTS `batchinvoices_hs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `batchinvoices_hs` (
  `id` int(11) unsigned NOT NULL,
  `batch_id` varchar(50) NOT NULL,
  `batch_date` date NOT NULL,
  `batch_description` varchar(255) NOT NULL,
  `batch_type` varchar(50) NOT NULL,
  `batch_details` longtext NOT NULL,
  `comments` text NOT NULL,
  `inputter` varchar(50) NOT NULL,
  `input_date` datetime NOT NULL,
  `authorizer` varchar(50) NOT NULL,
  `auth_date` datetime NOT NULL,
  `record_status` char(4) NOT NULL,
  `current_no` int(11) NOT NULL,
  PRIMARY KEY (`id`,`current_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `batchinvoices_hs`
--

LOCK TABLES `batchinvoices_hs` WRITE;
/*!40000 ALTER TABLE `batchinvoices_hs` DISABLE KEYS */;
/*!40000 ALTER TABLE `batchinvoices_hs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `batchinvoices_is`
--

DROP TABLE IF EXISTS `batchinvoices_is`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `batchinvoices_is` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `batch_id` varchar(50) DEFAULT NULL,
  `batch_date` date DEFAULT '0000-00-00',
  `batch_description` varchar(255) DEFAULT NULL,
  `batch_type` varchar(50) DEFAULT NULL,
  `batch_details` longtext,
  `comments` text,
  `inputter` varchar(50) DEFAULT NULL,
  `input_date` datetime DEFAULT NULL,
  `authorizer` varchar(50) DEFAULT NULL,
  `auth_date` datetime DEFAULT NULL,
  `record_status` char(4) DEFAULT NULL,
  `current_no` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_batch_id` (`batch_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `batchinvoices_is`
--

LOCK TABLES `batchinvoices_is` WRITE;
/*!40000 ALTER TABLE `batchinvoices_is` DISABLE KEYS */;
/*!40000 ALTER TABLE `batchinvoices_is` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bicrs`
--

DROP TABLE IF EXISTS `bicrs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bicrs` (
  `id` int(11) unsigned NOT NULL,
  `batchrequest_id` varchar(40) NOT NULL,
  `requesttype` varchar(20) NOT NULL,
  `cc_id` varchar(8) DEFAULT NULL,
  `description` varchar(255) NOT NULL,
  `start_date` date NOT NULL DEFAULT '0000-00-00',
  `end_date` date NOT NULL DEFAULT '0000-00-00',
  `run` enum('N','Y') NOT NULL DEFAULT 'N',
  `comments` text,
  `inputter` varchar(50) NOT NULL,
  `input_date` datetime NOT NULL,
  `authorizer` varchar(50) NOT NULL,
  `auth_date` datetime NOT NULL,
  `record_status` char(4) NOT NULL,
  `current_no` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_batchrequest_id` (`batchrequest_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bicrs`
--

LOCK TABLES `bicrs` WRITE;
/*!40000 ALTER TABLE `bicrs` DISABLE KEYS */;
INSERT INTO `bicrs` VALUES (1006,'BICR.ECOC0001.2013-01-01.2013-08-31','PERCC-ONE','ECOC0001','ECOC0001 for period 2013-01-01 to 2013-08-31','2013-01-01','2013-08-31','N','','ADMIN','2013-08-11 07:38:53','ADMIN','2013-08-11 07:38:53','LIVE',1),(1009,'BICR.KALC0001.2013-01-01.2013-01-31','PERCC-ONE','KALC0001','KALC0001 for period 2013-01-01 to 2013-01-31','2013-01-01','2013-01-31','Y','','ADMIN','2013-08-13 04:23:21','ADMIN','2013-08-13 04:23:21','LIVE',38),(1010,'BICR.ECOC0001.2013-01-01.2013-02-28','PERCC-ONE','ECOC0001','ECOC0001 for period 2013-01-01 to 2013-02-28','2013-01-01','2013-02-28','Y','','ADMIN','2013-08-13 04:32:03','ADMIN','2013-08-13 04:32:03','LIVE',2),(1012,'BICR.ECOC0001.2013-02-01.2013-02-28','PERCC-ONE','ECOC0001','ECOC0001 for period 2013-02-01 to 2013-02-28','2013-02-01','2013-02-28','N','','ADMIN','2013-08-13 05:25:12','ADMIN','2013-08-13 05:25:12','LIVE',6),(1013,'BICR.ECOC0001.2013-03-01.2013-03-31','EOMCC-ONE','ECOC0001','ECOC0001 for month 2013-03-01 to 2013-03-31','2013-03-01','2013-03-31','N','','ADMIN','2013-08-13 05:29:45','ADMIN','2013-08-13 05:29:45','LIVE',1),(1015,'BICR.EOMCC-ALL.2013-01-01.2013-01-31','EOMCC-ALL','','EOMCC-ALL for month 2013-01-01 to 2013-01-31','2013-01-01','2013-01-31','N','','ADMIN','2013-08-13 06:28:55','ADMIN','2013-08-13 06:28:55','LIVE',1),(1016,'BICR.ECOC0001.2013-04-01.2013-04-15','PERCC-ONE','ECOC0001','ECOC0001 for period 2013-04-01 to 2013-04-15','2013-04-01','2013-04-15','N','','ADMIN','2013-08-13 06:55:01','ADMIN','2013-08-13 06:55:01','LIVE',1),(1017,'BICR.ECOC0001.2013-04-01.2013-04-30','EOMCC-ONE','ECOC0001','ECOC0001 for month 2013-04-01 to 2013-04-30','2013-04-01','2013-04-30','N','','ADMIN','2013-08-13 06:57:55','ADMIN','2013-08-13 06:57:55','LIVE',1);
/*!40000 ALTER TABLE `bicrs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bicrs_hs`
--

DROP TABLE IF EXISTS `bicrs_hs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bicrs_hs` (
  `id` int(11) unsigned NOT NULL,
  `batchrequest_id` varchar(40) NOT NULL,
  `requesttype` varchar(20) NOT NULL,
  `cc_id` varchar(8) DEFAULT NULL,
  `description` varchar(255) NOT NULL,
  `start_date` date NOT NULL DEFAULT '0000-00-00',
  `end_date` date NOT NULL DEFAULT '0000-00-00',
  `run` enum('N','Y') NOT NULL DEFAULT 'N',
  `comments` text,
  `inputter` varchar(50) NOT NULL,
  `input_date` datetime NOT NULL,
  `authorizer` varchar(50) NOT NULL,
  `auth_date` datetime NOT NULL,
  `record_status` char(4) NOT NULL,
  `current_no` int(11) NOT NULL,
  PRIMARY KEY (`id`,`current_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bicrs_hs`
--

LOCK TABLES `bicrs_hs` WRITE;
/*!40000 ALTER TABLE `bicrs_hs` DISABLE KEYS */;
/*!40000 ALTER TABLE `bicrs_hs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bicrs_is`
--

DROP TABLE IF EXISTS `bicrs_is`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bicrs_is` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `batchrequest_id` varchar(40) DEFAULT NULL,
  `requesttype` varchar(20) DEFAULT NULL,
  `cc_id` varchar(8) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `start_date` date DEFAULT '0000-00-00',
  `end_date` date DEFAULT '0000-00-00',
  `run` enum('N','Y') DEFAULT 'N',
  `comments` text,
  `inputter` varchar(50) DEFAULT NULL,
  `input_date` datetime DEFAULT NULL,
  `authorizer` varchar(50) DEFAULT NULL,
  `auth_date` datetime DEFAULT NULL,
  `record_status` char(4) DEFAULT NULL,
  `current_no` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_batchrequest_id` (`batchrequest_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bicrs_is`
--

LOCK TABLES `bicrs_is` WRITE;
/*!40000 ALTER TABLE `bicrs_is` DISABLE KEYS */;
/*!40000 ALTER TABLE `bicrs_is` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `branches`
--

DROP TABLE IF EXISTS `branches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `branches` (
  `id` int(11) unsigned NOT NULL,
  `branch_id` varchar(50) NOT NULL,
  `description` varchar(255) NOT NULL,
  `location` varchar(255) NOT NULL,
  `region_id` int(11) unsigned NOT NULL,
  `active` enum('Y','N') NOT NULL,
  `inputter` varchar(50) NOT NULL,
  `input_date` datetime NOT NULL,
  `authorizer` varchar(50) NOT NULL,
  `auth_date` datetime NOT NULL,
  `record_status` char(4) NOT NULL,
  `current_no` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_branch_id` (`branch_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `branches`
--

LOCK TABLES `branches` WRITE;
/*!40000 ALTER TABLE `branches` DISABLE KEYS */;
INSERT INTO `branches` VALUES (1,'HEAD.OFFICE','GPSRescue Ltd, Head Office','Maloney Street',503,'Y','IMPLEMENTATION','2010-08-28 00:00:00','ADMIN','2010-08-28 00:00:00','LIVE',1);
/*!40000 ALTER TABLE `branches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `branches_hs`
--

DROP TABLE IF EXISTS `branches_hs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `branches_hs` (
  `id` int(11) unsigned NOT NULL,
  `branch_id` varchar(50) NOT NULL,
  `description` varchar(255) NOT NULL,
  `location` varchar(255) NOT NULL,
  `region_id` int(11) unsigned NOT NULL,
  `active` enum('Y','N') NOT NULL,
  `inputter` varchar(50) NOT NULL,
  `input_date` datetime NOT NULL,
  `authorizer` varchar(50) NOT NULL,
  `auth_date` datetime NOT NULL,
  `record_status` char(4) NOT NULL,
  `current_no` int(11) NOT NULL,
  PRIMARY KEY (`id`,`current_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `branches_hs`
--

LOCK TABLES `branches_hs` WRITE;
/*!40000 ALTER TABLE `branches_hs` DISABLE KEYS */;
/*!40000 ALTER TABLE `branches_hs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `branches_is`
--

DROP TABLE IF EXISTS `branches_is`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `branches_is` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `branch_id` varchar(50) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `region_id` int(11) unsigned DEFAULT NULL,
  `active` enum('Y','N') DEFAULT NULL,
  `inputter` varchar(50) DEFAULT NULL,
  `input_date` datetime DEFAULT NULL,
  `authorizer` varchar(50) DEFAULT NULL,
  `auth_date` datetime DEFAULT NULL,
  `record_status` char(4) DEFAULT NULL,
  `current_no` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_branch_id` (`branch_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `branches_is`
--

LOCK TABLES `branches_is` WRITE;
/*!40000 ALTER TABLE `branches_is` DISABLE KEYS */;
/*!40000 ALTER TABLE `branches_is` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chargeaccounts`
--

DROP TABLE IF EXISTS `chargeaccounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `chargeaccounts` (
  `id` int(11) unsigned NOT NULL,
  `customer_id` varchar(8) NOT NULL,
  `activation_date` date NOT NULL DEFAULT '1901-12-14',
  `status_change_date` date NOT NULL DEFAULT '1901-12-14',
  `active` enum('Y','N') NOT NULL DEFAULT 'N',
  `special_instructions` text,
  `comments` text,
  `inputter` varchar(50) NOT NULL,
  `input_date` datetime NOT NULL,
  `authorizer` varchar(50) NOT NULL,
  `auth_date` datetime NOT NULL,
  `record_status` char(4) NOT NULL,
  `current_no` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_customer_id` (`customer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chargeaccounts`
--

LOCK TABLES `chargeaccounts` WRITE;
/*!40000 ALTER TABLE `chargeaccounts` DISABLE KEYS */;
/*!40000 ALTER TABLE `chargeaccounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chargeaccounts_hs`
--

DROP TABLE IF EXISTS `chargeaccounts_hs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `chargeaccounts_hs` (
  `id` int(11) unsigned NOT NULL,
  `customer_id` varchar(8) NOT NULL,
  `activation_date` date NOT NULL DEFAULT '1901-12-14',
  `status_change_date` date NOT NULL DEFAULT '1901-12-14',
  `active` enum('Y','N') NOT NULL DEFAULT 'N',
  `special_instructions` text,
  `comments` text,
  `inputter` varchar(50) NOT NULL,
  `input_date` datetime NOT NULL,
  `authorizer` varchar(50) NOT NULL,
  `auth_date` datetime NOT NULL,
  `record_status` char(4) NOT NULL,
  `current_no` int(11) NOT NULL,
  PRIMARY KEY (`id`,`current_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chargeaccounts_hs`
--

LOCK TABLES `chargeaccounts_hs` WRITE;
/*!40000 ALTER TABLE `chargeaccounts_hs` DISABLE KEYS */;
/*!40000 ALTER TABLE `chargeaccounts_hs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chargeaccounts_is`
--

DROP TABLE IF EXISTS `chargeaccounts_is`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `chargeaccounts_is` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `customer_id` varchar(8) DEFAULT NULL,
  `activation_date` date DEFAULT '1901-12-14',
  `status_change_date` date DEFAULT '1901-12-14',
  `active` enum('Y','N') DEFAULT 'N',
  `special_instructions` text,
  `comments` text,
  `inputter` varchar(50) DEFAULT NULL,
  `input_date` datetime DEFAULT NULL,
  `authorizer` varchar(50) DEFAULT NULL,
  `auth_date` datetime DEFAULT NULL,
  `record_status` char(4) DEFAULT NULL,
  `current_no` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_customer_id` (`customer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chargeaccounts_is`
--

LOCK TABLES `chargeaccounts_is` WRITE;
/*!40000 ALTER TABLE `chargeaccounts_is` DISABLE KEYS */;
/*!40000 ALTER TABLE `chargeaccounts_is` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `countrys`
--

DROP TABLE IF EXISTS `countrys`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `countrys` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `country_id` varchar(3) NOT NULL,
  `common_name` varchar(255) DEFAULT NULL,
  `formal_name` varchar(255) DEFAULT NULL,
  `capital` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `sub_type` varchar(255) DEFAULT NULL,
  `sovereignty` varchar(255) DEFAULT NULL,
  `currency_code` varchar(3) DEFAULT NULL,
  `currency_name` varchar(255) DEFAULT NULL,
  `telephone_code` int(4) DEFAULT NULL,
  `iana_country_code` varchar(3) DEFAULT NULL,
  `inputter` varchar(50) DEFAULT NULL,
  `input_date` datetime DEFAULT NULL,
  `authorizer` varchar(50) DEFAULT NULL,
  `auth_date` datetime DEFAULT NULL,
  `record_status` varchar(4) DEFAULT NULL,
  `current_no` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=272 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `countrys`
--

LOCK TABLES `countrys` WRITE;
/*!40000 ALTER TABLE `countrys` DISABLE KEYS */;
INSERT INTO `countrys` VALUES (1,'AC','Ascension',NULL,'Georgetown','Proto Dependency','Dependency of Saint Helena','United Kingdom','SHP','Pound',247,'.ac','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(2,'AD','Andorra','Principality of Andorra','Andorra la Vella','Independent State',NULL,NULL,'EUR','Euro',376,'.ad','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(3,'AE','United Arab Emirates','United Arab Emirates','Abu Dhabi','Independent State',NULL,NULL,'AED','Dirham',971,'.ae','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(4,'AF','Afghanistan','Islamic State of Afghanistan','Kabul','Independent State',NULL,NULL,'AFN','Afghani',93,'.af','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(5,'AG','Antigua and Barbuda',NULL,'Saint John\'s','Independent State',NULL,NULL,'XCD','Dollar',268,'.ag','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(6,'AI','Anguilla',NULL,'The Valley','Dependency','Overseas Territory','United Kingdom','XCD','Dollar',264,'.ai','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(7,'AL','Albania','Republic of Albania','Tirana','Independent State',NULL,NULL,'ALL','Lek',355,'.al','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(8,'AM','Armenia','Republic of Armenia','Yerevan','Independent State',NULL,NULL,'AMD','Dram',374,'.am','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(9,'AN','Netherlands Antilles',NULL,'Willemstad','Proto Dependency',NULL,'Netherlands','ANG','Guilder',599,'.an','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(10,'AO','Angola','Republic of Angola','Luanda','Independent State',NULL,NULL,'AOA','Kwanza',244,'.ao','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(11,'AQ','Antarctica',NULL,NULL,'Disputed Territory',NULL,'Undetermined',NULL,NULL,NULL,'.aq','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(12,'AQ1','Australian Antarctic Territory',NULL,NULL,'Antarctic Territory','External Territory','Australia',NULL,NULL,NULL,'.aq','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(13,'AQ2','Ross Dependency',NULL,NULL,'Antarctic Territory','Territory','New Zealand',NULL,NULL,NULL,'.aq','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(14,'AQ3','Peter I Island',NULL,NULL,'Antarctic Territory','Territory','Norway',NULL,NULL,NULL,'.aq','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(15,'AQ4','Queen Maud Land',NULL,NULL,'Antarctic Territory','Territory','Norway',NULL,NULL,NULL,'.aq','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(16,'AQ5','British Antarctic Territory',NULL,NULL,'Antarctic Territory','Overseas Territory','United Kingdom',NULL,NULL,NULL,'.aq','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(17,'AR','Argentina','Argentine Republic','Buenos Aires','Independent State',NULL,NULL,'ARS','Peso',54,'.ar','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(18,'AS','American Samoa','Territory of American Samoa','Pago Pago','Dependency','Territory','United States','USD','Dollar',684,'.as','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(19,'AT','Austria','Republic of Austria','Vienna','Independent State',NULL,NULL,'EUR','Euro',43,'.at','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(20,'AU','Australia','Commonwealth of Australia','Canberra','Independent State',NULL,NULL,'AUD','Dollar',61,'.au','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(21,'AU1','Ashmore and Cartier Islands','Territory of Ashmore and Cartier Islands',NULL,'Dependency','External Territory','Australia',NULL,NULL,NULL,'.au','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(22,'AU2','Coral Sea Islands','Coral Sea Islands Territory',NULL,'Dependency','External Territory','Australia',NULL,NULL,NULL,'.au','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(23,'AW','Aruba',NULL,'Oranjestad','Proto Dependency',NULL,'Netherlands','AWG','Guilder',297,'.aw','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(24,'AX','Aland',NULL,'Mariehamn','Proto Dependency',NULL,'Finland','EUR','Euro',340,'.ax','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(25,'AZ','Azerbaijan','Republic of Azerbaijan','Baku','Independent State',NULL,NULL,'AZN','Manat',994,'.az','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(26,'AZ1','Nagorno-Karabakh','Nagorno-Karabakh Republic','Stepanakert','Proto Independent State',NULL,NULL,'AMD','Dram',277,'.az','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(27,'BA','Bosnia and Herzegovina',NULL,'Sarajevo','Independent State',NULL,NULL,'BAM','Marka',387,'.ba','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(28,'BB','Barbados',NULL,'Bridgetown','Independent State',NULL,NULL,'BBD','Dollar',246,'.bb','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(29,'BD','Bangladesh','People\'s Republic of Bangladesh','Dhaka','Independent State',NULL,NULL,'BDT','Taka',880,'.bd','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(30,'BE','Belgium','Kingdom of Belgium','Brussels','Independent State',NULL,NULL,'EUR','Euro',32,'.be','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(31,'BF','Burkina Faso',NULL,'Ouagadougou','Independent State',NULL,NULL,'XOF','Franc',226,'.bf','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(32,'BG','Bulgaria','Republic of Bulgaria','Sofia','Independent State',NULL,NULL,'BGN','Lev',359,'.bg','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(33,'BH','Bahrain','Kingdom of Bahrain','Manama','Independent State',NULL,NULL,'BHD','Dinar',973,'.bh','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(34,'BI','Burundi','Republic of Burundi','Bujumbura','Independent State',NULL,NULL,'BIF','Franc',257,'.bi','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(35,'BJ','Benin','Republic of Benin','Porto-Novo','Independent State',NULL,NULL,'XOF','Franc',229,'.bj','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(36,'BM','Bermuda',NULL,'Hamilton','Dependency','Overseas Territory','United Kingdom','BMD','Dollar',441,'.bm','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(37,'BN','Brunei','Negara Brunei Darussalam','Bandar Seri Begawan','Independent State',NULL,NULL,'BND','Dollar',673,'.bn','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(38,'BO','Bolivia','Republic of Bolivia','La Paz (administrative/legislative) and Sucre (judical)','Independent State',NULL,NULL,'BOB','Boliviano',591,'.bo','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(39,'BR','Brazil','Federative Republic of Brazil','Brasilia','Independent State',NULL,NULL,'BRL','Real',55,'.br','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(40,'BS','Bahamas',' The','Commonwealth of The Bahamas','Nassau','Independent State',NULL,NULL,'BSD',NULL,NULL,'IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(41,'BT','Bhutan','Kingdom of Bhutan','Thimphu','Independent State',NULL,NULL,'BTN','Ngultrum',975,'.bt','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(42,'BV','Bouvet Island',NULL,NULL,'Dependency','Territory','Norway',NULL,NULL,NULL,'.bv','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(43,'BW','Botswana','Republic of Botswana','Gaborone','Independent State',NULL,NULL,'BWP','Pula',267,'.bw','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(44,'BY','Belarus','Republic of Belarus','Minsk','Independent State',NULL,NULL,'BYR','Ruble',375,'.by','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(45,'BZ','Belize',NULL,'Belmopan','Independent State',NULL,NULL,'BZD','Dollar',501,'.bz','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(46,'CA','Canada',NULL,'Ottawa','Independent State',NULL,NULL,'CAD','Dollar',1,'.ca','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(47,'CC','Cocos (Keeling) Islands','Territory of Cocos (Keeling) Islands','West Island','Dependency','External Territory','Australia','AUD','Dollar',61,'.cc','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(48,'CD','Congo',' Democratic Republic of the (Congo â€“ Kinshasa)','Democratic Republic of the Congo','Kinshasa','Independent State',NULL,NULL,'CDF',NULL,NULL,'IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(49,'CF','Central African Republic',NULL,'Bangui','Independent State',NULL,NULL,'XAF','Franc',236,'.cf','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(50,'CG','Congo',' Republic of the (Congo â€“ Brazzaville)','Republic of the Congo','Brazzaville','Independent State',NULL,NULL,'XAF',NULL,NULL,'IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(51,'CH','Switzerland','Swiss Confederation','Bern','Independent State',NULL,NULL,'CHF','Franc',41,'.ch','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(52,'CI','Cote d\'Ivoire (Ivory Coast)','Republic of Cote d\'Ivoire','Yamoussoukro','Independent State',NULL,NULL,'XOF','Franc',225,'.ci','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(53,'CK','Cook Islands',NULL,'Avarua','Dependency','Self-Governing in Free Association','New Zealand','NZD','Dollar',682,'.ck','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(54,'CL','Chile','Republic of Chile','Santiago (administrative/judical) and Valparaiso (legislative)','Independent State',NULL,NULL,'CLP','Peso',56,'.cl','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(55,'CM','Cameroon','Republic of Cameroon','Yaounde','Independent State',NULL,NULL,'XAF','Franc',237,'.cm','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(56,'CN','China',' People\'s Republic of','People\'s Republic of China','Beijing','Independent State',NULL,NULL,'CNY',NULL,NULL,'IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(57,'CO','Colombia','Republic of Colombia','Bogota','Independent State',NULL,NULL,'COP','Peso',57,'.co','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(58,'CR','Costa Rica','Republic of Costa Rica','San Jose','Independent State',NULL,NULL,'CRC','Colon',506,'.cr','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(59,'CS','Kosovo',NULL,'Pristina','Disputed Territory',NULL,'Administrated by the UN','CSD','Dinar and Euro',381,'.cs','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(60,'CU','Cuba','Republic of Cuba','Havana','Independent State',NULL,NULL,'CUP','Peso',53,'.cu','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(61,'CV','Cape Verde','Republic of Cape Verde','Praia','Independent State',NULL,NULL,'CVE','Escudo',238,'.cv','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(62,'CX','Christmas Island','Territory of Christmas Island','The Settlement (Flying Fish Cove)','Dependency','External Territory','Australia','AUD','Dollar',61,'.cx','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(63,'CY','Cyprus','Republic of Cyprus','Nicosia','Independent State',NULL,NULL,'CYP','Pound',357,'.cy','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(64,'CY1','Northern Cyprus','Turkish Republic of Northern Cyprus','Nicosia','Proto Independent State',NULL,NULL,'TRY','Lira',392,'.nc','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(65,'CZ','Czech Republic',NULL,'Prague','Independent State',NULL,NULL,'CZK','Koruna',420,'.cz','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(66,'DE','Germany','Federal Republic of Germany','Berlin','Independent State',NULL,NULL,'EUR','Euro',49,'.de','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(67,'DJ','Djibouti','Republic of Djibouti','Djibouti','Independent State',NULL,NULL,'DJF','Franc',253,'.dj','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(68,'DK','Denmark','Kingdom of Denmark','Copenhagen','Independent State',NULL,NULL,'DKK','Krone',45,'.dk','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(69,'DM','Dominica','Commonwealth of Dominica','Roseau','Independent State',NULL,NULL,'XCD','Dollar',766,'.dm','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(70,'DO','Dominican Republic',NULL,'Santo Domingo','Independent State',NULL,NULL,'DOP','Peso',829,'.do','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(71,'DZ','Algeria','People\'s Democratic Republic of Algeria','Algiers','Independent State',NULL,NULL,'DZD','Dinar',213,'.dz','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(72,'EC','Ecuador','Republic of Ecuador','Quito','Independent State',NULL,NULL,'USD','Dollar',593,'.ec','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(73,'EE','Estonia','Republic of Estonia','Tallinn','Independent State',NULL,NULL,'EEK','Kroon',372,'.ee','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(74,'EG','Egypt','Arab Republic of Egypt','Cairo','Independent State',NULL,NULL,'EGP','Pound',20,'.eg','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(75,'EH','Western Sahara',NULL,'El-Aaiun','Disputed Territory',NULL,'Administrated by Morocco','MAD','Dirham',212,'.eh','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(76,'ER','Eritrea','State of Eritrea','Asmara','Independent State',NULL,NULL,'ERN','Nakfa',291,'.er','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(77,'ES','Spain','Kingdom of Spain','Madrid','Independent State',NULL,NULL,'EUR','Euro',34,'.es','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(78,'ET','Ethiopia','Federal Democratic Republic of Ethiopia','Addis Ababa','Independent State',NULL,NULL,'ETB','Birr',251,'.et','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(79,'FI','Finland','Republic of Finland','Helsinki','Independent State',NULL,NULL,'EUR','Euro',358,'.fi','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(80,'FJ','Fiji','Republic of the Fiji Islands','Suva','Independent State',NULL,NULL,'FJD','Dollar',679,'.fj','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(81,'FK','Falkland Islands (Islas Malvinas)',NULL,'Stanley','Dependency','Overseas Territory','United Kingdom','FKP','Pound',500,'.fk','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(82,'FM','Micronesia','Federated States of Micronesia','Palikir','Independent State',NULL,NULL,'USD','Dollar',691,'.fm','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(83,'FO','Faroe Islands',NULL,'Torshavn','Proto Dependency',NULL,'Denmark','DKK','Krone',298,'.fo','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(84,'FR','France','French Republic','Paris','Independent State',NULL,NULL,'EUR','Euro',33,'.fr','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(85,'GA','Gabon','Gabonese Republic','Libreville','Independent State',NULL,NULL,'XAF','Franc',241,'.ga','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(86,'GB','United Kingdom','United Kingdom of Great Britain and Northern Ireland','London','Independent State',NULL,NULL,'GBP','Pound',44,'.uk','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(87,'GD','Grenada',NULL,'Saint George\'s','Independent State',NULL,NULL,'XCD','Dollar',473,'.gd','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(88,'GE','Georgia','Republic of Georgia','Tbilisi','Independent State',NULL,NULL,'GEL','Lari',995,'.ge','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(89,'GE1','Abkhazia','Republic of Abkhazia','Sokhumi','Proto Independent State',NULL,NULL,'RUB','Ruble',995,'.ge','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(90,'GE2','South Ossetia','Republic of South Ossetia','Tskhinvali','Proto Independent State',NULL,NULL,'RUB','Ruble and Lari',995,'.ge','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(91,'GF','French Guiana','Overseas Region of Guiana','Cayenne','Proto Dependency','Overseas Region','France','EUR','Euro',594,'.gf','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(92,'GG','Guernsey','Bailiwick of Guernsey','Saint Peter Port','Dependency','Crown Dependency','United Kingdom','GGP','Pound',44,'.gg','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(93,'GH','Ghana','Republic of Ghana','Accra','Independent State',NULL,NULL,'GHS','Cedi',233,'.gh','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(94,'GI','Gibraltar',NULL,'Gibraltar','Dependency','Overseas Territory','United Kingdom','GIP','Pound',350,'.gi','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(95,'GL','Greenland',NULL,'Nuuk (Godthab)','Proto Dependency',NULL,'Denmark','DKK','Krone',299,'.gl','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(96,'GM','Gambia',' The','Republic of The Gambia','Banjul','Independent State',NULL,NULL,'GMD',NULL,NULL,'IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(97,'GN','Guinea','Republic of Guinea','Conakry','Independent State',NULL,NULL,'GNF','Franc',224,'.gn','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(98,'GP1','Saint Barthelemy','Collectivity of Saint Barthelemy','Gustavia','Dependency','Overseas Collectivity','France','EUR','Euro',590,'.gp','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(99,'GP2','Guadeloupe','Overseas Region of Guadeloupe','Basse-Terre','Proto Dependency','Overseas Region','France','EUR','Euro',590,'.gp','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(100,'GP3','Saint Martin','Collectivity of Saint Martin','Marigot','Dependency','Overseas Collectivity','France','EUR','Euro',590,'.gp','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(101,'GQ','Equatorial Guinea','Republic of Equatorial Guinea','Malabo','Independent State',NULL,NULL,'XAF','Franc',240,'.gq','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(102,'GR','Greece','Hellenic Republic','Athens','Independent State',NULL,NULL,'EUR','Euro',30,'.gr','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(103,'GS','South Georgia and the South Sandwich Islands',NULL,NULL,'Dependency','Overseas Territory','United Kingdom',NULL,NULL,NULL,'.gs','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(104,'GT','Guatemala','Republic of Guatemala','Guatemala','Independent State',NULL,NULL,'GTQ','Quetzal',502,'.gt','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(105,'GU','Guam','Territory of Guam','Hagatna','Dependency','Territory','United States','USD','Dollar',671,'.gu','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(106,'GW','Guinea-Bissau','Republic of Guinea-Bissau','Bissau','Independent State',NULL,NULL,'XOF','Franc',245,'.gw','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(107,'GY','Guyana','Co-operative Republic of Guyana','Georgetown','Independent State',NULL,NULL,'GYD','Dollar',592,'.gy','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(108,'HK','Hong Kong','Hong Kong Special Administrative Region',NULL,'Proto Dependency','Special Administrative Region','China','HKD','Dollar',852,'.hk','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(109,'HM','Heard Island and McDonald Islands','Territory of Heard Island and McDonald Islands',NULL,'Dependency','External Territory','Australia',NULL,NULL,NULL,'.hm','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(110,'HN','Honduras','Republic of Honduras','Tegucigalpa','Independent State',NULL,NULL,'HNL','Lempira',504,'.hn','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(111,'HR','Croatia','Republic of Croatia','Zagreb','Independent State',NULL,NULL,'HRK','Kuna',385,'.hr','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(112,'HT','Haiti','Republic of Haiti','Port-au-Prince','Independent State',NULL,NULL,'HTG','Gourde',509,'.ht','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(113,'HU','Hungary','Republic of Hungary','Budapest','Independent State',NULL,NULL,'HUF','Forint',36,'.hu','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(114,'ID','Indonesia','Republic of Indonesia','Jakarta','Independent State',NULL,NULL,'IDR','Rupiah',62,'.id','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(115,'IE','Ireland',NULL,'Dublin','Independent State',NULL,NULL,'EUR','Euro',353,'.ie','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(116,'IL','Israel','State of Israel','Jerusalem','Independent State',NULL,NULL,'ILS','Shekel',972,'.il','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(117,'IM','Isle of Man',NULL,'Douglas','Dependency','Crown Dependency','United Kingdom','IMP','Pound',44,'.im','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(118,'IN','India','Republic of India','New Delhi','Independent State',NULL,NULL,'INR','Rupee',91,'.in','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(119,'IO','British Indian Ocean Territory',NULL,NULL,'Dependency','Overseas Territory','United Kingdom',NULL,NULL,246,'.io','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(120,'IQ','Iraq','Republic of Iraq','Baghdad','Independent State',NULL,NULL,'IQD','Dinar',964,'.iq','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(121,'IR','Iran','Islamic Republic of Iran','Tehran','Independent State',NULL,NULL,'IRR','Rial',98,'.ir','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(122,'IS','Iceland','Republic of Iceland','Reykjavik','Independent State',NULL,NULL,'ISK','Krona',354,'.is','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(123,'IT','Italy','Italian Republic','Rome','Independent State',NULL,NULL,'EUR','Euro',39,'.it','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(124,'JE','Jersey','Bailiwick of Jersey','Saint Helier','Dependency','Crown Dependency','United Kingdom','JEP','Pound',44,'.je','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(125,'JM','Jamaica',NULL,'Kingston','Independent State',NULL,NULL,'JMD','Dollar',-875,'.jm','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(126,'JO','Jordan','Hashemite Kingdom of Jordan','Amman','Independent State',NULL,NULL,'JOD','Dinar',962,'.jo','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(127,'JP','Japan',NULL,'Tokyo','Independent State',NULL,NULL,'JPY','Yen',81,'.jp','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(128,'KE','Kenya','Republic of Kenya','Nairobi','Independent State',NULL,NULL,'KES','Shilling',254,'.ke','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(129,'KG','Kyrgyzstan','Kyrgyz Republic','Bishkek','Independent State',NULL,NULL,'KGS','Som',996,'.kg','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(130,'KH','Cambodia','Kingdom of Cambodia','Phnom Penh','Independent State',NULL,NULL,'KHR','Riels',855,'.kh','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(131,'KI','Kiribati','Republic of Kiribati','Tarawa','Independent State',NULL,NULL,'AUD','Dollar',686,'.ki','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(132,'KM','Comoros','Union of Comoros','Moroni','Independent State',NULL,NULL,'KMF','Franc',269,'.km','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(133,'KN','Saint Kitts and Nevis','Federation of Saint Kitts and Nevis','Basseterre','Independent State',NULL,NULL,'XCD','Dollar',869,'.kn','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(134,'KP','Korea',' Democratic People\'s Republic of (North Korea)','Democratic People\'s Republic of Korea','Pyongyang','Independent State',NULL,NULL,'KPW',NULL,NULL,'IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(135,'KR','Korea',' Republic of  (South Korea)','Republic of Korea','Seoul','Independent State',NULL,NULL,'KRW',NULL,NULL,'IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(136,'KW','Kuwait','State of Kuwait','Kuwait','Independent State',NULL,NULL,'KWD','Dinar',965,'.kw','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(137,'KY','Cayman Islands',NULL,'George Town','Dependency','Overseas Territory','United Kingdom','KYD','Dollar',345,'.ky','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(138,'KZ','Kazakhstan','Republic of Kazakhstan','Astana','Independent State',NULL,NULL,'KZT','Tenge',7,'.kz','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(139,'LA','Laos','Lao People\'s Democratic Republic','Vientiane','Independent State',NULL,NULL,'LAK','Kip',856,'.la','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(140,'LB','Lebanon','Lebanese Republic','Beirut','Independent State',NULL,NULL,'LBP','Pound',961,'.lb','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(141,'LC','Saint Lucia',NULL,'Castries','Independent State',NULL,NULL,'XCD','Dollar',758,'.lc','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(142,'LI','Liechtenstein','Principality of Liechtenstein','Vaduz','Independent State',NULL,NULL,'CHF','Franc',423,'.li','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(143,'LK','Sri Lanka','Democratic Socialist Republic of Sri Lanka','Colombo (administrative/judical) and Sri Jayewardenepura Kotte (legislative)','Independent State',NULL,NULL,'LKR','Rupee',94,'.lk','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(144,'LR','Liberia','Republic of Liberia','Monrovia','Independent State',NULL,NULL,'LRD','Dollar',231,'.lr','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(145,'LS','Lesotho','Kingdom of Lesotho','Maseru','Independent State',NULL,NULL,'LSL','Loti',266,'.ls','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(146,'LT','Lithuania','Republic of Lithuania','Vilnius','Independent State',NULL,NULL,'LTL','Litas',370,'.lt','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(147,'LU','Luxembourg','Grand Duchy of Luxembourg','Luxembourg','Independent State',NULL,NULL,'EUR','Euro',352,'.lu','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(148,'LV','Latvia','Republic of Latvia','Riga','Independent State',NULL,NULL,'LVL','Lat',371,'.lv','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(149,'LY','Libya','Great Socialist People\'s Libyan Arab Jamahiriya','Tripoli','Independent State',NULL,NULL,'LYD','Dinar',218,'.ly','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(150,'MA','Morocco','Kingdom of Morocco','Rabat','Independent State',NULL,NULL,'MAD','Dirham',212,'.ma','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(151,'MC','Monaco','Principality of Monaco','Monaco','Independent State',NULL,NULL,'EUR','Euro',377,'.mc','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(152,'MD','Moldova','Republic of Moldova','Chisinau','Independent State',NULL,NULL,'MDL','Leu',373,'.md','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(153,'MD1','Pridnestrovie (Transnistria)','Pridnestrovian Moldavian Republic','Tiraspol','Proto Independent State',NULL,NULL,NULL,'Ruple',533,'.md','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(154,'ME','Montenegro','Republic of Montenegro','Podgorica','Independent State',NULL,NULL,'EUR','Euro',382,'.me','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(155,'MG','Madagascar','Republic of Madagascar','Antananarivo','Independent State',NULL,NULL,'MGA','Ariary',261,'.mg','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(156,'MH','Marshall Islands','Republic of the Marshall Islands','Majuro','Independent State',NULL,NULL,'USD','Dollar',692,'.mh','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(157,'MK','Macedonia','Republic of Macedonia','Skopje','Independent State',NULL,NULL,'MKD','Denar',389,'.mk','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(158,'ML','Mali','Republic of Mali','Bamako','Independent State',NULL,NULL,'XOF','Franc',223,'.ml','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(159,'MM','Myanmar (Burma)','Union of Myanmar','Naypyidaw','Independent State',NULL,NULL,'MMK','Kyat',95,'.mm','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(160,'MN','Mongolia',NULL,'Ulaanbaatar','Independent State',NULL,NULL,'MNT','Tugrik',976,'.mn','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(161,'MO','Macau','Macau Special Administrative Region','Macau','Proto Dependency','Special Administrative Region','China','MOP','Pataca',853,'.mo','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(162,'MP','Northern Mariana Islands','Commonwealth of The Northern Mariana Islands','Saipan','Dependency','Commonwealth','United States','USD','Dollar',670,'.mp','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(163,'MQ','Martinique','Overseas Region of Martinique','Fort-de-France','Proto Dependency','Overseas Region','France','EUR','Euro',596,'.mq','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(164,'MR','Mauritania','Islamic Republic of Mauritania','Nouakchott','Independent State',NULL,NULL,'MRO','Ouguiya',222,'.mr','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(165,'MS','Montserrat',NULL,'Plymouth','Dependency','Overseas Territory','United Kingdom','XCD','Dollar',664,'.ms','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(166,'MT','Malta','Republic of Malta','Valletta','Independent State',NULL,NULL,'MTL','Lira',356,'.mt','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(167,'MU','Mauritius','Republic of Mauritius','Port Louis','Independent State',NULL,NULL,'MUR','Rupee',230,'.mu','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(168,'MV','Maldives','Republic of Maldives','Male','Independent State',NULL,NULL,'MVR','Rufiyaa',960,'.mv','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(169,'MW','Malawi','Republic of Malawi','Lilongwe','Independent State',NULL,NULL,'MWK','Kwacha',265,'.mw','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(170,'MX','Mexico','United Mexican States','Mexico','Independent State',NULL,NULL,'MXN','Peso',52,'.mx','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(171,'MY','Malaysia',NULL,'Kuala Lumpur (legislative/judical) and Putrajaya (administrative)','Independent State',NULL,NULL,'MYR','Ringgit',60,'.my','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(172,'MZ','Mozambique','Republic of Mozambique','Maputo','Independent State',NULL,NULL,'MZM','Meticail',258,'.mz','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(173,'NA','Namibia','Republic of Namibia','Windhoek','Independent State',NULL,NULL,'NAD','Dollar',264,'.na','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(174,'NC','New Caledonia',NULL,'Noumea','Dependency','Sui generis Collectivity','France','XPF','Franc',687,'.nc','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(175,'NE','Niger','Republic of Niger','Niamey','Independent State',NULL,NULL,'XOF','Franc',227,'.ne','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(176,'NF','Norfolk Island','Territory of Norfolk Island','Kingston','Dependency','External Territory','Australia','AUD','Dollar',672,'.nf','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(177,'NG','Nigeria','Federal Republic of Nigeria','Abuja','Independent State',NULL,NULL,'NGN','Naira',234,'.ng','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(178,'NI','Nicaragua','Republic of Nicaragua','Managua','Independent State',NULL,NULL,'NIO','Cordoba',505,'.ni','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(179,'NL','Netherlands','Kingdom of the Netherlands','Amsterdam (administrative) and The Hague (legislative/judical)','Independent State',NULL,NULL,'EUR','Euro',31,'.nl','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(180,'NO','Norway','Kingdom of Norway','Oslo','Independent State',NULL,NULL,'NOK','Krone',47,'.no','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(181,'NP','Nepal',NULL,'Kathmandu','Independent State',NULL,NULL,'NPR','Rupee',977,'.np','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(182,'NR','Nauru','Republic of Nauru','Yaren','Independent State',NULL,NULL,'AUD','Dollar',674,'.nr','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(183,'NU','Niue',NULL,'Alofi','Dependency','Self-Governing in Free Association','New Zealand','NZD','Dollar',683,'.nu','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(184,'NZ','New Zealand',NULL,'Wellington','Independent State',NULL,NULL,'NZD','Dollar',64,'.nz','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(185,'OM','Oman','Sultanate of Oman','Muscat','Independent State',NULL,NULL,'OMR','Rial',968,'.om','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(186,'PA','Panama','Republic of Panama','Panama','Independent State',NULL,NULL,'PAB','Balboa',507,'.pa','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(187,'PE','Peru','Republic of Peru','Lima','Independent State',NULL,NULL,'PEN','Sol',51,'.pe','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(188,'PF','French Polynesia','Overseas Country of French Polynesia','Papeete','Dependency','Overseas Collectivity','France','XPF','Franc',689,'.pf','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(189,'PF1','Clipperton Island',NULL,NULL,'Dependency','Possession','France',NULL,NULL,NULL,'.pf','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(190,'PG','Papua New Guinea','Independent State of Papua New Guinea','Port Moresby','Independent State',NULL,NULL,'PGK','Kina',675,'.pg','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(191,'PH','Philippines','Republic of the Philippines','Manila','Independent State',NULL,NULL,'PHP','Peso',63,'.ph','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(192,'PK','Pakistan','Islamic Republic of Pakistan','Islamabad','Independent State',NULL,NULL,'PKR','Rupee',92,'.pk','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(193,'PL','Poland','Republic of Poland','Warsaw','Independent State',NULL,NULL,'PLN','Zloty',48,'.pl','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(194,'PM','Saint Pierre and Miquelon','Territorial Collectivity of Saint Pierre and Miquelon','Saint-Pierre','Dependency','Overseas Collectivity','France','EUR','Euro',508,'.pm','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(195,'PN','Pitcairn Islands',NULL,'Adamstown','Dependency','Overseas Territory','United Kingdom','NZD','Dollar',NULL,'.pn','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(196,'PR','Puerto Rico','Commonwealth of Puerto Rico','San Juan','Dependency','Commonwealth','United States','USD','Dollar',939,'.pr','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(197,'PS','Palestinian Territories (Gaza Strip and West Bank)',NULL,'Gaza City (Gaza Strip) and Ramallah (West Bank)','Disputed Territory',NULL,'Administrated by Israel','ILS','Shekel',970,'.ps','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(198,'PT','Portugal','Portuguese Republic','Lisbon','Independent State',NULL,NULL,'EUR','Euro',351,'.pt','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(199,'PW','Palau','Republic of Palau','Melekeok','Independent State',NULL,NULL,'USD','Dollar',680,'.pw','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(200,'PY','Paraguay','Republic of Paraguay','Asuncion','Independent State',NULL,NULL,'PYG','Guarani',595,'.py','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(201,'QA','Qatar','State of Qatar','Doha','Independent State',NULL,NULL,'QAR','Rial',974,'.qa','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(202,'RE','Reunion','Overseas Region of Reunion','Saint-Denis','Proto Dependency','Overseas Region','France','EUR','Euro',262,'.re','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(203,'RO','Romania',NULL,'Bucharest','Independent State',NULL,NULL,'RON','Leu',40,'.ro','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(204,'RS','Serbia','Republic of Serbia','Belgrade','Independent State',NULL,NULL,'RSD','Dinar',381,'.rs','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(205,'RU','Russia','Russian Federation','Moscow','Independent State',NULL,NULL,'RUB','Ruble',7,'.ru','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(206,'RW','Rwanda','Republic of Rwanda','Kigali','Independent State',NULL,NULL,'RWF','Franc',250,'.rw','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(207,'SA','Saudi Arabia','Kingdom of Saudi Arabia','Riyadh','Independent State',NULL,NULL,'SAR','Rial',966,'.sa','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(208,'SB','Solomon Islands',NULL,'Honiara','Independent State',NULL,NULL,'SBD','Dollar',677,'.sb','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(209,'SC','Seychelles','Republic of Seychelles','Victoria','Independent State',NULL,NULL,'SCR','Rupee',248,'.sc','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(210,'SD','Sudan','Republic of the Sudan','Khartoum','Independent State',NULL,NULL,'SDG','Pound',249,'.sd','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(211,'SE','Sweden','Kingdom of Sweden','Stockholm','Independent State',NULL,NULL,'SEK','Kronoa',46,'.se','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(212,'SG','Singapore','Republic of Singapore','Singapore','Independent State',NULL,NULL,'SGD','Dollar',65,'.sg','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(213,'SH','Saint Helena',NULL,'Jamestown','Dependency','Overseas Territory','United Kingdom','SHP','Pound',290,'.sh','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(214,'SI','Slovenia','Republic of Slovenia','Ljubljana','Independent State',NULL,NULL,'EUR','Euro',386,'.si','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(215,'SJ','Svalbard',NULL,'Longyearbyen','Proto Dependency',NULL,'Norway','NOK','Krone',47,'.sj','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(216,'SK','Slovakia','Slovak Republic','Bratislava','Independent State',NULL,NULL,'SKK','Koruna',421,'.sk','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(217,'SL','Sierra Leone','Republic of Sierra Leone','Freetown','Independent State',NULL,NULL,'SLL','Leone',232,'.sl','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(218,'SM','San Marino','Republic of San Marino','San Marino','Independent State',NULL,NULL,'EUR','Euro',378,'.sm','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(219,'SN','Senegal','Republic of Senegal','Dakar','Independent State',NULL,NULL,'XOF','Franc',221,'.sn','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(220,'SO','Somalia',NULL,'Mogadishu','Independent State',NULL,NULL,'SOS','Shilling',252,'.so','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(221,'SO1','Somaliland','Republic of Somaliland','Hargeisa','Proto Independent State',NULL,NULL,NULL,'Shilling',252,'.so','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(222,'SR','Suriname','Republic of Suriname','Paramaribo','Independent State',NULL,NULL,'SRD','Dollar',597,'.sr','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(223,'ST','Sao Tome and Principe','Democratic Republic of Sao Tome and Principe','Sao Tome','Independent State',NULL,NULL,'STD','Dobra',239,'.st','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(224,'SV','El Salvador','Republic of El Salvador','San Salvador','Independent State',NULL,NULL,'USD','Dollar',503,'.sv','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(225,'SY','Syria','Syrian Arab Republic','Damascus','Independent State',NULL,NULL,'SYP','Pound',963,'.sy','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(226,'SZ','Swaziland','Kingdom of Swaziland','Mbabane (administrative) and Lobamba (legislative)','Independent State',NULL,NULL,'SZL','Lilangeni',268,'.sz','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(227,'TA','Tristan da Cunha',NULL,'Edinburgh','Proto Dependency','Dependency of Saint Helena','United Kingdom','SHP','Pound',290,NULL,'IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(228,'TC','Turks and Caicos Islands',NULL,'Grand Turk','Dependency','Overseas Territory','United Kingdom','USD','Dollar',649,'.tc','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(229,'TD','Chad','Republic of Chad','N\'Djamena','Independent State',NULL,NULL,'XAF','Franc',235,'.td','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(230,'TF','French Southern and Antarctic Lands','Territory of the French Southern and Antarctic Lands','Martin-de-ViviÃ¨s','Dependency','Overseas Territory','France',NULL,NULL,NULL,'.tf','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(231,'TG','Togo','Togolese Republic','Lome','Independent State',NULL,NULL,'XOF','Franc',228,'.tg','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(232,'TH','Thailand','Kingdom of Thailand','Bangkok','Independent State',NULL,NULL,'THB','Baht',66,'.th','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(233,'TJ','Tajikistan','Republic of Tajikistan','Dushanbe','Independent State',NULL,NULL,'TJS','Somoni',992,'.tj','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(234,'TK','Tokelau',NULL,NULL,'Dependency','Territory','New Zealand','NZD','Dollar',690,'.tk','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(235,'TL','Timor-Leste (East Timor)','Democratic Republic of Timor-Leste','Dili','Independent State',NULL,NULL,'USD','Dollar',670,'.tp','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(236,'TM','Turkmenistan',NULL,'Ashgabat','Independent State',NULL,NULL,'TMM','Manat',993,'.tm','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(237,'TN','Tunisia','Tunisian Republic','Tunis','Independent State',NULL,NULL,'TND','Dinar',216,'.tn','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(238,'TO','Tonga','Kingdom of Tonga','Nuku\'alofa','Independent State',NULL,NULL,'TOP','Pa\'anga',676,'.to','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(239,'TR','Turkey','Republic of Turkey','Ankara','Independent State',NULL,NULL,'TRY','Lira',90,'.tr','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(240,'TT','Trinidad and Tobago','Republic of Trinidad and Tobago','Port-of-Spain','Independent State',NULL,NULL,'TTD','Dollar',868,'.tt','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(241,'TV','Tuvalu',NULL,'Funafuti','Independent State',NULL,NULL,'AUD','Dollar',688,'.tv','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(242,'TW','China',' Republic of (Taiwan)','Republic of China','Taipei','Proto Independent State',NULL,NULL,'TWD',NULL,NULL,'IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(243,'TZ','Tanzania','United Republic of Tanzania','Dar es Salaam (administrative/judical) and Dodoma (legislative)','Independent State',NULL,NULL,'TZS','Shilling',255,'.tz','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(244,'UA','Ukraine',NULL,'Kiev','Independent State',NULL,NULL,'UAH','Hryvnia',380,'.ua','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(245,'UG','Uganda','Republic of Uganda','Kampala','Independent State',NULL,NULL,'UGX','Shilling',256,'.ug','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(246,'UM1','Baker Island',NULL,NULL,'Dependency','Territory','United States',NULL,NULL,NULL,NULL,'IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(247,'UM2','Howland Island',NULL,NULL,'Dependency','Territory','United States',NULL,NULL,NULL,NULL,'IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(248,'UM3','Jarvis Island',NULL,NULL,'Dependency','Territory','United States',NULL,NULL,NULL,NULL,'IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(249,'UM4','Johnston Atoll',NULL,NULL,'Dependency','Territory','United States',NULL,NULL,NULL,NULL,'IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(250,'UM5','Kingman Reef',NULL,NULL,'Dependency','Territory','United States',NULL,NULL,NULL,NULL,'IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(251,'UM6','Midway Islands',NULL,NULL,'Dependency','Territory','United States',NULL,NULL,NULL,NULL,'IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(252,'UM7','Navassa Island',NULL,NULL,'Dependency','Territory','United States',NULL,NULL,NULL,NULL,'IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(253,'UM8','Palmyra Atoll',NULL,NULL,'Dependency','Territory','United States',NULL,NULL,NULL,NULL,'IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(254,'UM9','Wake Island',NULL,NULL,'Dependency','Territory','United States',NULL,NULL,NULL,NULL,'IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(255,'US','United States','United States of America','Washington','Independent State',NULL,NULL,'USD','Dollar',1,'.us','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(256,'UY','Uruguay','Oriental Republic of Uruguay','Montevideo','Independent State',NULL,NULL,'UYU','Peso',598,'.uy','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(257,'UZ','Uzbekistan','Republic of Uzbekistan','Tashkent','Independent State',NULL,NULL,'UZS','Som',998,'.uz','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(258,'VA','Vatican City','State of the Vatican City','Vatican City','Independent State',NULL,NULL,'EUR','Euro',379,'.va','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(259,'VC','Saint Vincent and the Grenadines',NULL,'Kingstown','Independent State',NULL,NULL,'XCD','Dollar',784,'.vc','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(260,'VE','Venezuela','Bolivarian Republic of Venezuela','Caracas','Independent State',NULL,NULL,'VEB','Bolivar',58,'.ve','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(261,'VG','British Virgin Islands',NULL,'Road Town','Dependency','Overseas Territory','United Kingdom','USD','Dollar',284,'.vg','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(262,'VI','U.S. Virgin Islands','United States Virgin Islands','Charlotte Amalie','Dependency','Territory','United States','USD','Dollar',340,'.vi','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(263,'VN','Vietnam','Socialist Republic of Vietnam','Hanoi','Independent State',NULL,NULL,'VND','Dong',84,'.vn','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(264,'VU','Vanuatu','Republic of Vanuatu','Port-Vila','Independent State',NULL,NULL,'VUV','Vatu',678,'.vu','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(265,'WF','Wallis and Futuna','Collectivity of the Wallis and Futuna Islands','Mata\'utu','Dependency','Overseas Collectivity','France','XPF','Franc',681,'.wf','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(266,'WS','Samoa','Independent State of Samoa','Apia','Independent State',NULL,NULL,'WST','Tala',685,'.ws','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(267,'YE','Yemen','Republic of Yemen','Sanaa','Independent State',NULL,NULL,'YER','Rial',967,'.ye','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(268,'YT','Mayotte','Departmental Collectivity of Mayotte','Mamoudzou','Dependency','Overseas Collectivity','France','EUR','Euro',262,'.yt','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(269,'ZA','South Africa','Republic of South Africa','Pretoria (administrative)',' Cape Town (legislative)',' and Bloemfontein (judical)','Independent State',NULL,NULL,NULL,'Ran','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(270,'ZM','Zambia','Republic of Zambia','Lusaka','Independent State',NULL,NULL,'ZMK','Kwacha',260,'.zm','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(271,'ZW','Zimbabwe','Republic of Zimbabwe','Harare','Independent State',NULL,NULL,'ZWD','Dollar',263,'.zw','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1);
/*!40000 ALTER TABLE `countrys` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `countrys_hs`
--

DROP TABLE IF EXISTS `countrys_hs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `countrys_hs` (
  `id` int(11) unsigned NOT NULL,
  `country_id` varchar(3) NOT NULL,
  `common_name` varchar(255) NOT NULL,
  `formal_name` varchar(255) DEFAULT NULL,
  `capital` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `sub_type` varchar(255) DEFAULT NULL,
  `sovereignty` varchar(255) DEFAULT NULL,
  `currency_code` varchar(3) DEFAULT NULL,
  `currency_name` varchar(255) DEFAULT NULL,
  `telephone_code` int(4) DEFAULT NULL,
  `iana_country_code` varchar(3) DEFAULT NULL,
  `inputter` varchar(50) NOT NULL,
  `input_date` datetime NOT NULL,
  `authorizer` varchar(50) NOT NULL,
  `auth_date` datetime NOT NULL,
  `record_status` char(4) NOT NULL,
  `current_no` int(11) NOT NULL,
  PRIMARY KEY (`id`,`current_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `countrys_hs`
--

LOCK TABLES `countrys_hs` WRITE;
/*!40000 ALTER TABLE `countrys_hs` DISABLE KEYS */;
/*!40000 ALTER TABLE `countrys_hs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `countrys_is`
--

DROP TABLE IF EXISTS `countrys_is`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `countrys_is` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `country_id` varchar(3) DEFAULT NULL,
  `common_name` varchar(255) DEFAULT NULL,
  `formal_name` varchar(255) DEFAULT NULL,
  `capital` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `sub_type` varchar(255) DEFAULT NULL,
  `sovereignty` varchar(255) DEFAULT NULL,
  `currency_code` varchar(3) DEFAULT NULL,
  `currency_name` varchar(255) DEFAULT NULL,
  `telephone_code` int(4) DEFAULT NULL,
  `iana_country_code` varchar(3) DEFAULT NULL,
  `inputter` varchar(50) DEFAULT NULL,
  `input_date` datetime DEFAULT NULL,
  `authorizer` varchar(50) DEFAULT NULL,
  `auth_date` datetime DEFAULT NULL,
  `record_status` char(4) DEFAULT NULL,
  `current_no` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_country_id` (`country_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `countrys_is`
--

LOCK TABLES `countrys_is` WRITE;
/*!40000 ALTER TABLE `countrys_is` DISABLE KEYS */;
/*!40000 ALTER TABLE `countrys_is` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `csvs`
--

DROP TABLE IF EXISTS `csvs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `csvs` (
  `id` int(11) unsigned NOT NULL,
  `csv_id` varchar(30) NOT NULL,
  `controller` varchar(50) NOT NULL,
  `type` varchar(20) NOT NULL,
  `csv` longtext,
  `inputter` varchar(50) NOT NULL,
  `input_date` datetime NOT NULL,
  `authorizer` varchar(50) NOT NULL,
  `auth_date` datetime NOT NULL,
  `record_status` char(4) NOT NULL,
  `current_no` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_csv_id` (`csv_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `csvs`
--

LOCK TABLES `csvs` WRITE;
/*!40000 ALTER TABLE `csvs` DISABLE KEYS */;
/*!40000 ALTER TABLE `csvs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `csvs_hs`
--

DROP TABLE IF EXISTS `csvs_hs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `csvs_hs` (
  `id` int(11) unsigned NOT NULL,
  `csv_id` varchar(30) NOT NULL,
  `controller` varchar(50) NOT NULL,
  `type` varchar(20) NOT NULL,
  `csv` longtext,
  `inputter` varchar(50) NOT NULL,
  `input_date` datetime NOT NULL,
  `authorizer` varchar(50) NOT NULL,
  `auth_date` datetime NOT NULL,
  `record_status` char(4) NOT NULL,
  `current_no` int(11) NOT NULL,
  PRIMARY KEY (`id`,`current_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `csvs_hs`
--

LOCK TABLES `csvs_hs` WRITE;
/*!40000 ALTER TABLE `csvs_hs` DISABLE KEYS */;
/*!40000 ALTER TABLE `csvs_hs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `csvs_is`
--

DROP TABLE IF EXISTS `csvs_is`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `csvs_is` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `csv_id` varchar(30) DEFAULT NULL,
  `controller` varchar(50) DEFAULT NULL,
  `type` varchar(20) DEFAULT NULL,
  `csv` longtext,
  `inputter` varchar(50) DEFAULT NULL,
  `input_date` datetime DEFAULT NULL,
  `authorizer` varchar(50) DEFAULT NULL,
  `auth_date` datetime DEFAULT NULL,
  `record_status` char(4) DEFAULT NULL,
  `current_no` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_csv_id` (`csv_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `csvs_is`
--

LOCK TABLES `csvs_is` WRITE;
/*!40000 ALTER TABLE `csvs_is` DISABLE KEYS */;
/*!40000 ALTER TABLE `csvs_is` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customers`
--

DROP TABLE IF EXISTS `customers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customers` (
  `id` int(11) unsigned NOT NULL,
  `customer_id` varchar(8) NOT NULL,
  `customer_type` enum('INDIVIDUAL','COMPANY') NOT NULL,
  `business_type` varchar(50) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `address1` varchar(255) NOT NULL,
  `address2` varchar(255) DEFAULT NULL,
  `city` varchar(255) NOT NULL,
  `region_id` int(11) unsigned NOT NULL,
  `country_id` varchar(2) NOT NULL,
  `date_of_birth` date DEFAULT NULL,
  `gender` enum('M','F','N') NOT NULL,
  `phone_home` varchar(7) DEFAULT NULL,
  `phone_work` varchar(7) DEFAULT NULL,
  `phone_mobile1` varchar(7) NOT NULL,
  `phone_mobile2` varchar(7) DEFAULT NULL,
  `email_address` varchar(255) DEFAULT NULL,
  `driver_permit` varchar(10) NOT NULL,
  `identification_card` varchar(12) DEFAULT NULL,
  `passport` varchar(10) DEFAULT NULL,
  `driver_permit_expiry_date` date DEFAULT NULL,
  `emergency_contact` varchar(255) DEFAULT NULL,
  `emergency_contact_phone` varchar(7) DEFAULT NULL,
  `branch_id` varchar(50) NOT NULL,
  `referrer_id` varchar(8) DEFAULT NULL,
  `comments` text,
  `inputter` varchar(50) NOT NULL,
  `input_date` datetime NOT NULL,
  `authorizer` varchar(50) NOT NULL,
  `auth_date` datetime NOT NULL,
  `record_status` char(4) NOT NULL,
  `current_no` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_customer_id` (`customer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customers`
--

LOCK TABLES `customers` WRITE;
/*!40000 ALTER TABLE `customers` DISABLE KEYS */;
/*!40000 ALTER TABLE `customers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customers_hs`
--

DROP TABLE IF EXISTS `customers_hs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customers_hs` (
  `id` int(11) unsigned NOT NULL,
  `customer_id` varchar(8) NOT NULL,
  `customer_type` enum('INDIVIDUAL','COMPANY') NOT NULL,
  `business_type` varchar(50) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `address1` varchar(255) NOT NULL,
  `address2` varchar(255) DEFAULT NULL,
  `city` varchar(255) NOT NULL,
  `region_id` int(11) NOT NULL,
  `country_id` varchar(2) NOT NULL,
  `date_of_birth` date DEFAULT NULL,
  `gender` enum('M','F','N') NOT NULL,
  `phone_home` varchar(7) DEFAULT NULL,
  `phone_work` varchar(7) DEFAULT NULL,
  `phone_mobile1` varchar(7) DEFAULT NULL,
  `phone_mobile2` varchar(7) DEFAULT NULL,
  `email_address` varchar(255) DEFAULT NULL,
  `branch_id` varchar(50) NOT NULL,
  `referrer_id` varchar(8) DEFAULT NULL,
  `comments` text,
  `inputter` varchar(50) NOT NULL,
  `input_date` datetime NOT NULL,
  `authorizer` varchar(50) NOT NULL,
  `auth_date` datetime NOT NULL,
  `record_status` char(4) NOT NULL,
  `current_no` int(11) NOT NULL,
  PRIMARY KEY (`id`,`current_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customers_hs`
--

LOCK TABLES `customers_hs` WRITE;
/*!40000 ALTER TABLE `customers_hs` DISABLE KEYS */;
/*!40000 ALTER TABLE `customers_hs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customers_is`
--

DROP TABLE IF EXISTS `customers_is`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customers_is` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `customer_id` varchar(8) DEFAULT NULL,
  `customer_type` enum('INDIVIDUAL','COMPANY') DEFAULT NULL,
  `business_type` varchar(50) DEFAULT 'PERSONAL',
  `first_name` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  `address1` varchar(255) DEFAULT NULL,
  `address2` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `region_id` int(11) DEFAULT NULL,
  `country_id` varchar(2) DEFAULT 'TT',
  `date_of_birth` date DEFAULT '0000-00-00',
  `gender` enum('M','F','N') DEFAULT NULL,
  `phone_home` varchar(7) DEFAULT NULL,
  `phone_work` varchar(7) DEFAULT NULL,
  `phone_mobile1` varchar(7) DEFAULT NULL,
  `phone_mobile2` varchar(7) DEFAULT NULL,
  `email_address` varchar(255) DEFAULT NULL,
  `branch_id` varchar(50) DEFAULT 'HEAD.OFFICE',
  `referrer_id` varchar(8) DEFAULT NULL,
  `comments` text,
  `inputter` varchar(50) DEFAULT NULL,
  `input_date` datetime DEFAULT NULL,
  `authorizer` varchar(50) DEFAULT NULL,
  `auth_date` datetime DEFAULT NULL,
  `record_status` char(4) DEFAULT NULL,
  `current_no` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customers_is`
--

LOCK TABLES `customers_is` WRITE;
/*!40000 ALTER TABLE `customers_is` DISABLE KEYS */;
/*!40000 ALTER TABLE `customers_is` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `daytimes`
--

DROP TABLE IF EXISTS `daytimes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `daytimes` (
  `id` int(11) unsigned NOT NULL,
  `daytime_id` time NOT NULL,
  `description` varchar(25) NOT NULL,
  `inputter` varchar(50) NOT NULL,
  `input_date` datetime NOT NULL,
  `authorizer` varchar(50) NOT NULL,
  `auth_date` datetime NOT NULL,
  `record_status` char(4) NOT NULL,
  `current_no` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_datetime_id` (`daytime_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `daytimes`
--

LOCK TABLES `daytimes` WRITE;
/*!40000 ALTER TABLE `daytimes` DISABLE KEYS */;
INSERT INTO `daytimes` VALUES (1,'00:00:00','12:00 AM','IMPLEMENTATION','2010-08-28 00:00:00','ADMIN','2010-08-28 00:00:00','LIVE',1),(2,'00:15:00','12:15 AM','IMPLEMENTATION','2010-08-28 00:00:00','ADMIN','2010-08-28 00:00:00','LIVE',1),(3,'00:30:00','12:30 AM','IMPLEMENTATION','2010-08-28 00:00:00','ADMIN','2010-08-28 00:00:00','LIVE',1),(4,'00:45:00','12:45 AM','IMPLEMENTATION','2010-08-28 00:00:00','ADMIN','2010-08-28 00:00:00','LIVE',1),(5,'01:00:00','1:00 AM','IMPLEMENTATION','2010-08-28 00:00:00','ADMIN','2010-08-28 00:00:00','LIVE',1),(6,'01:15:00','1:15 AM','IMPLEMENTATION','2010-08-28 00:00:00','ADMIN','2010-08-28 00:00:00','LIVE',1),(7,'01:30:00','1:30 AM','IMPLEMENTATION','2010-08-28 00:00:00','ADMIN','2010-08-28 00:00:00','LIVE',1),(8,'01:45:00','1:45 AM','IMPLEMENTATION','2010-08-28 00:00:00','ADMIN','2010-08-28 00:00:00','LIVE',1),(9,'02:00:00','2:00 AM','IMPLEMENTATION','2010-08-28 00:00:00','ADMIN','2010-08-28 00:00:00','LIVE',1),(10,'02:15:00','2:15 AM','IMPLEMENTATION','2010-08-28 00:00:00','ADMIN','2010-08-28 00:00:00','LIVE',1),(11,'02:30:00','2:30 AM','IMPLEMENTATION','2010-08-28 00:00:00','ADMIN','2010-08-28 00:00:00','LIVE',1),(12,'02:45:00','2:45 AM','IMPLEMENTATION','2010-08-28 00:00:00','ADMIN','2010-08-28 00:00:00','LIVE',1),(13,'03:00:00','3:00 AM','IMPLEMENTATION','2010-08-28 00:00:00','ADMIN','2010-08-28 00:00:00','LIVE',1),(14,'03:15:00','3:15 AM','IMPLEMENTATION','2010-08-28 00:00:00','ADMIN','2010-08-28 00:00:00','LIVE',1),(15,'03:30:00','3:30 AM','IMPLEMENTATION','2010-08-28 00:00:00','ADMIN','2010-08-28 00:00:00','LIVE',1),(16,'03:45:00','3:45 AM','IMPLEMENTATION','2010-08-28 00:00:00','ADMIN','2010-08-28 00:00:00','LIVE',1),(17,'04:00:00','4:00 AM','IMPLEMENTATION','2010-08-28 00:00:00','ADMIN','2010-08-28 00:00:00','LIVE',1),(18,'04:15:00','4:15 AM','IMPLEMENTATION','2010-08-28 00:00:00','ADMIN','2010-08-28 00:00:00','LIVE',1),(19,'04:30:00','4:30 AM','IMPLEMENTATION','2010-08-28 00:00:00','ADMIN','2010-08-28 00:00:00','LIVE',1),(20,'04:45:00','4:45 AM','IMPLEMENTATION','2010-08-28 00:00:00','ADMIN','2010-08-28 00:00:00','LIVE',1),(21,'05:00:00','5:00 AM','IMPLEMENTATION','2010-08-28 00:00:00','ADMIN','2010-08-28 00:00:00','LIVE',1),(22,'05:15:00','5:15 AM','IMPLEMENTATION','2010-08-28 00:00:00','ADMIN','2010-08-28 00:00:00','LIVE',1),(23,'05:30:00','5:30 AM','IMPLEMENTATION','2010-08-28 00:00:00','ADMIN','2010-08-28 00:00:00','LIVE',1),(24,'05:45:00','5:45 AM','IMPLEMENTATION','2010-08-28 00:00:00','ADMIN','2010-08-28 00:00:00','LIVE',1),(25,'06:00:00','6:00 AM','IMPLEMENTATION','2010-08-28 00:00:00','ADMIN','2010-08-28 00:00:00','LIVE',1),(26,'06:15:00','6:15 AM','IMPLEMENTATION','2010-08-28 00:00:00','ADMIN','2010-08-28 00:00:00','LIVE',1),(27,'06:30:00','6:30 AM','IMPLEMENTATION','2010-08-28 00:00:00','ADMIN','2010-08-28 00:00:00','LIVE',1),(28,'06:45:00','6:45 AM','IMPLEMENTATION','2010-08-28 00:00:00','ADMIN','2010-08-28 00:00:00','LIVE',1),(29,'07:00:00','7:00 AM','IMPLEMENTATION','2010-08-28 00:00:00','ADMIN','2010-08-28 00:00:00','LIVE',1),(30,'07:15:00','7:15 AM','IMPLEMENTATION','2010-08-28 00:00:00','ADMIN','2010-08-28 00:00:00','LIVE',1),(31,'07:30:00','7:30 AM','IMPLEMENTATION','2010-08-28 00:00:00','ADMIN','2010-08-28 00:00:00','LIVE',1),(32,'07:45:00','7:45 AM','IMPLEMENTATION','2010-08-28 00:00:00','ADMIN','2010-08-28 00:00:00','LIVE',1),(33,'08:00:00','8:00 AM','IMPLEMENTATION','2010-08-28 00:00:00','ADMIN','2010-08-28 00:00:00','LIVE',1),(34,'08:15:00','8:15 AM','IMPLEMENTATION','2010-08-28 00:00:00','ADMIN','2010-08-28 00:00:00','LIVE',1),(35,'08:30:00','8:30 AM','IMPLEMENTATION','2010-08-28 00:00:00','ADMIN','2010-08-28 00:00:00','LIVE',1),(36,'08:45:00','8:45 AM','IMPLEMENTATION','2010-08-28 00:00:00','ADMIN','2010-08-28 00:00:00','LIVE',1),(37,'09:00:00','9:00 AM','IMPLEMENTATION','2010-08-28 00:00:00','ADMIN','2010-08-28 00:00:00','LIVE',1),(38,'09:15:00','9:15 AM','IMPLEMENTATION','2010-08-28 00:00:00','ADMIN','2010-08-28 00:00:00','LIVE',1),(39,'09:30:00','9:30 AM','IMPLEMENTATION','2010-08-28 00:00:00','ADMIN','2010-08-28 00:00:00','LIVE',1),(40,'09:45:00','9:45 AM','IMPLEMENTATION','2010-08-28 00:00:00','ADMIN','2010-08-28 00:00:00','LIVE',1),(41,'10:00:00','10:00 AM','IMPLEMENTATION','2010-08-28 00:00:00','ADMIN','2010-08-28 00:00:00','LIVE',1),(42,'10:15:00','10:15 AM','IMPLEMENTATION','2010-08-28 00:00:00','ADMIN','2010-08-28 00:00:00','LIVE',1),(43,'10:30:00','10:30 AM','IMPLEMENTATION','2010-08-28 00:00:00','ADMIN','2010-08-28 00:00:00','LIVE',1),(44,'10:45:00','10:45 AM','IMPLEMENTATION','2010-08-28 00:00:00','ADMIN','2010-08-28 00:00:00','LIVE',1),(45,'11:00:00','11:00 AM','IMPLEMENTATION','2010-08-28 00:00:00','ADMIN','2010-08-28 00:00:00','LIVE',1),(46,'11:15:00','11:15 AM','IMPLEMENTATION','2010-08-28 00:00:00','ADMIN','2010-08-28 00:00:00','LIVE',1),(47,'11:30:00','11:30 AM','IMPLEMENTATION','2010-08-28 00:00:00','ADMIN','2010-08-28 00:00:00','LIVE',1),(48,'11:45:00','11:45 AM','IMPLEMENTATION','2010-08-28 00:00:00','ADMIN','2010-08-28 00:00:00','LIVE',1),(49,'12:00:00','12:00 PM','IMPLEMENTATION','2010-08-28 00:00:00','ADMIN','2010-08-28 00:00:00','LIVE',1),(50,'12:15:00','12:15 PM','IMPLEMENTATION','2010-08-28 00:00:00','ADMIN','2010-08-28 00:00:00','LIVE',1),(51,'12:30:00','12:30 PM','IMPLEMENTATION','2010-08-28 00:00:00','ADMIN','2010-08-28 00:00:00','LIVE',1),(52,'12:45:00','12:45 PM','IMPLEMENTATION','2010-08-28 00:00:00','ADMIN','2010-08-28 00:00:00','LIVE',1),(53,'13:00:00','1:00 PM','IMPLEMENTATION','2010-08-28 00:00:00','ADMIN','2010-08-28 00:00:00','LIVE',1),(54,'13:15:00','1:15 PM','IMPLEMENTATION','2010-08-28 00:00:00','ADMIN','2010-08-28 00:00:00','LIVE',1),(55,'13:30:00','1:30 PM','IMPLEMENTATION','2010-08-28 00:00:00','ADMIN','2010-08-28 00:00:00','LIVE',1),(56,'13:45:00','1:45 PM','IMPLEMENTATION','2010-08-28 00:00:00','ADMIN','2010-08-28 00:00:00','LIVE',1),(57,'14:00:00','2:00 PM','IMPLEMENTATION','2010-08-28 00:00:00','ADMIN','2010-08-28 00:00:00','LIVE',1),(58,'14:15:00','2:15 PM','IMPLEMENTATION','2010-08-28 00:00:00','ADMIN','2010-08-28 00:00:00','LIVE',1),(59,'14:30:00','2:30 PM','IMPLEMENTATION','2010-08-28 00:00:00','ADMIN','2010-08-28 00:00:00','LIVE',1),(60,'14:45:00','2:45 PM','IMPLEMENTATION','2010-08-28 00:00:00','ADMIN','2010-08-28 00:00:00','LIVE',1),(61,'15:00:00','3:00 PM','IMPLEMENTATION','2010-08-28 00:00:00','ADMIN','2010-08-28 00:00:00','LIVE',1),(62,'15:15:00','3:15 PM','IMPLEMENTATION','2010-08-28 00:00:00','ADMIN','2010-08-28 00:00:00','LIVE',1),(63,'15:30:00','3:30 PM','IMPLEMENTATION','2010-08-28 00:00:00','ADMIN','2010-08-28 00:00:00','LIVE',1),(64,'15:45:00','3:45 PM','IMPLEMENTATION','2010-08-28 00:00:00','ADMIN','2010-08-28 00:00:00','LIVE',1),(65,'16:00:00','4:00 PM','IMPLEMENTATION','2010-08-28 00:00:00','ADMIN','2010-08-28 00:00:00','LIVE',1),(66,'16:15:00','4:15 PM','IMPLEMENTATION','2010-08-28 00:00:00','ADMIN','2010-08-28 00:00:00','LIVE',1),(67,'16:30:00','4:30 PM','IMPLEMENTATION','2010-08-28 00:00:00','ADMIN','2010-08-28 00:00:00','LIVE',1),(68,'16:45:00','4:45 PM','IMPLEMENTATION','2010-08-28 00:00:00','ADMIN','2010-08-28 00:00:00','LIVE',1),(69,'17:00:00','5:00 PM','IMPLEMENTATION','2010-08-28 00:00:00','ADMIN','2010-08-28 00:00:00','LIVE',1),(70,'17:15:00','5:15 PM','IMPLEMENTATION','2010-08-28 00:00:00','ADMIN','2010-08-28 00:00:00','LIVE',1),(71,'17:30:00','5:30 PM','IMPLEMENTATION','2010-08-28 00:00:00','ADMIN','2010-08-28 00:00:00','LIVE',1),(72,'17:45:00','5:45 PM','IMPLEMENTATION','2010-08-28 00:00:00','ADMIN','2010-08-28 00:00:00','LIVE',1),(73,'18:00:00','6:00 PM','IMPLEMENTATION','2010-08-28 00:00:00','ADMIN','2010-08-28 00:00:00','LIVE',1),(74,'18:15:00','6:15 PM','IMPLEMENTATION','2010-08-28 00:00:00','ADMIN','2010-08-28 00:00:00','LIVE',1),(75,'18:30:00','6:30 PM','IMPLEMENTATION','2010-08-28 00:00:00','ADMIN','2010-08-28 00:00:00','LIVE',1),(76,'18:45:00','6:45 PM','IMPLEMENTATION','2010-08-28 00:00:00','ADMIN','2010-08-28 00:00:00','LIVE',1),(77,'19:00:00','7:00 PM','IMPLEMENTATION','2010-08-28 00:00:00','ADMIN','2010-08-28 00:00:00','LIVE',1),(78,'19:15:00','7:15 PM','IMPLEMENTATION','2010-08-28 00:00:00','ADMIN','2010-08-28 00:00:00','LIVE',1),(79,'19:30:00','7:30 PM','IMPLEMENTATION','2010-08-28 00:00:00','ADMIN','2010-08-28 00:00:00','LIVE',1),(80,'19:45:00','7:45 PM','IMPLEMENTATION','2010-08-28 00:00:00','ADMIN','2010-08-28 00:00:00','LIVE',1),(81,'20:00:00','8:00 PM','IMPLEMENTATION','2010-08-28 00:00:00','ADMIN','2010-08-28 00:00:00','LIVE',1),(82,'20:15:00','8:15 PM','IMPLEMENTATION','2010-08-28 00:00:00','ADMIN','2010-08-28 00:00:00','LIVE',1),(83,'20:30:00','8:30 PM','IMPLEMENTATION','2010-08-28 00:00:00','ADMIN','2010-08-28 00:00:00','LIVE',1),(84,'20:45:00','8:45 PM','IMPLEMENTATION','2010-08-28 00:00:00','ADMIN','2010-08-28 00:00:00','LIVE',1),(85,'21:00:00','9:00 PM','IMPLEMENTATION','2010-08-28 00:00:00','ADMIN','2010-08-28 00:00:00','LIVE',1),(86,'21:15:00','9:15 PM','IMPLEMENTATION','2010-08-28 00:00:00','ADMIN','2010-08-28 00:00:00','LIVE',1),(87,'21:30:00','9:30 PM','IMPLEMENTATION','2010-08-28 00:00:00','ADMIN','2010-08-28 00:00:00','LIVE',1),(88,'21:45:00','9:45 PM','IMPLEMENTATION','2010-08-28 00:00:00','ADMIN','2010-08-28 00:00:00','LIVE',1),(89,'22:00:00','10:00 PM','IMPLEMENTATION','2010-08-28 00:00:00','ADMIN','2010-08-28 00:00:00','LIVE',1),(90,'22:15:00','10:15 PM','IMPLEMENTATION','2010-08-28 00:00:00','ADMIN','2010-08-28 00:00:00','LIVE',1),(91,'22:30:00','10:30 PM','IMPLEMENTATION','2010-08-28 00:00:00','ADMIN','2010-08-28 00:00:00','LIVE',1),(92,'22:45:00','10:45 PM','IMPLEMENTATION','2010-08-28 00:00:00','ADMIN','2010-08-28 00:00:00','LIVE',1),(93,'23:00:00','11:00 PM','IMPLEMENTATION','2010-08-28 00:00:00','ADMIN','2010-08-28 00:00:00','LIVE',1),(94,'23:15:00','11:15 PM','IMPLEMENTATION','2010-08-28 00:00:00','ADMIN','2010-08-28 00:00:00','LIVE',1),(95,'23:30:00','11:30 PM','IMPLEMENTATION','2010-08-28 00:00:00','ADMIN','2010-08-28 00:00:00','LIVE',1),(96,'23:45:00','11:45 PM','IMPLEMENTATION','2010-08-28 00:00:00','ADMIN','2010-08-28 00:00:00','LIVE',1);
/*!40000 ALTER TABLE `daytimes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `daytimes_hs`
--

DROP TABLE IF EXISTS `daytimes_hs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `daytimes_hs` (
  `id` int(11) unsigned NOT NULL,
  `daytime_id` time NOT NULL,
  `description` varchar(25) NOT NULL,
  `inputter` varchar(50) NOT NULL,
  `input_date` datetime NOT NULL,
  `authorizer` varchar(50) NOT NULL,
  `auth_date` datetime NOT NULL,
  `record_status` char(4) NOT NULL,
  `current_no` int(11) NOT NULL,
  PRIMARY KEY (`id`,`current_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `daytimes_hs`
--

LOCK TABLES `daytimes_hs` WRITE;
/*!40000 ALTER TABLE `daytimes_hs` DISABLE KEYS */;
/*!40000 ALTER TABLE `daytimes_hs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `daytimes_is`
--

DROP TABLE IF EXISTS `daytimes_is`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `daytimes_is` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `daytime_id` time DEFAULT NULL,
  `description` varchar(25) DEFAULT NULL,
  `inputter` varchar(50) DEFAULT NULL,
  `input_date` datetime DEFAULT NULL,
  `authorizer` varchar(50) DEFAULT NULL,
  `auth_date` datetime DEFAULT NULL,
  `record_status` char(4) DEFAULT NULL,
  `current_no` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_datetime_id` (`daytime_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `daytimes_is`
--

LOCK TABLES `daytimes_is` WRITE;
/*!40000 ALTER TABLE `daytimes_is` DISABLE KEYS */;
/*!40000 ALTER TABLE `daytimes_is` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `deliverynotes`
--

DROP TABLE IF EXISTS `deliverynotes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `deliverynotes` (
  `id` int(11) unsigned NOT NULL,
  `deliverynote_id` varchar(16) NOT NULL,
  `order_id` varchar(16) NOT NULL,
  `deliverynote_date` date NOT NULL,
  `details` text NOT NULL,
  `status` varchar(20) NOT NULL,
  `delivered_by` varchar(50) DEFAULT NULL,
  `delivery_date` date DEFAULT NULL,
  `returned_signed_by` varchar(50) DEFAULT NULL,
  `returned_signed_date` date DEFAULT NULL,
  `comments` text,
  `inputter` varchar(50) NOT NULL,
  `input_date` datetime NOT NULL,
  `authorizer` varchar(50) NOT NULL,
  `auth_date` datetime NOT NULL,
  `record_status` char(4) NOT NULL,
  `current_no` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_deliverynote_id` (`deliverynote_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `deliverynotes`
--

LOCK TABLES `deliverynotes` WRITE;
/*!40000 ALTER TABLE `deliverynotes` DISABLE KEYS */;
/*!40000 ALTER TABLE `deliverynotes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `deliverynotes_hs`
--

DROP TABLE IF EXISTS `deliverynotes_hs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `deliverynotes_hs` (
  `id` int(11) unsigned NOT NULL,
  `deliverynote_id` varchar(16) NOT NULL,
  `order_id` varchar(16) NOT NULL,
  `deliverynote_date` date NOT NULL,
  `details` text NOT NULL,
  `status` varchar(20) NOT NULL,
  `delivered_by` varchar(50) DEFAULT NULL,
  `delivery_date` date DEFAULT NULL,
  `returned_signed_by` varchar(50) DEFAULT NULL,
  `returned_signed_date` date DEFAULT NULL,
  `comments` text,
  `inputter` varchar(50) NOT NULL,
  `input_date` datetime NOT NULL,
  `authorizer` varchar(50) NOT NULL,
  `auth_date` datetime NOT NULL,
  `record_status` char(4) NOT NULL,
  `current_no` int(11) NOT NULL,
  PRIMARY KEY (`id`,`current_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `deliverynotes_hs`
--

LOCK TABLES `deliverynotes_hs` WRITE;
/*!40000 ALTER TABLE `deliverynotes_hs` DISABLE KEYS */;
/*!40000 ALTER TABLE `deliverynotes_hs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `deliverynotes_is`
--

DROP TABLE IF EXISTS `deliverynotes_is`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `deliverynotes_is` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `deliverynote_id` varchar(16) DEFAULT NULL,
  `order_id` varchar(16) DEFAULT NULL,
  `deliverynote_date` date DEFAULT NULL,
  `details` text,
  `status` varchar(20) DEFAULT NULL,
  `delivered_by` varchar(50) DEFAULT NULL,
  `delivery_date` date DEFAULT NULL,
  `returned_signed_by` varchar(50) DEFAULT NULL,
  `returned_signed_date` date DEFAULT NULL,
  `comments` text,
  `inputter` varchar(50) DEFAULT NULL,
  `input_date` datetime DEFAULT NULL,
  `authorizer` varchar(50) DEFAULT NULL,
  `auth_date` datetime DEFAULT NULL,
  `record_status` char(4) DEFAULT NULL,
  `current_no` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_deliverynote_id` (`deliverynote_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `deliverynotes_is`
--

LOCK TABLES `deliverynotes_is` WRITE;
/*!40000 ALTER TABLE `deliverynotes_is` DISABLE KEYS */;
/*!40000 ALTER TABLE `deliverynotes_is` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `departments`
--

DROP TABLE IF EXISTS `departments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `departments` (
  `id` int(11) unsigned NOT NULL,
  `department_id` varchar(50) NOT NULL,
  `description` varchar(255) NOT NULL,
  `inputter` varchar(50) NOT NULL,
  `input_date` datetime NOT NULL,
  `authorizer` varchar(50) NOT NULL,
  `auth_date` datetime NOT NULL,
  `record_status` char(4) NOT NULL,
  `current_no` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_department_id` (`department_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `departments`
--

LOCK TABLES `departments` WRITE;
/*!40000 ALTER TABLE `departments` DISABLE KEYS */;
INSERT INTO `departments` VALUES (501,'EXECUTIVE','Executive / Management','IMPLEMENTATION','2011-03-28 00:00:00','ADMIN','2011-03-28 00:00:00','LIVE',1),(502,'ADMINISTRATION','Administration Department','IMPLEMENTATION','2011-03-28 00:00:00','ADMIN','2011-03-28 00:00:00','LIVE',1),(503,'ACCOUNTS','Accounts Department','IMPLEMENTATION','2011-03-28 00:00:00','ADMIN','2011-03-28 00:00:00','LIVE',1),(504,'INFORMATION.TECHNOLOGY','IT Department','IMPLEMENTATION','2011-03-28 00:00:00','ADMIN','2011-03-28 00:00:00','LIVE',1),(505,'SALES','Sales Department','IMPLEMENTATION','2011-03-28 00:00:00','ADMIN','2011-03-28 00:00:00','LIVE',1),(506,'TECHNICAL','Technical Department','IMPLEMENTATION','2011-03-28 00:00:00','ADMIN','2011-03-28 00:00:00','LIVE',1),(507,'SUPPORT.SERVICES','Support Services','IMPLEMENTATION','2011-03-28 00:00:00','ADMIN','2011-03-28 00:00:00','LIVE',1);
/*!40000 ALTER TABLE `departments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `departments_hs`
--

DROP TABLE IF EXISTS `departments_hs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `departments_hs` (
  `id` int(11) unsigned NOT NULL,
  `department_id` varchar(50) NOT NULL,
  `description` varchar(255) NOT NULL,
  `inputter` varchar(50) NOT NULL,
  `input_date` datetime NOT NULL,
  `authorizer` varchar(50) NOT NULL,
  `auth_date` datetime NOT NULL,
  `record_status` char(4) NOT NULL,
  `current_no` int(11) NOT NULL,
  PRIMARY KEY (`id`,`current_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `departments_hs`
--

LOCK TABLES `departments_hs` WRITE;
/*!40000 ALTER TABLE `departments_hs` DISABLE KEYS */;
/*!40000 ALTER TABLE `departments_hs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `departments_is`
--

DROP TABLE IF EXISTS `departments_is`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `departments_is` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `department_id` varchar(50) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `inputter` varchar(50) DEFAULT NULL,
  `input_date` datetime DEFAULT NULL,
  `authorizer` varchar(50) DEFAULT NULL,
  `auth_date` datetime DEFAULT NULL,
  `record_status` char(4) DEFAULT NULL,
  `current_no` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_department_id` (`department_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `departments_is`
--

LOCK TABLES `departments_is` WRITE;
/*!40000 ALTER TABLE `departments_is` DISABLE KEYS */;
/*!40000 ALTER TABLE `departments_is` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dlorders`
--

DROP TABLE IF EXISTS `dlorders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dlorders` (
  `id` int(11) unsigned NOT NULL,
  `order_id` varchar(12) NOT NULL,
  `batch_id` varchar(20) NOT NULL,
  `customer_id` varchar(14) NOT NULL,
  `tax_id` varchar(10) NOT NULL,
  `name` varchar(50) NOT NULL,
  `contact` varchar(50) NOT NULL,
  `street` varchar(50) NOT NULL,
  `city` varchar(50) NOT NULL,
  `country` varchar(50) NOT NULL,
  `phone` varchar(21) NOT NULL,
  `paymentterms` varchar(20) NOT NULL,
  `cdate` date NOT NULL,
  `ctime` time NOT NULL,
  `orderlines` text,
  `inputter` varchar(50) NOT NULL,
  `input_date` datetime NOT NULL,
  `authorizer` varchar(50) NOT NULL,
  `auth_date` datetime NOT NULL,
  `record_status` char(4) NOT NULL,
  `current_no` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_order_id` (`order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dlorders`
--

LOCK TABLES `dlorders` WRITE;
/*!40000 ALTER TABLE `dlorders` DISABLE KEYS */;
/*!40000 ALTER TABLE `dlorders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dlorders_hs`
--

DROP TABLE IF EXISTS `dlorders_hs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dlorders_hs` (
  `id` int(11) unsigned NOT NULL,
  `order_id` varchar(12) NOT NULL,
  `batch_id` varchar(20) NOT NULL,
  `customer_id` varchar(14) NOT NULL,
  `tax_id` varchar(10) NOT NULL,
  `name` varchar(50) NOT NULL,
  `contact` varchar(50) NOT NULL,
  `street` varchar(50) NOT NULL,
  `city` varchar(50) NOT NULL,
  `country` varchar(50) NOT NULL,
  `phone` varchar(21) NOT NULL,
  `paymentterms` varchar(20) NOT NULL,
  `cdate` date NOT NULL,
  `ctime` time NOT NULL,
  `orderlines` text,
  `inputter` varchar(50) NOT NULL,
  `input_date` datetime NOT NULL,
  `authorizer` varchar(50) NOT NULL,
  `auth_date` datetime NOT NULL,
  `record_status` char(4) NOT NULL,
  `current_no` int(11) NOT NULL,
  PRIMARY KEY (`id`,`current_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dlorders_hs`
--

LOCK TABLES `dlorders_hs` WRITE;
/*!40000 ALTER TABLE `dlorders_hs` DISABLE KEYS */;
/*!40000 ALTER TABLE `dlorders_hs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dlorders_is`
--

DROP TABLE IF EXISTS `dlorders_is`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dlorders_is` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `order_id` varchar(12) DEFAULT NULL,
  `batch_id` varchar(20) DEFAULT NULL,
  `customer_id` varchar(14) DEFAULT NULL,
  `tax_id` varchar(10) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  `contact` varchar(50) DEFAULT NULL,
  `street` varchar(50) DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL,
  `country` varchar(50) DEFAULT NULL,
  `phone` varchar(21) DEFAULT NULL,
  `paymentterms` varchar(20) DEFAULT NULL,
  `cdate` date DEFAULT NULL,
  `ctime` time DEFAULT NULL,
  `orderlines` text,
  `inputter` varchar(50) DEFAULT NULL,
  `input_date` datetime DEFAULT NULL,
  `authorizer` varchar(50) DEFAULT NULL,
  `auth_date` datetime DEFAULT NULL,
  `record_status` char(4) DEFAULT NULL,
  `current_no` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_order_id` (`order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dlorders_is`
--

LOCK TABLES `dlorders_is` WRITE;
/*!40000 ALTER TABLE `dlorders_is` DISABLE KEYS */;
/*!40000 ALTER TABLE `dlorders_is` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dlors`
--

DROP TABLE IF EXISTS `dlors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dlors` (
  `id` int(11) unsigned NOT NULL,
  `request_id` varchar(30) NOT NULL,
  `description` varchar(255) NOT NULL,
  `run` enum('N','Y') NOT NULL DEFAULT 'N',
  `comments` text,
  `inputter` varchar(50) NOT NULL,
  `input_date` datetime NOT NULL,
  `authorizer` varchar(50) NOT NULL,
  `auth_date` datetime NOT NULL,
  `record_status` char(4) NOT NULL,
  `current_no` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_request_id` (`request_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dlors`
--

LOCK TABLES `dlors` WRITE;
/*!40000 ALTER TABLE `dlors` DISABLE KEYS */;
INSERT INTO `dlors` VALUES (1001,'DEFAULT','Download of Handshake Orders in Processing Status','N','','ADMIN','2013-09-14 04:51:01','ADMIN','2013-09-14 04:51:01','LIVE',5);
/*!40000 ALTER TABLE `dlors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dlors_hs`
--

DROP TABLE IF EXISTS `dlors_hs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dlors_hs` (
  `id` int(11) unsigned NOT NULL,
  `request_id` varchar(30) NOT NULL,
  `description` varchar(255) NOT NULL,
  `run` enum('N','Y') NOT NULL DEFAULT 'N',
  `comments` text,
  `inputter` varchar(50) NOT NULL,
  `input_date` datetime NOT NULL,
  `authorizer` varchar(50) NOT NULL,
  `auth_date` datetime NOT NULL,
  `record_status` char(4) NOT NULL,
  `current_no` int(11) NOT NULL,
  PRIMARY KEY (`id`,`current_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dlors_hs`
--

LOCK TABLES `dlors_hs` WRITE;
/*!40000 ALTER TABLE `dlors_hs` DISABLE KEYS */;
INSERT INTO `dlors_hs` VALUES (1001,'DEFAULT','Download of Handshake Orders in Processing Status','N',NULL,'ADMIN','2013-09-14 00:00:00','ADMIN','2013-09-14 00:00:00','HIST',1),(1001,'DEFAULT','Download of Handshake Orders in Processing Status','Y','','ADMIN','2013-09-14 04:32:52','ADMIN','2013-09-14 04:32:52','HIST',2),(1001,'DEFAULT','Download of Handshake Orders in Processing Status','N','','ADMIN','2013-09-14 04:40:32','ADMIN','2013-09-14 04:40:32','HIST',3),(1001,'DEFAULT','Download of Handshake Orders in Processing Status','N','','ADMIN','2013-09-14 04:48:06','ADMIN','2013-09-14 04:48:06','HIST',4);
/*!40000 ALTER TABLE `dlors_hs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dlors_is`
--

DROP TABLE IF EXISTS `dlors_is`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dlors_is` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `request_id` varchar(30) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `run` enum('N','Y') DEFAULT 'N',
  `comments` text,
  `inputter` varchar(50) DEFAULT NULL,
  `input_date` datetime DEFAULT NULL,
  `authorizer` varchar(50) DEFAULT NULL,
  `auth_date` datetime DEFAULT NULL,
  `record_status` char(4) DEFAULT NULL,
  `current_no` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_request_id` (`request_id`)
) ENGINE=InnoDB AUTO_INCREMENT=1002 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dlors_is`
--

LOCK TABLES `dlors_is` WRITE;
/*!40000 ALTER TABLE `dlors_is` DISABLE KEYS */;
/*!40000 ALTER TABLE `dlors_is` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `enquirydefs`
--

DROP TABLE IF EXISTS `enquirydefs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `enquirydefs` (
  `id` int(11) unsigned NOT NULL,
  `enquirydef_id` varchar(255) DEFAULT NULL,
  `controller` varchar(255) NOT NULL,
  `dflag` enum('Y','N') DEFAULT NULL,
  `formfields` text,
  `tablename` varchar(255) NOT NULL,
  `model` varchar(255) NOT NULL,
  `view` varchar(255) NOT NULL,
  `idfield` varchar(50) NOT NULL,
  `enqheader` varchar(255) NOT NULL,
  `showfilter` tinyint(1) NOT NULL,
  `printuser` tinyint(1) NOT NULL,
  `printdatetime` tinyint(1) NOT NULL,
  `inputter` varchar(50) NOT NULL,
  `input_date` datetime NOT NULL,
  `authorizer` varchar(50) NOT NULL,
  `auth_date` datetime NOT NULL,
  `record_status` char(4) NOT NULL,
  `current_no` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uniq_controller` (`controller`),
  KEY `uniq_enquirydef_id` (`enquirydef_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `enquirydefs`
--

LOCK TABLES `enquirydefs` WRITE;
/*!40000 ALTER TABLE `enquirydefs` DISABLE KEYS */;
INSERT INTO `enquirydefs` VALUES (401,'core_enquiry_orders','orders_enq','Y','<?xml version=\'1.0\' standalone=\'yes\'?>\n<formfields>	\n<field><name>id</name><label>Id</label><filterfield>yes</filterfield></field>	\n<field><name>order_id</name><label>Order Id</label><filterfield>yes</filterfield></field>\n<field><name>branch_id</name><label>Branch Id</label><filterfield>yes</filterfield></field>	\n<field><name>customer_id</name><label>Customer Id</label><filterfield>yes</filterfield></field>	\n<field><name>is_co</name><label>Charge Order</label><filterfield>no</filterfield></field>	\r\n<field><name>cc_id</name><label>Charge Customer Id</label><filterfield>no</filterfield></field>	\r\n<field><name>first_name</name><label>First Name</label><filterfield>yes</filterfield></field>\n<field><name>last_name</name><label>Last Name</label><filterfield>yes</filterfield></field>\n<field><name>order_details</name><label>Order Details</label><filterfield>no</filterfield></field>\r\n<field><name>customer_type</name><label>Customer Type</label><filterfield>yes</filterfield></field>\n<field><name>address1</name><label>Address1</label><filterfield>no</filterfield></field>\n<field><name>address2</name><label>Address2</label><filterfield>no</filterfield></field>\n<field><name>city</name><label>City</label><filterfield>no</filterfield></field>\n<field><name>phone_mobile1</name><label>Phone Mobile1</label><filterfield>no</filterfield></field>\n<field><name>phone_home</name><label>Phone Home</label><filterfield>no</filterfield></field>\n<field><name>phone_work</name><label>Phone Work</label><filterfield>no</filterfield></field>\n<field><name>order_date</name><label>Order Date</label><filterfield>yes</filterfield></field>\n<field><name>quotation_date</name><label>Quotation Date</label><filterfield>yes</filterfield></field>\n<field><name>invoice_date</name><label>Invoice Date</label><filterfield>yes</filterfield></field>\n<field><name>order_status</name><label>Order Status</label><filterfield>yes</filterfield></field>\n<field><name>inventory_checkout_status</name><label>Checkout Status</label><filterfield>yes</filterfield></field>\n<field><name>inventory_update_type</name><label>Update Type</label><filterfield>yes</filterfield></field>\n<field><name>inputter</name><label>Inputter</label><filterfield>yes</filterfield></field>	\r\n<field><name>input_date</name><label>Input Date</label><filterfield>no</filterfield></field>	\r\n<field><name>invoice_note</name><label>Invoice Note</label><filterfield>no</filterfield></field>\r\n<field><name>comments</name><label>Comments</label><filterfield>no</filterfield></field>\n<field><name>current_no</name><label>Current No</label><filterfield>no</filterfield></field>\n<field><name>extended_total</name><label>Sub Total</label><filterfield>no</filterfield></field>\n<field><name>discount_total</name><label>Discount Total</label><filterfield>no</filterfield></field>\n<field><name>tax_total</name><label>Tax Total</label><filterfield>no</filterfield></field>\n<field><name>order_total</name><label>Order Total</label><filterfield>no</filterfield></field>\n<field><name>payment_total</name><label>Payment Total</label><filterfield>no</filterfield></field>\n<field><name>balance</name><label>Balance</label><filterfield>no</filterfield></field>\n</formfields>','vw_orderbalances','EnqDB','enquiry/orders_view','order_id','Orders',1,1,1,'DUNSTAN.NESBIT','2012-07-06 14:03:04','DUNSTAN.NESBIT','2012-07-06 14:03:10','LIVE',2),(402,'core_enquiry_deliverynotes','deliverynotes_enq','Y','<?xml version=\'1.0\' standalone=\'yes\'?>\n<formfields>	\n<field><name>id</name><label>Id</label><filterfield>yes</filterfield></field>	\n<field><name>deliverynote_id</name><label>Deliverynote Id</label><filterfield>yes</filterfield></field>\r\n<field><name>invoice_id</name><label>Invoice Id</label><filterfield>yes</filterfield></field>\r\n<field><name>order_id</name><label>Order Id</label><filterfield>yes</filterfield></field>\n<field><name>deliverynote_date</name><label>Deliverynote Date</label><filterfield>yes</filterfield></field>\r\n<field><name>status</name><label>Delivery Status</label><filterfield>no</filterfield></field>\r\n<field><name>delivered_by</name><label>Delivered By</label><filterfield>yes</filterfield></field>\r\n<field><name>delivery_date</name><label>Delivery Date</label><filterfield>yes</filterfield></field>\r\n<field><name>returned_signed_by</name><label>Returned Signed By</label><filterfield>no</filterfield></field>\r\n<field><name>returned_signed_date</name><label>Returned Signed Date</label><filterfield>no</filterfield></field>\r\n<field><name>comments</name><label>Comments</label><filterfield>no</filterfield></field>    \r\n<field><name>branch_id</name><label>Branch Id</label><filterfield>yes</filterfield></field>	\r\n<field><name>customer_id</name><label>Customer Id</label><filterfield>yes</filterfield></field>	\r\n<field><name>is_co</name><label>Charge Order</label><filterfield>no</filterfield></field>	\r\n<field><name>cc_id</name><label>Charge Customer Id</label><filterfield>no</filterfield></field>	\r\n<field><name>first_name</name><label>First Name</label><filterfield>yes</filterfield></field>\r\n<field><name>last_name</name><label>Last Name</label><filterfield>yes</filterfield></field>\r\n<field><name>customer_type</name><label>Customer Type</label><filterfield>no</filterfield></field>\r\n<field><name>address1</name><label>Address1</label><filterfield>no</filterfield></field>\r\n<field><name>address2</name><label>Address2</label><filterfield>no</filterfield></field>\r\n<field><name>city</name><label>City</label><filterfield>no</filterfield></field>\r\n<field><name>phone_mobile1</name><label>Phone Mobile1</label><filterfield>no</filterfield></field>\r\n<field><name>phone_home</name><label>Phone Home</label><filterfield>no</filterfield></field>\r\n<field><name>phone_work</name><label>Phone Work</label><filterfield>no</filterfield></field>\r\n<field><name>order_date</name><label>Order Date</label><filterfield>yes</filterfield></field>\r\n<field><name>order_status</name><label>Order Status</label><filterfield>no</filterfield></field>\r\n<field><name>inventory_checkout_status</name><label>Checkout Status</label><filterfield>no</filterfield></field>\r\n<field><name>inventory_update_type</name><label>Update Type</label><filterfield>no</filterfield></field>\r\n<field><name>inputter</name><label>Inputter</label><filterfield>no</filterfield></field>	\r\n<field><name>input_date</name><label>Input Date</label><filterfield>no</filterfield></field>	\r\n</formfields>','vw_deliverynotes','EnqDB','enquiry/deliverynotes_view','deliverynote_id','Delivery Notes',1,1,1,'ADMIN','2013-03-16 04:00:54','ADMIN','2013-03-16 04:01:01','LIVE',1),(501,'core_enquiry_vehicleaccount','vehicleaccount_enq','Y','<?xml version=\'1.0\' standalone=\'yes\'?>\r\n<formfields>\r\n	<field><name>id</name><label>Id</label><filterfield>no</filterfield></field>\r\n	<field><name>vehicle_id</name><label>Vehicle Id</label><filterfield>yes</filterfield></field>\r\n	<field><name>owner_id</name><label>Customer Id</label><filterfield>yes</filterfield></field>\r\n	<field><name>device_id</name><label>Device Id</label><filterfield>yes</filterfield></field>\r\n	<field><name>chassis_number</name><label>Chassis Number</label><filterfield>no</filterfield></field>\r\n	<field><name>make</name><label>Vehicle Make</label><filterfield>no</filterfield></field>\r\n	<field><name>vehicle_model</name><label>Vehicle Model</label><filterfield>no</filterfield></field>\r\n	<field><name>color</name><label>Vehicle Color</label><filterfield>no</filterfield></field>\r\n	<field><name>vehicletype</name><label>Vehicle Type</label><filterfield>no</filterfield></field>\r\n	<field><name>vehicleusage</name><label>Vehicle Usage</label><filterfield>no</filterfield></field>\r\n	<field><name>installer</name><label>Installer</label><filterfield>no</filterfield></field>\r\n	<field><name>location</name><label>Location</label><filterfield>no</filterfield></field>\r\n	<field><name>installation_date</name><label>Installation Date</label><filterfield>yes</filterfield></field>\r\n	<field><name>comments</name><label>Comments</label><filterfield>no</filterfield></field>\r\n	<field><name>customer_type</name><label>Customer Type</label><filterfield>no</filterfield></field>\r\n	<field><name>business_type</name><label>Business Type</label><filterfield>no</filterfield></field>\r\n	<field><name>first_name</name><label>First Name</label><filterfield>yes</filterfield></field>\r\n	<field><name>last_name</name><label>Last Name</label><filterfield>yes</filterfield></field>\r\n	<field><name>address1</name><label>Street</label><filterfield>no</filterfield></field>\r\n	<field><name>address2</name><label>Village</label><filterfield>no</filterfield></field>\r\n	<field><name>city</name><label>City</label><filterfield>no</filterfield></field>\r\n	<field><name>date_of_birth</name><label>Date Of Birth</label><filterfield>no</filterfield></field>\r\n	<field><name>gender</name><label>Gender</label><filterfield>no</filterfield></field>\r\n	<field><name>phone_home</name><label>Phone(Home)</label><filterfield>no</filterfield></field>\r\n	<field><name>phone_work</name><label>Phone(Work)</label><filterfield>no</filterfield></field>\r\n	<field><name>phone_mobile1</name><label>Phone(Mobile1)</label><filterfield>no</filterfield></field>\r\n	<field><name>phone_mobile2</name><label>Phone(Mobile2)</label><filterfield>no</filterfield></field>\r\n	<field><name>email_address</name><label>Email Address</label><filterfield>no</filterfield></field>\r\n	<field><name>driver_permit</name><label>Driver Permit#</label><filterfield>no</filterfield></field>\r\n	<field><name>driver_permit_expiry_date</name><label>Driver Permit Expiry Date</label><filterfield>no</filterfield></field>\r\n	<field><name>emergency_contact</name><label>Emergency Contact</label><filterfield>no</filterfield></field>\r\n	<field><name>emergency_contact_phone</name><label>Emergency Contact Phone#</label><filterfield>no</filterfield></field>\r\n	<field><name>branch_id</name><label>Branch Id</label><filterfield>no</filterfield></field>\r\n	<field><name>referrer_id</name><label>Referrer Id</label><filterfield>no</filterfield></field>\r\n	<field><name>customer_comments</name><label>Customer Comments</label><filterfield>no</filterfield></field>\r\n	<field><name>device_tag_id</name><label>Device Tag Id</label><filterfield>no</filterfield></field>\r\n	<field><name>device_model</name><label>Device Model</label><filterfield>no</filterfield></field>\r\n	<field><name>device_status</name><label>Device Status</label><filterfield>yes</filterfield></field>\r\n	<field><name>warranty_expiry_date</name><label>Warranty Expiry Date</label><filterfield>no</filterfield></field>\r\n	<field><name>passcode</name><label>Passcode</label><filterfield>no</filterfield></field>\r\n	<field><name>sms_enabled</name><label>SMS Enabled</label><filterfield>no</filterfield></field>\r\n	<field><name>gprs_enabled</name><label>GPRS Enabled</label><filterfield>no</filterfield></field>\r\n	<field><name>imei</name><label>IMEI#</label><filterfield>yes</filterfield></field>\r\n	<field><name>phone_device</name><label>Device/System#</label><filterfield>yes</filterfield></field>\r\n	<field><name>phone_textback1</name><label>Primary Contact#</label><filterfield>yes</filterfield></field>\r\n	<field><name>phone_textback2</name><label>Secondary Contact#</label><filterfield>no</filterfield></field>\r\n	<field><name>sms_server</name><label>Mapinfo Server#</label><filterfield>no</filterfield></field>\r\n	<field><name>gprs_server</name><label>Realtime Server</label><filterfield>no</filterfield></field>\r\n	<field><name>realtime_useraccount</name><label>Realtime User Account</label><filterfield>no</filterfield></field>\r\n	<field><name>realtime_password</name><label>Realtime User Password</label><filterfield>no</filterfield></field>\r\n	<field><name>realtime_appname</name><label>Realtime AppName</label><filterfield>no</filterfield></field>\r\n	<field><name>order_id</name><label>Order/Invoice#</label><filterfield>no</filterfield></field>\r\n	<field><name>device_comments</name><label>Device Comments</label><filterfield>no</filterfield></field>\r\n	<field><name>plate</name><label>Plate</label><filterfield>no</filterfield></field>\r\n	<field><name>security_code</name><label>Security Code</label><filterfield>no</filterfield></field>\r\n</formfields>','vw_vehicle_accounts','EnqDB','enquiry/vehicleaccount_view','vehicle_id','Vehicle Account Summary',1,1,1,'IMPLEMENTATION','2011-04-28 00:00:00','ADMIN','2011-04-28 00:00:00','LIVE',1),(502,'core_enquiry_pendingsmsaccounts','pendingsmsaccounts_enq','Y','<?xml version=\'1.0\' standalone=\'yes\'?>\r\n<formfields>\r\n	<field><name>vehicle_id</name><label>Vehicle Id</label><filterfield>yes</filterfield></field>\r\n	<field><name>telno</name><label>Phone(Device#)</label><filterfield>yes</filterfield></field>\r\n	<field><name>username</name><label>Username</label><filterfield>yes</filterfield></field>\r\n	<field><name>mobile</name><label>Mobile</label><filterfield>yes</filterfield></field>\r\n	<field><name>duplicate_telno</name><label>Duplicate_Phone(Device#)</label><filterfield>yes</filterfield></field>\r\n</formfields>','vw_telbooks_available','EnqDB','enquiry/pendingsmsaccounts_view','vehicle_id','SMS Accounts Pending Setup',1,1,1,'IMPLEMENTATION','2011-08-08 00:00:00','ADMIN','2011-08-08 00:00:00','LIVE',1),(503,'core_enquiry_certofinstallation','certofinstallation_enq','Y','<?xml version=\'1.0\' standalone=\'yes\'?>\r\n<formfields>\r\n	<field><name>id</name><label>Id</label><filterfield>no</filterfield></field>\r\n	<field><name>vehicle_id</name><label>Vehicle Id</label><filterfield>yes</filterfield></field>\r\n	<field><name>certificate_id</name><label>Certificate Id</label><filterfield>yes</filterfield></field>\r\n	<field><name>certificate_status</name><label>Certificate Status</label><filterfield>yes</filterfield></field>\r\n	<field><name>chassis_number</name><label>Chassis Number</label><filterfield>no</filterfield></field>\r\n	<field><name>vehicle_type</name><label>Vehicle Type</label><filterfield>no</filterfield></field>>\r\n	<field><name>vehicle_make</name><label>Vehicle Make</label><filterfield>no</filterfield></field>\r\n	<field><name>vehicle_model</name><label>Vehicle Model</label><filterfield>no</filterfield></field>\r\n	<field><name>vehicle_colour</name><label>Vehicle Colour</label><filterfield>no</filterfield></field>\r\n	<field><name>first_name</name><label>First Name</label><filterfield>yes</filterfield></field>\r\n	<field><name>last_name</name><label>Last Name</label><filterfield>yes</filterfield></field>\r\n	<field><name>address1</name><label>Street</label><filterfield>no</filterfield></field>\r\n	<field><name>address2</name><label>Village</label><filterfield>no</filterfield></field>\r\n	<field><name>city</name><label>City</label><filterfield>no</filterfield></field>\r\n	<field><name>installation_type</name><label>Installation Type</label><filterfield>no</filterfield></field>\r\n	<field><name>device_model</name><label>Device Model</label><filterfield>no</filterfield></field>\r\n	<field><name>device_serial_no</name><label>Device Serial#</label><filterfield>no</filterfield></field>\r\n	<field><name>issue_date</name><label>Issue Date</label><filterfield>yes</filterfield></field>\r\n	<field><name>expiry_date</name><label>Expiry Date</label><filterfield>yes</filterfield></field>\r\n	<field><name>commisioning_fld01</name><label>Multipoint immobilization</label><filterfield>no</filterfield></field>\r\n	<field><name>commisioning_fld02</name><label>SMS tracking availability</label><filterfield>no</filterfield></field>\r\n	<field><name>commisioning_fld03</name><label>GPRS tracking availability</label><filterfield>no</filterfield></field>\r\n	<field><name>commisioning_fld04</name><label>Cell tower id acquisition</label><filterfield>no</filterfield></field>\r\n	<field><name>commisioning_fld05</name><label>Lithium ion battery backup</label><filterfield>no</filterfield></field>\r\n	<field><name>commisioning_fld06</name><label>Anti tampering alerts</label><filterfield>no</filterfield></field>\r\n	<field><name>commisioning_fld07</name><label>User and call center tracking ability</label><filterfield>no</filterfield></field>\r\n	<field><name>commisioning_fld08</name><label>Wiring free of defects</label><filterfield>no</filterfield></field>\r\n	<field><name>commisioning_fld09</name><label>GPS triangulation</label><filterfield>no</filterfield></field>\r\n	<field><name>commisioning_fld10</name><label>Remote buttons checked</label><filterfield>no</filterfield></field>\r\n	<field><name>commisioning_fld11</name><label>In-vehicle audio monitoring checked</label><filterfield>no</filterfield></field>\r\n	<field><name>commisioning_fld12</name><label>Location secure and hidden</label><filterfield>no</filterfield></field>\r\n	<field><name>usrinstr_fld01</name><label>How to GPS pinpoint vehicle</label><filterfield>no</filterfield></field>\r\n	<field><name>usrinstr_fld02</name><label>How to shutdown vehicle and restore</label><filterfield>no</filterfield></field>\r\n	<field><name>usrinstr_fld03</name><label>How to interpert standard SMS responses</label><filterfield>no</filterfield></field>\r\n	<field><name>usrinstr_fld04</name><label>How to listen in on in-vehicle audio</label><filterfield>no</filterfield></field>\r\n	<field><name>usrinstr_fld05</name><label>How locate vehicle on Google map</label><filterfield>no</filterfield></field>\r\n	<field><name>usrinstr_fld06</name><label>Actions to be taken in the event of emergency</label><filterfield>no</filterfield></field>\r\n	<field><name>usrinstr_fld07</name><label>Arm / Disarm from remote</label><filterfield>no</filterfield></field>\r\n	<field><name>usrinstr_fld08</name><label>Arm / Disarm from phone</label><filterfield>no</filterfield></field>\r\n	<field><name>usrinstr_fld09</name><label>How to interpret shock sensor alerts</label><filterfield>no</filterfield></field>\r\n	<field><name>usrinstr_fld10</name><label>How to interpet power alerts</label><filterfield>no</filterfield></field>\r\n	<field><name>usrinstr_fld11</name><label>How to interpet speed alerts</label><filterfield>no</filterfield></field>\r\n	<field><name>usrinstr_fld12</name><label>How to add SMS top-up credit</label><filterfield>no</filterfield></field>\r\n	<field><name>variations</name><label>Variations</label><filterfield>no</filterfield></field>\r\n	<field><name>validation_period</name><label>Validation Period</label><filterfield>no</filterfield></field>\r\n	<field><name>signature_name</name><label>Signature Name</label><filterfield>no</filterfield></field>\r\n	<field><name>signature_position</name><label>Signature Position</label><filterfield>no</filterfield></field>\r\n</formfields>','certofinstallations','EnqDB','enquiry/certofinstallation_view','certificate_id','Certificate Of Installation',1,1,1,'IMPLEMANTATION','2012-09-15 00:00:00','ADMIN','2012-09-15 00:00:00','LIVE',1),(504,'core_enquiry_trackers','trackers_enq','Y','<?xml version=\'1.0\' standalone=\'yes\'?>\n<formfields>\n	<field><name>id</name><label>Id</label><filterfield>yes</filterfield></field>\n	<field><name>serial_no</name><label>Serial-Imei</label><filterfield>yes</filterfield></field>\n	<field><name>device_id</name><label>Device Id</label><filterfield>yes</filterfield></field>\r\n	<field><name>item_status</name><label>Item Status</label><filterfield>yes</filterfield></field>\n	<field><name>product_id</name><label>Product Id</label><filterfield>yes</filterfield></field>\n	<field><name>stockbatch_id</name><label>Stock Batch Id</label><filterfield>yes</filterfield></field>\n	<field><name>stock_description</name><label>Stock Description</label><filterfield>no</filterfield></field>\n	<field><name>stockin_date</name><label>StockIn Date</label><filterfield>yes</filterfield></field>\n	<field><name>stockin_quantity</name><label>StockIn Qty</label><filterfield>yes</filterfield></field>\n	<field><name>stockbatch_status</name><label>Stock Batch Status</label><filterfield>no</filterfield></field>\n	<field><name>item_comments</name><label>Item Comments</label><filterfield>no</filterfield></field>\n	<field><name>it_comments</name><label>Stock Batch Comments</label><filterfield>no</filterfield></field>\n	<field><name>device_status</name><label>Device Status</label><filterfield>yes</filterfield></field>\r\n	<field><name>warranty_expiry_date</name><label>Warranty Expiry Date</label><filterfield>no</filterfield></field>\n	<field><name>passcode</name><label>Passcode</label><filterfield>no</filterfield></field>\n	<field><name>sms_enabled</name><label>SMS Enabled</label><filterfield>no</filterfield></field>\n	<field><name>gprs_enabled</name><label>GPRS Enabled</label><filterfield>no</filterfield></field>\n	<field><name>phone_device</name><label>Device/System#</label><filterfield>yes</filterfield></field>\n	<field><name>phone_textback1</name><label>Primary Contact#</label><filterfield>yes</filterfield></field>\n	<field><name>phone_textback2</name><label>Secondary Contact#</label><filterfield>no</filterfield></field>\n	<field><name>sms_server</name><label>Mapinfo Server#</label><filterfield>no</filterfield></field>\n	<field><name>gprs_server</name><label>Realtime Server</label><filterfield>no</filterfield></field>\n	<field><name>realtime_useraccount</name><label>Realtime User Account</label><filterfield>no</filterfield></field>\n	<field><name>realtime_password</name><label>Realtime User Password</label><filterfield>no</filterfield></field>\n	<field><name>realtime_appname</name><label>Realtime AppName</label><filterfield>no</filterfield></field>\n	<field><name>order_id</name><label>Order/Invoice#</label><filterfield>no</filterfield></field>\n	<field><name>device_comments</name><label>Device Comments</label><filterfield>no</filterfield></field>\n</formfields>','vw_trackers_info','EnqDB','enquiry/trackers_view','serial_no','Trackers',1,1,1,'ADMIN','2012-10-28 01:33:41','ADMIN','2012-10-28 02:08:54','LIVE',1);
/*!40000 ALTER TABLE `enquirydefs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `enquirydefs_hs`
--

DROP TABLE IF EXISTS `enquirydefs_hs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `enquirydefs_hs` (
  `id` int(11) unsigned NOT NULL,
  `enquirydef_id` varchar(255) DEFAULT NULL,
  `controller` varchar(255) NOT NULL,
  `dflag` enum('Y','N') DEFAULT NULL,
  `formfields` text,
  `tablename` varchar(255) NOT NULL,
  `model` varchar(255) NOT NULL,
  `view` varchar(255) NOT NULL,
  `idfield` varchar(50) NOT NULL,
  `enqheader` varchar(255) NOT NULL,
  `showfilter` tinyint(1) NOT NULL,
  `printuser` tinyint(1) NOT NULL,
  `printdatetime` tinyint(1) NOT NULL,
  `inputter` varchar(50) NOT NULL,
  `input_date` datetime NOT NULL,
  `authorizer` varchar(50) NOT NULL,
  `auth_date` datetime NOT NULL,
  `record_status` char(4) NOT NULL,
  `current_no` int(11) NOT NULL,
  PRIMARY KEY (`id`,`current_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `enquirydefs_hs`
--

LOCK TABLES `enquirydefs_hs` WRITE;
/*!40000 ALTER TABLE `enquirydefs_hs` DISABLE KEYS */;
/*!40000 ALTER TABLE `enquirydefs_hs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `enquirydefs_is`
--

DROP TABLE IF EXISTS `enquirydefs_is`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `enquirydefs_is` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `enquirydef_id` varchar(255) DEFAULT NULL,
  `controller` varchar(255) DEFAULT NULL,
  `dflag` enum('Y','N') DEFAULT NULL,
  `formfields` text,
  `tablename` varchar(255) DEFAULT NULL,
  `model` varchar(255) DEFAULT NULL,
  `view` varchar(255) DEFAULT NULL,
  `idfield` varchar(50) DEFAULT NULL,
  `enqheader` varchar(255) DEFAULT NULL,
  `showfilter` tinyint(1) DEFAULT '1',
  `printuser` tinyint(1) DEFAULT '1',
  `printdatetime` tinyint(1) DEFAULT '1',
  `inputter` varchar(50) DEFAULT NULL,
  `input_date` datetime DEFAULT NULL,
  `authorizer` varchar(50) DEFAULT NULL,
  `auth_date` datetime DEFAULT NULL,
  `record_status` char(4) DEFAULT NULL,
  `current_no` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_controller` (`controller`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `enquirydefs_is`
--

LOCK TABLES `enquirydefs_is` WRITE;
/*!40000 ALTER TABLE `enquirydefs_is` DISABLE KEYS */;
/*!40000 ALTER TABLE `enquirydefs_is` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fixedselections`
--

DROP TABLE IF EXISTS `fixedselections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fixedselections` (
  `id` int(11) unsigned NOT NULL,
  `fixedselection_id` varchar(50) NOT NULL,
  `enquiry_type` enum('default','custom') NOT NULL,
  `formfields` text,
  `inputter` varchar(50) NOT NULL,
  `input_date` datetime NOT NULL,
  `authorizer` varchar(50) NOT NULL,
  `auth_date` datetime NOT NULL,
  `record_status` char(4) NOT NULL,
  `current_no` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_controller` (`fixedselection_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fixedselections`
--

LOCK TABLES `fixedselections` WRITE;
/*!40000 ALTER TABLE `fixedselections` DISABLE KEYS */;
INSERT INTO `fixedselections` VALUES (1,'message','default','<?xml version=\'1.0\' standalone=\'yes\'?>\n<formfields>\n<field><name>recipient</name><value>%IDNAME%</value><operand>EQ</operand><onload>readonly</onload></field>\n<field><name>sender</name><value>%OR% %IDNAME%</value><operand>EQ</operand><onload>readonly</onload></field>\n</formfields>','ADMIN','2012-01-23 02:15:44','ADMIN','2012-01-23 02:15:53','LIVE',4),(2,'userchangepassword','default','<?xml version=\'1.0\' standalone=\'yes\'?>\n<formfields>\n<field><name>idname</name><value>%IDNAME%</value><operand>EQ</operand><onload>readonly</onload></field>\n</formfields>','ADMIN','2011-11-14 10:03:35','ADMIN','2011-11-14 10:08:11','LIVE',1),(3,'order','default','','DUNSTAN.NESBIT','2012-10-06 16:54:05','DUNSTAN.NESBIT','2012-10-06 17:00:48','LIVE',2),(4,'useradmin','default','<?xml version=\'1.0\' standalone=\'yes\'?>\n<formfields>\n<field><name>department_id</name><value>_SYSTEM</value><operand>NE</operand><onload>readonly</onload></field>\n</formfields>','ADMIN','2012-01-13 05:42:51','ADMIN','2012-01-13 05:42:58','LIVE',1),(6,'tilluser','default','<?xml version=\'1.0\' standalone=\'yes\'?>\n<formfields>\n<field><name>till_user</name><value>%IDNAME%</value><operand>EQ</operand><onload>readonly</onload></field>\n</formfields>','ADMIN','2012-05-03 12:50:51','ADMIN','2012-05-03 12:50:59','LIVE',1),(7,'tilltransaction','default','<?xml version=\'1.0\' standalone=\'yes\'?>\n<formfields>\n<field><name>till_id</name><value>%IDNAME%</value><operand>LK</operand><onload>readonly</onload></field>\n<field><name>auth_date</name><value>%CURDATE%</value><operand>GT</operand><onload>enabled</onload></field>\r\n</formfields>','ADMIN','2012-05-03 19:11:45','ADMIN','2012-05-03 19:11:55','LIVE',1);
/*!40000 ALTER TABLE `fixedselections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fixedselections_hs`
--

DROP TABLE IF EXISTS `fixedselections_hs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fixedselections_hs` (
  `id` int(11) unsigned NOT NULL,
  `fixedselection_id` varchar(50) NOT NULL,
  `enquiry_type` enum('default','custom') NOT NULL,
  `formfields` text,
  `inputter` varchar(50) NOT NULL,
  `input_date` datetime NOT NULL,
  `authorizer` varchar(50) NOT NULL,
  `auth_date` datetime NOT NULL,
  `record_status` char(4) NOT NULL,
  `current_no` int(11) NOT NULL,
  PRIMARY KEY (`id`,`current_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fixedselections_hs`
--

LOCK TABLES `fixedselections_hs` WRITE;
/*!40000 ALTER TABLE `fixedselections_hs` DISABLE KEYS */;
/*!40000 ALTER TABLE `fixedselections_hs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fixedselections_is`
--

DROP TABLE IF EXISTS `fixedselections_is`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fixedselections_is` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `fixedselection_id` varchar(50) DEFAULT NULL,
  `enquiry_type` enum('default','custom') DEFAULT 'default',
  `formfields` text,
  `inputter` varchar(50) DEFAULT NULL,
  `input_date` datetime DEFAULT NULL,
  `authorizer` varchar(50) DEFAULT NULL,
  `auth_date` datetime DEFAULT NULL,
  `record_status` char(4) DEFAULT NULL,
  `current_no` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_controller` (`fixedselection_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fixedselections_is`
--

LOCK TABLES `fixedselections_is` WRITE;
/*!40000 ALTER TABLE `fixedselections_is` DISABLE KEYS */;
/*!40000 ALTER TABLE `fixedselections_is` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `interfaceconfigurations`
--

DROP TABLE IF EXISTS `interfaceconfigurations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `interfaceconfigurations` (
  `id` int(11) unsigned NOT NULL,
  `config_id` varchar(30) NOT NULL,
  `db_server` varchar(30) NOT NULL,
  `db_name` varchar(30) NOT NULL,
  `db_user` varchar(30) NOT NULL,
  `db_password` varchar(30) NOT NULL,
  `hs_apikey` varchar(64) NOT NULL,
  `folderc_import` varchar(256) NOT NULL,
  `folderc_export` varchar(256) NOT NULL,
  `foldera_import` varchar(256) NOT NULL,
  `foldera_export` varchar(256) NOT NULL,
  `comments` text,
  `inputter` varchar(50) NOT NULL,
  `input_date` datetime NOT NULL,
  `authorizer` varchar(50) NOT NULL,
  `auth_date` datetime NOT NULL,
  `record_status` char(4) NOT NULL,
  `current_no` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_config_id` (`config_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `interfaceconfigurations`
--

LOCK TABLES `interfaceconfigurations` WRITE;
/*!40000 ALTER TABLE `interfaceconfigurations` DISABLE KEYS */;
INSERT INTO `interfaceconfigurations` VALUES (1001,'DEFAULT','localhost','hndshkif','dbuser','dbpass','dadc68c1ee88efb68f82bd51017645ca6188022d','/zipstore/hsi/current/import','/zipstore/hsi/current/export','/zipstore/hsi/archive/import','/zipstore/hsi/archive/export','','ADMIN','2013-09-13 16:34:51','ADMIN','2013-09-13 16:34:51','LIVE',1);
/*!40000 ALTER TABLE `interfaceconfigurations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `interfaceconfigurations_hs`
--

DROP TABLE IF EXISTS `interfaceconfigurations_hs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `interfaceconfigurations_hs` (
  `id` int(11) unsigned NOT NULL,
  `config_id` varchar(30) NOT NULL,
  `db_server` varchar(30) NOT NULL,
  `db_name` varchar(30) NOT NULL,
  `db_user` varchar(30) NOT NULL,
  `db_password` varchar(30) NOT NULL,
  `hs_apikey` varchar(64) NOT NULL,
  `folderc_import` varchar(256) NOT NULL,
  `folderc_export` varchar(256) NOT NULL,
  `foldera_import` varchar(256) NOT NULL,
  `foldera_export` varchar(256) NOT NULL,
  `comments` text,
  `inputter` varchar(50) NOT NULL,
  `input_date` datetime NOT NULL,
  `authorizer` varchar(50) NOT NULL,
  `auth_date` datetime NOT NULL,
  `record_status` char(4) NOT NULL,
  `current_no` int(11) NOT NULL,
  PRIMARY KEY (`id`,`current_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `interfaceconfigurations_hs`
--

LOCK TABLES `interfaceconfigurations_hs` WRITE;
/*!40000 ALTER TABLE `interfaceconfigurations_hs` DISABLE KEYS */;
/*!40000 ALTER TABLE `interfaceconfigurations_hs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `interfaceconfigurations_is`
--

DROP TABLE IF EXISTS `interfaceconfigurations_is`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `interfaceconfigurations_is` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `config_id` varchar(30) DEFAULT NULL,
  `db_server` varchar(30) DEFAULT NULL,
  `db_name` varchar(30) DEFAULT NULL,
  `db_user` varchar(30) DEFAULT NULL,
  `db_password` varchar(30) DEFAULT NULL,
  `hs_apikey` varchar(64) DEFAULT NULL,
  `folderc_import` varchar(256) DEFAULT NULL,
  `folderc_export` varchar(256) DEFAULT NULL,
  `foldera_import` varchar(256) DEFAULT NULL,
  `foldera_export` varchar(256) DEFAULT NULL,
  `comments` text,
  `inputter` varchar(50) DEFAULT NULL,
  `input_date` datetime DEFAULT NULL,
  `authorizer` varchar(50) DEFAULT NULL,
  `auth_date` datetime DEFAULT NULL,
  `record_status` char(4) DEFAULT NULL,
  `current_no` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_config_id` (`config_id`)
) ENGINE=InnoDB AUTO_INCREMENT=1002 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `interfaceconfigurations_is`
--

LOCK TABLES `interfaceconfigurations_is` WRITE;
/*!40000 ALTER TABLE `interfaceconfigurations_is` DISABLE KEYS */;
/*!40000 ALTER TABLE `interfaceconfigurations_is` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inventchkouts`
--

DROP TABLE IF EXISTS `inventchkouts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `inventchkouts` (
  `id` int(11) unsigned NOT NULL,
  `order_id` varchar(16) NOT NULL,
  `checkout_details` text,
  `run` enum('Y','N') NOT NULL,
  `comments` text,
  `inputter` varchar(50) NOT NULL,
  `input_date` datetime NOT NULL,
  `authorizer` varchar(50) NOT NULL,
  `auth_date` datetime NOT NULL,
  `record_status` char(4) NOT NULL,
  `current_no` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_order_id` (`order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventchkouts`
--

LOCK TABLES `inventchkouts` WRITE;
/*!40000 ALTER TABLE `inventchkouts` DISABLE KEYS */;
/*!40000 ALTER TABLE `inventchkouts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inventchkouts_hs`
--

DROP TABLE IF EXISTS `inventchkouts_hs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `inventchkouts_hs` (
  `id` int(11) unsigned NOT NULL,
  `order_id` varchar(16) NOT NULL,
  `checkout_details` text,
  `run` enum('Y','N') NOT NULL,
  `comments` text,
  `inputter` varchar(50) NOT NULL,
  `input_date` datetime NOT NULL,
  `authorizer` varchar(50) NOT NULL,
  `auth_date` datetime NOT NULL,
  `record_status` char(4) NOT NULL,
  `current_no` int(11) NOT NULL,
  PRIMARY KEY (`id`,`current_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventchkouts_hs`
--

LOCK TABLES `inventchkouts_hs` WRITE;
/*!40000 ALTER TABLE `inventchkouts_hs` DISABLE KEYS */;
/*!40000 ALTER TABLE `inventchkouts_hs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inventchkouts_is`
--

DROP TABLE IF EXISTS `inventchkouts_is`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `inventchkouts_is` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `order_id` varchar(16) DEFAULT NULL,
  `checkout_details` text,
  `run` enum('Y','N') DEFAULT NULL,
  `comments` text,
  `inputter` varchar(50) DEFAULT NULL,
  `input_date` datetime DEFAULT NULL,
  `authorizer` varchar(50) DEFAULT NULL,
  `auth_date` datetime DEFAULT NULL,
  `record_status` char(4) DEFAULT NULL,
  `current_no` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_order_id` (`order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventchkouts_is`
--

LOCK TABLES `inventchkouts_is` WRITE;
/*!40000 ALTER TABLE `inventchkouts_is` DISABLE KEYS */;
/*!40000 ALTER TABLE `inventchkouts_is` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inventory_sale_logs`
--

DROP TABLE IF EXISTS `inventory_sale_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `inventory_sale_logs` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `inventory_id` varchar(255) NOT NULL,
  `order_id` varchar(16) NOT NULL,
  `product_id` varchar(50) NOT NULL,
  `branch_id` varchar(50) NOT NULL,
  `qty_instock` float(16,2) unsigned NOT NULL,
  `qty_diff` float(16,2) NOT NULL,
  `last_update_type` varchar(50) NOT NULL,
  `update_date` date NOT NULL,
  `comments` text,
  `inputter` varchar(50) NOT NULL,
  `input_date` datetime NOT NULL,
  `authorizer` varchar(50) NOT NULL,
  `auth_date` datetime NOT NULL,
  `record_status` char(4) NOT NULL,
  `current_no` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventory_sale_logs`
--

LOCK TABLES `inventory_sale_logs` WRITE;
/*!40000 ALTER TABLE `inventory_sale_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `inventory_sale_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inventorys`
--

DROP TABLE IF EXISTS `inventorys`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `inventorys` (
  `id` int(11) unsigned NOT NULL,
  `inventory_id` varchar(255) NOT NULL,
  `product_id` varchar(50) NOT NULL,
  `branch_id` varchar(50) NOT NULL,
  `qty_instock` float(16,2) unsigned NOT NULL,
  `qty_diff` float(16,2) NOT NULL,
  `reorder_level` int(11) unsigned NOT NULL,
  `last_update_type` varchar(50) NOT NULL,
  `comments` text,
  `inputter` varchar(50) NOT NULL,
  `input_date` datetime NOT NULL,
  `authorizer` varchar(50) NOT NULL,
  `auth_date` datetime NOT NULL,
  `record_status` char(4) NOT NULL,
  `current_no` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_product_id_branch_id` (`product_id`,`branch_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventorys`
--

LOCK TABLES `inventorys` WRITE;
/*!40000 ALTER TABLE `inventorys` DISABLE KEYS */;
INSERT INTO `inventorys` VALUES (501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',100.00,-1.00,1,'SALE','','ADMIN','2013-08-13 00:43:06','SYSAUTH','2013-08-13 00:43:06','LIVE',407);
/*!40000 ALTER TABLE `inventorys` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inventorys_hs`
--

DROP TABLE IF EXISTS `inventorys_hs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `inventorys_hs` (
  `id` int(11) unsigned NOT NULL,
  `inventory_id` varchar(255) NOT NULL,
  `product_id` varchar(50) NOT NULL,
  `branch_id` varchar(50) NOT NULL,
  `qty_instock` float(16,2) unsigned NOT NULL,
  `qty_diff` float(16,2) NOT NULL,
  `reorder_level` int(11) unsigned NOT NULL,
  `last_update_type` varchar(50) NOT NULL,
  `comments` text,
  `inputter` varchar(50) NOT NULL,
  `input_date` datetime NOT NULL,
  `authorizer` varchar(50) NOT NULL,
  `auth_date` datetime NOT NULL,
  `record_status` char(4) NOT NULL,
  `current_no` int(11) NOT NULL,
  PRIMARY KEY (`id`,`current_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventorys_hs`
--

LOCK TABLES `inventorys_hs` WRITE;
/*!40000 ALTER TABLE `inventorys_hs` DISABLE KEYS */;
INSERT INTO `inventorys_hs` VALUES (501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',8.00,0.00,1,'STOCK.CHECK','','ADMIN','2012-05-12 13:13:21','ADMIN','2012-05-12 13:13:33','LIVE',1),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',7.00,0.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-05-14 10:13:15','SYSAUTH','2012-05-14 10:13:15','LIVE',2),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',6.00,0.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-05-14 11:25:43','SYSAUTH','2012-05-14 11:25:43','LIVE',3),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',5.00,0.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-05-14 13:46:21','SYSAUTH','2012-05-14 13:46:21','LIVE',4),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',4.00,0.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-05-16 10:02:12','SYSAUTH','2012-05-16 10:02:12','LIVE',5),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',3.00,0.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-05-17 13:27:03','SYSAUTH','2012-05-17 13:27:03','LIVE',6),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',2.00,0.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-05-17 13:27:03','SYSAUTH','2012-05-17 13:27:03','LIVE',7),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',1.00,0.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-05-17 13:27:03','SYSAUTH','2012-05-17 13:27:03','HIST',8),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',4.00,0.00,1,'STOCK.NEW.IN','','RAENELLE.SAMAROO-MAHARAJ','2012-05-19 12:34:54','RAENELLE.SAMAROO-MAHARAJ','2012-05-19 12:34:54','LIVE',9),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',3.00,0.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-05-19 12:38:22','SYSAUTH','2012-05-19 12:38:22','LIVE',10),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',2.00,0.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-05-19 12:39:39','SYSAUTH','2012-05-19 12:39:39','LIVE',11),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',1.00,0.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-05-19 12:40:20','SYSAUTH','2012-05-19 12:40:20','HIST',12),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',2.00,0.00,1,'STOCK.CHECK','order was cancelled and G10 was returned to stock','RAENELLE.SAMAROO-MAHARAJ','2012-05-19 12:44:58','RAENELLE.SAMAROO-MAHARAJ','2012-05-19 12:44:58','LIVE',13),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',1.00,0.00,1,'SALE','order was cancelled and G10 was returned to stock','RAENELLE.SAMAROO-MAHARAJ','2012-05-21 15:21:26','SYSAUTH','2012-05-21 15:21:26','LIVE',14),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',0.00,0.00,1,'SALE','order was cancelled and G10 was returned to stock','RAENELLE.SAMAROO-MAHARAJ','2012-05-21 15:23:19','SYSAUTH','2012-05-21 15:23:19','HIST',15),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',10.00,0.00,1,'STOCK.NEW.IN','order was cancelled and G10 was returned to stock','RAENELLE.SAMAROO-MAHARAJ','2012-05-21 16:18:15','RAENELLE.SAMAROO-MAHARAJ','2012-05-21 16:18:15','LIVE',16),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',9.00,0.00,1,'SALE','order was cancelled and G10 was returned to stock','DANNY.RAMDASS','2012-05-25 10:16:52','SYSAUTH','2012-05-25 10:16:52','LIVE',17),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',8.00,-1.00,1,'SALE','order was cancelled and G10 was returned to stock','RAENELLE.SAMAROO-MAHARAJ','2012-05-28 09:30:57','SYSAUTH','2012-05-28 09:30:57','LIVE',18),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',7.00,-1.00,1,'SALE','order was cancelled and G10 was returned to stock','RAENELLE.SAMAROO-MAHARAJ','2012-05-29 11:01:16','SYSAUTH','2012-05-29 11:01:16','LIVE',19),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',6.00,-1.00,1,'SALE','order was cancelled and G10 was returned to stock','RAENELLE.SAMAROO-MAHARAJ','2012-05-29 11:51:24','SYSAUTH','2012-05-29 11:51:24','LIVE',20),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',5.00,-1.00,1,'SALE','order was cancelled and G10 was returned to stock','RAENELLE.SAMAROO-MAHARAJ','2012-05-31 11:34:22','SYSAUTH','2012-05-31 11:34:22','LIVE',21),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',4.00,-1.00,1,'SALE','order was cancelled and G10 was returned to stock','RAENELLE.SAMAROO-MAHARAJ','2012-06-02 09:54:14','SYSAUTH','2012-06-02 09:54:14','LIVE',22),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',3.00,-1.00,1,'SALE','order was cancelled and G10 was returned to stock','RAENELLE.SAMAROO-MAHARAJ','2012-06-02 11:19:04','SYSAUTH','2012-06-02 11:19:04','LIVE',23),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',2.00,-1.00,1,'SALE','order was cancelled and G10 was returned to stock','RAENELLE.SAMAROO-MAHARAJ','2012-06-04 11:57:40','SYSAUTH','2012-06-04 11:57:40','LIVE',24),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',1.00,-1.00,1,'SALE','order was cancelled and G10 was returned to stock','RAENELLE.SAMAROO-MAHARAJ','2012-06-04 12:24:04','SYSAUTH','2012-06-04 12:24:04','LIVE',25),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',0.00,-1.00,1,'SALE','order was cancelled and G10 was returned to stock','RAENELLE.SAMAROO-MAHARAJ','2012-06-04 13:50:41','SYSAUTH','2012-06-04 13:50:41','HIST',26),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',40.00,40.00,1,'STOCK.NEW.IN','order was cancelled and G10 was returned to stock','RAENELLE.SAMAROO-MAHARAJ','2012-06-06 11:16:44','RAENELLE.SAMAROO-MAHARAJ','2012-06-06 11:16:44','LIVE',27),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',39.00,-1.00,1,'SALE','order was cancelled and G10 was returned to stock','RAENELLE.SAMAROO-MAHARAJ','2012-06-06 15:42:40','SYSAUTH','2012-06-06 15:42:40','LIVE',28),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',38.00,-1.00,1,'SALE','order was cancelled and G10 was returned to stock','RAENELLE.SAMAROO-MAHARAJ','2012-06-08 09:00:41','SYSAUTH','2012-06-08 09:00:41','LIVE',29),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',37.00,-1.00,1,'SALE','order was cancelled and G10 was returned to stock','RAENELLE.SAMAROO-MAHARAJ','2012-06-08 10:34:56','SYSAUTH','2012-06-08 10:34:56','LIVE',30),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',36.00,-1.00,1,'SALE','order was cancelled and G10 was returned to stock','RAENELLE.SAMAROO-MAHARAJ','2012-06-08 10:39:56','SYSAUTH','2012-06-08 10:39:56','LIVE',31),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',35.00,-1.00,1,'SALE','order was cancelled and G10 was returned to stock','RAENELLE.SAMAROO-MAHARAJ','2012-06-08 11:20:08','SYSAUTH','2012-06-08 11:20:08','LIVE',32),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',34.00,-1.00,1,'SALE','order was cancelled and G10 was returned to stock','RAENELLE.SAMAROO-MAHARAJ','2012-06-08 11:20:08','SYSAUTH','2012-06-08 11:20:08','LIVE',33),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',33.00,-1.00,1,'SALE','order was cancelled and G10 was returned to stock','RAENELLE.SAMAROO-MAHARAJ','2012-06-09 08:29:43','SYSAUTH','2012-06-09 08:29:43','LIVE',34),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',32.00,-1.00,1,'SALE','order was cancelled and G10 was returned to stock','RAENELLE.SAMAROO-MAHARAJ','2012-06-09 08:54:30','SYSAUTH','2012-06-09 08:54:30','LIVE',35),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',31.00,-1.00,1,'SALE','order was cancelled and G10 was returned to stock','RAENELLE.SAMAROO-MAHARAJ','2012-06-09 08:56:18','SYSAUTH','2012-06-09 08:56:18','LIVE',36),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',28.00,-3.00,1,'SALE','order was cancelled and G10 was returned to stock','RAENELLE.SAMAROO-MAHARAJ','2012-06-09 10:05:07','SYSAUTH','2012-06-09 10:05:07','LIVE',37),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',27.00,-1.00,1,'SALE','order was cancelled and G10 was returned to stock','RAENELLE.SAMAROO-MAHARAJ','2012-06-11 11:23:17','SYSAUTH','2012-06-11 11:23:17','LIVE',38),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',26.00,-1.00,1,'SALE','order was cancelled and G10 was returned to stock','RAENELLE.SAMAROO-MAHARAJ','2012-06-11 16:14:47','SYSAUTH','2012-06-11 16:14:47','LIVE',39),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',25.00,-1.00,1,'SALE','order was cancelled and G10 was returned to stock','RAENELLE.SAMAROO-MAHARAJ','2012-06-14 12:48:57','SYSAUTH','2012-06-14 12:48:57','LIVE',40),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',24.00,-1.00,1,'SALE','order was cancelled and G10 was returned to stock','RAENELLE.SAMAROO-MAHARAJ','2012-06-14 14:35:00','SYSAUTH','2012-06-14 14:35:00','HIST',41),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',15.00,0.00,1,'STOCK.CHECK','','RAENELLE.SAMAROO-MAHARAJ','2012-06-15 09:51:05','RAENELLE.SAMAROO-MAHARAJ','2012-06-15 09:51:05','LIVE',42),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',14.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-06-15 11:20:51','SYSAUTH','2012-06-15 11:20:51','LIVE',43),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',13.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-06-16 10:37:41','SYSAUTH','2012-06-16 10:37:41','LIVE',44),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',12.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-06-20 09:09:35','SYSAUTH','2012-06-20 09:09:35','LIVE',45),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',11.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-06-20 12:04:00','SYSAUTH','2012-06-20 12:04:00','LIVE',46),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',10.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-06-20 15:54:01','SYSAUTH','2012-06-20 15:54:01','LIVE',47),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',9.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-06-21 10:16:32','SYSAUTH','2012-06-21 10:16:32','LIVE',48),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',8.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-06-21 10:18:13','SYSAUTH','2012-06-21 10:18:13','LIVE',49),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',7.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-06-21 12:50:32','SYSAUTH','2012-06-21 12:50:32','HIST',50),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',7.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-06-21 16:43:26','RAENELLE.SAMAROO-MAHARAJ','2012-06-21 16:43:26','LIVE',51),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',6.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-06-22 10:10:45','SYSAUTH','2012-06-22 10:10:45','LIVE',52),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',5.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-06-22 11:39:16','SYSAUTH','2012-06-22 11:39:16','HIST',53),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',6.00,1.00,1,'CUSTOMER.RETURN','','RAENELLE.SAMAROO-MAHARAJ','2012-06-22 13:28:00','RAENELLE.SAMAROO-MAHARAJ','2012-06-22 13:28:00','LIVE',54),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',5.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-06-23 08:50:51','SYSAUTH','2012-06-23 08:50:51','HIST',55),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',11.00,6.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-06-23 10:28:21','RAENELLE.SAMAROO-MAHARAJ','2012-06-23 10:28:21','HIST',56),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',11.00,0.00,1,'STOCK.NEW.IN','','RAENELLE.SAMAROO-MAHARAJ','2012-06-23 10:28:49','RAENELLE.SAMAROO-MAHARAJ','2012-06-23 10:28:49','LIVE',57),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',9.00,-2.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-06-23 10:31:31','SYSAUTH','2012-06-23 10:31:31','LIVE',58),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',6.00,-3.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-06-23 12:01:21','SYSAUTH','2012-06-23 12:01:21','LIVE',59),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',5.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-06-23 13:48:50','SYSAUTH','2012-06-23 13:48:50','LIVE',60),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',4.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-06-26 09:20:23','SYSAUTH','2012-06-26 09:20:23','LIVE',61),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',3.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-06-26 10:05:08','SYSAUTH','2012-06-26 10:05:08','LIVE',62),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',2.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-06-26 11:56:39','SYSAUTH','2012-06-26 11:56:39','LIVE',63),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',1.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-06-26 12:27:04','SYSAUTH','2012-06-26 12:27:04','LIVE',64),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',0.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-06-26 13:53:14','SYSAUTH','2012-06-26 13:53:14','HIST',65),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',8.00,8.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-06-27 12:46:53','RAENELLE.SAMAROO-MAHARAJ','2012-06-27 12:46:53','HIST',66),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',7.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-06-27 12:47:56','RAENELLE.SAMAROO-MAHARAJ','2012-06-27 12:47:56','LIVE',67),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',6.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-06-27 15:19:43','SYSAUTH','2012-06-27 15:19:43','LIVE',68),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',5.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-06-27 16:44:39','SYSAUTH','2012-06-27 16:44:39','LIVE',69),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',4.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-06-28 09:54:07','SYSAUTH','2012-06-28 09:54:07','LIVE',70),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',3.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-06-28 12:38:44','SYSAUTH','2012-06-28 12:38:44','LIVE',71),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',2.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-06-28 14:49:46','SYSAUTH','2012-06-28 14:49:46','LIVE',72),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',1.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-06-28 15:55:48','SYSAUTH','2012-06-28 15:55:48','HIST',73),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',7.00,6.00,1,'STOCK.NEW.IN','','RAENELLE.SAMAROO-MAHARAJ','2012-06-28 16:56:08','RAENELLE.SAMAROO-MAHARAJ','2012-06-28 16:56:08','LIVE',74),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',6.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-06-29 10:31:02','SYSAUTH','2012-06-29 10:31:02','LIVE',75),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',5.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-06-29 11:12:40','SYSAUTH','2012-06-29 11:12:40','LIVE',76),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',4.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-06-29 14:00:12','SYSAUTH','2012-06-29 14:00:12','LIVE',77),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',3.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-06-29 14:42:29','SYSAUTH','2012-06-29 14:42:29','HIST',78),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',4.00,1.00,1,'CUSTOMER.RETURN','','RAENELLE.SAMAROO-MAHARAJ','2012-06-29 17:06:05','RAENELLE.SAMAROO-MAHARAJ','2012-06-29 17:06:05','LIVE',79),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',3.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-06-30 11:10:43','SYSAUTH','2012-06-30 11:10:43','LIVE',80),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',2.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-07-02 09:27:23','SYSAUTH','2012-07-02 09:27:23','LIVE',81),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',1.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-07-02 11:56:59','SYSAUTH','2012-07-02 11:56:59','HIST',82),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',18.00,0.00,1,'STOCK.CHECK','','RAENELLE.SAMAROO-MAHARAJ','2012-07-02 16:43:07','RAENELLE.SAMAROO-MAHARAJ','2012-07-02 16:43:07','LIVE',83),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',17.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-07-03 12:15:27','SYSAUTH','2012-07-03 12:15:27','LIVE',84),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',16.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-07-03 13:05:22','SYSAUTH','2012-07-03 13:05:22','LIVE',85),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',15.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-07-03 13:54:11','SYSAUTH','2012-07-03 13:54:11','LIVE',86),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',14.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-07-03 15:02:59','SYSAUTH','2012-07-03 15:02:59','LIVE',87),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',13.00,-1.00,1,'SALE','','DUNSTAN.NESBIT','2012-07-03 17:15:47','SYSAUTH','2012-07-03 17:15:47','LIVE',88),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',7.00,-6.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-07-05 11:16:50','SYSAUTH','2012-07-05 11:16:50','LIVE',89),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',6.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-07-05 11:57:50','SYSAUTH','2012-07-05 11:57:50','LIVE',90),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',5.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-07-05 12:53:49','SYSAUTH','2012-07-05 12:53:49','LIVE',91),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',4.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-07-05 14:12:38','SYSAUTH','2012-07-05 14:12:38','LIVE',92),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',2.00,-2.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-07-06 09:47:19','SYSAUTH','2012-07-06 09:47:19','LIVE',93),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',1.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-07-06 09:48:12','SYSAUTH','2012-07-06 09:48:12','HIST',94),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',10.00,9.00,1,'STOCK.NEW.IN','','RAENELLE.SAMAROO-MAHARAJ','2012-07-06 10:56:59','RAENELLE.SAMAROO-MAHARAJ','2012-07-06 10:56:59','HIST',95),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',8.00,-2.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-07-07 08:39:49','RAENELLE.SAMAROO-MAHARAJ','2012-07-07 08:39:49','LIVE',96),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',7.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-07-07 08:49:47','SYSAUTH','2012-07-07 08:49:47','LIVE',97),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',6.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-07-07 09:40:07','SYSAUTH','2012-07-07 09:40:07','LIVE',98),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',5.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-07-10 10:52:10','SYSAUTH','2012-07-10 10:52:10','LIVE',99),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',4.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-07-10 12:45:49','SYSAUTH','2012-07-10 12:45:49','LIVE',100),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',3.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-07-11 09:19:37','SYSAUTH','2012-07-11 09:19:37','LIVE',101),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',2.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-07-11 09:44:17','SYSAUTH','2012-07-11 09:44:17','HIST',102),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',12.00,10.00,1,'STOCK.NEW.IN','','RAENELLE.SAMAROO-MAHARAJ','2012-07-11 13:06:23','RAENELLE.SAMAROO-MAHARAJ','2012-07-11 13:06:23','LIVE',103),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',11.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-07-11 14:52:44','SYSAUTH','2012-07-11 14:52:44','LIVE',104),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',10.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-07-12 12:15:31','SYSAUTH','2012-07-12 12:15:31','LIVE',105),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',9.00,-1.00,1,'SALE','','DUNSTAN.NESBIT','2012-07-12 13:54:37','SYSAUTH','2012-07-12 13:54:37','LIVE',106),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',8.00,-1.00,1,'SALE','','DUNSTAN.NESBIT','2012-07-12 13:56:23','SYSAUTH','2012-07-12 13:56:23','LIVE',107),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',7.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-07-12 14:32:17','SYSAUTH','2012-07-12 14:32:17','HIST',108),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',9.00,0.00,1,'STOCK.CHECK','','RAENELLE.SAMAROO-MAHARAJ','2012-07-12 16:30:08','RAENELLE.SAMAROO-MAHARAJ','2012-07-12 16:30:08','LIVE',109),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',8.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-07-13 09:38:13','SYSAUTH','2012-07-13 09:38:13','LIVE',110),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',7.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-07-14 09:06:59','SYSAUTH','2012-07-14 09:06:59','LIVE',111),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',6.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-07-14 10:18:04','SYSAUTH','2012-07-14 10:18:04','LIVE',112),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',5.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-07-14 11:01:22','SYSAUTH','2012-07-14 11:01:22','HIST',113),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',4.00,-1.00,1,'SENT.TO.REPAIR','','RAENELLE.SAMAROO-MAHARAJ','2012-07-14 11:55:43','RAENELLE.SAMAROO-MAHARAJ','2012-07-14 11:55:43','HIST',114),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',9.00,5.00,1,'STOCK.NEW.IN','','RAENELLE.SAMAROO-MAHARAJ','2012-07-17 09:52:54','RAENELLE.SAMAROO-MAHARAJ','2012-07-17 09:52:54','LIVE',115),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',8.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-07-17 14:36:03','SYSAUTH','2012-07-17 14:36:03','LIVE',116),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',7.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-07-17 14:53:12','SYSAUTH','2012-07-17 14:53:12','LIVE',117),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',6.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-07-20 09:46:53','SYSAUTH','2012-07-20 09:46:53','LIVE',118),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',5.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-07-20 09:57:42','SYSAUTH','2012-07-20 09:57:42','LIVE',119),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',4.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-07-20 12:26:48','SYSAUTH','2012-07-20 12:26:48','LIVE',120),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',3.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-07-20 13:13:16','SYSAUTH','2012-07-20 13:13:16','LIVE',121),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',2.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-07-20 13:24:44','SYSAUTH','2012-07-20 13:24:44','LIVE',122),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',1.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-07-21 12:25:11','SYSAUTH','2012-07-21 12:25:11','HIST',123),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',5.00,4.00,1,'STOCK.NEW.IN','','RAENELLE.SAMAROO-MAHARAJ','2012-07-21 12:32:53','RAENELLE.SAMAROO-MAHARAJ','2012-07-21 12:32:53','LIVE',124),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',4.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-07-23 10:16:39','SYSAUTH','2012-07-23 10:16:39','LIVE',125),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',3.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-07-23 10:41:57','SYSAUTH','2012-07-23 10:41:57','LIVE',126),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',2.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-07-23 12:25:45','SYSAUTH','2012-07-23 12:25:45','HIST',127),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',7.00,5.00,1,'STOCK.NEW.IN','','RAENELLE.SAMAROO-MAHARAJ','2012-07-23 15:03:03','RAENELLE.SAMAROO-MAHARAJ','2012-07-23 15:03:03','LIVE',128),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',6.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-07-25 10:30:48','SYSAUTH','2012-07-25 10:30:48','LIVE',129),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',5.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-07-25 15:22:43','SYSAUTH','2012-07-25 15:22:43','LIVE',130),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',4.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-07-26 10:05:14','SYSAUTH','2012-07-26 10:05:14','LIVE',131),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',3.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-07-26 11:34:11','SYSAUTH','2012-07-26 11:34:11','LIVE',132),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',2.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-07-26 13:19:04','SYSAUTH','2012-07-26 13:19:04','HIST',133),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',12.00,10.00,1,'STOCK.NEW.IN','','RAENELLE.SAMAROO-MAHARAJ','2012-07-26 14:39:57','RAENELLE.SAMAROO-MAHARAJ','2012-07-26 14:39:57','LIVE',134),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',11.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-07-27 09:25:00','SYSAUTH','2012-07-27 09:25:00','LIVE',135),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',10.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-07-27 13:17:06','SYSAUTH','2012-07-27 13:17:06','LIVE',136),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',9.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-07-30 11:18:38','SYSAUTH','2012-07-30 11:18:38','LIVE',137),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',8.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-07-30 12:16:52','SYSAUTH','2012-07-30 12:16:52','LIVE',138),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',7.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-07-30 14:29:00','SYSAUTH','2012-07-30 14:29:00','LIVE',139),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',6.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-07-31 09:34:22','SYSAUTH','2012-07-31 09:34:22','LIVE',140),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',5.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-07-31 12:23:38','SYSAUTH','2012-07-31 12:23:38','LIVE',141),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',4.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-07-31 12:31:21','SYSAUTH','2012-07-31 12:31:21','LIVE',142),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',3.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-07-31 12:31:21','SYSAUTH','2012-07-31 12:31:21','HIST',143),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',13.00,10.00,1,'STOCK.NEW.IN','','RAENELLE.SAMAROO-MAHARAJ','2012-07-31 12:56:28','RAENELLE.SAMAROO-MAHARAJ','2012-07-31 12:56:28','LIVE',144),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',12.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-07-31 12:57:53','SYSAUTH','2012-07-31 12:57:53','LIVE',145),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',11.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-08-03 09:27:55','SYSAUTH','2012-08-03 09:27:55','LIVE',146),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',10.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-08-06 13:20:11','SYSAUTH','2012-08-06 13:20:11','LIVE',147),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',9.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-08-06 14:06:08','SYSAUTH','2012-08-06 14:06:08','LIVE',148),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',8.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-08-07 11:25:22','SYSAUTH','2012-08-07 11:25:22','LIVE',149),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',7.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-08-07 14:38:05','SYSAUTH','2012-08-07 14:38:05','HIST',150),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',1.00,-6.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-08-08 09:42:39','RAENELLE.SAMAROO-MAHARAJ','2012-08-08 09:42:39','HIST',151),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',13.00,12.00,1,'STOCK.NEW.IN','','RAENELLE.SAMAROO-MAHARAJ','2012-08-08 09:43:03','RAENELLE.SAMAROO-MAHARAJ','2012-08-08 09:43:03','LIVE',152),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',12.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-08-09 10:30:52','SYSAUTH','2012-08-09 10:30:52','LIVE',153),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',11.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-08-10 10:39:09','SYSAUTH','2012-08-10 10:39:09','LIVE',154),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',10.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-08-11 09:10:05','SYSAUTH','2012-08-11 09:10:05','LIVE',155),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',9.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-08-11 09:28:52','SYSAUTH','2012-08-11 09:28:52','LIVE',156),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',8.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-08-11 10:49:43','SYSAUTH','2012-08-11 10:49:43','LIVE',157),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',7.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-08-11 11:31:21','SYSAUTH','2012-08-11 11:31:21','LIVE',158),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',6.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-08-11 12:07:45','SYSAUTH','2012-08-11 12:07:45','LIVE',159),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',5.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-08-14 11:45:26','SYSAUTH','2012-08-14 11:45:26','LIVE',160),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',4.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-08-14 12:44:46','SYSAUTH','2012-08-14 12:44:46','HIST',161),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',0.00,-4.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-08-16 14:30:46','RAENELLE.SAMAROO-MAHARAJ','2012-08-16 14:30:46','HIST',162),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',14.00,14.00,1,'STOCK.NEW.IN','','RAENELLE.SAMAROO-MAHARAJ','2012-08-16 14:31:04','RAENELLE.SAMAROO-MAHARAJ','2012-08-16 14:31:04','LIVE',163),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',13.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-08-17 10:29:45','SYSAUTH','2012-08-17 10:29:45','LIVE',164),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',12.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-08-18 08:43:44','SYSAUTH','2012-08-18 08:43:44','LIVE',165),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',11.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-08-18 10:43:27','SYSAUTH','2012-08-18 10:43:27','LIVE',166),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',10.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-08-23 10:28:38','SYSAUTH','2012-08-23 10:28:38','LIVE',167),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',9.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-08-23 15:24:47','SYSAUTH','2012-08-23 15:24:47','LIVE',168),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',8.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-08-24 15:30:46','SYSAUTH','2012-08-24 15:30:46','LIVE',169),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',7.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-08-25 09:26:04','SYSAUTH','2012-08-25 09:26:04','LIVE',170),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',6.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-08-27 10:58:56','SYSAUTH','2012-08-27 10:58:56','LIVE',171),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',5.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-08-29 12:12:42','SYSAUTH','2012-08-29 12:12:42','LIVE',172),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',4.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-08-30 13:34:27','SYSAUTH','2012-08-30 13:34:27','LIVE',173),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',3.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-08-30 15:42:13','SYSAUTH','2012-08-30 15:42:13','LIVE',174),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',2.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-08-30 15:42:13','SYSAUTH','2012-08-30 15:42:13','LIVE',175),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',1.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-09-01 09:55:57','SYSAUTH','2012-09-01 09:55:57','LIVE',176),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',0.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-09-01 10:06:37','SYSAUTH','2012-09-01 10:06:37','HIST',177),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',8.00,8.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-09-04 15:52:12','RAENELLE.SAMAROO-MAHARAJ','2012-09-04 15:52:12','HIST',178),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',8.00,0.00,1,'STOCK.CHECK','','RAENELLE.SAMAROO-MAHARAJ','2012-09-04 15:52:30','RAENELLE.SAMAROO-MAHARAJ','2012-09-04 15:52:30','LIVE',179),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',7.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-09-05 11:44:44','SYSAUTH','2012-09-05 11:44:44','LIVE',180),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',6.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-09-05 12:53:38','SYSAUTH','2012-09-05 12:53:38','LIVE',181),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',5.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-09-05 13:05:47','SYSAUTH','2012-09-05 13:05:47','LIVE',182),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',4.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-09-07 11:17:19','SYSAUTH','2012-09-07 11:17:19','LIVE',183),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',3.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-09-10 10:15:06','SYSAUTH','2012-09-10 10:15:06','LIVE',184),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',2.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-09-10 11:02:45','SYSAUTH','2012-09-10 11:02:45','LIVE',185),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',1.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-09-10 11:44:26','SYSAUTH','2012-09-10 11:44:26','LIVE',186),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',0.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-09-10 16:40:34','SYSAUTH','2012-09-10 16:40:34','HIST',187),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',6.00,6.00,1,'STOCK.NEW.IN','','RAENELLE.SAMAROO-MAHARAJ','2012-09-15 13:14:58','RAENELLE.SAMAROO-MAHARAJ','2012-09-15 13:14:58','LIVE',188),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',5.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-09-17 10:51:14','SYSAUTH','2012-09-17 10:51:14','LIVE',189),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',4.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-09-18 11:13:02','SYSAUTH','2012-09-18 11:13:02','LIVE',190),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',3.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-09-18 11:46:58','SYSAUTH','2012-09-18 11:46:58','LIVE',191),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',2.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-09-18 13:42:19','SYSAUTH','2012-09-18 13:42:19','LIVE',192),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',1.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-09-18 14:29:48','SYSAUTH','2012-09-18 14:29:48','LIVE',193),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',0.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-09-19 09:27:44','SYSAUTH','2012-09-19 09:27:44','HIST',194),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',5.00,5.00,1,'STOCK.NEW.IN','','RAENELLE.SAMAROO-MAHARAJ','2012-09-19 10:26:46','RAENELLE.SAMAROO-MAHARAJ','2012-09-19 10:26:46','LIVE',195),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',4.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-09-19 14:17:13','SYSAUTH','2012-09-19 14:17:13','LIVE',196),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',3.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-09-21 10:46:24','SYSAUTH','2012-09-21 10:46:24','LIVE',197),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',2.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-09-21 11:04:41','SYSAUTH','2012-09-21 11:04:41','LIVE',198),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',1.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-09-21 11:30:22','SYSAUTH','2012-09-21 11:30:22','LIVE',199),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',0.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-09-21 14:47:12','SYSAUTH','2012-09-21 14:47:12','HIST',200),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',12.00,12.00,1,'STOCK.NEW.IN','','RAENELLE.SAMAROO-MAHARAJ','2012-09-22 09:20:53','RAENELLE.SAMAROO-MAHARAJ','2012-09-22 09:20:53','HIST',201),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',6.00,0.00,1,'STOCK.CHECK','','RAENELLE.SAMAROO-MAHARAJ','2012-09-22 09:22:05','RAENELLE.SAMAROO-MAHARAJ','2012-09-22 09:22:05','LIVE',202),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',5.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-09-26 11:14:23','SYSAUTH','2012-09-26 11:14:23','LIVE',203),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',4.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-09-26 12:53:46','SYSAUTH','2012-09-26 12:53:46','LIVE',204),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',3.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-09-27 10:28:37','SYSAUTH','2012-09-27 10:28:37','LIVE',205),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',2.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-09-27 11:42:45','SYSAUTH','2012-09-27 11:42:45','LIVE',206),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',1.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-09-27 15:23:21','SYSAUTH','2012-09-27 15:23:21','LIVE',207),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',0.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-09-27 16:04:37','SYSAUTH','2012-09-27 16:04:37','HIST',208),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',9.00,9.00,1,'STOCK.NEW.IN','','RAENELLE.SAMAROO-MAHARAJ','2012-10-04 13:37:06','RAENELLE.SAMAROO-MAHARAJ','2012-10-04 13:37:06','LIVE',209),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',8.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-10-05 12:00:10','SYSAUTH','2012-10-05 12:00:10','LIVE',210),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',7.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-10-05 12:33:28','SYSAUTH','2012-10-05 12:33:28','LIVE',211),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',6.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-10-06 08:38:13','SYSAUTH','2012-10-06 08:38:13','LIVE',212),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',5.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-10-06 09:35:36','SYSAUTH','2012-10-06 09:35:36','LIVE',213),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',4.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-10-06 10:35:13','SYSAUTH','2012-10-06 10:35:13','LIVE',214),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',3.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-10-06 10:59:43','SYSAUTH','2012-10-06 10:59:43','HIST',215),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',2.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-10-06 11:41:56','RAENELLE.SAMAROO-MAHARAJ','2012-10-06 11:41:56','LIVE',216),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',1.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-10-06 13:17:22','SYSAUTH','2012-10-06 13:17:22','LIVE',217),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',0.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-10-08 09:13:35','SYSAUTH','2012-10-08 09:13:35','HIST',218),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',15.00,15.00,1,'STOCK.NEW.IN','','RAENELLE.SAMAROO-MAHARAJ','2012-10-08 09:57:47','RAENELLE.SAMAROO-MAHARAJ','2012-10-08 09:57:47','LIVE',219),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',14.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-10-08 10:15:03','SYSAUTH','2012-10-08 10:15:03','LIVE',220),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',13.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-10-08 10:50:32','SYSAUTH','2012-10-08 10:50:32','LIVE',221),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',12.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-10-08 11:05:55','SYSAUTH','2012-10-08 11:05:55','LIVE',222),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',11.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-10-09 09:36:57','SYSAUTH','2012-10-09 09:36:57','LIVE',223),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',10.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-10-09 10:58:00','SYSAUTH','2012-10-09 10:58:00','LIVE',224),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',9.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-10-10 09:53:20','SYSAUTH','2012-10-10 09:53:20','LIVE',225),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',8.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-10-10 12:05:49','SYSAUTH','2012-10-10 12:05:49','LIVE',226),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',7.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-10-10 12:34:13','SYSAUTH','2012-10-10 12:34:13','LIVE',227),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',6.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-10-11 10:06:57','SYSAUTH','2012-10-11 10:06:57','LIVE',228),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',5.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-10-11 15:23:54','SYSAUTH','2012-10-11 15:23:54','LIVE',229),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',4.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-10-11 15:25:38','SYSAUTH','2012-10-11 15:25:38','LIVE',230),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',3.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-10-12 10:45:01','SYSAUTH','2012-10-12 10:45:01','LIVE',231),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',2.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-10-13 10:45:27','SYSAUTH','2012-10-13 10:45:27','LIVE',232),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',1.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-10-13 11:39:17','SYSAUTH','2012-10-13 11:39:17','LIVE',233),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',0.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-10-16 10:25:02','SYSAUTH','2012-10-16 10:25:02','HIST',234),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',14.00,14.00,1,'STOCK.NEW.IN','','RAENELLE.SAMAROO-MAHARAJ','2012-10-16 15:38:35','RAENELLE.SAMAROO-MAHARAJ','2012-10-16 15:38:35','LIVE',235),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',13.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-10-17 13:39:07','SYSAUTH','2012-10-17 13:39:07','LIVE',236),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',12.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-10-18 10:34:28','SYSAUTH','2012-10-18 10:34:28','LIVE',237),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',11.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-10-18 10:53:28','SYSAUTH','2012-10-18 10:53:28','LIVE',238),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',10.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-10-18 16:04:18','SYSAUTH','2012-10-18 16:04:18','LIVE',239),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',9.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-10-19 10:31:02','SYSAUTH','2012-10-19 10:31:02','LIVE',240),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',8.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-10-19 10:39:15','SYSAUTH','2012-10-19 10:39:15','LIVE',241),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',7.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-10-19 11:47:10','SYSAUTH','2012-10-19 11:47:10','LIVE',242),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',6.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-10-19 12:10:45','SYSAUTH','2012-10-19 12:10:45','LIVE',243),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',5.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-10-19 14:16:29','SYSAUTH','2012-10-19 14:16:29','LIVE',244),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',4.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-10-19 14:45:55','SYSAUTH','2012-10-19 14:45:55','LIVE',245),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',3.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-10-20 10:39:25','SYSAUTH','2012-10-20 10:39:25','LIVE',246),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',2.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-10-22 11:53:37','SYSAUTH','2012-10-22 11:53:37','LIVE',247),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',1.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-10-23 09:44:24','SYSAUTH','2012-10-23 09:44:24','LIVE',248),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',0.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-10-23 13:03:50','SYSAUTH','2012-10-23 13:03:50','HIST',249),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',2.00,2.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-10-23 17:00:39','RAENELLE.SAMAROO-MAHARAJ','2012-10-23 17:00:39','HIST',250),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',12.00,10.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-10-24 16:39:35','RAENELLE.SAMAROO-MAHARAJ','2012-10-24 16:39:35','LIVE',251),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',11.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-10-25 09:09:56','SYSAUTH','2012-10-25 09:09:56','LIVE',252),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',10.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-10-26 10:45:35','SYSAUTH','2012-10-26 10:45:35','LIVE',253),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',9.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-10-26 12:05:49','SYSAUTH','2012-10-26 12:05:49','LIVE',254),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',8.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-10-26 14:10:49','SYSAUTH','2012-10-26 14:10:49','LIVE',255),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',7.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-10-27 09:02:30','SYSAUTH','2012-10-27 09:02:30','LIVE',256),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',6.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-10-29 09:53:41','SYSAUTH','2012-10-29 09:53:41','LIVE',257),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',5.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-10-29 11:04:36','SYSAUTH','2012-10-29 11:04:36','LIVE',258),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',4.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-10-29 13:09:40','SYSAUTH','2012-10-29 13:09:40','HIST',259),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',9.00,5.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-10-30 09:20:34','RAENELLE.SAMAROO-MAHARAJ','2012-10-30 09:20:34','LIVE',260),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',8.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-10-30 10:38:44','SYSAUTH','2012-10-30 10:38:44','LIVE',261),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',7.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-10-30 14:22:07','SYSAUTH','2012-10-30 14:22:07','LIVE',262),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',6.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-10-30 16:15:38','SYSAUTH','2012-10-30 16:15:38','LIVE',263),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',5.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-10-31 09:35:39','SYSAUTH','2012-10-31 09:35:39','LIVE',264),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',4.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-10-31 09:48:36','SYSAUTH','2012-10-31 09:48:36','LIVE',265),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',3.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-10-31 10:01:42','SYSAUTH','2012-10-31 10:01:42','LIVE',266),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',2.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-10-31 12:07:29','SYSAUTH','2012-10-31 12:07:29','LIVE',267),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',1.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-10-31 12:39:39','SYSAUTH','2012-10-31 12:39:39','LIVE',268),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',0.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-11-01 08:59:47','SYSAUTH','2012-11-01 08:59:47','HIST',269),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',6.00,0.00,1,'STOCK.CHECK','','RAENELLE.SAMAROO-MAHARAJ','2012-11-05 12:05:42','RAENELLE.SAMAROO-MAHARAJ','2012-11-05 12:05:42','LIVE',270),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',5.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-11-05 12:23:02','SYSAUTH','2012-11-05 12:23:02','LIVE',271),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',4.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-11-06 09:49:48','SYSAUTH','2012-11-06 09:49:48','HIST',272),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',10.00,6.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-11-06 16:56:53','RAENELLE.SAMAROO-MAHARAJ','2012-11-06 16:56:53','LIVE',273),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',9.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-11-07 10:39:23','SYSAUTH','2012-11-07 10:39:23','LIVE',274),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',8.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-11-09 09:45:14','SYSAUTH','2012-11-09 09:45:14','LIVE',275),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',7.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-11-09 11:28:55','SYSAUTH','2012-11-09 11:28:55','LIVE',276),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',6.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-11-09 11:52:05','SYSAUTH','2012-11-09 11:52:05','LIVE',277),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',5.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-11-09 14:07:00','SYSAUTH','2012-11-09 14:07:00','LIVE',278),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',4.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-11-09 16:13:31','SYSAUTH','2012-11-09 16:13:31','LIVE',279),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',3.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-11-12 12:45:24','SYSAUTH','2012-11-12 12:45:24','LIVE',280),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',2.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-11-12 14:27:34','SYSAUTH','2012-11-12 14:27:34','LIVE',281),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',1.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-11-14 09:31:11','SYSAUTH','2012-11-14 09:31:11','LIVE',282),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',0.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-11-14 09:31:20','SYSAUTH','2012-11-14 09:31:20','HIST',283),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',9.00,9.00,1,'STOCK.NEW.IN','','RAENELLE.SAMAROO-MAHARAJ','2012-11-17 11:11:47','RAENELLE.SAMAROO-MAHARAJ','2012-11-17 11:11:47','LIVE',284),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',7.00,-2.00,1,'SALE','','AMANDA.OUDAI','2012-11-17 11:38:53','SYSAUTH','2012-11-17 11:38:53','LIVE',285),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',6.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-11-17 11:39:34','SYSAUTH','2012-11-17 11:39:34','LIVE',286),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',5.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-11-19 09:53:36','SYSAUTH','2012-11-19 09:53:36','LIVE',287),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',4.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-11-20 10:16:02','SYSAUTH','2012-11-20 10:16:02','HIST',288),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',12.00,8.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-11-20 15:13:53','RAENELLE.SAMAROO-MAHARAJ','2012-11-20 15:13:53','LIVE',289),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',10.00,-2.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-11-21 10:24:26','SYSAUTH','2012-11-21 10:24:26','LIVE',290),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',9.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-11-21 11:50:56','SYSAUTH','2012-11-21 11:50:56','LIVE',291),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',8.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-11-21 12:49:06','SYSAUTH','2012-11-21 12:49:06','LIVE',292),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',7.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-11-21 16:05:18','SYSAUTH','2012-11-21 16:05:18','LIVE',293),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',6.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-11-22 09:30:35','SYSAUTH','2012-11-22 09:30:35','LIVE',294),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',5.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-11-22 09:55:18','SYSAUTH','2012-11-22 09:55:18','LIVE',295),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',4.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-11-22 11:24:50','SYSAUTH','2012-11-22 11:24:50','LIVE',296),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',3.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-11-23 11:08:04','SYSAUTH','2012-11-23 11:08:04','LIVE',297),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',2.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-11-23 13:06:24','SYSAUTH','2012-11-23 13:06:24','LIVE',298),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',1.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-11-26 10:42:22','SYSAUTH','2012-11-26 10:42:22','LIVE',299),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',0.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-11-26 10:51:37','SYSAUTH','2012-11-26 10:51:37','HIST',300),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',10.00,0.00,1,'STOCK.CHECK','','RAENELLE.SAMAROO-MAHARAJ','2012-11-26 14:51:30','RAENELLE.SAMAROO-MAHARAJ','2012-11-26 14:51:30','LIVE',301),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',9.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-11-27 12:01:37','SYSAUTH','2012-11-27 12:01:37','LIVE',302),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',8.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-11-27 15:38:52','SYSAUTH','2012-11-27 15:38:52','LIVE',303),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',7.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-11-28 13:32:24','SYSAUTH','2012-11-28 13:32:24','LIVE',304),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',6.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-11-29 10:47:24','SYSAUTH','2012-11-29 10:47:24','LIVE',305),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',5.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-11-29 11:16:39','SYSAUTH','2012-11-29 11:16:39','LIVE',306),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',4.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-11-29 12:45:50','SYSAUTH','2012-11-29 12:45:50','LIVE',307),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',3.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-11-29 12:48:48','SYSAUTH','2012-11-29 12:48:48','LIVE',308),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',2.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-11-29 13:13:44','SYSAUTH','2012-11-29 13:13:44','LIVE',309),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',1.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-11-30 10:32:14','SYSAUTH','2012-11-30 10:32:14','LIVE',310),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',0.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-11-30 13:33:15','SYSAUTH','2012-11-30 13:33:15','HIST',311),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',7.00,0.00,1,'STOCK.CHECK','','RAENELLE.SAMAROO-MAHARAJ','2012-11-30 16:09:39','RAENELLE.SAMAROO-MAHARAJ','2012-11-30 16:09:39','LIVE',312),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',6.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-12-01 08:50:44','SYSAUTH','2012-12-01 08:50:44','LIVE',313),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',5.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-12-01 08:52:01','SYSAUTH','2012-12-01 08:52:01','LIVE',314),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',4.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-12-01 10:24:34','SYSAUTH','2012-12-01 10:24:34','LIVE',315),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',3.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-12-01 12:48:53','SYSAUTH','2012-12-01 12:48:53','LIVE',316),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',2.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-12-03 10:15:09','SYSAUTH','2012-12-03 10:15:09','LIVE',317),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',1.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-12-03 12:08:00','SYSAUTH','2012-12-03 12:08:00','LIVE',318),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',0.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-12-04 11:33:00','SYSAUTH','2012-12-04 11:33:00','HIST',319),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',20.00,20.00,1,'STOCK.NEW.IN','','RAENELLE.SAMAROO-MAHARAJ','2012-12-04 15:35:57','RAENELLE.SAMAROO-MAHARAJ','2012-12-04 15:35:57','LIVE',320),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',19.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-12-05 13:04:05','SYSAUTH','2012-12-05 13:04:05','LIVE',321),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',18.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-12-05 15:59:23','SYSAUTH','2012-12-05 15:59:23','LIVE',322),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',17.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-12-06 15:32:26','SYSAUTH','2012-12-06 15:32:26','HIST',323),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',15.00,0.00,1,'STOCK.CHECK','','RAENELLE.SAMAROO-MAHARAJ','2012-12-07 16:42:59','RAENELLE.SAMAROO-MAHARAJ','2012-12-07 16:42:59','LIVE',324),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',14.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-12-08 09:51:18','SYSAUTH','2012-12-08 09:51:18','LIVE',325),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',13.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-12-08 10:35:53','SYSAUTH','2012-12-08 10:35:53','LIVE',326),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',12.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-12-08 10:57:48','SYSAUTH','2012-12-08 10:57:48','LIVE',327),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',11.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-12-10 09:38:25','SYSAUTH','2012-12-10 09:38:25','LIVE',328),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',10.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-12-10 14:04:35','SYSAUTH','2012-12-10 14:04:35','LIVE',329),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',9.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-12-11 16:35:29','SYSAUTH','2012-12-11 16:35:29','LIVE',330),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',8.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-12-12 09:51:51','SYSAUTH','2012-12-12 09:51:51','LIVE',331),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',7.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-12-12 10:11:08','SYSAUTH','2012-12-12 10:11:08','LIVE',332),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',6.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-12-12 12:50:44','SYSAUTH','2012-12-12 12:50:44','LIVE',333),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',5.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-12-12 14:45:14','SYSAUTH','2012-12-12 14:45:14','LIVE',334),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',4.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-12-13 10:11:15','SYSAUTH','2012-12-13 10:11:15','LIVE',335),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',3.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-12-13 10:42:28','SYSAUTH','2012-12-13 10:42:28','LIVE',336),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',2.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-12-13 10:54:39','SYSAUTH','2012-12-13 10:54:39','LIVE',337),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',1.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-12-13 13:39:24','SYSAUTH','2012-12-13 13:39:24','LIVE',338),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',0.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-12-13 15:01:31','SYSAUTH','2012-12-13 15:01:31','HIST',339),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',9.00,0.00,1,'STOCK.CHECK','','ADMIN','2012-12-18 15:55:35','ADMIN','2012-12-18 15:55:35','LIVE',340),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',8.00,-1.00,1,'SALE','','ADMIN','2012-12-18 16:09:27','SYSAUTH','2012-12-18 16:09:27','LIVE',341),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',7.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-12-19 10:21:17','SYSAUTH','2012-12-19 10:21:17','LIVE',342),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',6.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-12-19 10:40:24','SYSAUTH','2012-12-19 10:40:24','LIVE',343),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',5.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-12-19 12:55:24','SYSAUTH','2012-12-19 12:55:24','LIVE',344),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',4.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-12-20 10:19:00','SYSAUTH','2012-12-20 10:19:00','LIVE',345),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',3.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-12-20 13:15:47','SYSAUTH','2012-12-20 13:15:47','LIVE',346),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',2.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-12-20 14:39:07','SYSAUTH','2012-12-20 14:39:07','HIST',347),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',6.00,4.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-12-20 14:43:57','RAENELLE.SAMAROO-MAHARAJ','2012-12-20 14:43:57','HIST',348),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',8.00,2.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-12-20 14:46:23','RAENELLE.SAMAROO-MAHARAJ','2012-12-20 14:46:23','LIVE',349),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',7.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-12-20 14:54:25','SYSAUTH','2012-12-20 14:54:25','LIVE',350),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',6.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-12-21 09:30:05','SYSAUTH','2012-12-21 09:30:05','LIVE',351),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',5.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-12-21 11:24:34','SYSAUTH','2012-12-21 11:24:34','LIVE',352),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',4.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-12-21 11:27:37','SYSAUTH','2012-12-21 11:27:37','LIVE',353),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',100.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-12-21 12:02:17','SYSAUTH','2012-12-21 12:02:17','LIVE',354),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',99.00,-1.00,1,'SALE','','ADMIN','2013-02-20 23:04:00','SYSAUTH','2013-02-20 23:04:00','LIVE',355),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',98.00,-1.00,1,'SALE','','ADMIN','2013-02-20 23:06:21','SYSAUTH','2013-02-20 23:06:21','LIVE',356),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',97.00,-1.00,1,'SALE','','ADMIN','2013-02-20 23:12:20','SYSAUTH','2013-02-20 23:12:20','LIVE',357),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',96.00,-1.00,1,'SALE','','ADMIN','2013-02-20 23:15:22','SYSAUTH','2013-02-20 23:15:22','LIVE',358),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',95.00,-1.00,1,'SALE','','ADMIN','2013-02-20 23:27:06','SYSAUTH','2013-02-20 23:27:06','LIVE',359),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',94.00,-1.00,1,'SALE','','ADMIN','2013-02-24 15:40:19','SYSAUTH','2013-02-24 15:40:19','LIVE',360),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',92.00,-2.00,1,'SALE','','ADMIN','2013-02-24 15:40:19','SYSAUTH','2013-02-24 15:40:19','LIVE',361),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',89.00,-3.00,1,'SALE','','ADMIN','2013-02-24 15:40:19','SYSAUTH','2013-02-24 15:40:19','LIVE',362),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',88.00,-1.00,1,'SALE','','ADMIN','2013-02-24 23:49:08','SYSAUTH','2013-02-24 23:49:08','LIVE',363),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',87.00,-1.00,1,'SALE','','ADMIN','2013-02-25 01:07:45','SYSAUTH','2013-02-25 01:07:45','LIVE',364),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',86.00,-1.00,1,'SALE','','ADMIN','2013-02-25 01:17:52','SYSAUTH','2013-02-25 01:17:52','LIVE',365),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',85.00,-1.00,1,'SALE','','ADMIN','2013-02-25 01:23:07','SYSAUTH','2013-02-25 01:23:07','LIVE',366),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',84.00,-1.00,1,'SALE','','ADMIN','2013-02-25 01:24:44','SYSAUTH','2013-02-25 01:24:44','LIVE',367),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',83.00,-1.00,1,'SALE','','ADMIN','2013-02-25 02:41:48','SYSAUTH','2013-02-25 02:41:48','LIVE',368),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',82.00,-1.00,1,'SALE','','ADMIN','2013-02-25 02:41:48','SYSAUTH','2013-02-25 02:41:48','LIVE',369),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',81.00,-1.00,1,'SALE','','ADMIN','2013-02-25 03:07:04','SYSAUTH','2013-02-25 03:07:04','LIVE',370),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',80.00,-1.00,1,'SALE','','ADMIN','2013-02-25 03:07:04','SYSAUTH','2013-02-25 03:07:04','LIVE',371),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',79.00,-1.00,1,'SALE','','ADMIN','2013-02-25 03:07:05','SYSAUTH','2013-02-25 03:07:05','LIVE',372),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',78.00,-1.00,1,'SALE','','ADMIN','2013-02-25 03:12:18','SYSAUTH','2013-02-25 03:12:18','LIVE',373),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',77.00,-1.00,1,'SALE','','ADMIN','2013-02-25 03:18:21','SYSAUTH','2013-02-25 03:18:21','LIVE',374),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',76.00,-1.00,1,'SALE','','ADMIN','2013-02-25 03:28:59','SYSAUTH','2013-02-25 03:28:59','LIVE',375),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',71.00,-5.00,1,'SALE','','ADMIN','2013-02-25 03:37:04','SYSAUTH','2013-02-25 03:37:04','LIVE',376),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',70.00,-1.00,1,'SALE','','ADMIN','2013-02-25 12:53:50','SYSAUTH','2013-02-25 12:53:50','LIVE',377),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',69.00,-1.00,1,'SALE','','ADMIN','2013-02-25 12:59:56','SYSAUTH','2013-02-25 12:59:56','LIVE',378),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',68.00,-1.00,1,'SALE','','ADMIN','2013-02-25 13:09:00','SYSAUTH','2013-02-25 13:09:00','LIVE',379),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',67.00,-1.00,1,'SALE','','ADMIN','2013-02-25 13:12:46','SYSAUTH','2013-02-25 13:12:46','LIVE',380),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',62.00,-5.00,1,'SALE','','ADMIN','2013-02-26 19:55:47','SYSAUTH','2013-02-26 19:55:47','LIVE',381),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',61.00,-1.00,1,'SALE','','ADMIN','2013-03-17 13:45:49','SYSAUTH','2013-03-17 13:45:49','LIVE',382),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',60.00,-1.00,1,'SALE','','ADMIN','2013-03-17 17:19:28','SYSAUTH','2013-03-17 17:19:28','LIVE',383),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',59.00,-1.00,1,'SALE','','ADMIN','2013-03-17 17:26:27','SYSAUTH','2013-03-17 17:26:27','LIVE',384),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',58.00,-1.00,1,'SALE','','ADMIN','2013-03-17 17:28:50','SYSAUTH','2013-03-17 17:28:50','LIVE',385),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',57.00,-1.00,1,'SALE','','ADMIN','2013-03-17 17:53:45','SYSAUTH','2013-03-17 17:53:45','LIVE',386),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',56.00,-1.00,1,'SALE','','ADMIN','2013-03-17 17:56:25','SYSAUTH','2013-03-17 17:56:25','LIVE',387),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',55.00,-1.00,1,'SALE','','ADMIN','2013-03-18 03:12:46','SYSAUTH','2013-03-18 03:12:46','LIVE',388),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',54.00,-1.00,1,'SALE','','ADMIN','2013-03-18 03:15:56','SYSAUTH','2013-03-18 03:15:56','LIVE',389),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',53.00,-1.00,1,'SALE','','ADMIN','2013-03-18 03:43:19','SYSAUTH','2013-03-18 03:43:19','LIVE',390),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',52.00,-1.00,1,'SALE','','ADMIN','2013-03-18 04:57:36','SYSAUTH','2013-03-18 04:57:36','LIVE',391),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',51.00,-1.00,1,'SALE','','ADMIN','2013-03-18 10:06:05','SYSAUTH','2013-03-18 10:06:05','LIVE',392),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',46.00,-5.00,1,'SALE','','ADMIN','2013-03-18 11:33:06','SYSAUTH','2013-03-18 11:33:06','HIST',393),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',46.00,10.00,1,'ORDER.CANCEL.RETURN','','ADMIN','2013-03-18 13:28:51','ADMIN','2013-03-18 13:28:51','LIVE',394),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',45.00,-1.00,1,'SALE','','ADMIN','2013-03-18 13:51:27','SYSAUTH','2013-03-18 13:51:27','HIST',395),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',46.00,1.00,1,'ORDER.CANCEL.RETURN','','ADMIN','2013-03-18 14:15:01','ADMIN','2013-03-18 14:15:01','LIVE',396),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',43.00,-3.00,1,'SALE','','ADMIN','2013-03-18 14:27:01','SYSAUTH','2013-03-18 14:27:01','LIVE',397),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',39.00,-4.00,1,'SALE','','ADMIN','2013-03-18 14:32:12','SYSAUTH','2013-03-18 14:32:12','HIST',398),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',43.00,4.00,1,'ORDER.CANCEL.RETURN','','ADMIN','2013-03-18 14:33:20','ADMIN','2013-03-18 14:33:21','LIVE',399),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',36.00,-7.00,1,'SALE','','ADMIN','2013-03-18 14:37:30','SYSAUTH','2013-03-18 14:37:30','HIST',400),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',43.00,7.00,1,'ORDER.CANCEL.RETURN','','ADMIN','2013-03-18 14:39:10','ADMIN','2013-03-18 14:39:10','LIVE',401),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',41.00,-2.00,1,'SALE','','ADMIN','2013-03-18 18:39:54','SYSAUTH','2013-03-18 18:39:54','HIST',402),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',43.00,2.00,1,'ORDER.CANCEL.RETURN','','ADMIN','2013-03-18 18:41:56','ADMIN','2013-03-18 18:41:56','LIVE',403),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',42.00,-1.00,1,'SALE','','ADMIN','2013-03-19 07:24:14','SYSAUTH','2013-03-19 07:24:14','LIVE',404),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',41.00,-1.00,1,'SALE','','ADMIN','2013-03-19 09:31:45','SYSAUTH','2013-03-19 09:31:45','HIST',405),(501,'G10-HEAD.OFFICE','G10','HEAD.OFFICE',58.00,1.00,1,'ORDER.CANCEL.RETURN','','ADMIN','2013-03-21 01:57:32','ADMIN','2013-03-21 01:57:32','LIVE',406),(502,'GIT101-HEAD.OFFICE','GIT101','HEAD.OFFICE',4.00,0.00,1,'STOCK.CHECK','','ADMIN','2012-05-12 13:16:37','ADMIN','2012-05-12 13:16:47','HIST',1),(502,'GIT101-HEAD.OFFICE','GIT101','HEAD.OFFICE',5.00,0.00,1,'STOCK.NEW.IN','','RAENELLE.SAMAROO-MAHARAJ','2012-05-19 12:36:30','RAENELLE.SAMAROO-MAHARAJ','2012-05-19 12:36:30','LIVE',2),(502,'GIT101-HEAD.OFFICE','GIT101','HEAD.OFFICE',4.00,0.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-05-19 12:41:24','SYSAUTH','2012-05-19 12:41:24','LIVE',3),(502,'GIT101-HEAD.OFFICE','GIT101','HEAD.OFFICE',3.00,0.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-05-19 12:46:06','SYSAUTH','2012-05-19 12:46:06','LIVE',4),(502,'GIT101-HEAD.OFFICE','GIT101','HEAD.OFFICE',2.00,0.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-05-19 12:46:50','SYSAUTH','2012-05-19 12:46:50','LIVE',5),(502,'GIT101-HEAD.OFFICE','GIT101','HEAD.OFFICE',1.00,0.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-05-21 15:22:34','SYSAUTH','2012-05-21 15:22:34','HIST',6),(502,'GIT101-HEAD.OFFICE','GIT101','HEAD.OFFICE',3.00,0.00,1,'STOCK.NEW.IN','','RAENELLE.SAMAROO-MAHARAJ','2012-05-21 16:19:58','RAENELLE.SAMAROO-MAHARAJ','2012-05-21 16:19:58','HIST',7),(502,'GIT101-HEAD.OFFICE','GIT101','HEAD.OFFICE',4.00,0.00,1,'STOCK.NEW.IN','','RAENELLE.SAMAROO-MAHARAJ','2012-05-21 16:20:23','RAENELLE.SAMAROO-MAHARAJ','2012-05-21 16:20:23','LIVE',8),(502,'GIT101-HEAD.OFFICE','GIT101','HEAD.OFFICE',3.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-05-28 09:59:47','SYSAUTH','2012-05-28 09:59:47','HIST',9),(502,'GIT101-HEAD.OFFICE','GIT101','HEAD.OFFICE',4.00,1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-05-28 11:46:12','RAENELLE.SAMAROO-MAHARAJ','2012-05-28 11:46:12','LIVE',10),(502,'GIT101-HEAD.OFFICE','GIT101','HEAD.OFFICE',3.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-05-29 13:08:44','SYSAUTH','2012-05-29 13:08:44','LIVE',11),(502,'GIT101-HEAD.OFFICE','GIT101','HEAD.OFFICE',2.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-06-01 09:22:27','SYSAUTH','2012-06-01 09:22:27','LIVE',12),(502,'GIT101-HEAD.OFFICE','GIT101','HEAD.OFFICE',1.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-06-01 09:27:13','SYSAUTH','2012-06-01 09:27:13','HIST',13),(502,'GIT101-HEAD.OFFICE','GIT101','HEAD.OFFICE',4.00,3.00,1,'STOCK.NEW.IN','','RAENELLE.SAMAROO-MAHARAJ','2012-06-06 11:18:11','RAENELLE.SAMAROO-MAHARAJ','2012-06-06 11:18:11','HIST',14),(502,'GIT101-HEAD.OFFICE','GIT101','HEAD.OFFICE',4.00,0.00,1,'STOCK.NEW.IN','','RAENELLE.SAMAROO-MAHARAJ','2012-06-06 11:18:46','RAENELLE.SAMAROO-MAHARAJ','2012-06-06 11:18:46','LIVE',15),(502,'GIT101-HEAD.OFFICE','GIT101','HEAD.OFFICE',3.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-06-06 12:23:54','SYSAUTH','2012-06-06 12:23:54','LIVE',16),(502,'GIT101-HEAD.OFFICE','GIT101','HEAD.OFFICE',2.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-06-06 15:02:55','SYSAUTH','2012-06-06 15:02:55','LIVE',17),(502,'GIT101-HEAD.OFFICE','GIT101','HEAD.OFFICE',1.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-06-08 12:41:15','SYSAUTH','2012-06-08 12:41:15','LIVE',18),(502,'GIT101-HEAD.OFFICE','GIT101','HEAD.OFFICE',0.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-06-11 09:53:41','SYSAUTH','2012-06-11 09:53:41','HIST',19),(502,'GIT101-HEAD.OFFICE','GIT101','HEAD.OFFICE',6.00,6.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-06-15 09:42:54','RAENELLE.SAMAROO-MAHARAJ','2012-06-15 09:42:54','HIST',20),(502,'GIT101-HEAD.OFFICE','GIT101','HEAD.OFFICE',5.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-06-15 09:43:16','RAENELLE.SAMAROO-MAHARAJ','2012-06-15 09:43:16','HIST',21),(502,'GIT101-HEAD.OFFICE','GIT101','HEAD.OFFICE',5.00,0.00,1,'STOCK.CHECK','','RAENELLE.SAMAROO-MAHARAJ','2012-06-15 09:44:05','RAENELLE.SAMAROO-MAHARAJ','2012-06-15 09:44:05','LIVE',22),(502,'GIT101-HEAD.OFFICE','GIT101','HEAD.OFFICE',4.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-06-20 12:59:05','SYSAUTH','2012-06-20 12:59:05','LIVE',23),(502,'GIT101-HEAD.OFFICE','GIT101','HEAD.OFFICE',3.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-06-20 13:22:52','SYSAUTH','2012-06-20 13:22:52','HIST',24),(502,'GIT101-HEAD.OFFICE','GIT101','HEAD.OFFICE',5.00,0.00,1,'STOCK.CHECK','','RAENELLE.SAMAROO-MAHARAJ','2012-06-21 16:43:14','RAENELLE.SAMAROO-MAHARAJ','2012-06-21 16:43:14','LIVE',25),(502,'GIT101-HEAD.OFFICE','GIT101','HEAD.OFFICE',4.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-06-22 12:12:41','SYSAUTH','2012-06-22 12:12:41','LIVE',26),(502,'GIT101-HEAD.OFFICE','GIT101','HEAD.OFFICE',3.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-06-22 13:12:42','SYSAUTH','2012-06-22 13:12:42','LIVE',27),(502,'GIT101-HEAD.OFFICE','GIT101','HEAD.OFFICE',2.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-06-26 10:29:31','SYSAUTH','2012-06-26 10:29:31','HIST',28),(502,'GIT101-HEAD.OFFICE','GIT101','HEAD.OFFICE',5.00,0.00,1,'STOCK.CHECK','','RAENELLE.SAMAROO-MAHARAJ','2012-06-27 12:48:23','RAENELLE.SAMAROO-MAHARAJ','2012-06-27 12:48:23','LIVE',29),(502,'GIT101-HEAD.OFFICE','GIT101','HEAD.OFFICE',4.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-06-29 11:09:08','SYSAUTH','2012-06-29 11:09:08','LIVE',30),(502,'GIT101-HEAD.OFFICE','GIT101','HEAD.OFFICE',3.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-07-02 12:55:41','SYSAUTH','2012-07-02 12:55:41','LIVE',31),(502,'GIT101-HEAD.OFFICE','GIT101','HEAD.OFFICE',2.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-07-02 13:11:30','SYSAUTH','2012-07-02 13:11:30','HIST',32),(502,'GIT101-HEAD.OFFICE','GIT101','HEAD.OFFICE',7.00,5.00,1,'STOCK.NEW.IN','','RAENELLE.SAMAROO-MAHARAJ','2012-07-02 16:43:30','RAENELLE.SAMAROO-MAHARAJ','2012-07-02 16:43:30','LIVE',33),(502,'GIT101-HEAD.OFFICE','GIT101','HEAD.OFFICE',6.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-07-03 10:18:31','SYSAUTH','2012-07-03 10:18:31','LIVE',34),(502,'GIT101-HEAD.OFFICE','GIT101','HEAD.OFFICE',5.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-07-07 10:46:39','SYSAUTH','2012-07-07 10:46:39','LIVE',35),(502,'GIT101-HEAD.OFFICE','GIT101','HEAD.OFFICE',4.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-07-12 15:48:31','SYSAUTH','2012-07-12 15:48:31','HIST',36),(502,'GIT101-HEAD.OFFICE','GIT101','HEAD.OFFICE',5.00,0.00,1,'STOCK.CHECK','','RAENELLE.SAMAROO-MAHARAJ','2012-07-12 16:29:45','RAENELLE.SAMAROO-MAHARAJ','2012-07-12 16:29:45','LIVE',37),(502,'GIT101-HEAD.OFFICE','GIT101','HEAD.OFFICE',4.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-07-13 09:13:42','SYSAUTH','2012-07-13 09:13:42','LIVE',38),(502,'GIT101-HEAD.OFFICE','GIT101','HEAD.OFFICE',2.00,-2.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-07-14 11:43:37','SYSAUTH','2012-07-14 11:43:37','HIST',39),(502,'GIT101-HEAD.OFFICE','GIT101','HEAD.OFFICE',1.00,-1.00,1,'CUSTOMER.REPLACEMENT','','RAENELLE.SAMAROO-MAHARAJ','2012-07-14 11:56:32','RAENELLE.SAMAROO-MAHARAJ','2012-07-14 11:56:32','LIVE',40),(502,'GIT101-HEAD.OFFICE','GIT101','HEAD.OFFICE',0.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-07-16 11:46:13','SYSAUTH','2012-07-16 11:46:13','HIST',41),(502,'GIT101-HEAD.OFFICE','GIT101','HEAD.OFFICE',5.00,5.00,1,'STOCK.NEW.IN','','RAENELLE.SAMAROO-MAHARAJ','2012-07-17 09:52:32','RAENELLE.SAMAROO-MAHARAJ','2012-07-17 09:52:32','LIVE',42),(502,'GIT101-HEAD.OFFICE','GIT101','HEAD.OFFICE',4.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-07-17 12:46:50','SYSAUTH','2012-07-17 12:46:50','HIST',43),(502,'GIT101-HEAD.OFFICE','GIT101','HEAD.OFFICE',10.00,6.00,1,'STOCK.NEW.IN','','RAENELLE.SAMAROO-MAHARAJ','2012-07-17 16:42:42','RAENELLE.SAMAROO-MAHARAJ','2012-07-17 16:42:42','HIST',44),(502,'GIT101-HEAD.OFFICE','GIT101','HEAD.OFFICE',9.00,-1.00,1,'STOCK.NEW.IN','','RAENELLE.SAMAROO-MAHARAJ','2012-07-17 16:47:33','RAENELLE.SAMAROO-MAHARAJ','2012-07-17 16:47:33','LIVE',45),(502,'GIT101-HEAD.OFFICE','GIT101','HEAD.OFFICE',8.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-07-18 11:37:23','SYSAUTH','2012-07-18 11:37:23','LIVE',46),(502,'GIT101-HEAD.OFFICE','GIT101','HEAD.OFFICE',7.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-07-21 09:04:37','SYSAUTH','2012-07-21 09:04:37','LIVE',47),(502,'GIT101-HEAD.OFFICE','GIT101','HEAD.OFFICE',6.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-07-21 10:14:39','SYSAUTH','2012-07-21 10:14:39','LIVE',48),(502,'GIT101-HEAD.OFFICE','GIT101','HEAD.OFFICE',5.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-07-21 12:49:05','SYSAUTH','2012-07-21 12:49:05','HIST',49),(502,'GIT101-HEAD.OFFICE','GIT101','HEAD.OFFICE',3.00,-2.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-07-23 15:03:25','RAENELLE.SAMAROO-MAHARAJ','2012-07-23 15:03:25','HIST',50),(502,'GIT101-HEAD.OFFICE','GIT101','HEAD.OFFICE',1.00,-2.00,1,'CUSTOMER.REPLACEMENT','','RAENELLE.SAMAROO-MAHARAJ','2012-07-23 15:03:54','RAENELLE.SAMAROO-MAHARAJ','2012-07-23 15:03:54','HIST',51),(502,'GIT101-HEAD.OFFICE','GIT101','HEAD.OFFICE',5.00,4.00,1,'STOCK.NEW.IN','','RAENELLE.SAMAROO-MAHARAJ','2012-07-23 17:06:32','RAENELLE.SAMAROO-MAHARAJ','2012-07-23 17:06:32','LIVE',52),(502,'GIT101-HEAD.OFFICE','GIT101','HEAD.OFFICE',4.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-07-24 15:09:06','SYSAUTH','2012-07-24 15:09:06','LIVE',53),(502,'GIT101-HEAD.OFFICE','GIT101','HEAD.OFFICE',3.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-07-25 09:39:38','SYSAUTH','2012-07-25 09:39:38','LIVE',54),(502,'GIT101-HEAD.OFFICE','GIT101','HEAD.OFFICE',2.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-07-26 10:05:34','SYSAUTH','2012-07-26 10:05:34','HIST',55),(502,'GIT101-HEAD.OFFICE','GIT101','HEAD.OFFICE',5.00,3.00,1,'STOCK.NEW.IN','','RAENELLE.SAMAROO-MAHARAJ','2012-07-26 14:40:16','RAENELLE.SAMAROO-MAHARAJ','2012-07-26 14:40:16','LIVE',56),(502,'GIT101-HEAD.OFFICE','GIT101','HEAD.OFFICE',4.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-07-27 15:24:55','SYSAUTH','2012-07-27 15:24:55','LIVE',57),(502,'GIT101-HEAD.OFFICE','GIT101','HEAD.OFFICE',3.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-07-31 12:59:46','SYSAUTH','2012-07-31 12:59:46','LIVE',58),(502,'GIT101-HEAD.OFFICE','GIT101','HEAD.OFFICE',2.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-08-02 13:21:39','SYSAUTH','2012-08-02 13:21:39','LIVE',59),(502,'GIT101-HEAD.OFFICE','GIT101','HEAD.OFFICE',1.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-08-03 10:49:46','SYSAUTH','2012-08-03 10:49:46','LIVE',60),(502,'GIT101-HEAD.OFFICE','GIT101','HEAD.OFFICE',0.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-08-03 12:20:13','SYSAUTH','2012-08-03 12:20:13','HIST',61),(502,'GIT101-HEAD.OFFICE','GIT101','HEAD.OFFICE',1.00,0.00,1,'STOCK.CHECK','','RAENELLE.SAMAROO-MAHARAJ','2012-08-08 09:43:18','RAENELLE.SAMAROO-MAHARAJ','2012-08-08 09:43:18','HIST',62),(502,'GIT101-HEAD.OFFICE','GIT101','HEAD.OFFICE',7.00,6.00,1,'STOCK.NEW.IN','','RAENELLE.SAMAROO-MAHARAJ','2012-08-09 09:34:52','RAENELLE.SAMAROO-MAHARAJ','2012-08-09 09:34:52','LIVE',63),(502,'GIT101-HEAD.OFFICE','GIT101','HEAD.OFFICE',6.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-08-09 09:37:00','SYSAUTH','2012-08-09 09:37:00','LIVE',64),(502,'GIT101-HEAD.OFFICE','GIT101','HEAD.OFFICE',5.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-08-09 12:13:41','SYSAUTH','2012-08-09 12:13:41','LIVE',65),(502,'GIT101-HEAD.OFFICE','GIT101','HEAD.OFFICE',4.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-08-10 17:16:51','SYSAUTH','2012-08-10 17:16:51','LIVE',66),(502,'GIT101-HEAD.OFFICE','GIT101','HEAD.OFFICE',3.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-08-10 17:17:48','SYSAUTH','2012-08-10 17:17:48','LIVE',67),(502,'GIT101-HEAD.OFFICE','GIT101','HEAD.OFFICE',2.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-08-14 15:58:40','SYSAUTH','2012-08-14 15:58:40','HIST',68),(502,'GIT101-HEAD.OFFICE','GIT101','HEAD.OFFICE',3.00,1.00,1,'STOCK.NEW.IN','','RAENELLE.SAMAROO-MAHARAJ','2012-08-16 14:31:22','RAENELLE.SAMAROO-MAHARAJ','2012-08-16 14:31:22','LIVE',69),(502,'GIT101-HEAD.OFFICE','GIT101','HEAD.OFFICE',2.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-08-17 14:27:05','SYSAUTH','2012-08-17 14:27:05','LIVE',70),(502,'GIT101-HEAD.OFFICE','GIT101','HEAD.OFFICE',1.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-08-22 10:34:55','SYSAUTH','2012-08-22 10:34:55','HIST',71),(502,'GIT101-HEAD.OFFICE','GIT101','HEAD.OFFICE',10.00,9.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-08-22 16:28:14','RAENELLE.SAMAROO-MAHARAJ','2012-08-22 16:28:14','HIST',72),(502,'GIT101-HEAD.OFFICE','GIT101','HEAD.OFFICE',11.00,1.00,1,'STOCK.NEW.IN','','RAENELLE.SAMAROO-MAHARAJ','2012-08-22 16:28:43','RAENELLE.SAMAROO-MAHARAJ','2012-08-22 16:28:43','LIVE',73),(502,'GIT101-HEAD.OFFICE','GIT101','HEAD.OFFICE',10.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-08-23 14:40:04','SYSAUTH','2012-08-23 14:40:04','LIVE',74),(502,'GIT101-HEAD.OFFICE','GIT101','HEAD.OFFICE',9.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-09-03 10:55:09','SYSAUTH','2012-09-03 10:55:09','LIVE',75),(502,'GIT101-HEAD.OFFICE','GIT101','HEAD.OFFICE',8.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-09-07 11:49:19','SYSAUTH','2012-09-07 11:49:19','LIVE',76),(502,'GIT101-HEAD.OFFICE','GIT101','HEAD.OFFICE',7.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-09-08 13:07:57','SYSAUTH','2012-09-08 13:07:57','LIVE',77),(502,'GIT101-HEAD.OFFICE','GIT101','HEAD.OFFICE',6.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-09-10 10:04:31','SYSAUTH','2012-09-10 10:04:31','LIVE',78),(502,'GIT101-HEAD.OFFICE','GIT101','HEAD.OFFICE',5.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-09-10 13:34:15','SYSAUTH','2012-09-10 13:34:15','LIVE',79),(502,'GIT101-HEAD.OFFICE','GIT101','HEAD.OFFICE',4.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-09-15 09:10:14','SYSAUTH','2012-09-15 09:10:14','LIVE',80),(502,'GIT101-HEAD.OFFICE','GIT101','HEAD.OFFICE',3.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-09-17 10:02:45','SYSAUTH','2012-09-17 10:02:45','LIVE',81),(502,'GIT101-HEAD.OFFICE','GIT101','HEAD.OFFICE',2.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-09-17 12:57:59','SYSAUTH','2012-09-17 12:57:59','LIVE',82),(502,'GIT101-HEAD.OFFICE','GIT101','HEAD.OFFICE',1.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-09-17 13:52:01','SYSAUTH','2012-09-17 13:52:01','LIVE',83),(502,'GIT101-HEAD.OFFICE','GIT101','HEAD.OFFICE',0.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-09-18 15:53:37','SYSAUTH','2012-09-18 15:53:37','HIST',84),(502,'GIT101-HEAD.OFFICE','GIT101','HEAD.OFFICE',5.00,5.00,1,'STOCK.NEW.IN','','RAENELLE.SAMAROO-MAHARAJ','2012-09-19 10:27:00','RAENELLE.SAMAROO-MAHARAJ','2012-09-19 10:27:00','LIVE',85),(502,'GIT101-HEAD.OFFICE','GIT101','HEAD.OFFICE',4.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-09-21 09:27:13','SYSAUTH','2012-09-21 09:27:13','LIVE',86),(502,'GIT101-HEAD.OFFICE','GIT101','HEAD.OFFICE',3.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-09-25 10:45:27','SYSAUTH','2012-09-25 10:45:27','LIVE',87),(502,'GIT101-HEAD.OFFICE','GIT101','HEAD.OFFICE',2.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-09-25 11:08:27','SYSAUTH','2012-09-25 11:08:27','LIVE',88),(502,'GIT101-HEAD.OFFICE','GIT101','HEAD.OFFICE',1.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-10-02 10:51:50','SYSAUTH','2012-10-02 10:51:50','LIVE',89),(502,'GIT101-HEAD.OFFICE','GIT101','HEAD.OFFICE',0.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-10-03 16:50:08','SYSAUTH','2012-10-03 16:50:08','HIST',90),(502,'GIT101-HEAD.OFFICE','GIT101','HEAD.OFFICE',2.00,2.00,1,'STOCK.NEW.IN','','RAENELLE.SAMAROO-MAHARAJ','2012-10-04 13:37:56','RAENELLE.SAMAROO-MAHARAJ','2012-10-04 13:37:56','LIVE',91),(502,'GIT101-HEAD.OFFICE','GIT101','HEAD.OFFICE',1.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-10-04 16:27:30','SYSAUTH','2012-10-04 16:27:30','HIST',92),(502,'GIT101-HEAD.OFFICE','GIT101','HEAD.OFFICE',2.00,0.00,1,'STOCK.CHECK','','RAENELLE.SAMAROO-MAHARAJ','2012-10-04 17:18:44','RAENELLE.SAMAROO-MAHARAJ','2012-10-04 17:18:44','HIST',93),(502,'GIT101-HEAD.OFFICE','GIT101','HEAD.OFFICE',7.00,5.00,1,'STOCK.NEW.IN','','RAENELLE.SAMAROO-MAHARAJ','2012-10-06 11:41:14','RAENELLE.SAMAROO-MAHARAJ','2012-10-06 11:41:14','LIVE',94),(502,'GIT101-HEAD.OFFICE','GIT101','HEAD.OFFICE',6.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-10-08 15:00:47','SYSAUTH','2012-10-08 15:00:47','LIVE',95),(502,'GIT101-HEAD.OFFICE','GIT101','HEAD.OFFICE',5.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-10-08 15:00:47','SYSAUTH','2012-10-08 15:00:47','LIVE',96),(502,'GIT101-HEAD.OFFICE','GIT101','HEAD.OFFICE',4.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-10-10 09:07:30','SYSAUTH','2012-10-10 09:07:30','LIVE',97),(502,'GIT101-HEAD.OFFICE','GIT101','HEAD.OFFICE',3.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-10-10 10:30:59','SYSAUTH','2012-10-10 10:30:59','LIVE',98),(502,'GIT101-HEAD.OFFICE','GIT101','HEAD.OFFICE',2.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-10-12 13:29:46','SYSAUTH','2012-10-12 13:29:46','LIVE',99),(502,'GIT101-HEAD.OFFICE','GIT101','HEAD.OFFICE',1.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-10-13 08:59:20','SYSAUTH','2012-10-13 08:59:20','LIVE',100),(502,'GIT101-HEAD.OFFICE','GIT101','HEAD.OFFICE',0.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-10-13 09:48:58','SYSAUTH','2012-10-13 09:48:58','HIST',101),(502,'GIT101-HEAD.OFFICE','GIT101','HEAD.OFFICE',1.00,0.00,1,'STOCK.CHECK','','RAENELLE.SAMAROO-MAHARAJ','2012-10-16 15:38:55','RAENELLE.SAMAROO-MAHARAJ','2012-10-16 15:38:55','LIVE',102),(502,'GIT101-HEAD.OFFICE','GIT101','HEAD.OFFICE',0.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-10-17 11:04:31','SYSAUTH','2012-10-17 11:04:31','HIST',103),(502,'GIT101-HEAD.OFFICE','GIT101','HEAD.OFFICE',5.00,5.00,1,'STOCK.NEW.IN','','RAENELLE.SAMAROO-MAHARAJ','2012-10-17 16:22:08','RAENELLE.SAMAROO-MAHARAJ','2012-10-17 16:22:08','LIVE',104),(502,'GIT101-HEAD.OFFICE','GIT101','HEAD.OFFICE',4.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-10-18 09:37:37','SYSAUTH','2012-10-18 09:37:37','LIVE',105),(502,'GIT101-HEAD.OFFICE','GIT101','HEAD.OFFICE',3.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-10-18 12:42:53','SYSAUTH','2012-10-18 12:42:53','LIVE',106),(502,'GIT101-HEAD.OFFICE','GIT101','HEAD.OFFICE',2.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-10-19 09:08:36','SYSAUTH','2012-10-19 09:08:36','LIVE',107),(502,'GIT101-HEAD.OFFICE','GIT101','HEAD.OFFICE',1.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-10-22 15:01:18','SYSAUTH','2012-10-22 15:01:18','HIST',108),(502,'GIT101-HEAD.OFFICE','GIT101','HEAD.OFFICE',3.00,2.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-10-23 16:57:46','RAENELLE.SAMAROO-MAHARAJ','2012-10-23 16:57:46','LIVE',109),(502,'GIT101-HEAD.OFFICE','GIT101','HEAD.OFFICE',2.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-10-24 09:32:10','SYSAUTH','2012-10-24 09:32:10','HIST',110),(502,'GIT101-HEAD.OFFICE','GIT101','HEAD.OFFICE',7.00,5.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-10-30 09:20:47','RAENELLE.SAMAROO-MAHARAJ','2012-10-30 09:20:47','HIST',111),(502,'GIT101-HEAD.OFFICE','GIT101','HEAD.OFFICE',8.00,0.00,1,'STOCK.CHECK','','RAENELLE.SAMAROO-MAHARAJ','2012-11-05 12:10:34','RAENELLE.SAMAROO-MAHARAJ','2012-11-05 12:10:35','LIVE',112),(502,'GIT101-HEAD.OFFICE','GIT101','HEAD.OFFICE',7.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-11-07 13:58:30','SYSAUTH','2012-11-07 13:58:30','LIVE',113),(502,'GIT101-HEAD.OFFICE','GIT101','HEAD.OFFICE',6.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-11-09 10:49:20','SYSAUTH','2012-11-09 10:49:20','LIVE',114),(502,'GIT101-HEAD.OFFICE','GIT101','HEAD.OFFICE',5.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-11-09 15:29:18','SYSAUTH','2012-11-09 15:29:18','LIVE',115),(502,'GIT101-HEAD.OFFICE','GIT101','HEAD.OFFICE',4.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-11-12 14:23:29','SYSAUTH','2012-11-12 14:23:29','LIVE',116),(502,'GIT101-HEAD.OFFICE','GIT101','HEAD.OFFICE',3.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-11-17 09:20:40','SYSAUTH','2012-11-17 09:20:40','LIVE',117),(502,'GIT101-HEAD.OFFICE','GIT101','HEAD.OFFICE',2.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-11-20 09:43:32','SYSAUTH','2012-11-20 09:43:32','HIST',118),(502,'GIT101-HEAD.OFFICE','GIT101','HEAD.OFFICE',1.00,-1.00,1,'SENT.TO.REPAIR','','RAENELLE.SAMAROO-MAHARAJ','2012-11-20 15:13:38','RAENELLE.SAMAROO-MAHARAJ','2012-11-20 15:13:38','LIVE',119),(502,'GIT101-HEAD.OFFICE','GIT101','HEAD.OFFICE',0.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-11-21 13:49:31','SYSAUTH','2012-11-21 13:49:31','HIST',120),(502,'GIT101-HEAD.OFFICE','GIT101','HEAD.OFFICE',2.00,2.00,1,'STOCK.NEW.IN','','RAENELLE.SAMAROO-MAHARAJ','2012-11-22 12:30:10','RAENELLE.SAMAROO-MAHARAJ','2012-11-22 12:30:10','LIVE',121),(502,'GIT101-HEAD.OFFICE','GIT101','HEAD.OFFICE',1.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-11-22 13:12:16','SYSAUTH','2012-11-22 13:12:16','LIVE',122),(502,'GIT101-HEAD.OFFICE','GIT101','HEAD.OFFICE',0.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-11-23 10:07:43','SYSAUTH','2012-11-23 10:07:43','HIST',123),(502,'GIT101-HEAD.OFFICE','GIT101','HEAD.OFFICE',2.00,0.00,1,'STOCK.CHECK','','RAENELLE.SAMAROO-MAHARAJ','2012-11-26 14:52:36','RAENELLE.SAMAROO-MAHARAJ','2012-11-26 14:52:36','HIST',124),(502,'GIT101-HEAD.OFFICE','GIT101','HEAD.OFFICE',4.00,0.00,1,'STOCK.CHECK','','RAENELLE.SAMAROO-MAHARAJ','2012-11-30 16:09:52','RAENELLE.SAMAROO-MAHARAJ','2012-11-30 16:09:52','LIVE',125),(502,'GIT101-HEAD.OFFICE','GIT101','HEAD.OFFICE',3.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-12-04 09:04:20','SYSAUTH','2012-12-04 09:04:20','LIVE',126),(502,'GIT101-HEAD.OFFICE','GIT101','HEAD.OFFICE',2.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-12-07 09:29:47','SYSAUTH','2012-12-07 09:29:47','LIVE',127),(502,'GIT101-HEAD.OFFICE','GIT101','HEAD.OFFICE',1.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-12-21 12:32:49','SYSAUTH','2012-12-21 12:32:49','LIVE',128),(502,'GIT101-HEAD.OFFICE','GIT101','HEAD.OFFICE',2.00,-1.00,1,'SALE','','ADMIN','2013-02-20 23:27:07','SYSAUTH','2013-02-20 23:27:07','LIVE',129),(502,'GIT101-HEAD.OFFICE','GIT101','HEAD.OFFICE',1.00,-2.00,1,'SALE','','ADMIN','2013-02-20 23:33:54','SYSAUTH','2013-02-20 23:33:54','LIVE',130),(502,'GIT101-HEAD.OFFICE','GIT101','HEAD.OFFICE',10.00,-1.00,1,'SALE','','ADMIN','2013-02-24 15:40:19','SYSAUTH','2013-02-24 15:40:19','LIVE',131),(502,'GIT101-HEAD.OFFICE','GIT101','HEAD.OFFICE',8.00,-2.00,1,'SALE','','ADMIN','2013-02-25 03:37:04','SYSAUTH','2013-02-25 03:37:04','LIVE',132),(502,'GIT101-HEAD.OFFICE','GIT101','HEAD.OFFICE',7.00,-1.00,1,'SALE','','ADMIN','2013-03-17 17:28:50','SYSAUTH','2013-03-17 17:28:50','LIVE',133),(502,'GIT101-HEAD.OFFICE','GIT101','HEAD.OFFICE',6.00,-1.00,1,'SALE','','ADMIN','2013-03-18 18:39:54','SYSAUTH','2013-03-18 18:39:54','HIST',134),(502,'GIT101-HEAD.OFFICE','GIT101','HEAD.OFFICE',7.00,1.00,1,'ORDER.CANCEL.RETURN','','ADMIN','2013-03-18 18:41:56','ADMIN','2013-03-18 18:41:56','LIVE',135),(502,'GIT101-HEAD.OFFICE','GIT101','HEAD.OFFICE',6.00,-1.00,1,'SALE','','ADMIN','2013-03-19 07:24:14','SYSAUTH','2013-03-19 07:24:14','LIVE',136),(503,'NRT500-HEAD.OFFICE','NRT500','HEAD.OFFICE',2.00,0.00,1,'STOCK.CHECK','','ADMIN','2012-05-12 13:10:36','ADMIN','2012-05-12 13:10:45','LIVE',1),(503,'NRT500-HEAD.OFFICE','NRT500','HEAD.OFFICE',1.00,0.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-05-15 10:55:46','SYSAUTH','2012-05-15 10:55:46','HIST',2),(503,'NRT500-HEAD.OFFICE','NRT500','HEAD.OFFICE',6.00,0.00,1,'STOCK.NEW.IN','','RAENELLE.SAMAROO-MAHARAJ','2012-05-19 12:35:18','RAENELLE.SAMAROO-MAHARAJ','2012-05-19 12:35:18','LIVE',3),(503,'NRT500-HEAD.OFFICE','NRT500','HEAD.OFFICE',0.00,-6.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-05-31 15:55:43','SYSAUTH','2012-05-31 15:55:43','HIST',4),(503,'NRT500-HEAD.OFFICE','NRT500','HEAD.OFFICE',4.00,4.00,1,'STOCK.NEW.IN','','RAENELLE.SAMAROO-MAHARAJ','2012-06-06 11:19:22','RAENELLE.SAMAROO-MAHARAJ','2012-06-06 11:19:22','HIST',5),(503,'NRT500-HEAD.OFFICE','NRT500','HEAD.OFFICE',11.00,7.00,1,'STOCK.NEW.IN','','RAENELLE.SAMAROO-MAHARAJ','2012-06-06 11:21:03','RAENELLE.SAMAROO-MAHARAJ','2012-06-06 11:21:03','HIST',6),(503,'NRT500-HEAD.OFFICE','NRT500','HEAD.OFFICE',11.00,0.00,1,'STOCK.TRANSFER.IN','','RAENELLE.SAMAROO-MAHARAJ','2012-06-06 11:21:30','RAENELLE.SAMAROO-MAHARAJ','2012-06-06 11:21:30','HIST',7),(503,'NRT500-HEAD.OFFICE','NRT500','HEAD.OFFICE',11.00,0.00,1,'STOCK.CHECK','','RAENELLE.SAMAROO-MAHARAJ','2012-06-11 13:57:53','RAENELLE.SAMAROO-MAHARAJ','2012-06-11 13:57:53','HIST',8),(503,'NRT500-HEAD.OFFICE','NRT500','HEAD.OFFICE',10.00,0.00,1,'STOCK.CHECK','','RAENELLE.SAMAROO-MAHARAJ','2012-06-15 09:44:49','RAENELLE.SAMAROO-MAHARAJ','2012-06-15 09:44:49','HIST',9),(503,'NRT500-HEAD.OFFICE','NRT500','HEAD.OFFICE',7.00,0.00,1,'STOCK.CHECK','','RAENELLE.SAMAROO-MAHARAJ','2012-06-15 09:49:55','RAENELLE.SAMAROO-MAHARAJ','2012-06-15 09:49:55','LIVE',10),(503,'NRT500-HEAD.OFFICE','NRT500','HEAD.OFFICE',6.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-06-20 10:00:45','SYSAUTH','2012-06-20 10:00:45','HIST',11),(503,'NRT500-HEAD.OFFICE','NRT500','HEAD.OFFICE',7.00,0.00,1,'STOCK.CHECK','','RAENELLE.SAMAROO-MAHARAJ','2012-06-21 16:43:46','RAENELLE.SAMAROO-MAHARAJ','2012-06-21 16:43:46','HIST',12),(503,'NRT500-HEAD.OFFICE','NRT500','HEAD.OFFICE',6.00,-1.00,1,'STOCK.TRANSFER.OUT','','RAENELLE.SAMAROO-MAHARAJ','2012-06-22 13:44:17','RAENELLE.SAMAROO-MAHARAJ','2012-06-22 13:44:17','HIST',13),(503,'NRT500-HEAD.OFFICE','NRT500','HEAD.OFFICE',4.00,0.00,1,'STOCK.CHECK','','RAENELLE.SAMAROO-MAHARAJ','2012-06-28 16:56:47','RAENELLE.SAMAROO-MAHARAJ','2012-06-28 16:56:48','HIST',14),(503,'NRT500-HEAD.OFFICE','NRT500','HEAD.OFFICE',0.00,0.00,1,'STOCK.CHECK','','RAENELLE.SAMAROO-MAHARAJ','2012-07-06 10:57:50','RAENELLE.SAMAROO-MAHARAJ','2012-07-06 10:57:50','HIST',15),(503,'NRT500-HEAD.OFFICE','NRT500','HEAD.OFFICE',9.00,0.00,1,'STOCK.CHECK','','RAENELLE.SAMAROO-MAHARAJ','2012-07-12 16:29:17','RAENELLE.SAMAROO-MAHARAJ','2012-07-12 16:29:17','LIVE',16),(503,'NRT500-HEAD.OFFICE','NRT500','HEAD.OFFICE',6.00,-3.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-07-13 12:05:08','SYSAUTH','2012-07-13 12:05:08','HIST',17),(503,'NRT500-HEAD.OFFICE','NRT500','HEAD.OFFICE',4.00,-2.00,1,'CUSTOMER.REPLACEMENT','','RAENELLE.SAMAROO-MAHARAJ','2012-07-14 11:57:11','RAENELLE.SAMAROO-MAHARAJ','2012-07-14 11:57:11','HIST',18),(503,'NRT500-HEAD.OFFICE','NRT500','HEAD.OFFICE',5.00,1.00,1,'STOCK.TRANSFER.IN','','RAENELLE.SAMAROO-MAHARAJ','2012-07-14 12:09:10','RAENELLE.SAMAROO-MAHARAJ','2012-07-14 12:09:10','LIVE',19),(503,'NRT500-HEAD.OFFICE','NRT500','HEAD.OFFICE',4.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-07-14 12:21:00','SYSAUTH','2012-07-14 12:21:00','HIST',20),(503,'NRT500-HEAD.OFFICE','NRT500','HEAD.OFFICE',2.00,-2.00,1,'STOCK.TRANSFER.OUT','','RAENELLE.SAMAROO-MAHARAJ','2012-07-16 10:09:57','RAENELLE.SAMAROO-MAHARAJ','2012-07-16 10:09:57','HIST',21),(503,'NRT500-HEAD.OFFICE','NRT500','HEAD.OFFICE',0.00,-2.00,1,'STOCK.TRANSFER.OUT','','RAENELLE.SAMAROO-MAHARAJ','2012-07-17 16:41:05','RAENELLE.SAMAROO-MAHARAJ','2012-07-17 16:41:05','HIST',22),(503,'NRT500-HEAD.OFFICE','NRT500','HEAD.OFFICE',10.00,10.00,1,'STOCK.TRANSFER.OUT','','RAENELLE.SAMAROO-MAHARAJ','2012-07-17 16:41:46','RAENELLE.SAMAROO-MAHARAJ','2012-07-17 16:41:46','HIST',23),(503,'NRT500-HEAD.OFFICE','NRT500','HEAD.OFFICE',10.00,0.00,1,'STOCK.NEW.IN','','RAENELLE.SAMAROO-MAHARAJ','2012-07-17 16:41:55','RAENELLE.SAMAROO-MAHARAJ','2012-07-17 16:41:55','HIST',24),(503,'NRT500-HEAD.OFFICE','NRT500','HEAD.OFFICE',9.00,-1.00,1,'STOCK.TRANSFER.OUT','','RAENELLE.SAMAROO-MAHARAJ','2012-07-18 11:29:22','RAENELLE.SAMAROO-MAHARAJ','2012-07-18 11:29:22','LIVE',25),(503,'NRT500-HEAD.OFFICE','NRT500','HEAD.OFFICE',8.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-07-23 15:22:10','SYSAUTH','2012-07-23 15:22:10','HIST',26),(503,'NRT500-HEAD.OFFICE','NRT500','HEAD.OFFICE',6.00,-2.00,1,'STOCK.TRANSFER.OUT','','RAENELLE.SAMAROO-MAHARAJ','2012-08-08 09:43:58','RAENELLE.SAMAROO-MAHARAJ','2012-08-08 09:43:58','HIST',27),(503,'NRT500-HEAD.OFFICE','NRT500','HEAD.OFFICE',16.00,10.00,1,'STOCK.NEW.IN','','RAENELLE.SAMAROO-MAHARAJ','2012-08-08 09:44:28','RAENELLE.SAMAROO-MAHARAJ','2012-08-08 09:44:28','LIVE',28),(503,'NRT500-HEAD.OFFICE','NRT500','HEAD.OFFICE',15.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-08-17 16:26:20','SYSAUTH','2012-08-17 16:26:20','LIVE',29),(503,'NRT500-HEAD.OFFICE','NRT500','HEAD.OFFICE',13.00,-2.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-09-05 12:53:38','SYSAUTH','2012-09-05 12:53:38','LIVE',30),(503,'NRT500-HEAD.OFFICE','NRT500','HEAD.OFFICE',12.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-09-07 16:21:05','SYSAUTH','2012-09-07 16:21:05','HIST',31),(503,'NRT500-HEAD.OFFICE','NRT500','HEAD.OFFICE',17.00,5.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-09-15 13:15:28','RAENELLE.SAMAROO-MAHARAJ','2012-09-15 13:15:28','HIST',32),(503,'NRT500-HEAD.OFFICE','NRT500','HEAD.OFFICE',22.00,5.00,1,'STOCK.NEW.IN','','RAENELLE.SAMAROO-MAHARAJ','2012-09-19 10:27:18','RAENELLE.SAMAROO-MAHARAJ','2012-09-19 10:27:18','LIVE',33),(503,'NRT500-HEAD.OFFICE','NRT500','HEAD.OFFICE',21.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-09-25 16:14:16','SYSAUTH','2012-09-25 16:14:16','HIST',34),(503,'NRT500-HEAD.OFFICE','NRT500','HEAD.OFFICE',3.00,0.00,1,'STOCK.CHECK','','RAENELLE.SAMAROO-MAHARAJ','2012-10-04 13:38:25','RAENELLE.SAMAROO-MAHARAJ','2012-10-04 13:38:25','HIST',35),(503,'NRT500-HEAD.OFFICE','NRT500','HEAD.OFFICE',0.00,0.00,1,'STOCK.CHECK','','RAENELLE.SAMAROO-MAHARAJ','2012-10-04 16:46:57','RAENELLE.SAMAROO-MAHARAJ','2012-10-04 16:46:57','HIST',36),(503,'NRT500-HEAD.OFFICE','NRT500','HEAD.OFFICE',5.00,5.00,1,'STOCK.NEW.IN','','RAENELLE.SAMAROO-MAHARAJ','2012-10-06 11:41:37','RAENELLE.SAMAROO-MAHARAJ','2012-10-06 11:41:37','HIST',37),(503,'NRT500-HEAD.OFFICE','NRT500','HEAD.OFFICE',10.00,5.00,1,'STOCK.NEW.IN','','RAENELLE.SAMAROO-MAHARAJ','2012-10-08 10:03:19','RAENELLE.SAMAROO-MAHARAJ','2012-10-08 10:03:19','HIST',38),(503,'NRT500-HEAD.OFFICE','NRT500','HEAD.OFFICE',0.00,-10.00,1,'STOCK.TRANSFER.OUT','','RAENELLE.SAMAROO-MAHARAJ','2012-10-12 11:36:30','RAENELLE.SAMAROO-MAHARAJ','2012-10-12 11:36:30','HIST',39),(503,'NRT500-HEAD.OFFICE','NRT500','HEAD.OFFICE',5.00,5.00,1,'STOCK.TRANSFER.OUT','','RAENELLE.SAMAROO-MAHARAJ','2012-10-30 09:21:57','RAENELLE.SAMAROO-MAHARAJ','2012-10-30 09:21:57','HIST',40),(503,'NRT500-HEAD.OFFICE','NRT500','HEAD.OFFICE',5.00,0.00,1,'STOCK.NEW.IN','','RAENELLE.SAMAROO-MAHARAJ','2012-10-30 09:22:08','RAENELLE.SAMAROO-MAHARAJ','2012-10-30 09:22:08','HIST',41),(503,'NRT500-HEAD.OFFICE','NRT500','HEAD.OFFICE',9.00,0.00,1,'STOCK.CHECK','','RAENELLE.SAMAROO-MAHARAJ','2012-11-05 12:10:52','RAENELLE.SAMAROO-MAHARAJ','2012-11-05 12:10:52','LIVE',42),(503,'NRT500-HEAD.OFFICE','NRT500','HEAD.OFFICE',7.00,-2.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-11-06 13:48:11','SYSAUTH','2012-11-06 13:48:11','LIVE',43),(503,'NRT500-HEAD.OFFICE','NRT500','HEAD.OFFICE',1.00,-6.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-11-06 16:35:25','SYSAUTH','2012-11-06 16:35:25','HIST',44),(503,'NRT500-HEAD.OFFICE','NRT500','HEAD.OFFICE',6.00,0.00,1,'STOCK.CHECK','','RAENELLE.SAMAROO-MAHARAJ','2012-11-06 16:56:37','RAENELLE.SAMAROO-MAHARAJ','2012-11-06 16:56:37','LIVE',45),(503,'NRT500-HEAD.OFFICE','NRT500','HEAD.OFFICE',5.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-11-12 15:09:58','SYSAUTH','2012-11-12 15:09:58','HIST',46),(503,'NRT500-HEAD.OFFICE','NRT500','HEAD.OFFICE',9.00,4.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-11-20 15:14:03','RAENELLE.SAMAROO-MAHARAJ','2012-11-20 15:14:03','LIVE',47),(503,'NRT500-HEAD.OFFICE','NRT500','HEAD.OFFICE',8.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-11-24 10:23:50','SYSAUTH','2012-11-24 10:23:50','LIVE',48),(503,'NRT500-HEAD.OFFICE','NRT500','HEAD.OFFICE',2.00,-6.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-11-28 13:45:30','SYSAUTH','2012-11-28 13:45:30','LIVE',49),(503,'NRT500-HEAD.OFFICE','NRT500','HEAD.OFFICE',0.00,-2.00,1,'SALE','','AMANDA.OUDAI','2012-11-29 14:57:14','SYSAUTH','2012-11-29 14:57:14','HIST',50),(503,'NRT500-HEAD.OFFICE','NRT500','HEAD.OFFICE',4.00,0.00,1,'STOCK.CHECK','','RAENELLE.SAMAROO-MAHARAJ','2012-11-30 16:10:23','RAENELLE.SAMAROO-MAHARAJ','2012-11-30 16:10:23','HIST',51),(503,'NRT500-HEAD.OFFICE','NRT500','HEAD.OFFICE',3.00,0.00,1,'STOCK.CHECK','','RAENELLE.SAMAROO-MAHARAJ','2012-11-30 16:10:46','RAENELLE.SAMAROO-MAHARAJ','2012-11-30 16:10:46','LIVE',52),(503,'NRT500-HEAD.OFFICE','NRT500','HEAD.OFFICE',1.00,-2.00,1,'SALE','','AMANDA.OUDAI','2012-12-03 11:14:31','SYSAUTH','2012-12-03 11:14:31','HIST',53),(503,'NRT500-HEAD.OFFICE','NRT500','HEAD.OFFICE',16.00,15.00,1,'STOCK.NEW.IN','','RAENELLE.SAMAROO-MAHARAJ','2012-12-04 15:33:35','RAENELLE.SAMAROO-MAHARAJ','2012-12-04 15:33:35','LIVE',54),(503,'NRT500-HEAD.OFFICE','NRT500','HEAD.OFFICE',15.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-12-06 17:59:36','SYSAUTH','2012-12-06 17:59:36','LIVE',55),(503,'NRT500-HEAD.OFFICE','NRT500','HEAD.OFFICE',14.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-12-06 17:59:36','SYSAUTH','2012-12-06 17:59:36','LIVE',56),(503,'NRT500-HEAD.OFFICE','NRT500','HEAD.OFFICE',13.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-12-06 17:59:36','SYSAUTH','2012-12-06 17:59:36','LIVE',57),(503,'NRT500-HEAD.OFFICE','NRT500','HEAD.OFFICE',12.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-12-06 17:59:36','SYSAUTH','2012-12-06 17:59:36','LIVE',58),(503,'NRT500-HEAD.OFFICE','NRT500','HEAD.OFFICE',11.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-12-06 17:59:36','SYSAUTH','2012-12-06 17:59:36','LIVE',59),(503,'NRT500-HEAD.OFFICE','NRT500','HEAD.OFFICE',10.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-12-06 17:59:36','SYSAUTH','2012-12-06 17:59:36','LIVE',60),(503,'NRT500-HEAD.OFFICE','NRT500','HEAD.OFFICE',9.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-12-06 17:59:36','SYSAUTH','2012-12-06 17:59:36','LIVE',61),(503,'NRT500-HEAD.OFFICE','NRT500','HEAD.OFFICE',8.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-12-06 17:59:36','SYSAUTH','2012-12-06 17:59:36','LIVE',62),(503,'NRT500-HEAD.OFFICE','NRT500','HEAD.OFFICE',7.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-12-06 17:59:36','SYSAUTH','2012-12-06 17:59:36','LIVE',63),(503,'NRT500-HEAD.OFFICE','NRT500','HEAD.OFFICE',6.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-12-06 17:59:36','SYSAUTH','2012-12-06 17:59:36','LIVE',64),(503,'NRT500-HEAD.OFFICE','NRT500','HEAD.OFFICE',5.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-12-06 17:59:36','SYSAUTH','2012-12-06 17:59:36','LIVE',65),(503,'NRT500-HEAD.OFFICE','NRT500','HEAD.OFFICE',4.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-12-06 17:59:36','SYSAUTH','2012-12-06 17:59:36','LIVE',66),(503,'NRT500-HEAD.OFFICE','NRT500','HEAD.OFFICE',3.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-12-06 17:59:36','SYSAUTH','2012-12-06 17:59:36','LIVE',67),(503,'NRT500-HEAD.OFFICE','NRT500','HEAD.OFFICE',2.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-12-06 17:59:36','SYSAUTH','2012-12-06 17:59:36','LIVE',68),(503,'NRT500-HEAD.OFFICE','NRT500','HEAD.OFFICE',1.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-12-06 17:59:37','SYSAUTH','2012-12-06 17:59:37','LIVE',69),(503,'NRT500-HEAD.OFFICE','NRT500','HEAD.OFFICE',0.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-12-06 17:59:37','SYSAUTH','2012-12-06 17:59:37','HIST',70),(503,'NRT500-HEAD.OFFICE','NRT500','HEAD.OFFICE',11.00,0.00,1,'STOCK.CHECK','','RAENELLE.SAMAROO-MAHARAJ','2012-12-07 16:41:32','RAENELLE.SAMAROO-MAHARAJ','2012-12-07 16:41:33','LIVE',71),(503,'NRT500-HEAD.OFFICE','NRT500','HEAD.OFFICE',10.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-12-11 12:17:50','SYSAUTH','2012-12-11 12:17:50','HIST',72),(503,'NRT500-HEAD.OFFICE','NRT500','HEAD.OFFICE',17.00,0.00,1,'STOCK.CHECK','','ADMIN','2012-12-18 15:55:58','ADMIN','2012-12-18 15:55:58','LIVE',73),(503,'NRT500-HEAD.OFFICE','NRT500','HEAD.OFFICE',16.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-12-19 14:16:19','SYSAUTH','2012-12-19 14:16:19','LIVE',74),(503,'NRT500-HEAD.OFFICE','NRT500','HEAD.OFFICE',1.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-12-20 12:23:54','SYSAUTH','2012-12-20 12:23:54','LIVE',75),(503,'NRT500-HEAD.OFFICE','NRT500','HEAD.OFFICE',20.00,-1.00,1,'SALE','','ADMIN','2013-02-24 15:40:19','SYSAUTH','2013-02-24 15:40:19','LIVE',76),(503,'NRT500-HEAD.OFFICE','NRT500','HEAD.OFFICE',17.00,-3.00,1,'SALE','','ADMIN','2013-02-25 03:37:04','SYSAUTH','2013-02-25 03:37:04','LIVE',77),(503,'NRT500-HEAD.OFFICE','NRT500','HEAD.OFFICE',12.00,-5.00,1,'LOAN','','ADMIN','2013-02-25 13:15:17','SYSAUTH','2013-02-25 13:15:17','LIVE',78),(503,'NRT500-HEAD.OFFICE','NRT500','HEAD.OFFICE',7.00,-5.00,1,'SALE','','ADMIN','2013-02-25 13:20:40','SYSAUTH','2013-02-25 13:20:40','LIVE',79),(503,'NRT500-HEAD.OFFICE','NRT500','HEAD.OFFICE',6.00,-1.00,1,'SALE','','ADMIN','2013-03-17 17:25:28','SYSAUTH','2013-03-17 17:25:28','LIVE',80),(504,'BT10-HEAD.OFFICE','BT10','HEAD.OFFICE',0.00,0.00,1,'STOCK.CHECK','','ADMIN','2012-05-12 13:14:41','ADMIN','2012-05-12 13:14:50','HIST',2),(504,'BT10-HEAD.OFFICE','BT10','HEAD.OFFICE',4.00,0.00,1,'STOCK.CHECK','','RAENELLE.SAMAROO-MAHARAJ','2012-05-21 16:23:23','RAENELLE.SAMAROO-MAHARAJ','2012-05-21 16:23:23','LIVE',3),(504,'BT10-HEAD.OFFICE','BT10','HEAD.OFFICE',3.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-09-14 15:51:28','SYSAUTH','2012-09-14 15:51:28','LIVE',4),(504,'BT10-HEAD.OFFICE','BT10','HEAD.OFFICE',2.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-09-20 14:01:16','SYSAUTH','2012-09-20 14:01:16','HIST',5),(504,'BT10-HEAD.OFFICE','BT10','HEAD.OFFICE',1.00,0.00,1,'STOCK.CHECK','','RAENELLE.SAMAROO-MAHARAJ','2012-10-04 13:38:47','RAENELLE.SAMAROO-MAHARAJ','2012-10-04 13:38:47','LIVE',6),(504,'BT10-HEAD.OFFICE','BT10','HEAD.OFFICE',0.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-12-01 12:48:53','SYSAUTH','2012-12-01 12:48:53','HIST',7),(505,'SIM.BMO.PRE50-HEAD.OFFICE','SIM.BMO.PRE50','HEAD.OFFICE',0.00,0.00,1,'STOCK.CHECK','','ADMIN','2012-05-12 13:19:03','ADMIN','2012-05-12 13:19:03','HIST',1),(505,'SIM.BMO.PRE50-HEAD.OFFICE','SIM.BMO.PRE50','HEAD.OFFICE',40.00,0.00,1,'STOCK.CHECK','','RAENELLE.SAMAROO-MAHARAJ','2012-05-15 10:58:21','RAENELLE.SAMAROO-MAHARAJ','2012-05-15 10:58:21','LIVE',2),(505,'SIM.BMO.PRE50-HEAD.OFFICE','SIM.BMO.PRE50','HEAD.OFFICE',39.00,0.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-05-15 10:58:54','SYSAUTH','2012-05-15 10:58:54','LIVE',3),(505,'SIM.BMO.PRE50-HEAD.OFFICE','SIM.BMO.PRE50','HEAD.OFFICE',38.00,0.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-05-16 10:02:12','SYSAUTH','2012-05-16 10:02:12','LIVE',4),(505,'SIM.BMO.PRE50-HEAD.OFFICE','SIM.BMO.PRE50','HEAD.OFFICE',35.00,0.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-05-17 13:27:03','SYSAUTH','2012-05-17 13:27:03','LIVE',5),(505,'SIM.BMO.PRE50-HEAD.OFFICE','SIM.BMO.PRE50','HEAD.OFFICE',34.00,0.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-05-19 12:38:22','SYSAUTH','2012-05-19 12:38:22','LIVE',6),(505,'SIM.BMO.PRE50-HEAD.OFFICE','SIM.BMO.PRE50','HEAD.OFFICE',33.00,0.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-05-19 12:39:39','SYSAUTH','2012-05-19 12:39:39','LIVE',7),(505,'SIM.BMO.PRE50-HEAD.OFFICE','SIM.BMO.PRE50','HEAD.OFFICE',32.00,0.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-05-19 12:40:20','SYSAUTH','2012-05-19 12:40:20','LIVE',8),(505,'SIM.BMO.PRE50-HEAD.OFFICE','SIM.BMO.PRE50','HEAD.OFFICE',31.00,0.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-05-19 12:41:24','SYSAUTH','2012-05-19 12:41:24','LIVE',9),(505,'SIM.BMO.PRE50-HEAD.OFFICE','SIM.BMO.PRE50','HEAD.OFFICE',30.00,0.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-05-19 12:46:06','SYSAUTH','2012-05-19 12:46:06','LIVE',10),(505,'SIM.BMO.PRE50-HEAD.OFFICE','SIM.BMO.PRE50','HEAD.OFFICE',29.00,0.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-05-19 12:46:50','SYSAUTH','2012-05-19 12:46:50','LIVE',11),(505,'SIM.BMO.PRE50-HEAD.OFFICE','SIM.BMO.PRE50','HEAD.OFFICE',28.00,0.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-05-21 15:21:26','SYSAUTH','2012-05-21 15:21:26','LIVE',12),(505,'SIM.BMO.PRE50-HEAD.OFFICE','SIM.BMO.PRE50','HEAD.OFFICE',27.00,0.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-05-21 15:22:34','SYSAUTH','2012-05-21 15:22:34','LIVE',13),(505,'SIM.BMO.PRE50-HEAD.OFFICE','SIM.BMO.PRE50','HEAD.OFFICE',26.00,0.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-05-21 15:23:19','SYSAUTH','2012-05-21 15:23:19','LIVE',14),(505,'SIM.BMO.PRE50-HEAD.OFFICE','SIM.BMO.PRE50','HEAD.OFFICE',25.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-05-28 09:30:57','SYSAUTH','2012-05-28 09:30:57','LIVE',15),(505,'SIM.BMO.PRE50-HEAD.OFFICE','SIM.BMO.PRE50','HEAD.OFFICE',24.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-05-28 09:59:47','SYSAUTH','2012-05-28 09:59:47','LIVE',16),(505,'SIM.BMO.PRE50-HEAD.OFFICE','SIM.BMO.PRE50','HEAD.OFFICE',23.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-05-29 11:01:17','SYSAUTH','2012-05-29 11:01:17','LIVE',17),(505,'SIM.BMO.PRE50-HEAD.OFFICE','SIM.BMO.PRE50','HEAD.OFFICE',22.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-05-29 11:51:25','SYSAUTH','2012-05-29 11:51:25','LIVE',18),(505,'SIM.BMO.PRE50-HEAD.OFFICE','SIM.BMO.PRE50','HEAD.OFFICE',21.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-05-31 11:34:22','SYSAUTH','2012-05-31 11:34:22','LIVE',19),(505,'SIM.BMO.PRE50-HEAD.OFFICE','SIM.BMO.PRE50','HEAD.OFFICE',13.00,-8.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-05-31 15:55:43','SYSAUTH','2012-05-31 15:55:43','LIVE',20),(505,'SIM.BMO.PRE50-HEAD.OFFICE','SIM.BMO.PRE50','HEAD.OFFICE',12.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-06-01 09:22:27','SYSAUTH','2012-06-01 09:22:27','LIVE',21),(505,'SIM.BMO.PRE50-HEAD.OFFICE','SIM.BMO.PRE50','HEAD.OFFICE',11.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-06-01 09:27:13','SYSAUTH','2012-06-01 09:27:13','LIVE',22),(505,'SIM.BMO.PRE50-HEAD.OFFICE','SIM.BMO.PRE50','HEAD.OFFICE',10.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-06-02 09:54:14','SYSAUTH','2012-06-02 09:54:14','LIVE',23),(505,'SIM.BMO.PRE50-HEAD.OFFICE','SIM.BMO.PRE50','HEAD.OFFICE',9.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-06-02 11:19:04','SYSAUTH','2012-06-02 11:19:04','LIVE',24),(505,'SIM.BMO.PRE50-HEAD.OFFICE','SIM.BMO.PRE50','HEAD.OFFICE',8.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-06-04 11:57:40','SYSAUTH','2012-06-04 11:57:40','LIVE',25),(505,'SIM.BMO.PRE50-HEAD.OFFICE','SIM.BMO.PRE50','HEAD.OFFICE',7.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-06-04 12:24:04','SYSAUTH','2012-06-04 12:24:04','LIVE',26),(505,'SIM.BMO.PRE50-HEAD.OFFICE','SIM.BMO.PRE50','HEAD.OFFICE',6.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-06-04 13:50:41','SYSAUTH','2012-06-04 13:50:41','LIVE',27),(505,'SIM.BMO.PRE50-HEAD.OFFICE','SIM.BMO.PRE50','HEAD.OFFICE',5.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-06-05 10:37:49','SYSAUTH','2012-06-05 10:37:49','HIST',28),(505,'SIM.BMO.PRE50-HEAD.OFFICE','SIM.BMO.PRE50','HEAD.OFFICE',27.00,0.00,1,'STOCK.CHECK','','RAENELLE.SAMAROO-MAHARAJ','2012-06-06 11:24:10','RAENELLE.SAMAROO-MAHARAJ','2012-06-06 11:24:10','LIVE',29),(505,'SIM.BMO.PRE50-HEAD.OFFICE','SIM.BMO.PRE50','HEAD.OFFICE',26.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-06-06 15:42:40','SYSAUTH','2012-06-06 15:42:40','LIVE',30),(505,'SIM.BMO.PRE50-HEAD.OFFICE','SIM.BMO.PRE50','HEAD.OFFICE',25.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-06-08 09:00:41','SYSAUTH','2012-06-08 09:00:41','LIVE',31),(505,'SIM.BMO.PRE50-HEAD.OFFICE','SIM.BMO.PRE50','HEAD.OFFICE',24.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-06-09 08:54:30','SYSAUTH','2012-06-09 08:54:30','LIVE',32),(505,'SIM.BMO.PRE50-HEAD.OFFICE','SIM.BMO.PRE50','HEAD.OFFICE',23.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-06-11 13:52:28','SYSAUTH','2012-06-11 13:52:28','LIVE',33),(505,'SIM.BMO.PRE50-HEAD.OFFICE','SIM.BMO.PRE50','HEAD.OFFICE',22.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-06-12 12:35:56','SYSAUTH','2012-06-12 12:35:56','LIVE',34),(505,'SIM.BMO.PRE50-HEAD.OFFICE','SIM.BMO.PRE50','HEAD.OFFICE',21.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-06-12 12:36:28','SYSAUTH','2012-06-12 12:36:28','HIST',35),(505,'SIM.BMO.PRE50-HEAD.OFFICE','SIM.BMO.PRE50','HEAD.OFFICE',18.00,0.00,1,'STOCK.CHECK','','RAENELLE.SAMAROO-MAHARAJ','2012-06-15 09:44:29','RAENELLE.SAMAROO-MAHARAJ','2012-06-15 09:44:29','LIVE',36),(505,'SIM.BMO.PRE50-HEAD.OFFICE','SIM.BMO.PRE50','HEAD.OFFICE',17.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-06-20 09:09:35','SYSAUTH','2012-06-20 09:09:35','LIVE',37),(505,'SIM.BMO.PRE50-HEAD.OFFICE','SIM.BMO.PRE50','HEAD.OFFICE',16.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-06-20 10:00:45','SYSAUTH','2012-06-20 10:00:45','LIVE',38),(505,'SIM.BMO.PRE50-HEAD.OFFICE','SIM.BMO.PRE50','HEAD.OFFICE',15.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-06-20 12:04:00','SYSAUTH','2012-06-20 12:04:00','LIVE',39),(505,'SIM.BMO.PRE50-HEAD.OFFICE','SIM.BMO.PRE50','HEAD.OFFICE',14.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-06-20 13:22:52','SYSAUTH','2012-06-20 13:22:52','LIVE',40),(505,'SIM.BMO.PRE50-HEAD.OFFICE','SIM.BMO.PRE50','HEAD.OFFICE',13.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-06-20 15:54:01','SYSAUTH','2012-06-20 15:54:01','LIVE',41),(505,'SIM.BMO.PRE50-HEAD.OFFICE','SIM.BMO.PRE50','HEAD.OFFICE',12.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-06-21 10:16:32','SYSAUTH','2012-06-21 10:16:32','LIVE',42),(505,'SIM.BMO.PRE50-HEAD.OFFICE','SIM.BMO.PRE50','HEAD.OFFICE',11.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-06-21 10:18:13','SYSAUTH','2012-06-21 10:18:13','LIVE',43),(505,'SIM.BMO.PRE50-HEAD.OFFICE','SIM.BMO.PRE50','HEAD.OFFICE',10.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-06-21 12:50:32','SYSAUTH','2012-06-21 12:50:32','LIVE',44),(505,'SIM.BMO.PRE50-HEAD.OFFICE','SIM.BMO.PRE50','HEAD.OFFICE',9.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-06-22 10:10:45','SYSAUTH','2012-06-22 10:10:45','LIVE',45),(505,'SIM.BMO.PRE50-HEAD.OFFICE','SIM.BMO.PRE50','HEAD.OFFICE',8.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-06-22 12:12:41','SYSAUTH','2012-06-22 12:12:41','LIVE',46),(505,'SIM.BMO.PRE50-HEAD.OFFICE','SIM.BMO.PRE50','HEAD.OFFICE',7.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-06-22 13:12:42','SYSAUTH','2012-06-22 13:12:42','LIVE',47),(505,'SIM.BMO.PRE50-HEAD.OFFICE','SIM.BMO.PRE50','HEAD.OFFICE',6.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-06-22 13:40:12','SYSAUTH','2012-06-22 13:40:12','HIST',48),(505,'SIM.BMO.PRE50-HEAD.OFFICE','SIM.BMO.PRE50','HEAD.OFFICE',10.00,0.00,1,'STOCK.CHECK','','RAENELLE.SAMAROO-MAHARAJ','2012-06-22 15:32:19','RAENELLE.SAMAROO-MAHARAJ','2012-06-22 15:32:19','HIST',49),(505,'SIM.BMO.PRE50-HEAD.OFFICE','SIM.BMO.PRE50','HEAD.OFFICE',27.00,0.00,1,'STOCK.CHECK','','RAENELLE.SAMAROO-MAHARAJ','2012-06-26 08:59:10','RAENELLE.SAMAROO-MAHARAJ','2012-06-26 08:59:10','LIVE',50),(505,'SIM.BMO.PRE50-HEAD.OFFICE','SIM.BMO.PRE50','HEAD.OFFICE',26.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-06-26 09:20:23','SYSAUTH','2012-06-26 09:20:23','LIVE',51),(505,'SIM.BMO.PRE50-HEAD.OFFICE','SIM.BMO.PRE50','HEAD.OFFICE',25.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-06-26 10:29:31','SYSAUTH','2012-06-26 10:29:31','LIVE',52),(505,'SIM.BMO.PRE50-HEAD.OFFICE','SIM.BMO.PRE50','HEAD.OFFICE',24.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-06-26 12:27:04','SYSAUTH','2012-06-26 12:27:04','LIVE',53),(505,'SIM.BMO.PRE50-HEAD.OFFICE','SIM.BMO.PRE50','HEAD.OFFICE',23.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-06-26 13:53:14','SYSAUTH','2012-06-26 13:53:14','LIVE',54),(505,'SIM.BMO.PRE50-HEAD.OFFICE','SIM.BMO.PRE50','HEAD.OFFICE',22.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-06-26 14:20:00','SYSAUTH','2012-06-26 14:20:00','LIVE',55),(505,'SIM.BMO.PRE50-HEAD.OFFICE','SIM.BMO.PRE50','HEAD.OFFICE',21.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-06-27 15:19:43','SYSAUTH','2012-06-27 15:19:43','LIVE',56),(505,'SIM.BMO.PRE50-HEAD.OFFICE','SIM.BMO.PRE50','HEAD.OFFICE',20.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-06-27 16:44:39','SYSAUTH','2012-06-27 16:44:39','LIVE',57),(505,'SIM.BMO.PRE50-HEAD.OFFICE','SIM.BMO.PRE50','HEAD.OFFICE',19.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-06-28 09:54:07','SYSAUTH','2012-06-28 09:54:07','LIVE',58),(505,'SIM.BMO.PRE50-HEAD.OFFICE','SIM.BMO.PRE50','HEAD.OFFICE',18.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-06-28 14:49:46','SYSAUTH','2012-06-28 14:49:46','LIVE',59),(505,'SIM.BMO.PRE50-HEAD.OFFICE','SIM.BMO.PRE50','HEAD.OFFICE',17.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-06-28 15:55:48','SYSAUTH','2012-06-28 15:55:48','LIVE',60),(505,'SIM.BMO.PRE50-HEAD.OFFICE','SIM.BMO.PRE50','HEAD.OFFICE',16.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-06-29 11:09:08','SYSAUTH','2012-06-29 11:09:08','LIVE',61),(505,'SIM.BMO.PRE50-HEAD.OFFICE','SIM.BMO.PRE50','HEAD.OFFICE',15.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-06-29 11:12:40','SYSAUTH','2012-06-29 11:12:40','LIVE',62),(505,'SIM.BMO.PRE50-HEAD.OFFICE','SIM.BMO.PRE50','HEAD.OFFICE',14.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-06-29 14:00:12','SYSAUTH','2012-06-29 14:00:12','HIST',63),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',3.00,0.00,1,'STOCK.CHECK','','ADMIN','2012-05-12 13:22:10','ADMIN','2012-05-12 13:22:11','LIVE',1),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',2.00,0.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-05-14 10:13:15','SYSAUTH','2012-05-14 10:13:15','LIVE',2),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',1.00,0.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-05-14 11:25:43','SYSAUTH','2012-05-14 11:25:43','LIVE',3),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',0.00,0.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-05-14 13:46:21','SYSAUTH','2012-05-14 13:46:21','HIST',4),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',40.00,0.00,5,'STOCK.CHECK','','RAENELLE.SAMAROO-MAHARAJ','2012-05-14 15:48:45','RAENELLE.SAMAROO-MAHARAJ','2012-05-14 15:48:45','HIST',5),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',0.00,0.00,5,'STOCK.CHECK','','RAENELLE.SAMAROO-MAHARAJ','2012-05-15 10:57:41','RAENELLE.SAMAROO-MAHARAJ','2012-05-15 10:57:41','HIST',6),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',19.00,0.00,5,'STOCK.CHECK','','RAENELLE.SAMAROO-MAHARAJ','2012-07-02 16:45:16','RAENELLE.SAMAROO-MAHARAJ','2012-07-02 16:45:16','LIVE',7),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',18.00,-1.00,5,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-07-03 10:18:31','SYSAUTH','2012-07-03 10:18:31','LIVE',8),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',17.00,-1.00,5,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-07-03 13:54:11','SYSAUTH','2012-07-03 13:54:11','LIVE',9),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',16.00,-1.00,5,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-07-05 14:12:38','SYSAUTH','2012-07-05 14:12:38','LIVE',10),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',15.00,-1.00,5,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-07-06 09:48:12','SYSAUTH','2012-07-06 09:48:12','LIVE',11),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',14.00,-1.00,5,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-07-07 08:49:47','SYSAUTH','2012-07-07 08:49:47','LIVE',12),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',13.00,-1.00,5,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-07-10 10:52:10','SYSAUTH','2012-07-10 10:52:10','LIVE',13),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',12.00,-1.00,5,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-07-10 12:45:49','SYSAUTH','2012-07-10 12:45:49','LIVE',14),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',11.00,-1.00,5,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-07-12 12:15:31','SYSAUTH','2012-07-12 12:15:31','LIVE',15),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',10.00,-1.00,5,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-07-13 09:38:13','SYSAUTH','2012-07-13 09:38:13','LIVE',16),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',7.00,-3.00,5,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-07-13 12:05:08','SYSAUTH','2012-07-13 12:05:08','LIVE',17),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',6.00,-1.00,5,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-07-14 09:06:59','SYSAUTH','2012-07-14 09:06:59','LIVE',18),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',5.00,-1.00,5,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-07-14 10:18:04','SYSAUTH','2012-07-14 10:18:04','HIST',19),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',10.00,5.00,5,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-07-14 11:58:26','RAENELLE.SAMAROO-MAHARAJ','2012-07-14 11:58:26','LIVE',20),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',9.00,-1.00,5,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-07-16 11:46:13','SYSAUTH','2012-07-16 11:46:13','LIVE',21),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',8.00,-1.00,5,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-07-17 14:36:03','SYSAUTH','2012-07-17 14:36:03','LIVE',22),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',7.00,-1.00,5,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-07-17 14:53:13','SYSAUTH','2012-07-17 14:53:13','LIVE',23),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',6.00,-1.00,5,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-07-20 09:46:53','SYSAUTH','2012-07-20 09:46:53','LIVE',24),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',5.00,-1.00,5,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-07-20 09:57:42','SYSAUTH','2012-07-20 09:57:42','LIVE',25),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',4.00,-1.00,5,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-07-20 12:26:48','SYSAUTH','2012-07-20 12:26:48','LIVE',26),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',3.00,-1.00,5,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-07-20 13:13:16','SYSAUTH','2012-07-20 13:13:16','LIVE',27),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',2.00,-1.00,5,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-07-20 13:24:44','SYSAUTH','2012-07-20 13:24:44','LIVE',28),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',1.00,-1.00,5,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-07-21 09:04:37','SYSAUTH','2012-07-21 09:04:37','LIVE',29),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',0.00,-1.00,5,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-07-21 12:49:05','SYSAUTH','2012-07-21 12:49:05','HIST',30),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',32.00,32.00,5,'STOCK.NEW.IN','','RAENELLE.SAMAROO-MAHARAJ','2012-07-23 17:07:30','RAENELLE.SAMAROO-MAHARAJ','2012-07-23 17:07:30','LIVE',31),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',31.00,-1.00,5,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-07-24 15:09:06','SYSAUTH','2012-07-24 15:09:06','LIVE',32),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',30.00,-1.00,5,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-07-25 10:30:48','SYSAUTH','2012-07-25 10:30:48','LIVE',33),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',29.00,-1.00,5,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-07-26 10:05:14','SYSAUTH','2012-07-26 10:05:14','LIVE',34),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',28.00,-1.00,5,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-07-26 10:05:34','SYSAUTH','2012-07-26 10:05:34','LIVE',35),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',27.00,-1.00,5,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-07-26 11:34:11','SYSAUTH','2012-07-26 11:34:11','LIVE',36),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',26.00,-1.00,5,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-07-27 15:24:56','SYSAUTH','2012-07-27 15:24:56','LIVE',37),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',25.00,-1.00,5,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-07-30 12:16:53','SYSAUTH','2012-07-30 12:16:53','LIVE',38),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',24.00,-1.00,5,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-07-30 14:29:00','SYSAUTH','2012-07-30 14:29:00','LIVE',39),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',23.00,-1.00,5,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-07-31 09:34:22','SYSAUTH','2012-07-31 09:34:22','LIVE',40),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',21.00,-2.00,5,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-07-31 12:31:21','SYSAUTH','2012-07-31 12:31:21','LIVE',41),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',20.00,-1.00,5,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-08-03 10:49:46','SYSAUTH','2012-08-03 10:49:46','LIVE',42),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',19.00,-1.00,5,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-08-03 12:20:13','SYSAUTH','2012-08-03 12:20:13','LIVE',43),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',18.00,-1.00,5,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-08-06 13:50:00','SYSAUTH','2012-08-06 13:50:00','LIVE',44),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',17.00,-1.00,5,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-08-06 14:06:08','SYSAUTH','2012-08-06 14:06:08','LIVE',45),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',16.00,-1.00,5,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-08-07 11:25:23','SYSAUTH','2012-08-07 11:25:23','LIVE',46),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',15.00,-1.00,5,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-08-10 10:39:09','SYSAUTH','2012-08-10 10:39:09','LIVE',47),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',14.00,-1.00,5,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-08-10 17:16:51','SYSAUTH','2012-08-10 17:16:51','LIVE',48),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',13.00,-1.00,5,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-08-10 17:17:49','SYSAUTH','2012-08-10 17:17:49','LIVE',49),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',12.00,-1.00,5,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-08-11 09:10:05','SYSAUTH','2012-08-11 09:10:05','LIVE',50),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',11.00,-1.00,5,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-08-11 09:28:52','SYSAUTH','2012-08-11 09:28:52','LIVE',51),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',10.00,-1.00,5,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-08-11 10:49:43','SYSAUTH','2012-08-11 10:49:43','LIVE',52),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',9.00,-1.00,5,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-08-11 11:31:21','SYSAUTH','2012-08-11 11:31:21','LIVE',53),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',8.00,-1.00,5,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-08-11 12:07:45','SYSAUTH','2012-08-11 12:07:45','LIVE',54),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',7.00,-1.00,5,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-08-14 11:45:26','SYSAUTH','2012-08-14 11:45:26','LIVE',55),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',6.00,-1.00,5,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-08-14 12:44:46','SYSAUTH','2012-08-14 12:44:46','LIVE',56),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',5.00,-1.00,5,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-08-14 15:58:40','SYSAUTH','2012-08-14 15:58:40','LIVE',57),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',4.00,-1.00,5,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-08-17 14:27:05','SYSAUTH','2012-08-17 14:27:05','LIVE',58),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',3.00,-1.00,5,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-08-17 16:26:20','SYSAUTH','2012-08-17 16:26:20','LIVE',59),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',2.00,-1.00,5,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-08-18 08:43:44','SYSAUTH','2012-08-18 08:43:44','LIVE',60),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',1.00,-1.00,5,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-08-18 10:43:27','SYSAUTH','2012-08-18 10:43:27','LIVE',61),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',0.00,-1.00,5,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-08-23 10:28:38','SYSAUTH','2012-08-23 10:28:38','HIST',62),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',29.00,0.00,5,'STOCK.CHECK','','RAENELLE.SAMAROO-MAHARAJ','2012-10-04 13:41:16','RAENELLE.SAMAROO-MAHARAJ','2012-10-04 13:41:16','LIVE',63),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',28.00,-1.00,5,'SALE','','AMANDA.OUDAI','2012-10-04 16:27:30','SYSAUTH','2012-10-04 16:27:30','HIST',64),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',29.00,0.00,5,'STOCK.CHECK','','RAENELLE.SAMAROO-MAHARAJ','2012-10-04 17:19:22','RAENELLE.SAMAROO-MAHARAJ','2012-10-04 17:19:22','LIVE',65),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',28.00,-1.00,5,'SALE','','AMANDA.OUDAI','2012-10-05 12:00:10','SYSAUTH','2012-10-05 12:00:10','LIVE',66),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',27.00,-1.00,5,'SALE','','AMANDA.OUDAI','2012-10-05 12:33:29','SYSAUTH','2012-10-05 12:33:29','LIVE',67),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',20.00,-7.00,5,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-10-05 15:03:25','SYSAUTH','2012-10-05 15:03:25','LIVE',68),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',19.00,-1.00,5,'SALE','','AMANDA.OUDAI','2012-10-06 08:38:13','SYSAUTH','2012-10-06 08:38:13','LIVE',69),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',18.00,-1.00,5,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-10-06 09:35:36','SYSAUTH','2012-10-06 09:35:36','LIVE',70),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',17.00,-1.00,5,'SALE','','AMANDA.OUDAI','2012-10-06 10:35:13','SYSAUTH','2012-10-06 10:35:13','LIVE',71),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',16.00,-1.00,5,'SALE','','AMANDA.OUDAI','2012-10-06 10:59:43','SYSAUTH','2012-10-06 10:59:43','LIVE',72),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',15.00,-1.00,5,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-10-06 13:17:22','SYSAUTH','2012-10-06 13:17:22','LIVE',73),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',14.00,-1.00,5,'SALE','','AMANDA.OUDAI','2012-10-08 09:13:35','SYSAUTH','2012-10-08 09:13:35','LIVE',74),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',13.00,-1.00,5,'SALE','','AMANDA.OUDAI','2012-10-08 10:15:03','SYSAUTH','2012-10-08 10:15:03','LIVE',75),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',12.00,-1.00,5,'SALE','','AMANDA.OUDAI','2012-10-08 10:50:32','SYSAUTH','2012-10-08 10:50:32','LIVE',76),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',11.00,-1.00,5,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-10-08 11:05:55','SYSAUTH','2012-10-08 11:05:55','LIVE',77),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',10.00,-1.00,5,'SALE','','AMANDA.OUDAI','2012-10-09 09:36:57','SYSAUTH','2012-10-09 09:36:57','LIVE',78),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',9.00,-1.00,5,'SALE','','AMANDA.OUDAI','2012-10-09 10:58:00','SYSAUTH','2012-10-09 10:58:00','LIVE',79),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',8.00,-1.00,5,'SALE','','AMANDA.OUDAI','2012-10-10 09:07:30','SYSAUTH','2012-10-10 09:07:30','LIVE',80),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',7.00,-1.00,5,'SALE','','AMANDA.OUDAI','2012-10-10 09:53:20','SYSAUTH','2012-10-10 09:53:20','LIVE',81),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',6.00,-1.00,5,'SALE','','AMANDA.OUDAI','2012-10-10 10:30:59','SYSAUTH','2012-10-10 10:30:59','LIVE',82),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',5.00,-1.00,5,'SALE','','AMANDA.OUDAI','2012-10-10 12:05:49','SYSAUTH','2012-10-10 12:05:49','LIVE',83),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',4.00,-1.00,5,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-10-10 14:09:42','SYSAUTH','2012-10-10 14:09:42','LIVE',84),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',3.00,-1.00,5,'SALE','','AMANDA.OUDAI','2012-10-10 16:36:01','SYSAUTH','2012-10-10 16:36:01','LIVE',85),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',2.00,-1.00,5,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-10-11 10:06:57','SYSAUTH','2012-10-11 10:06:57','LIVE',86),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',1.00,-1.00,5,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-10-11 15:23:54','SYSAUTH','2012-10-11 15:23:54','LIVE',87),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',0.00,-1.00,5,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-10-11 15:25:38','SYSAUTH','2012-10-11 15:25:38','HIST',88),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',28.00,0.00,5,'STOCK.CHECK','','RAENELLE.SAMAROO-MAHARAJ','2012-10-12 11:35:57','RAENELLE.SAMAROO-MAHARAJ','2012-10-12 11:35:57','LIVE',89),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',27.00,-1.00,5,'SALE','','AMANDA.OUDAI','2012-10-12 13:29:46','SYSAUTH','2012-10-12 13:29:46','LIVE',90),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',26.00,-1.00,5,'SALE','','AMANDA.OUDAI','2012-10-13 09:48:58','SYSAUTH','2012-10-13 09:48:58','LIVE',91),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',25.00,-1.00,5,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-10-13 10:45:27','SYSAUTH','2012-10-13 10:45:27','LIVE',92),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',24.00,-1.00,5,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-10-13 11:39:17','SYSAUTH','2012-10-13 11:39:17','LIVE',93),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',23.00,-1.00,5,'SALE','','AMANDA.OUDAI','2012-10-16 10:25:02','SYSAUTH','2012-10-16 10:25:02','LIVE',94),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',22.00,-1.00,5,'SALE','','AMANDA.OUDAI','2012-10-16 12:24:23','SYSAUTH','2012-10-16 12:24:23','HIST',95),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',61.00,0.00,5,'STOCK.CHECK','','RAENELLE.SAMAROO-MAHARAJ','2012-10-16 15:42:56','RAENELLE.SAMAROO-MAHARAJ','2012-10-16 15:42:56','HIST',96),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',21.00,0.00,5,'STOCK.CHECK','','RAENELLE.SAMAROO-MAHARAJ','2012-10-16 15:52:58','RAENELLE.SAMAROO-MAHARAJ','2012-10-16 15:52:58','LIVE',97),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',20.00,-1.00,5,'SALE','','AMANDA.OUDAI','2012-10-17 11:04:31','SYSAUTH','2012-10-17 11:04:31','LIVE',98),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',19.00,-1.00,5,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-10-17 13:39:07','SYSAUTH','2012-10-17 13:39:07','LIVE',99),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',18.00,-1.00,5,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-10-18 09:37:37','SYSAUTH','2012-10-18 09:37:37','LIVE',100),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',17.00,-1.00,5,'SALE','','AMANDA.OUDAI','2012-10-18 10:34:28','SYSAUTH','2012-10-18 10:34:28','LIVE',101),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',16.00,-1.00,5,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-10-18 10:53:28','SYSAUTH','2012-10-18 10:53:28','LIVE',102),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',15.00,-1.00,5,'SALE','','AMANDA.OUDAI','2012-10-18 16:04:18','SYSAUTH','2012-10-18 16:04:18','LIVE',103),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',14.00,-1.00,5,'SALE','','AMANDA.OUDAI','2012-10-19 09:08:36','SYSAUTH','2012-10-19 09:08:36','LIVE',104),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',13.00,-1.00,5,'SALE','','AMANDA.OUDAI','2012-10-19 10:31:02','SYSAUTH','2012-10-19 10:31:02','LIVE',105),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',12.00,-1.00,5,'SALE','','AMANDA.OUDAI','2012-10-19 12:10:46','SYSAUTH','2012-10-19 12:10:46','LIVE',106),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',11.00,-1.00,5,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-10-19 14:16:29','SYSAUTH','2012-10-19 14:16:29','LIVE',107),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',10.00,-1.00,5,'SALE','','AMANDA.OUDAI','2012-10-19 14:45:55','SYSAUTH','2012-10-19 14:45:55','LIVE',108),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',9.00,-1.00,5,'SALE','','AMANDA.OUDAI','2012-10-20 10:39:25','SYSAUTH','2012-10-20 10:39:25','LIVE',109),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',8.00,-1.00,5,'SALE','','AMANDA.OUDAI','2012-10-22 11:53:37','SYSAUTH','2012-10-22 11:53:37','LIVE',110),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',7.00,-1.00,5,'SALE','','AMANDA.OUDAI','2012-10-23 13:03:50','SYSAUTH','2012-10-23 13:03:50','LIVE',111),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',6.00,-1.00,5,'SALE','','AMANDA.OUDAI','2012-10-24 09:32:10','SYSAUTH','2012-10-24 09:32:10','LIVE',112),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',5.00,-1.00,5,'SALE','','AMANDA.OUDAI','2012-10-25 09:09:57','SYSAUTH','2012-10-25 09:09:57','LIVE',113),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',4.00,-1.00,5,'SALE','','AMANDA.OUDAI','2012-10-26 10:45:35','SYSAUTH','2012-10-26 10:45:35','LIVE',114),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',3.00,-1.00,5,'SALE','','AMANDA.OUDAI','2012-10-26 12:05:49','SYSAUTH','2012-10-26 12:05:49','LIVE',115),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',2.00,-1.00,5,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-10-26 14:10:49','SYSAUTH','2012-10-26 14:10:49','LIVE',116),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',1.00,-1.00,5,'SALE','','AMANDA.OUDAI','2012-10-27 09:02:30','SYSAUTH','2012-10-27 09:02:30','LIVE',117),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',0.00,-1.00,5,'SALE','','AMANDA.OUDAI','2012-10-29 09:53:41','SYSAUTH','2012-10-29 09:53:41','HIST',118),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',14.00,0.00,5,'STOCK.CHECK','','RAENELLE.SAMAROO-MAHARAJ','2012-10-30 09:23:58','RAENELLE.SAMAROO-MAHARAJ','2012-10-30 09:23:58','LIVE',119),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',13.00,-1.00,5,'SALE','','AMANDA.OUDAI','2012-10-30 10:38:44','SYSAUTH','2012-10-30 10:38:44','LIVE',120),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',12.00,-1.00,5,'SALE','','AMANDA.OUDAI','2012-10-30 16:15:38','SYSAUTH','2012-10-30 16:15:38','LIVE',121),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',11.00,-1.00,5,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-10-31 12:07:30','SYSAUTH','2012-10-31 12:07:30','LIVE',122),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',10.00,-1.00,5,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-10-31 12:39:39','SYSAUTH','2012-10-31 12:39:39','LIVE',123),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',9.00,-1.00,5,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-11-02 10:56:51','SYSAUTH','2012-11-02 10:56:51','LIVE',124),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',8.00,-1.00,5,'SALE','','AMANDA.OUDAI','2012-11-02 13:24:24','SYSAUTH','2012-11-02 13:24:24','LIVE',125),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',7.00,-1.00,5,'SALE','','AMANDA.OUDAI','2012-11-03 09:03:11','SYSAUTH','2012-11-03 09:03:11','LIVE',126),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',6.00,-1.00,5,'SALE','','AMANDA.OUDAI','2012-11-05 12:23:02','SYSAUTH','2012-11-05 12:23:02','LIVE',127),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',5.00,-1.00,5,'SALE','','AMANDA.OUDAI','2012-11-06 09:49:48','SYSAUTH','2012-11-06 09:49:48','LIVE',128),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',4.00,-1.00,5,'SALE','','AMANDA.OUDAI','2012-11-07 10:39:23','SYSAUTH','2012-11-07 10:39:23','LIVE',129),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',3.00,-1.00,5,'SALE','','AMANDA.OUDAI','2012-11-09 09:45:14','SYSAUTH','2012-11-09 09:45:14','LIVE',130),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',2.00,-1.00,5,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-11-09 10:49:20','SYSAUTH','2012-11-09 10:49:20','LIVE',131),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',1.00,-1.00,5,'SALE','','AMANDA.OUDAI','2012-11-09 11:28:55','SYSAUTH','2012-11-09 11:28:55','LIVE',132),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',0.00,-1.00,5,'SALE','','AMANDA.OUDAI','2012-11-09 15:29:18','SYSAUTH','2012-11-09 15:29:18','HIST',133),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',10.00,10.00,5,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-11-20 15:11:41','RAENELLE.SAMAROO-MAHARAJ','2012-11-20 15:11:41','LIVE',134),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',9.00,-1.00,5,'SALE','','AMANDA.OUDAI','2012-11-21 11:50:56','SYSAUTH','2012-11-21 11:50:56','LIVE',135),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',8.00,-1.00,5,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-11-21 12:49:06','SYSAUTH','2012-11-21 12:49:06','LIVE',136),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',7.00,-1.00,5,'SALE','','AMANDA.OUDAI','2012-11-21 13:49:31','SYSAUTH','2012-11-21 13:49:31','LIVE',137),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',6.00,-1.00,5,'SALE','','AMANDA.OUDAI','2012-11-21 14:00:15','SYSAUTH','2012-11-21 14:00:15','LIVE',138),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',5.00,-1.00,5,'SALE','','AMANDA.OUDAI','2012-11-22 09:30:35','SYSAUTH','2012-11-22 09:30:35','LIVE',139),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',4.00,-1.00,5,'SALE','','AMANDA.OUDAI','2012-11-22 11:24:50','SYSAUTH','2012-11-22 11:24:50','LIVE',140),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',3.00,-1.00,5,'SALE','','AMANDA.OUDAI','2012-11-23 11:08:05','SYSAUTH','2012-11-23 11:08:05','LIVE',141),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',2.00,-1.00,5,'SALE','','AMANDA.OUDAI','2012-11-26 10:42:22','SYSAUTH','2012-11-26 10:42:22','LIVE',142),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',1.00,-1.00,5,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-11-26 10:51:37','SYSAUTH','2012-11-26 10:51:37','LIVE',143),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',0.00,-1.00,5,'SALE','','AMANDA.OUDAI','2012-11-26 13:24:23','SYSAUTH','2012-11-26 13:24:23','HIST',144),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',11.00,0.00,5,'STOCK.CHECK','','RAENELLE.SAMAROO-MAHARAJ','2012-11-26 14:53:20','RAENELLE.SAMAROO-MAHARAJ','2012-11-26 14:53:20','LIVE',145),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',10.00,-1.00,5,'SALE','','AMANDA.OUDAI','2012-11-27 15:38:52','SYSAUTH','2012-11-27 15:38:52','LIVE',146),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',9.00,-1.00,5,'SALE','','AMANDA.OUDAI','2012-11-28 13:32:24','SYSAUTH','2012-11-28 13:32:24','LIVE',147),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',8.00,-1.00,5,'SALE','','AMANDA.OUDAI','2012-11-29 10:47:24','SYSAUTH','2012-11-29 10:47:24','LIVE',148),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',7.00,-1.00,5,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-11-29 11:16:39','SYSAUTH','2012-11-29 11:16:39','LIVE',149),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',6.00,-1.00,5,'SALE','','AMANDA.OUDAI','2012-11-29 12:45:50','SYSAUTH','2012-11-29 12:45:50','LIVE',150),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',5.00,-1.00,5,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-11-29 12:48:48','SYSAUTH','2012-11-29 12:48:48','LIVE',151),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',4.00,-1.00,5,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-11-29 13:13:44','SYSAUTH','2012-11-29 13:13:44','LIVE',152),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',3.00,-1.00,5,'SALE','','AMANDA.OUDAI','2012-11-30 10:32:15','SYSAUTH','2012-11-30 10:32:15','LIVE',153),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',2.00,-1.00,5,'SALE','','AMANDA.OUDAI','2012-11-30 13:33:15','SYSAUTH','2012-11-30 13:33:15','LIVE',154),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',1.00,-1.00,5,'SALE','','AMANDA.OUDAI','2012-11-30 14:41:57','SYSAUTH','2012-11-30 14:41:57','HIST',155),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',17.00,0.00,5,'STOCK.CHECK','','RAENELLE.SAMAROO-MAHARAJ','2012-11-30 16:13:48','RAENELLE.SAMAROO-MAHARAJ','2012-11-30 16:13:48','LIVE',156),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',16.00,-1.00,5,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-12-01 08:50:44','SYSAUTH','2012-12-01 08:50:44','LIVE',157),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',15.00,-1.00,5,'SALE','','AMANDA.OUDAI','2012-12-01 08:52:01','SYSAUTH','2012-12-01 08:52:01','LIVE',158),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',14.00,-1.00,5,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-12-01 10:24:34','SYSAUTH','2012-12-01 10:24:34','LIVE',159),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',13.00,-1.00,5,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-12-01 12:48:54','SYSAUTH','2012-12-01 12:48:54','LIVE',160),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',12.00,-1.00,5,'SALE','','AMANDA.OUDAI','2012-12-03 10:15:09','SYSAUTH','2012-12-03 10:15:09','LIVE',161),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',11.00,-1.00,5,'SALE','','AMANDA.OUDAI','2012-12-03 12:08:00','SYSAUTH','2012-12-03 12:08:00','LIVE',162),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',10.00,-1.00,5,'SALE','','AMANDA.OUDAI','2012-12-04 09:04:20','SYSAUTH','2012-12-04 09:04:20','LIVE',163),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',9.00,-1.00,5,'SALE','','AMANDA.OUDAI','2012-12-04 11:33:00','SYSAUTH','2012-12-04 11:33:00','HIST',164),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',23.00,0.00,5,'STOCK.CHECK','','RAENELLE.SAMAROO-MAHARAJ','2012-12-04 15:38:20','RAENELLE.SAMAROO-MAHARAJ','2012-12-04 15:38:20','LIVE',165),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',22.00,-1.00,5,'SALE','','AMANDA.OUDAI','2012-12-05 13:04:05','SYSAUTH','2012-12-05 13:04:05','LIVE',166),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',21.00,-1.00,5,'SALE','','AMANDA.OUDAI','2012-12-05 15:59:23','SYSAUTH','2012-12-05 15:59:23','LIVE',167),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',20.00,-1.00,5,'SALE','','AMANDA.OUDAI','2012-12-06 15:32:26','SYSAUTH','2012-12-06 15:32:26','LIVE',168),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',19.00,-1.00,5,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-12-06 18:02:44','SYSAUTH','2012-12-06 18:02:44','LIVE',169),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',18.00,-1.00,5,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-12-06 18:03:15','SYSAUTH','2012-12-06 18:03:15','LIVE',170),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',17.00,-1.00,5,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-12-06 18:03:25','SYSAUTH','2012-12-06 18:03:25','LIVE',171),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',16.00,-1.00,5,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-12-06 18:03:48','SYSAUTH','2012-12-06 18:03:48','LIVE',172),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',15.00,-1.00,5,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-12-06 18:04:26','SYSAUTH','2012-12-06 18:04:26','LIVE',173),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',14.00,-1.00,5,'SALE','','AMANDA.OUDAI','2012-12-07 09:29:47','SYSAUTH','2012-12-07 09:29:47','HIST',174),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',13.00,-1.00,5,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-12-07 16:39:47','RAENELLE.SAMAROO-MAHARAJ','2012-12-07 16:39:47','LIVE',175),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',12.00,-1.00,5,'SALE','','AMANDA.OUDAI','2012-12-08 09:51:18','SYSAUTH','2012-12-08 09:51:18','LIVE',176),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',11.00,-1.00,5,'SALE','','AMANDA.OUDAI','2012-12-08 10:35:53','SYSAUTH','2012-12-08 10:35:53','LIVE',177),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',10.00,-1.00,5,'SALE','','AMANDA.OUDAI','2012-12-08 10:57:48','SYSAUTH','2012-12-08 10:57:48','LIVE',178),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',9.00,-1.00,5,'SALE','','AMANDA.OUDAI','2012-12-10 14:04:35','SYSAUTH','2012-12-10 14:04:35','LIVE',179),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',8.00,-1.00,5,'SALE','','AMANDA.OUDAI','2012-12-11 16:35:29','SYSAUTH','2012-12-11 16:35:29','LIVE',180),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',7.00,-1.00,5,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-12-12 10:11:08','SYSAUTH','2012-12-12 10:11:08','LIVE',181),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',6.00,-1.00,5,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-12-13 10:42:28','SYSAUTH','2012-12-13 10:42:28','LIVE',182),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',5.00,-1.00,5,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-12-13 10:54:39','SYSAUTH','2012-12-13 10:54:39','LIVE',183),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',4.00,-1.00,5,'SALE','','AMANDA.OUDAI','2012-12-13 13:39:24','SYSAUTH','2012-12-13 13:39:24','LIVE',184),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',3.00,-1.00,5,'SALE','','AMANDA.OUDAI','2012-12-13 15:01:31','SYSAUTH','2012-12-13 15:01:31','LIVE',185),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',2.00,-1.00,5,'SALE','','AMANDA.OUDAI','2012-12-14 10:28:06','SYSAUTH','2012-12-14 10:28:06','LIVE',186),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',1.00,-1.00,5,'SALE','','AMANDA.OUDAI','2012-12-15 08:57:27','SYSAUTH','2012-12-15 08:57:27','LIVE',187),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',0.00,-1.00,5,'SALE','','AMANDA.OUDAI','2012-12-15 09:29:13','SYSAUTH','2012-12-15 09:29:13','HIST',188),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',11.00,0.00,5,'STOCK.CHECK','','ADMIN','2012-12-18 15:58:24','ADMIN','2012-12-18 15:58:24','LIVE',189),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',10.00,-1.00,5,'SALE','','AMANDA.OUDAI','2012-12-19 10:21:17','SYSAUTH','2012-12-19 10:21:17','LIVE',190),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',9.00,-1.00,5,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-12-19 10:40:24','SYSAUTH','2012-12-19 10:40:24','LIVE',191),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',8.00,-1.00,5,'SALE','','AMANDA.OUDAI','2012-12-19 12:55:24','SYSAUTH','2012-12-19 12:55:24','HIST',192),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',6.00,0.00,5,'STOCK.CHECK','','RAENELLE.SAMAROO-MAHARAJ','2012-12-19 16:29:02','RAENELLE.SAMAROO-MAHARAJ','2012-12-19 16:29:02','LIVE',193),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',5.00,-1.00,5,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-12-20 10:19:00','SYSAUTH','2012-12-20 10:19:00','LIVE',194),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',4.00,-1.00,5,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-12-20 14:39:07','SYSAUTH','2012-12-20 14:39:07','LIVE',195),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',3.00,-1.00,5,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-12-20 14:54:25','SYSAUTH','2012-12-20 14:54:25','LIVE',196),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',2.00,-1.00,5,'SALE','','AMANDA.OUDAI','2012-12-21 09:30:05','SYSAUTH','2012-12-21 09:30:05','LIVE',197),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',1.00,-1.00,5,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-12-21 11:27:37','SYSAUTH','2012-12-21 11:27:37','LIVE',198),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',100.00,-1.00,5,'SALE','','AMANDA.OUDAI','2012-12-21 12:02:17','SYSAUTH','2012-12-21 12:02:17','LIVE',199),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',97.00,-3.00,5,'SALE','','ADMIN','2013-02-25 03:37:05','SYSAUTH','2013-02-25 03:37:05','LIVE',200),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',96.00,-1.00,5,'SALE','','ADMIN','2013-02-25 13:12:46','SYSAUTH','2013-02-25 13:12:46','LIVE',201),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',91.00,-5.00,5,'LOAN','','ADMIN','2013-02-25 13:15:17','SYSAUTH','2013-02-25 13:15:17','LIVE',202),(507,'SIM.BMO.PRE100-HEAD.OFFICE','SIM.BMO.PRE100','HEAD.OFFICE',86.00,-5.00,5,'SALE','','ADMIN','2013-02-25 13:20:41','SYSAUTH','2013-02-25 13:20:41','LIVE',203),(512,'ACTUATOR-HEAD.OFFICE','ACTUATOR','HEAD.OFFICE',0.00,0.00,1,'STOCK.CHECK','','ADMIN','2012-05-12 13:23:43','ADMIN','2012-05-12 13:23:43','HIST',1),(512,'ACTUATOR-HEAD.OFFICE','ACTUATOR','HEAD.OFFICE',1.00,0.00,1,'STOCK.CHECK','','RAENELLE.SAMAROO-MAHARAJ','2012-11-20 15:11:03','RAENELLE.SAMAROO-MAHARAJ','2012-11-20 15:11:03','LIVE',2),(512,'ACTUATOR-HEAD.OFFICE','ACTUATOR','HEAD.OFFICE',0.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-11-29 11:16:39','SYSAUTH','2012-11-29 11:16:39','HIST',3),(512,'ACTUATOR-HEAD.OFFICE','ACTUATOR','HEAD.OFFICE',10.00,10.00,1,'STOCK.NEW.IN','','RAENELLE.SAMAROO-MAHARAJ','2012-12-04 11:16:04','RAENELLE.SAMAROO-MAHARAJ','2012-12-04 11:16:04','LIVE',4),(512,'ACTUATOR-HEAD.OFFICE','ACTUATOR','HEAD.OFFICE',6.00,-4.00,1,'SALE','','AMANDA.OUDAI','2012-12-04 11:33:00','SYSAUTH','2012-12-04 11:33:00','HIST',5),(514,'SIM.DIG.PRE-HEAD.OFFICE','SIM.DIG.PRE','HEAD.OFFICE',0.00,0.00,1,'STOCK.CHECK','','ADMIN','2012-05-12 13:24:18','ADMIN','2012-05-12 13:24:18','HIST',1),(514,'SIM.DIG.PRE-HEAD.OFFICE','SIM.DIG.PRE','HEAD.OFFICE',7.00,0.00,1,'STOCK.CHECK','','DAMIEN.NESBIT','2012-05-14 16:59:34','DAMIEN.NESBIT','2012-05-14 16:59:34','HIST',2),(514,'SIM.DIG.PRE-HEAD.OFFICE','SIM.DIG.PRE','HEAD.OFFICE',27.00,0.00,1,'STOCK.NEW.IN','','RAENELLE.SAMAROO-MAHARAJ','2012-05-21 16:23:03','RAENELLE.SAMAROO-MAHARAJ','2012-05-21 16:23:03','LIVE',3),(514,'SIM.DIG.PRE-HEAD.OFFICE','SIM.DIG.PRE','HEAD.OFFICE',26.00,0.00,1,'SALE','','DANNY.RAMDASS','2012-05-25 10:16:53','SYSAUTH','2012-05-25 10:16:53','HIST',4),(514,'SIM.DIG.PRE-HEAD.OFFICE','SIM.DIG.PRE','HEAD.OFFICE',27.00,0.00,1,'STOCK.CHECK','','RAENELLE.SAMAROO-MAHARAJ','2012-06-06 11:49:04','RAENELLE.SAMAROO-MAHARAJ','2012-06-06 11:49:04','LIVE',5),(514,'SIM.DIG.PRE-HEAD.OFFICE','SIM.DIG.PRE','HEAD.OFFICE',26.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-06-06 12:23:54','SYSAUTH','2012-06-06 12:23:54','LIVE',6),(514,'SIM.DIG.PRE-HEAD.OFFICE','SIM.DIG.PRE','HEAD.OFFICE',25.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-06-06 15:02:55','SYSAUTH','2012-06-06 15:02:55','LIVE',7),(514,'SIM.DIG.PRE-HEAD.OFFICE','SIM.DIG.PRE','HEAD.OFFICE',24.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-06-23 08:50:51','SYSAUTH','2012-06-23 08:50:51','LIVE',8),(514,'SIM.DIG.PRE-HEAD.OFFICE','SIM.DIG.PRE','HEAD.OFFICE',23.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-06-30 11:10:43','SYSAUTH','2012-06-30 11:10:43','LIVE',9),(514,'SIM.DIG.PRE-HEAD.OFFICE','SIM.DIG.PRE','HEAD.OFFICE',22.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-07-03 13:05:22','SYSAUTH','2012-07-03 13:05:22','LIVE',10),(514,'SIM.DIG.PRE-HEAD.OFFICE','SIM.DIG.PRE','HEAD.OFFICE',21.00,-1.00,1,'SALE','','DUNSTAN.NESBIT','2012-07-03 17:15:47','SYSAUTH','2012-07-03 17:15:47','LIVE',11),(514,'SIM.DIG.PRE-HEAD.OFFICE','SIM.DIG.PRE','HEAD.OFFICE',20.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-07-23 10:16:39','SYSAUTH','2012-07-23 10:16:39','LIVE',12),(514,'SIM.DIG.PRE-HEAD.OFFICE','SIM.DIG.PRE','HEAD.OFFICE',19.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-07-30 11:18:38','SYSAUTH','2012-07-30 11:18:38','LIVE',13),(514,'SIM.DIG.PRE-HEAD.OFFICE','SIM.DIG.PRE','HEAD.OFFICE',18.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-08-09 12:13:41','SYSAUTH','2012-08-09 12:13:41','LIVE',14),(514,'SIM.DIG.PRE-HEAD.OFFICE','SIM.DIG.PRE','HEAD.OFFICE',17.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-08-17 10:29:45','SYSAUTH','2012-08-17 10:29:45','LIVE',15),(514,'SIM.DIG.PRE-HEAD.OFFICE','SIM.DIG.PRE','HEAD.OFFICE',16.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-08-25 09:26:04','SYSAUTH','2012-08-25 09:26:04','LIVE',16),(514,'SIM.DIG.PRE-HEAD.OFFICE','SIM.DIG.PRE','HEAD.OFFICE',15.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-09-01 10:51:07','SYSAUTH','2012-09-01 10:51:07','LIVE',17),(514,'SIM.DIG.PRE-HEAD.OFFICE','SIM.DIG.PRE','HEAD.OFFICE',14.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-09-03 10:55:09','SYSAUTH','2012-09-03 10:55:09','LIVE',18),(514,'SIM.DIG.PRE-HEAD.OFFICE','SIM.DIG.PRE','HEAD.OFFICE',13.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-09-14 10:17:49','SYSAUTH','2012-09-14 10:17:49','LIVE',19),(514,'SIM.DIG.PRE-HEAD.OFFICE','SIM.DIG.PRE','HEAD.OFFICE',11.00,-2.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-09-14 16:01:46','SYSAUTH','2012-09-14 16:01:46','LIVE',20),(514,'SIM.DIG.PRE-HEAD.OFFICE','SIM.DIG.PRE','HEAD.OFFICE',10.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-09-17 12:57:59','SYSAUTH','2012-09-17 12:57:59','LIVE',21),(514,'SIM.DIG.PRE-HEAD.OFFICE','SIM.DIG.PRE','HEAD.OFFICE',9.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-09-21 16:08:28','SYSAUTH','2012-09-21 16:08:28','LIVE',22),(514,'SIM.DIG.PRE-HEAD.OFFICE','SIM.DIG.PRE','HEAD.OFFICE',8.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-09-25 10:45:27','SYSAUTH','2012-09-25 10:45:27','LIVE',23),(514,'SIM.DIG.PRE-HEAD.OFFICE','SIM.DIG.PRE','HEAD.OFFICE',7.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-09-26 11:14:23','SYSAUTH','2012-09-26 11:14:23','LIVE',24),(514,'SIM.DIG.PRE-HEAD.OFFICE','SIM.DIG.PRE','HEAD.OFFICE',6.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-09-27 10:28:37','SYSAUTH','2012-09-27 10:28:37','LIVE',25),(514,'SIM.DIG.PRE-HEAD.OFFICE','SIM.DIG.PRE','HEAD.OFFICE',5.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-10-02 14:31:41','SYSAUTH','2012-10-02 14:31:41','HIST',26),(514,'SIM.DIG.PRE-HEAD.OFFICE','SIM.DIG.PRE','HEAD.OFFICE',23.00,0.00,1,'STOCK.CHECK','','RAENELLE.SAMAROO-MAHARAJ','2012-10-04 13:52:02','RAENELLE.SAMAROO-MAHARAJ','2012-10-04 13:52:02','LIVE',27),(514,'SIM.DIG.PRE-HEAD.OFFICE','SIM.DIG.PRE','HEAD.OFFICE',22.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-10-08 15:00:47','SYSAUTH','2012-10-08 15:00:47','LIVE',28),(514,'SIM.DIG.PRE-HEAD.OFFICE','SIM.DIG.PRE','HEAD.OFFICE',21.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-10-10 12:34:13','SYSAUTH','2012-10-10 12:34:13','LIVE',29),(514,'SIM.DIG.PRE-HEAD.OFFICE','SIM.DIG.PRE','HEAD.OFFICE',20.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-10-12 10:45:01','SYSAUTH','2012-10-12 10:45:01','LIVE',30),(514,'SIM.DIG.PRE-HEAD.OFFICE','SIM.DIG.PRE','HEAD.OFFICE',19.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-10-13 08:59:20','SYSAUTH','2012-10-13 08:59:20','LIVE',31),(514,'SIM.DIG.PRE-HEAD.OFFICE','SIM.DIG.PRE','HEAD.OFFICE',18.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-10-16 13:05:09','SYSAUTH','2012-10-16 13:05:09','LIVE',32),(514,'SIM.DIG.PRE-HEAD.OFFICE','SIM.DIG.PRE','HEAD.OFFICE',17.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-10-17 11:25:43','SYSAUTH','2012-10-17 11:25:43','LIVE',33),(514,'SIM.DIG.PRE-HEAD.OFFICE','SIM.DIG.PRE','HEAD.OFFICE',16.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-10-18 12:42:53','SYSAUTH','2012-10-18 12:42:53','LIVE',34),(514,'SIM.DIG.PRE-HEAD.OFFICE','SIM.DIG.PRE','HEAD.OFFICE',15.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-10-19 11:47:10','SYSAUTH','2012-10-19 11:47:10','LIVE',35),(514,'SIM.DIG.PRE-HEAD.OFFICE','SIM.DIG.PRE','HEAD.OFFICE',14.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-10-23 09:44:24','SYSAUTH','2012-10-23 09:44:24','LIVE',36),(514,'SIM.DIG.PRE-HEAD.OFFICE','SIM.DIG.PRE','HEAD.OFFICE',13.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-10-30 14:22:07','SYSAUTH','2012-10-30 14:22:07','LIVE',37),(514,'SIM.DIG.PRE-HEAD.OFFICE','SIM.DIG.PRE','HEAD.OFFICE',12.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-10-31 09:35:39','SYSAUTH','2012-10-31 09:35:39','LIVE',38),(514,'SIM.DIG.PRE-HEAD.OFFICE','SIM.DIG.PRE','HEAD.OFFICE',11.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-10-31 09:48:36','SYSAUTH','2012-10-31 09:48:36','LIVE',39),(514,'SIM.DIG.PRE-HEAD.OFFICE','SIM.DIG.PRE','HEAD.OFFICE',10.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-10-31 10:01:42','SYSAUTH','2012-10-31 10:01:42','LIVE',40),(514,'SIM.DIG.PRE-HEAD.OFFICE','SIM.DIG.PRE','HEAD.OFFICE',9.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-11-01 08:59:47','SYSAUTH','2012-11-01 08:59:47','LIVE',41),(514,'SIM.DIG.PRE-HEAD.OFFICE','SIM.DIG.PRE','HEAD.OFFICE',8.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-11-02 09:45:42','SYSAUTH','2012-11-02 09:45:42','LIVE',42),(514,'SIM.DIG.PRE-HEAD.OFFICE','SIM.DIG.PRE','HEAD.OFFICE',7.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-11-02 11:27:48','SYSAUTH','2012-11-02 11:27:48','LIVE',43),(514,'SIM.DIG.PRE-HEAD.OFFICE','SIM.DIG.PRE','HEAD.OFFICE',6.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-11-09 11:52:05','SYSAUTH','2012-11-09 11:52:05','LIVE',44),(514,'SIM.DIG.PRE-HEAD.OFFICE','SIM.DIG.PRE','HEAD.OFFICE',5.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-11-09 14:07:01','SYSAUTH','2012-11-09 14:07:01','LIVE',45),(514,'SIM.DIG.PRE-HEAD.OFFICE','SIM.DIG.PRE','HEAD.OFFICE',4.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-11-09 16:13:31','SYSAUTH','2012-11-09 16:13:31','LIVE',46),(514,'SIM.DIG.PRE-HEAD.OFFICE','SIM.DIG.PRE','HEAD.OFFICE',3.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-11-14 09:31:11','SYSAUTH','2012-11-14 09:31:11','LIVE',47),(514,'SIM.DIG.PRE-HEAD.OFFICE','SIM.DIG.PRE','HEAD.OFFICE',2.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-11-15 09:28:05','SYSAUTH','2012-11-15 09:28:05','HIST',48),(514,'SIM.DIG.PRE-HEAD.OFFICE','SIM.DIG.PRE','HEAD.OFFICE',40.00,38.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-11-20 15:10:16','RAENELLE.SAMAROO-MAHARAJ','2012-11-20 15:10:16','HIST',49),(514,'SIM.DIG.PRE-HEAD.OFFICE','SIM.DIG.PRE','HEAD.OFFICE',42.00,2.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-11-20 15:10:37','RAENELLE.SAMAROO-MAHARAJ','2012-11-20 15:10:37','LIVE',50),(514,'SIM.DIG.PRE-HEAD.OFFICE','SIM.DIG.PRE','HEAD.OFFICE',41.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-11-22 09:55:18','SYSAUTH','2012-11-22 09:55:18','LIVE',51),(514,'SIM.DIG.PRE-HEAD.OFFICE','SIM.DIG.PRE','HEAD.OFFICE',40.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-11-23 10:07:43','SYSAUTH','2012-11-23 10:07:43','LIVE',52),(514,'SIM.DIG.PRE-HEAD.OFFICE','SIM.DIG.PRE','HEAD.OFFICE',39.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-11-23 13:06:24','SYSAUTH','2012-11-23 13:06:24','HIST',53),(514,'SIM.DIG.PRE-HEAD.OFFICE','SIM.DIG.PRE','HEAD.OFFICE',38.00,0.00,1,'STOCK.CHECK','','RAENELLE.SAMAROO-MAHARAJ','2012-11-30 16:11:55','RAENELLE.SAMAROO-MAHARAJ','2012-11-30 16:11:55','LIVE',54),(514,'SIM.DIG.PRE-HEAD.OFFICE','SIM.DIG.PRE','HEAD.OFFICE',37.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-12-10 09:38:25','SYSAUTH','2012-12-10 09:38:25','LIVE',55),(514,'SIM.DIG.PRE-HEAD.OFFICE','SIM.DIG.PRE','HEAD.OFFICE',36.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-12-12 09:51:51','SYSAUTH','2012-12-12 09:51:51','LIVE',56),(514,'SIM.DIG.PRE-HEAD.OFFICE','SIM.DIG.PRE','HEAD.OFFICE',35.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-12-12 12:50:44','SYSAUTH','2012-12-12 12:50:44','LIVE',57),(514,'SIM.DIG.PRE-HEAD.OFFICE','SIM.DIG.PRE','HEAD.OFFICE',34.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-12-12 14:45:14','SYSAUTH','2012-12-12 14:45:14','LIVE',58),(514,'SIM.DIG.PRE-HEAD.OFFICE','SIM.DIG.PRE','HEAD.OFFICE',33.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-12-14 09:31:29','SYSAUTH','2012-12-14 09:31:29','LIVE',59),(514,'SIM.DIG.PRE-HEAD.OFFICE','SIM.DIG.PRE','HEAD.OFFICE',32.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-12-14 11:23:43','SYSAUTH','2012-12-14 11:23:43','HIST',60),(514,'SIM.DIG.PRE-HEAD.OFFICE','SIM.DIG.PRE','HEAD.OFFICE',31.00,0.00,1,'STOCK.CHECK','','ADMIN','2012-12-18 15:57:29','ADMIN','2012-12-18 15:57:29','HIST',61),(514,'SIM.DIG.PRE-HEAD.OFFICE','SIM.DIG.PRE','HEAD.OFFICE',30.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-12-19 16:28:36','RAENELLE.SAMAROO-MAHARAJ','2012-12-19 16:28:36','LIVE',62),(514,'SIM.DIG.PRE-HEAD.OFFICE','SIM.DIG.PRE','HEAD.OFFICE',29.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-12-20 13:15:47','SYSAUTH','2012-12-20 13:15:47','LIVE',63),(514,'SIM.DIG.PRE-HEAD.OFFICE','SIM.DIG.PRE','HEAD.OFFICE',28.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-12-21 11:24:34','SYSAUTH','2012-12-21 11:24:34','LIVE',64),(515,'NRT500B-HEAD.OFFICE','NRT500B','HEAD.OFFICE',0.00,0.00,1,'STOCK.CHECK','','DUNSTAN.NESBIT','2012-06-22 07:18:53','DUNSTAN.NESBIT','2012-06-22 07:18:53','HIST',1),(515,'NRT500B-HEAD.OFFICE','NRT500B','HEAD.OFFICE',1.00,1.00,1,'STOCK.TRANSFER.IN','','RAENELLE.SAMAROO-MAHARAJ','2012-06-22 13:44:33','RAENELLE.SAMAROO-MAHARAJ','2012-06-22 13:44:33','HIST',2),(515,'NRT500B-HEAD.OFFICE','NRT500B','HEAD.OFFICE',0.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-06-22 13:45:00','RAENELLE.SAMAROO-MAHARAJ','2012-06-22 13:45:00','HIST',3),(515,'NRT500B-HEAD.OFFICE','NRT500B','HEAD.OFFICE',2.00,2.00,1,'STOCK.TRANSFER.IN','','RAENELLE.SAMAROO-MAHARAJ','2012-07-16 10:10:14','RAENELLE.SAMAROO-MAHARAJ','2012-07-16 10:10:14','HIST',4),(515,'NRT500B-HEAD.OFFICE','NRT500B','HEAD.OFFICE',4.00,2.00,1,'STOCK.TRANSFER.IN','','RAENELLE.SAMAROO-MAHARAJ','2012-07-17 16:41:27','RAENELLE.SAMAROO-MAHARAJ','2012-07-17 16:41:27','HIST',5),(515,'NRT500B-HEAD.OFFICE','NRT500B','HEAD.OFFICE',5.00,1.00,1,'STOCK.TRANSFER.IN','','RAENELLE.SAMAROO-MAHARAJ','2012-07-18 11:29:42','RAENELLE.SAMAROO-MAHARAJ','2012-07-18 11:29:42','HIST',6),(515,'NRT500B-HEAD.OFFICE','NRT500B','HEAD.OFFICE',10.00,5.00,1,'STOCK.TRANSFER.IN','','RAENELLE.SAMAROO-MAHARAJ','2012-07-26 14:41:22','RAENELLE.SAMAROO-MAHARAJ','2012-07-26 14:41:22','LIVE',7),(515,'NRT500B-HEAD.OFFICE','NRT500B','HEAD.OFFICE',9.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-08-17 11:54:21','SYSAUTH','2012-08-17 11:54:21','LIVE',8),(515,'NRT500B-HEAD.OFFICE','NRT500B','HEAD.OFFICE',8.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-09-12 12:49:10','SYSAUTH','2012-09-12 12:49:10','LIVE',9),(515,'NRT500B-HEAD.OFFICE','NRT500B','HEAD.OFFICE',7.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-09-26 14:46:25','SYSAUTH','2012-09-26 14:46:25','LIVE',10),(515,'NRT500B-HEAD.OFFICE','NRT500B','HEAD.OFFICE',6.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-09-26 14:46:25','SYSAUTH','2012-09-26 14:46:25','LIVE',11),(515,'NRT500B-HEAD.OFFICE','NRT500B','HEAD.OFFICE',5.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-09-26 14:46:25','SYSAUTH','2012-09-26 14:46:25','HIST',12),(515,'NRT500B-HEAD.OFFICE','NRT500B','HEAD.OFFICE',0.00,0.00,1,'STOCK.CHECK','','RAENELLE.SAMAROO-MAHARAJ','2012-10-04 13:52:34','RAENELLE.SAMAROO-MAHARAJ','2012-10-04 13:52:34','HIST',13),(515,'NRT500B-HEAD.OFFICE','NRT500B','HEAD.OFFICE',3.00,3.00,1,'STOCK.TRANSFER.IN','','RAENELLE.SAMAROO-MAHARAJ','2012-10-04 16:47:27','RAENELLE.SAMAROO-MAHARAJ','2012-10-04 16:47:27','LIVE',14),(515,'NRT500B-HEAD.OFFICE','NRT500B','HEAD.OFFICE',0.00,-3.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-10-04 16:49:53','SYSAUTH','2012-10-04 16:49:53','HIST',15),(515,'NRT500B-HEAD.OFFICE','NRT500B','HEAD.OFFICE',4.00,0.00,1,'STOCK.CHECK','','RAENELLE.SAMAROO-MAHARAJ','2012-10-05 15:01:29','RAENELLE.SAMAROO-MAHARAJ','2012-10-05 15:01:29','LIVE',16),(515,'NRT500B-HEAD.OFFICE','NRT500B','HEAD.OFFICE',0.00,-4.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-10-05 15:03:25','SYSAUTH','2012-10-05 15:03:25','HIST',17),(515,'NRT500B-HEAD.OFFICE','NRT500B','HEAD.OFFICE',0.00,0.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-10-12 11:37:02','RAENELLE.SAMAROO-MAHARAJ','2012-10-12 11:37:02','HIST',18),(515,'NRT500B-HEAD.OFFICE','NRT500B','HEAD.OFFICE',4.00,4.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-10-12 11:37:27','RAENELLE.SAMAROO-MAHARAJ','2012-10-12 11:37:27','HIST',19),(515,'NRT500B-HEAD.OFFICE','NRT500B','HEAD.OFFICE',8.00,0.00,1,'STOCK.CHECK','','RAENELLE.SAMAROO-MAHARAJ','2012-10-16 15:39:14','RAENELLE.SAMAROO-MAHARAJ','2012-10-16 15:39:14','HIST',20),(515,'NRT500B-HEAD.OFFICE','NRT500B','HEAD.OFFICE',7.00,0.00,1,'STOCK.CHECK','','RAENELLE.SAMAROO-MAHARAJ','2012-10-23 17:00:06','RAENELLE.SAMAROO-MAHARAJ','2012-10-23 17:00:06','HIST',21),(515,'NRT500B-HEAD.OFFICE','NRT500B','HEAD.OFFICE',0.00,-7.00,1,'STOCK.NEW.IN','','RAENELLE.SAMAROO-MAHARAJ','2012-10-30 09:21:35','RAENELLE.SAMAROO-MAHARAJ','2012-10-30 09:21:35','HIST',22),(517,'VIPER-HEAD.OFFICE','VIPER','HEAD.OFFICE',4.00,4.00,1,'STOCK.NEW.IN','','DUNSTAN.NESBIT','2012-10-17 16:59:33','DUNSTAN.NESBIT','2012-10-17 16:59:33','LIVE',1),(517,'VIPER-HEAD.OFFICE','VIPER','HEAD.OFFICE',3.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-10-23 09:44:24','SYSAUTH','2012-10-23 09:44:24','LIVE',2),(517,'VIPER-HEAD.OFFICE','VIPER','HEAD.OFFICE',2.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-10-26 10:45:35','SYSAUTH','2012-10-26 10:45:35','LIVE',3),(517,'VIPER-HEAD.OFFICE','VIPER','HEAD.OFFICE',1.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-10-29 11:04:36','SYSAUTH','2012-10-29 11:04:36','HIST',4),(517,'VIPER-HEAD.OFFICE','VIPER','HEAD.OFFICE',0.00,0.00,1,'STOCK.CHECK','','RAENELLE.SAMAROO-MAHARAJ','2012-10-30 09:23:13','RAENELLE.SAMAROO-MAHARAJ','2012-10-30 09:23:13','HIST',5),(517,'VIPER-HEAD.OFFICE','VIPER','HEAD.OFFICE',12.00,12.00,1,'STOCK.NEW.IN','','RAENELLE.SAMAROO-MAHARAJ','2012-11-01 09:05:42','RAENELLE.SAMAROO-MAHARAJ','2012-11-01 09:05:42','HIST',6),(517,'VIPER-HEAD.OFFICE','VIPER','HEAD.OFFICE',11.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-11-01 09:08:28','RAENELLE.SAMAROO-MAHARAJ','2012-11-01 09:08:28','LIVE',7),(517,'VIPER-HEAD.OFFICE','VIPER','HEAD.OFFICE',10.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-11-02 09:45:42','SYSAUTH','2012-11-02 09:45:42','LIVE',8),(517,'VIPER-HEAD.OFFICE','VIPER','HEAD.OFFICE',9.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-11-06 09:49:49','SYSAUTH','2012-11-06 09:49:49','LIVE',9),(517,'VIPER-HEAD.OFFICE','VIPER','HEAD.OFFICE',8.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-11-09 11:28:55','SYSAUTH','2012-11-09 11:28:55','LIVE',10),(517,'VIPER-HEAD.OFFICE','VIPER','HEAD.OFFICE',7.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-11-14 09:31:11','SYSAUTH','2012-11-14 09:31:11','LIVE',11),(517,'VIPER-HEAD.OFFICE','VIPER','HEAD.OFFICE',6.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-11-16 13:12:26','SYSAUTH','2012-11-16 13:12:26','HIST',12),(517,'VIPER-HEAD.OFFICE','VIPER','HEAD.OFFICE',5.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-11-20 15:14:37','RAENELLE.SAMAROO-MAHARAJ','2012-11-20 15:14:38','LIVE',13),(517,'VIPER-HEAD.OFFICE','VIPER','HEAD.OFFICE',4.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-11-22 09:55:18','SYSAUTH','2012-11-22 09:55:18','LIVE',14),(517,'VIPER-HEAD.OFFICE','VIPER','HEAD.OFFICE',3.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-11-23 13:06:24','SYSAUTH','2012-11-23 13:06:24','LIVE',15),(517,'VIPER-HEAD.OFFICE','VIPER','HEAD.OFFICE',2.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-11-29 10:47:24','SYSAUTH','2012-11-29 10:47:24','LIVE',16),(517,'VIPER-HEAD.OFFICE','VIPER','HEAD.OFFICE',1.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-11-29 11:16:39','SYSAUTH','2012-11-29 11:16:39','HIST',17),(517,'VIPER-HEAD.OFFICE','VIPER','HEAD.OFFICE',4.00,0.00,1,'STOCK.CHECK','','RAENELLE.SAMAROO-MAHARAJ','2012-11-30 16:11:34','RAENELLE.SAMAROO-MAHARAJ','2012-11-30 16:11:34','LIVE',18),(517,'VIPER-HEAD.OFFICE','VIPER','HEAD.OFFICE',3.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-12-04 11:33:00','SYSAUTH','2012-12-04 11:33:00','HIST',19),(517,'VIPER-HEAD.OFFICE','VIPER','HEAD.OFFICE',2.00,-1.00,1,'SENT.TO.REPAIR','','RAENELLE.SAMAROO-MAHARAJ','2012-12-04 15:32:11','RAENELLE.SAMAROO-MAHARAJ','2012-12-04 15:32:12','HIST',20),(517,'VIPER-HEAD.OFFICE','VIPER','HEAD.OFFICE',1.00,0.00,1,'STOCK.CHECK','','RAENELLE.SAMAROO-MAHARAJ','2012-12-04 15:36:15','RAENELLE.SAMAROO-MAHARAJ','2012-12-04 15:36:15','LIVE',21),(517,'VIPER-HEAD.OFFICE','VIPER','HEAD.OFFICE',0.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-12-05 13:04:05','SYSAUTH','2012-12-05 13:04:05','HIST',22),(517,'VIPER-HEAD.OFFICE','VIPER','HEAD.OFFICE',8.00,8.00,1,'STOCK.NEW.IN','','RAENELLE.SAMAROO-MAHARAJ','2012-12-07 16:28:52','RAENELLE.SAMAROO-MAHARAJ','2012-12-07 16:28:52','LIVE',23),(517,'VIPER-HEAD.OFFICE','VIPER','HEAD.OFFICE',7.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-12-14 11:23:44','SYSAUTH','2012-12-14 11:23:44','LIVE',24),(517,'VIPER-HEAD.OFFICE','VIPER','HEAD.OFFICE',6.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-12-17 16:38:59','SYSAUTH','2012-12-17 16:38:59','HIST',25),(517,'VIPER-HEAD.OFFICE','VIPER','HEAD.OFFICE',4.00,0.00,1,'STOCK.CHECK','','ADMIN','2012-12-18 15:56:21','ADMIN','2012-12-18 15:56:21','LIVE',26),(517,'VIPER-HEAD.OFFICE','VIPER','HEAD.OFFICE',3.00,-1.00,1,'SALE','','RAENELLE.SAMAROO-MAHARAJ','2012-12-20 13:15:47','SYSAUTH','2012-12-20 13:15:47','LIVE',27),(517,'VIPER-HEAD.OFFICE','VIPER','HEAD.OFFICE',2.00,-1.00,1,'SALE','','AMANDA.OUDAI','2012-12-21 11:24:34','SYSAUTH','2012-12-21 11:24:34','LIVE',28);
/*!40000 ALTER TABLE `inventorys_hs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inventorys_is`
--

DROP TABLE IF EXISTS `inventorys_is`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `inventorys_is` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `inventory_id` varchar(255) DEFAULT NULL,
  `product_id` varchar(50) DEFAULT NULL,
  `branch_id` varchar(50) DEFAULT NULL,
  `qty_instock` float(16,2) unsigned DEFAULT '0.00',
  `qty_diff` float(16,2) DEFAULT '0.00',
  `reorder_level` int(11) unsigned DEFAULT '1',
  `last_update_type` varchar(50) DEFAULT NULL,
  `comments` text,
  `inputter` varchar(50) DEFAULT NULL,
  `input_date` datetime DEFAULT NULL,
  `authorizer` varchar(50) DEFAULT NULL,
  `auth_date` datetime DEFAULT NULL,
  `record_status` char(4) DEFAULT NULL,
  `current_no` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_product_id` (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventorys_is`
--

LOCK TABLES `inventorys_is` WRITE;
/*!40000 ALTER TABLE `inventorys_is` DISABLE KEYS */;
/*!40000 ALTER TABLE `inventorys_is` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inventupdtypes`
--

DROP TABLE IF EXISTS `inventupdtypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `inventupdtypes` (
  `id` int(11) unsigned NOT NULL,
  `update_type_id` varchar(50) NOT NULL,
  `description` varchar(255) NOT NULL,
  `stock_movement` varchar(20) NOT NULL,
  `comments` text,
  `inputter` varchar(50) NOT NULL,
  `input_date` datetime NOT NULL,
  `authorizer` varchar(50) NOT NULL,
  `auth_date` datetime NOT NULL,
  `record_status` char(4) NOT NULL,
  `current_no` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_update_type_id` (`update_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventupdtypes`
--

LOCK TABLES `inventupdtypes` WRITE;
/*!40000 ALTER TABLE `inventupdtypes` DISABLE KEYS */;
INSERT INTO `inventupdtypes` VALUES (1,'STOCK.CHECK','Stock Check, Inventory Reset','STOCK.RESET','','IMPLEMENTATION','2011-11-17 00:00:00','ADMIN','2011-11-17 00:00:00','LIVE',1),(2,'STOCK.NEW.IN','New Stock In','STOCK.IN','','IMPLEMENTATION','2011-11-17 00:00:00','ADMIN','2011-11-17 00:00:00','LIVE',1),(3,'STOCK.TRANSFER.IN','Stock Transfer In','STOCK.IN','','IMPLEMENTATION','2011-11-17 00:00:00','ADMIN','2011-11-17 00:00:00','LIVE',1),(4,'STOCK.TRANSFER.OUT','Stock Transfer Out','STOCK.OUT','','IMPLEMENTATION','2011-11-17 00:00:00','ADMIN','2011-11-17 00:00:00','LIVE',1),(5,'SALE','Stock Sale','STOCK.OUT','','IMPLEMENTATION','2011-11-17 00:00:00','ADMIN','2011-11-17 00:00:00','LIVE',1),(6,'LOAN','Loan Item','STOCK.OUT','','IMPLEMENTATION','2011-11-17 00:00:00','ADMIN','2011-11-17 00:00:00','LIVE',1),(7,'LOAN.RETURN','Loan Item Returned','STOCK.IN','','IMPLEMENTATION','2011-11-17 00:00:00','ADMIN','2011-11-17 00:00:00','LIVE',1),(8,'SENT.TO.REPAIR','Item Sent To Be Repair','STOCK.OUT','','IMPLEMENTATION','2011-11-17 00:00:00','ADMIN','2011-11-17 00:00:00','LIVE',1),(9,'CUSTOMER.RETURN','Customer Returns Sold Item','STOCK.IN','','IMPLEMENTATION','2011-11-17 00:00:00','ADMIN','2011-11-17 00:00:00','LIVE',1),(10,'CUSTOMER.REPLACEMENT','Exchange/Replace Item, Possibly Defective','STOCK.OUT','','IMPLEMENTATION','2011-11-17 00:00:00','ADMIN','2011-11-17 00:00:00','LIVE',1),(11,'ORDER.CANCEL.RETURN','Cancelled Order Item Returned','STOCK.IN','','IMPLEMENTATION','2013-03-18 10:31:25','ADMIN','2013-03-18 10:31:52','LIVE',1);
/*!40000 ALTER TABLE `inventupdtypes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inventupdtypes_hs`
--

DROP TABLE IF EXISTS `inventupdtypes_hs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `inventupdtypes_hs` (
  `id` int(11) unsigned NOT NULL,
  `update_type_id` varchar(50) NOT NULL,
  `description` varchar(255) NOT NULL,
  `stock_movement` varchar(20) NOT NULL,
  `comments` text,
  `inputter` varchar(50) NOT NULL,
  `input_date` datetime NOT NULL,
  `authorizer` varchar(50) NOT NULL,
  `auth_date` datetime NOT NULL,
  `record_status` char(4) NOT NULL,
  `current_no` int(11) NOT NULL,
  PRIMARY KEY (`id`,`current_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventupdtypes_hs`
--

LOCK TABLES `inventupdtypes_hs` WRITE;
/*!40000 ALTER TABLE `inventupdtypes_hs` DISABLE KEYS */;
/*!40000 ALTER TABLE `inventupdtypes_hs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inventupdtypes_is`
--

DROP TABLE IF EXISTS `inventupdtypes_is`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `inventupdtypes_is` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `update_type_id` varchar(50) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `stock_movement` varchar(20) DEFAULT NULL,
  `comments` text,
  `inputter` varchar(50) DEFAULT NULL,
  `input_date` datetime DEFAULT NULL,
  `authorizer` varchar(50) DEFAULT NULL,
  `auth_date` datetime DEFAULT NULL,
  `record_status` char(4) DEFAULT NULL,
  `current_no` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_update_type_id` (`update_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventupdtypes_is`
--

LOCK TABLES `inventupdtypes_is` WRITE;
/*!40000 ALTER TABLE `inventupdtypes_is` DISABLE KEYS */;
/*!40000 ALTER TABLE `inventupdtypes_is` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `menudefs`
--

DROP TABLE IF EXISTS `menudefs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `menudefs` (
  `id` int(11) unsigned NOT NULL,
  `menu_id` int(11) unsigned NOT NULL,
  `parent_id` int(11) unsigned DEFAULT NULL,
  `sortpos` float(16,5) DEFAULT NULL,
  `nleft` int(11) DEFAULT NULL,
  `nright` int(11) DEFAULT NULL,
  `nlevel` int(11) DEFAULT NULL,
  `node_or_leaf` enum('L','N') DEFAULT NULL,
  `module` varchar(50) DEFAULT NULL,
  `label_input` varchar(255) DEFAULT NULL,
  `label_enquiry` varchar(255) DEFAULT NULL,
  `url_input` varchar(255) DEFAULT NULL,
  `url_enquiry` varchar(255) DEFAULT NULL,
  `controls_input` varchar(255) DEFAULT NULL,
  `controls_enquiry` varchar(255) DEFAULT NULL,
  `inputter` varchar(50) DEFAULT NULL,
  `input_date` datetime DEFAULT NULL,
  `authorizer` varchar(50) DEFAULT NULL,
  `auth_date` datetime DEFAULT NULL,
  `record_status` char(4) DEFAULT NULL,
  `current_no` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_menu_id` (`menu_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `menudefs`
--

LOCK TABLES `menudefs` WRITE;
/*!40000 ALTER TABLE `menudefs` DISABLE KEYS */;
INSERT INTO `menudefs` VALUES (1,10,0,0.10000,1,16,1,'N','useraccount','My Account',NULL,NULL,NULL,NULL,NULL,'IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(2,15,0,0.15000,17,30,1,'N','useradmin','User Administration',NULL,NULL,NULL,NULL,NULL,'IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(3,20,0,0.20000,31,68,1,'N','sysadmin','System Administration','',NULL,NULL,NULL,NULL,'IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(4,25,0,0.25000,69,104,1,'N','developer','Developer','',NULL,NULL,NULL,NULL,'IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(5,1000,10,10.00000,2,11,2,'N','useraccount','Messages','','','','','','IMPLEMENTATION','2011-04-25 16:04:29','ADMIN','2011-04-25 16:26:09','LIVE',1),(6,1001,10,10.01000,12,15,2,'N','useraccount','User','','','','','','IMPLEMENTATION','2011-04-25 16:04:29','ADMIN','2011-04-25 16:26:16','LIVE',1),(10,1500,15,15.00000,18,25,2,'N','useradmin','Users','',NULL,NULL,NULL,NULL,'IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(11,1501,15,15.01000,26,29,2,'N','useradmin','Roles','',NULL,NULL,NULL,NULL,'IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(12,2000,20,20.00000,32,39,2,'N','sysadmin','System Configurations','','','','','','IMPLEMENTATION','2011-04-27 14:04:34','ADMIN','2011-04-27 14:05:42','LIVE',1),(13,2001,20,20.01000,40,45,2,'N','sysadmin','Countries & Regions','','','','','','IMPLEMENTATION','2011-04-27 13:04:32','ADMIN','2011-04-27 13:36:38','LIVE',1),(15,2500,25,25.00000,70,85,2,'N','developer','Definition','','','','','','IMPLEMENTATION','2011-05-08 14:05:33','ADMIN','2011-05-08 14:48:31','LIVE',1),(17,2501,25,25.01000,86,89,2,'N','developer','Enquiry Administration','','','','','','IMPLEMENTATION','2011-05-08 14:05:55','ADMIN','2011-05-08 14:48:46','LIVE',1),(19,2502,25,25.02000,90,97,2,'N','developer','Report Administration','','','','','','IMPLEMENTATION','2011-05-08 14:05:55','ADMIN','2011-05-08 14:48:55','LIVE',1),(23,150050,1500,1500.50000,19,20,3,'L','useradmin','User','magicon016.png%IMG%','core_useradmin_useradmin','core_useradmin_useradmin/enquirydefault','if,vw,nw,cp,in,ao,as,rj,hd,va','ls,is,hs,ex','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(24,150051,1500,1500.51001,21,22,3,'L','useradmin','User Password Reset','','core_useradmin_userpasswdreset','','if,vw,iw,in,ao,as,rj,hd,va','','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(25,150052,1500,1500.52002,23,24,3,'L','useradmin','User Roles','magicon016.png%IMG%','core_useradmin_userrole','core_useradmin_userrole/enquirydefault','if,vw,nw,cp,in,ao,as,rj,hd,va','ls,is,hs,ex','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(28,150150,1501,1501.50000,27,28,3,'L','useradmin','Role','magicon016.png%IMG%','core_useradmin_roleadmin','core_useradmin_roleadmin/enquirydefault','if,vw,nw,cp,in,ao,as,rj,hd,va','ls,is,hs,ex','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(30,2002,20,20.02000,46,53,2,'N','sysadmin','Dates & Times','','','','','','IMPLEMENTATION','2011-04-27 13:04:32','ADMIN','2011-04-27 13:36:51','LIVE',1),(31,2003,20,20.03000,54,59,2,'N','sysadmin','End Of Day','','','','','','IMPLEMENTATION','2011-04-27 13:04:32','ADMIN','2011-04-27 13:37:09','LIVE',1),(32,2004,20,20.04000,60,67,2,'N','sysadmin','System Maintenance','','','','','','IMPLEMENTATION','2011-04-27 13:04:32','ADMIN','2011-04-27 13:37:14','LIVE',1),(33,200050,2000,2000.50000,33,34,3,'L','sysadmin','System Configuration ','magicon016.png%IMG%','core_sysadmin_sysconfig','core_sysadmin_sysconfig/enquirydefault','if,vw,nw,cp,in,ao,as,rj,hd,va','ls,is,hs,ex','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(34,200051,2000,2000.51001,35,36,3,'L','sysadmin','Branch','magicon016.png%IMG%','core_sysadmin_branch','core_sysadmin_branch/enquirydefault','if,vw,nw,cp,in,ao,as,rj,hd,va','ls,is,hs,ex','IMPLEMENTATION','2011-04-27 13:04:32','ADMIN','2011-04-27 13:37:20','LIVE',1),(35,200052,2000,2000.52002,37,38,3,'L','sysadmin','Department','magicon016.png%IMG%','core_sysadmin_department','core_sysadmin_department/enquirydefault','if,vw,nw,cp,in,ao,as,rj,hd,va','ls,is,hs,ex','IMPLEMENTATION','2011-04-27 13:04:32','ADMIN','2011-04-27 13:39:51','LIVE',1),(36,100050,1000,1000.50000,3,4,3,'L','useraccount','Message','magicon016.png%IMG%','core_useraccount_message','core_useraccount_message/enquirydefault','vw,nw,cp,iw,as,rj,hd','ls,is,ex','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(37,100051,1000,1000.51001,5,6,3,'L','useraccount',' ','Inbox','','core_useraccount_message/inbox','df,ls,is,hs,ex',NULL,'IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(38,100052,1000,1000.52002,7,8,3,'L','useraccount',' ','Drafts','','core_useraccount_message/drafts','df,ls,is,hs,ex',NULL,'IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(39,100053,1000,1000.53003,9,10,3,'L','useraccount',' ','Sent','','core_useraccount_message/sent','df,ls,is,hs,ex',NULL,'IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(40,100150,1001,1001.50000,13,14,3,'L','useraccount','Change Password','magicon016.png%IMG%','core_useraccount_userchangepassword','core_useraccount_userchangepassword/enquirydefault','vw,in,as,rj,va','ls,is','IMPLEMENTATION','2011-04-25 16:04:29','ADMIN','2011-04-25 16:26:29','LIVE',1),(41,200150,2001,2001.50000,41,42,3,'L','sysadmin','Country','magicon016.png%IMG%','core_sysadmin_country','core_sysadmin_country/enquirydefault','if,vw,nw,cp,in,ao,as,rj,hd,va','ls,is,hs,ex','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(42,200151,2001,2001.51001,43,44,3,'L','sysadmin','Region','magicon016.png%IMG%','core_sysadmin_region','core_sysadmin_region/enquirydefault','if,vw,nw,cp,in,ao,as,rj,hd,va','ls,is,hs,ex','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(43,200250,2002,2002.53003,47,48,3,'L','sysadmin','Weekday','magicon016.png%IMG%','core_sysadmin_weekday','core_sysadmin_weekday/enquirydefault','if,vw,nw,cp,in,ao,as,rj,hd,va','ls,is,hs,ex','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(44,200251,2002,2002.54004,49,50,3,'L','sysadmin','Daytime','magicon016.png%IMG%','core_sysadmin_daytime','core_sysadmin_daytime/enquirydefault','if,vw,nw,cp,in,ao,as,rj,hd,va','ls,is,hs,ex','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(45,200253,2002,2002.55005,51,52,3,'L','sysadmin','Recurrence','magicon016.png%IMG%','core_sysadmin_recurrence','core_sysadmin_recurrence/enquirydefault','if,vw,nw,cp,in,ao,as,rj,hd,va','ls,is,hs,ex','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(46,200350,2003,2003.50000,55,56,3,'L','sysadmin','EOD Configuration','magicon016.png%IMG%','core_sysadmin_endofday','core_sysadmin_endofday/enquirydefault','if,vw,nw,cp,in,ao,as,rj,hd,va','ls,is,hs,ex','IMPLEMENTATION','2011-04-27 13:04:32','ADMIN','2011-04-27 13:37:58','LIVE',1),(47,200351,2003,2003.51001,57,58,3,'L','sysadmin','Run EOD','magicon016.png%IMG%','core_sysadmin_runeod','core_sysadmin_runeod/enquirydefault','if,vw,nw,cp,in,ao,as,rj,hd,va','ls,is,hs,ex','IMPLEMENTATION','2011-04-27 13:04:32','ADMIN','2011-04-27 13:37:50','LIVE',1),(48,200450,2004,2004.51001,61,62,3,'L','sysadmin','Record Lock','magicon016.png%IMG%','core_sysadmin_recordlock','core_sysadmin_recordlock/enquirydefault','if,vw,de','ls','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(49,250050,2500,2500.50000,71,72,3,'L','developer','Param Definition','magicon016.png%IMG%','core_developer_param','core_developer_param/enquirydefault','if,vw,nw,cp,in,ao,as,rj,hd,va','ls,is,hs,ex','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(50,250051,2500,2500.51001,73,74,3,'L','developer','Form Definition','magicon016.png%IMG%','core_developer_formdef','core_developer_formdef/enquirydefault','if,vw,in,ao,as,rj,hd,va','ls,is,hs,ex','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(51,200451,2004,2004.51001,63,64,3,'L','sysadmin','PDF','magicon016.png%IMG%','core_sysadmin_pdf','core_sysadmin_pdf/enquirydefault','if,vw,in,ao,as,rj,hd,va','ls,is,hs,ex','IMPLEMENTATION','2011-05-03 20:05:00','ADMIN','2011-05-03 21:57:50','LIVE',1),(52,200452,2004,2004.52002,65,66,3,'L','sysadmin','CSV','magicon016.png%IMG%','core_sysadmin_csv','core_sysadmin_csv/enquirydefault','if,vw,in,ao,as,rj,hd,va','ls,is,hs,ex','IMPLEMENTATION','2011-05-04 20:05:06','ADMIN','2011-05-04 20:48:04','LIVE',1),(53,250052,2500,2500.52002,75,76,3,'L','developer','Menu Definition','magicon016.png%IMG%','core_developer_menudef','core_developer_menudef/enquirydefault','if,vw,nw,cp,in,ao,as,rj,hd,va','ls,is,hs,ex','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(54,250053,2500,2500.53003,77,78,3,'L','developer','Enquiry Definition','magicon016.png%IMG%','core_developer_enqdef','core_developer_enqdef/enquirydefault','if,vw,nw,cp,in,ao,as,rj,hd,va','ls,is,hs,ex','IMPLEMENTATION','2011-04-28 02:04:07','ADMIN','2011-04-28 02:53:55','LIVE',1),(55,250054,2500,2500.54004,79,80,3,'L','developer','Report Definition','magicon016.png%IMG%','core_developer_reportdef','core_developer_reportdef/enquirydefault','if,vw,nw,cp,in,ao,as,rj,hd,va','ls,is,hs,ex','IMPLEMENTATION','2011-04-28 02:04:07','ADMIN','2011-04-28 02:54:02','LIVE',1),(56,250055,2501,2501.50000,87,88,3,'L','developer','Fixed Selection','magicon016.png%IMG%','core_developer_fixedselection','core_developer_fixedselection/enquirydefault','if,vw,nw,cp,in,ao,as,rj,hd,va','ls,is,hs,ex','IMPLEMENTATION','2011-05-05 19:05:22','ADMIN','2011-05-05 19:52:42','LIVE',1),(57,250250,2502,2502.50000,91,92,3,'L','developer','Run Report Refresh','magicon016.png%IMG%','core_developer_runreportrefresh','core_developer_runreportrefresh/enquirydefault','if,vw,nw,cp,in,ao,as,rj,hd,va','ls,is,hs,ex','IMPLEMENTATION','2011-05-08 14:05:55','ADMIN','2011-05-08 14:49:09','LIVE',1),(58,250251,2502,2502.51001,93,94,3,'L','developer','Report Refresh Configuration','magicon016.png%IMG%','core_developer_reportrefreshconfig','core_developer_reportrefreshconfig/enquirydefault','if,vw,nw,cp,in,ao,as,rj,hd,va','ls,is,hs,ex','IMPLEMENTATION','2011-05-08 14:05:55','ADMIN','2011-05-08 14:49:23','LIVE',1),(59,2503,25,25.03000,98,103,2,'N','developer','Table Administration','','','','','','IMPLEMENTATION','2011-05-08 14:05:55','ADMIN','2011-05-08 14:49:37','LIVE',1),(60,250350,2503,2503.50000,99,100,3,'L','developer','Run Table Reset','magicon016.png%IMG%','core_developer_tableresetrun','core_developer_tableresetrun/enquirydefault','if,vw,nw,cp,in,ao,as,rj,hd,va','ls,is,hs,ex','IMPLEMENTATION','2011-05-08 14:05:55','ADMIN','2011-05-08 14:49:47','LIVE',1),(61,250351,2503,2503.51001,101,102,3,'L','developer','Table Reset Configuration','magicon016.png%IMG%','core_developer_tableresetconfig','core_developer_tableresetconfig/enquirydefault','if,vw,nw,cp,in,ao,as,rj,hd,va','ls,is,hs,ex','IMPLEMENTATION','2011-05-08 14:05:55','ADMIN','2011-05-08 14:49:57','LIVE',1),(62,250056,2500,2500.55005,81,82,3,'L','developer','PDF Template','magicon016.png%IMG%','core_developer_pdftemplate','core_developer_pdftemplate/enquirydefault','if,vw,nw,cp,in,ao,as,rj,hd,va','ls,is,hs,ex','IMPLEMENTATION','2011-05-05 19:05:22','ADMIN','2011-05-05 19:52:42','LIVE',1),(63,250057,2500,2500.57007,83,84,3,'L','developer','Auto Definitions','','core_developer_autodef','','vw','','IMPLEMENTATION','2013-02-13 19:02:48','ADMIN','2013-02-13 19:23:28','LIVE',1),(401,5010,0,50.10000,105,110,1,'N','customer','Customers','','','','','','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(402,501050,5010,5010.50000,106,107,2,'L','customer','Customer','magicon016.png%IMG%','core_customer_customer','core_customer_customer/enquirydefault','if,vw,nw,cp,in,ao,as,rj,hd,va','ls,is,hs,ex','IMPLEMENTATION','2011-04-18 03:04:15','ADMIN','2011-04-18 03:07:37','LIVE',1),(403,5040,0,50.40000,123,162,1,'N','sales','Sales','','','','','','IMPLEMENTATION','2011-04-17 20:04:23','ADMIN','2011-04-17 21:01:27','LIVE',1),(404,504000,5040,5040.00000,124,133,2,'N','sales','Products','','','','','','IMPLEMENTATION','2011-08-29 17:08:53','ADMIN','2011-08-29 17:26:09','LIVE',1),(405,504001,5040,5040.00977,134,145,2,'N','sales','Orders & Payments','','','','','','IMPLEMENTATION','2011-08-29 17:08:53','ADMIN','2011-08-29 17:26:41','LIVE',1),(406,50400050,504000,504000.50000,125,126,3,'L','sales','Product','magicon016.png%IMG%','core_sales_product','core_sales_product/enquirydefault','if,vw,nw,cp,in,ao,as,rj,hd,va','ls,is,hs,ex','IMPLEMENTATION','2011-08-29 17:08:53','ADMIN','2011-08-29 17:26:19','LIVE',1),(407,50400051,504000,504000.50000,127,128,3,'L','sales','Inventory','magicon016.png%IMG%','core_sales_inventory','core_sales_inventory/enquirydefault','if,vw,nw,cp,in,ao,as,rj,hd,va','ls,is,hs,ex','IMPLEMENTATION','2011-08-29 17:08:53','ADMIN','2011-08-29 17:26:31','LIVE',1),(408,50400052,504000,504000.53125,129,130,3,'L','sales','Inventory Update Type','magicon016.png%IMG%','core_sales_inventupdtype','core_sales_inventupdtype/enquirydefault','if,vw,nw,cp,in,ao,as,rj,hd,va','ls,is,hs,ex','IMPLEMENTATION','2011-11-18 07:11:51','ADMIN','2011-11-18 07:49:38','LIVE',1),(409,50400150,504001,504001.50000,135,136,3,'L','sales','Estimator','','core_sales_estimator','','vw,nw','','IMPLEMENTATION','2012-01-10 21:01:54','ADMIN','2012-01-10 21:18:23','LIVE',1),(410,50400151,504001,504001.50000,137,138,3,'L','sales','Order','magicon016.png%IMG%','core_sales_order','core_sales_order/enquirydefault','if,vw,nw,cp,in,ao,as,rj,hd,va','ls,is,hs,ex','IMPLEMENTATION','2011-08-29 17:08:53','ADMIN','2011-08-29 17:26:51','LIVE',1),(411,50400152,504001,504001.53125,139,140,3,'L','sales','Payment','magicon016.png%IMG%','core_sales_payment','core_sales_payment/enquirydefault','if,vw,nw,in,ao,as,rj,hd,va','ls,is,hs,ex','IMPLEMENTATION','2011-08-29 17:08:53','ADMIN','2011-08-29 17:27:02','LIVE',1),(412,50400153,504001,504001.53125,141,142,3,'L','sales','Inventory Checkout','magicon016.png%IMG%','core_sales_inventchkout','core_sales_inventchkout/enquirydefault','if,vw,in,ao,as,rj,hd,va','ls,is,hs,ex','IMPLEMENTATION','2012-01-10 20:01:47','ADMIN','2012-01-10 21:00:31','LIVE',1),(413,50400154,504001,504001.53125,143,144,3,'L','sales','Delivery Note','magicon016.png%IMG%','core_sales_deliverynote','core_sales_deliverynote/enquirydefault','if,vw,in,ao,as,rj,hd,va','ls,is,hs,ex','IMPLEMENTATION','2012-01-13 00:00:00','ADMIN','2012-01-12 00:00:00','LIVE',1),(414,504002,5040,5040.02002,146,153,2,'N','sales','Tills','','','','','','IMPLEMENTATION','2012-05-02 14:05:37','ADMIN','2012-05-02 14:24:32','LIVE',1),(415,50400250,504002,504002.50000,147,148,3,'L','sales','User Till','magicon016.png%IMG%','core_sales_tilluser','core_sales_tilluser/enquirydefault','if,vw,nw,in,ao,as,rj,hd,va','ls,is,hs,ex','IMPLEMENTATION','2012-05-02 14:05:37','ADMIN','2012-05-02 14:24:51','LIVE',1),(416,50400251,504002,504002.50000,149,150,3,'L','sales','Manage Till','magicon016.png%IMG%','core_sales_tillmanage','core_sales_tillmanage/enquirydefault','if,vw,nw,in,ao,as,rj,hd,va','ls,is,hs,ex','IMPLEMENTATION','2012-05-02 14:05:37','ADMIN','2012-05-02 14:24:58','LIVE',1),(417,50400252,504002,504002.53125,151,152,3,'L','sales','Till Transaction','magicon016.png%IMG%','core_sales_tilltransaction','core_sales_tilltransaction/enquirydefault','if,vw,nw,in,ao,as,rj,hd,va','ls,is,hs,ex','IMPLEMENTATION','2012-05-02 14:05:37','ADMIN','2012-05-02 14:25:08','LIVE',1),(418,504003,5040,5040.02979,154,161,2,'N','sales','Sales Admin','','','','','','IMPLEMENTATION','2012-12-23 17:12:29','ADMIN','2012-12-23 17:39:51','LIVE',1),(419,5100,0,51.00000,173,192,1,'N','report','Reports','','','','','','IMPLEMENTATION','2011-04-17 20:04:23','ADMIN','2011-04-17 21:01:45','LIVE',1),(420,50200150,502001,502001.50000,115,116,3,'L','businessadmin','Batch Invoices','magicon016.png%IMG%','core_businessadmin_batchinvoice','core_businessadmin_batchinvoice/enquirydefault','if,vw,nw,in,ao,as,rj,hd,va','ls,is,hs,ex','IMPLEMENTATION','2012-07-25 00:03:42','ADMIN','2012-07-25 00:04:26','LIVE',1),(421,51000055,510000,510000.56250,187,188,3,'L','report','Batch Invoices','','core_report_batchinvoices','','vw,pr','','ADMIN','2012-07-25 00:55:30','ADMIN','2012-07-25 00:58:29','LIVE',1),(422,50400350,504003,504003.50000,155,156,3,'L','sales','Order Cancel','magicon016.png%IMG%','core_sales_ordercancel','core_sales_ordercancel/enquirydefault','if,vw,nw,iw,ao,as,rj,hd,va','ls,is,hs,ex','IMPLEMENTATION','2012-12-23 17:12:29','ADMIN','2012-12-23 17:40:22','LIVE',1),(423,50400351,504003,504003.50000,157,158,3,'L','sales','Payment Cancel','magicon016.png%IMG%','core_sales_paymentcancel','core_sales_paymentcancel/enquirydefault','if,vw,nw,iw,ao,as,rj,hd,va','ls,is,hs,ex','IMPLEMENTATION','2012-12-23 17:12:29','ADMIN','2012-12-23 17:40:39','LIVE',1),(424,50400352,504003,504003.53125,159,160,3,'L','sales','Order Re-Open','magicon016.png%IMG%','core_sales_orderopen','core_sales_orderopen/enquirydefault','if,vw,nw,iw,ao,as,rj,hd,va','ls,is,hs,ex','IMPLEMENTATION','2012-12-23 17:12:29','ADMIN','2012-12-23 17:42:00','LIVE',1),(425,250252,2502,2502.52002,95,96,3,'L','developer','Jasper Compile','magicon016.png%IMG%','core_developer_jaspercompile','core_developer_jaspercompile/enquirydefault','if,vw,nw,cp,in,ao,as,rj,hd,va','ls,is,hs,ex','IMPLEMENTATION','2012-12-26 02:12:01','ADMIN','2012-12-26 02:35:23','LIVE',1),(426,501051,5010,5010.50977,108,109,2,'L','customer','Charge Account','magicon016.png%IMG%','core_customer_chargeaccount','core_customer_chargeaccount/enquirydefault','if,vw,nw,cp,in,ao,as,rj,hd,va','ls,is,hs,ex','IMPLEMENTATION','2013-02-18 03:02:37','ADMIN','2013-02-18 03:45:22','LIVE',1),(427,50400053,504000,504000.53125,131,132,3,'L','sales','Inventory Sale Log','magicon016.png%IMG%','core_sales_inventorysalelog','core_sales_inventorysalelog/enquirydefault','if,vw','ls,is,ex','IMPLEMENTATION','2013-02-25 13:02:43','ADMIN','2013-02-25 13:50:50','LIVE',1),(428,50200151,502001,502001.50000,117,118,3,'L','businessadmin','Charge Invoices (Monthly)','magicon016.png%IMG%','core_businessadmin_bicrmonthly','core_businessadmin_bicrmonthly/enquirydefault','if,vw,nw,in,ao,as,rj,hd,va','ls,is,hs,ex','IMPLEMENTATION','2013-03-29 14:03:49','ADMIN','2013-03-29 14:42:26','LIVE',1),(429,50200152,502001,502001.53125,119,120,3,'L','businessadmin','Charge Invoices (Period)','magicon016.png%IMG%','core_businessadmin_bicrperiod','core_businessadmin_bicrperiod/enquirydefault','if,vw,nw,in,ao,as,rj,hd,va','ls,is,hs,ex','IMPLEMENTATION','2013-03-29 14:03:49','ADMIN','2013-03-29 14:42:39','LIVE',1),(509,5090,0,50.90000,163,172,1,'N','enquiry','Enquiries','','','','','','IMPLEMENTATION','2011-04-17 20:04:23','ADMIN','2011-04-17 21:01:37','LIVE',1),(515,509000,5090,5090.00000,164,165,2,'N','enquiry','Customer','','','','','','IMPLEMENTATION','2011-04-19 15:04:51','ADMIN','2011-04-19 15:33:04','LIVE',1),(517,5020,0,50.20000,111,122,1,'N','businessadmin','Business Administration','','','','','','IMPLEMENTATION','2011-04-29 15:04:44','ADMIN','2011-04-29 15:19:15','LIVE',1),(518,502000,5020,5020.00000,112,113,2,'N','businessadmin','Support Services','','','','','','IMPLEMENTATION','2011-04-29 15:04:44','ADMIN','2011-04-29 15:19:20','LIVE',1),(530,509001,5090,5090.00977,166,171,2,'N','enquiry','Sales','','','','','','IMPLEMENTATION','2012-06-16 23:06:19','ADMIN','2012-06-16 23:58:07','LIVE',1),(531,50900150,509001,509001.50000,167,168,3,'L','enquiry','Orders','magicon016.png%IMG%','core_enquiry_orders','core_enquiry_orders/enquirycustom','vw,pr','df,ex','IMPLEMENTATION','2012-06-16 23:06:19','ADMIN','2012-06-16 23:58:21','LIVE',1),(532,50900151,509001,509001.50000,169,170,3,'L','enquiry','Delivery Notes','magicon016.png%IMG%','core_enquiry_deliverynotes','core_enquiry_deliverynotes/enquirycustom','vw,pr','df,ex','IMPLEMENTATION','2012-06-16 23:06:19','ADMIN','2012-06-16 23:58:34','LIVE',1),(534,510000,5100,5100.00000,174,189,2,'N','report','Standard','','','','','','IMPLEMENTATION','2012-07-22 20:07:36','ADMIN','2012-07-22 20:46:45','LIVE',1),(535,51000050,510000,510000.50000,175,176,3,'L','report','Sales','','core_report_sales','','vw,pr','','IMPLEMENTATION','2012-07-22 20:07:36','ADMIN','2012-07-22 20:47:01','LIVE',1),(536,51000051,510000,510000.50000,177,178,3,'L','report','Outstanding Balances','','core_report_receivables','','vw,pr','','IMPLEMENTATION','2012-07-22 20:07:36','ADMIN','2012-07-22 20:47:12','LIVE',1),(537,51000052,510000,510000.53125,181,182,3,'L','report','Stock Reorder','','core_report_stockreorder','','vw,pr','','IMPLEMENTATION','2012-07-22 20:07:36','ADMIN','2012-07-22 20:47:25','LIVE',1),(538,51000053,510000,510000.53125,183,184,3,'L','report','Till','','core_report_till','','vw,pr','','IMPLEMENTATION','2012-07-22 20:07:36','ADMIN','2012-07-22 20:47:38','LIVE',1),(539,51000054,510000,510000.53125,185,186,3,'L','report','Checkout Status','','core_report_chkoutstatus','','vw,pr','','IMPLEMENTATION','2012-07-22 20:07:36','ADMIN','2012-07-22 20:47:52','LIVE',1),(540,51000056,510000,510000.50000,179,180,3,'L','report','Quotations','','core_report_quotations','core_report_quotations/enquirydefault','vw,pr','','IMPLEMENTATION','2012-12-18 15:12:52','ADMIN','2012-12-18 15:31:11','LIVE',1),(601,502001,5020,5020.00977,114,121,2,'N','businessadmin','Batches','','','','','','IMPLEMENTATION','2012-07-21 20:07:36','ADMIN','2012-07-21 20:16:48','LIVE',1),(603,510001,5100,5100.00977,190,191,2,'N','report','Custom','','','','','','IMPLEMENTATION','2012-07-22 20:07:36','ADMIN','2012-07-22 20:48:03','LIVE',1),(1000,6000,0,60.00000,193,246,1,'N','hndshkif','Handshake Interface','','','','','','IMPLEMENTATION','2013-09-10 06:09:27','ADMIN','2013-09-10 06:35:22','LIVE',1),(1010,600000,6000,6000.00000,194,199,2,'N','hndshkif','Notifications','','','','','','IMPLEMENTATION','2013-09-10 06:09:27','ADMIN','2013-09-10 06:35:31','LIVE',1),(1011,60000050,600000,600000.50000,195,196,3,'L','hndshkif','Summary','magicon016.png%IMG%','hndshkif_notifications_summary','hndshkif_notifications_summary/enquirydefault','if,vw,nw,cp,in,ao,as,rj,hd,va','ls,is,hs,ex','IMPLEMENTATION','2013-09-10 06:09:27','ADMIN','2013-09-10 06:35:39','LIVE',1),(1012,60000051,600000,600000.50000,197,198,3,'L','hndshkif','Errors','magicon016.png%IMG%','hndshkif_notifications_summary','hndshkif_notifications_summary/enquirydefault','if,vw,nw,cp,in,ao,as,rj,hd,va','ls,is,hs,ex','IMPLEMENTATION','2013-09-10 06:09:27','ADMIN','2013-09-10 06:35:50','LIVE',1),(1020,600001,6000,6000.00977,200,213,2,'N','hndshkif','Orders','','','','','','IMPLEMENTATION','2013-09-10 06:09:27','ADMIN','2013-09-10 06:35:59','LIVE',1),(1021,60000150,600001,600001.50000,203,204,3,'L','hndshkif','Downloaded Orders','magicon016.png%IMG%','hndshkif_orders_dlorder','hndshkif_orders_dlorder/enquirydefault','if,vw','ls,ex','IMPLEMENTATION','2013-09-10 06:09:27','ADMIN','2013-09-10 06:36:08','LIVE',1),(1022,60000151,600001,600001.50000,205,206,3,'L','hndshkif','Downloaded Order Batches','magicon016.png%IMG%','hndshkif_orders_dlorderbatch','hndshkif_orders_dlorderbatch/enquirydefault','if,vw,nw,cp,in,ao,as,rj,hd,va','ls,is,hs,ex','IMPLEMENTATION','2013-09-10 06:09:27','ADMIN','2013-09-10 06:36:26','LIVE',1),(1023,60000152,600001,600001.50000,207,208,3,'L','hndshkif','Downloaded Orders Report','magicon016.png%IMG%','hndshkif_orders_dlorderreport','hndshkif_orders_dlorderreport/enquirydefault','if,vw,nw,cp,in,ao,as,rj,hd,va','ls,is,hs,ex','IMPLEMENTATION','2013-09-10 06:09:27','ADMIN','2013-09-10 06:36:39','LIVE',1),(1024,60000153,600001,600001.50000,201,202,3,'L','hndshkif','Last Download Report','magicon016.png%IMG%','hndshkif_orders_dlorderlastreport','hndshkif_orders_dlorderlastreport/enquirydefault','if,vw,nw,cp,in,ao,as,rj,hd,va','ls,is,hs,ex','IMPLEMENTATION','2013-09-10 06:09:27','ADMIN','2013-09-10 06:36:46','LIVE',1),(1025,60000154,600001,600001.56250,209,210,3,'L','hndshkif','Get Handshake Orders','magicon016.png%IMG%','hndshkif_orders_gethandshakeorders','hndshkif_orders_gethandshakeorders/enquirydefault','if,vw,in,ao,as,rj,hd,va','ls,is,hs,ex','IMPLEMENTATION','2013-09-10 06:09:27','ADMIN','2013-09-10 06:36:54','LIVE',1),(1026,60000155,600001,600001.56250,211,212,3,'L','hndshkif','Orders Import File','magicon016.png%IMG%','hndshkif_orders_ordersimportfile','hndshkif_orders_ordersimportfile/enquirydefault','if,vw,nw,cp,in,ao,as,rj,hd,va','ls,is,hs,ex','IMPLEMENTATION','2013-09-10 06:09:27','ADMIN','2013-09-10 06:37:02','LIVE',1),(1040,600002,6000,6000.02002,214,225,2,'N','hndshkif','Customers','','','','','','IMPLEMENTATION','2013-09-10 06:09:27','ADMIN','2013-09-10 06:37:17','LIVE',1),(1041,60000250,600002,600002.50000,215,216,3,'L','hndshkif','Customer Mapping','magicon016.png%IMG%','hndshkif_customers_customermapping','hndshkif_customers_customermapping/enquirydefault','if,vw,nw,cp,in,ao,as,rj,hd,va','ls,is,hs,ex','IMPLEMENTATION','2013-09-10 06:09:27','ADMIN','2013-09-10 06:37:40','LIVE',1),(1042,60000251,600002,600002.50000,217,218,3,'L','hndshkif','Customer Batches','magicon016.png%IMG%','hndshkif_customers_customerbatch','hndshkif_customers_customerbatch/enquirydefault','if,vw,nw,cp,in,ao,as,rj,hd,va','ls,is,hs,ex','IMPLEMENTATION','2013-09-10 06:09:27','ADMIN','2013-09-10 06:37:50','LIVE',1),(1043,60000252,600002,600002.50000,219,220,3,'L','hndshkif','Customer Changelog','magicon016.png%IMG%','hndshkif_customers_customerchangelog','hndshkif_customers_customerchangelog/enquirydefault','if,vw,nw,cp,in,ao,as,rj,hd,va','ls,is,hs,ex','IMPLEMENTATION','2013-09-10 06:09:27','ADMIN','2013-09-10 06:38:00','LIVE',1),(1044,60000253,600002,600002.50000,221,222,3,'L','hndshkif','Get Dac Easy Customers','magicon016.png%IMG%','hndshkif_customers_getdaceasycustomers','hndshkif_customers_getdaceasycustomers/enquirydefault','if,vw,nw,cp,in,ao,as,rj,hd,va','ls,is,hs,ex','IMPLEMENTATION','2013-09-10 06:09:27','ADMIN','2013-09-10 06:38:12','LIVE',1),(1045,60000254,600002,600002.56250,223,224,3,'L','hndshkif','Push Handshake Customers','magicon016.png%IMG%','hndshkif_customers_pushhandshakecustomers','hndshkif_customers_pushhandshakecustomers/enquirydefault','if,vw,nw,cp,in,ao,as,rj,hd,va','ls,is,hs,ex','IMPLEMENTATION','2013-09-10 06:09:27','ADMIN','2013-09-10 06:38:21','LIVE',1),(1050,600003,6000,6000.02979,226,237,2,'N','hndshkif','Inventory','','','','','','IMPLEMENTATION','2013-09-10 06:09:27','ADMIN','2013-09-10 06:38:30','LIVE',1),(1051,60000350,600003,600003.50000,227,228,3,'L','hndshkif','Inventory Mapping','magicon016.png%IMG%','hndshkif_inventory_inventorymapping','hndshkif_inventory_inventorymapping/enquirydefault','if,vw,nw,cp,in,ao,as,rj,hd,va','ls,is,hs,ex','IMPLEMENTATION','2013-09-10 06:09:27','ADMIN','2013-09-10 06:38:39','LIVE',1),(1052,60000351,600003,600003.50000,229,230,3,'L','hndshkif','Inventory Batches','magicon016.png%IMG%','hndshkif_inventory_inventorybatch','hndshkif_inventory_inventorybatch/enquirydefault','if,vw,nw,cp,in,ao,as,rj,hd,va','ls,is,hs,ex','IMPLEMENTATION','2013-09-10 06:09:27','ADMIN','2013-09-10 06:38:52','LIVE',1),(1053,60000352,600003,600003.50000,231,232,3,'L','hndshkif','Inventory Changelog','magicon016.png%IMG%','hndshkif_inventory_inventorychangelog','hndshkif_inventory_inventorychangelog/enquirydefault','if,vw,nw,cp,in,ao,as,rj,hd,va','ls,is,hs,ex','IMPLEMENTATION','2013-09-10 06:09:27','ADMIN','2013-09-10 06:39:00','LIVE',1),(1054,60000353,600003,600003.50000,233,234,3,'L','hndshkif','Get Dac Easy Inventory','magicon016.png%IMG%','hndshkif_inventory_getdaceasyinventory','hndshkif_inventory_getdaceasyinventory/enquirydefault','if,vw,nw,cp,in,ao,as,rj,hd,va','ls,is,hs,ex','IMPLEMENTATION','2013-09-10 06:09:27','ADMIN','2013-09-10 06:39:10','LIVE',1),(1055,60000354,600003,600003.56250,235,236,3,'L','hndshkif','Push Handshake Inventory','magicon016.png%IMG%','hndshkif_inventory_pushhandshakeinventory','hndshkif_inventory_pushhandshakeinventory/enquirydefault','if,vw,nw,cp,in,ao,as,rj,hd,va','ls,is,hs,ex','IMPLEMENTATION','2013-09-10 06:09:27','ADMIN','2013-09-10 06:39:18','LIVE',1),(1060,600004,6000,6000.04004,238,245,2,'N','hndshkif','Settings','','','','','','IMPLEMENTATION','2013-09-10 06:09:27','ADMIN','2013-09-10 06:39:28','LIVE',1),(1061,60000450,600004,600004.50000,239,240,3,'L','hndshkif','Interface Configuration','magicon016.png%IMG%','hndshkif_settings_interfaceconfiguration','hndshkif_settings_interfaceconfiguration/enquirydefault','if,vw,nw,cp,in,ao,as,rj,hd,va','ls,is,hs,ex','IMPLEMENTATION','2013-09-10 06:09:27','ADMIN','2013-09-10 06:39:38','LIVE',1),(1062,60000451,600004,600004.50000,241,242,3,'L','hndshkif','Scheduling','magicon016.png%IMG%','hndshkif_settings_scheduling','hndshkif_settings_scheduling/enquirydefault','if,vw,nw,cp,in,ao,as,rj,hd,va','ls,is,hs,ex','IMPLEMENTATION','2013-09-10 06:09:27','ADMIN','2013-09-10 06:39:47','LIVE',1),(1064,60000453,600004,600004.50000,243,244,3,'L','hndshkif','Interface Status','magicon016.png%IMG%','hndshkif_settings_interfacestatus','hndshkif_settings_interfacestatus/enquirydefault','if,vw,nw,cp,in,ao,as,rj,hd,va','ls,is,hs,ex','IMPLEMENTATION','2013-09-10 06:09:27','ADMIN','2013-09-10 06:40:08','LIVE',1);
/*!40000 ALTER TABLE `menudefs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `menudefs_hs`
--

DROP TABLE IF EXISTS `menudefs_hs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `menudefs_hs` (
  `id` int(11) unsigned NOT NULL,
  `menu_id` int(11) unsigned NOT NULL,
  `parent_id` int(11) unsigned NOT NULL,
  `sortpos` float(16,5) NOT NULL,
  `nleft` int(11) DEFAULT NULL,
  `nright` int(11) DEFAULT NULL,
  `nlevel` int(11) DEFAULT NULL,
  `node_or_leaf` enum('L','N') NOT NULL,
  `module` varchar(50) NOT NULL,
  `label_input` varchar(255) NOT NULL,
  `label_enquiry` varchar(255) NOT NULL,
  `url_input` varchar(255) DEFAULT NULL,
  `url_enquiry` varchar(255) DEFAULT NULL,
  `controls_input` varchar(255) DEFAULT NULL,
  `controls_enquiry` varchar(255) DEFAULT NULL,
  `inputter` varchar(50) NOT NULL,
  `input_date` datetime NOT NULL,
  `authorizer` varchar(50) NOT NULL,
  `auth_date` datetime NOT NULL,
  `record_status` char(4) NOT NULL,
  `current_no` int(11) NOT NULL,
  PRIMARY KEY (`id`,`current_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `menudefs_hs`
--

LOCK TABLES `menudefs_hs` WRITE;
/*!40000 ALTER TABLE `menudefs_hs` DISABLE KEYS */;
/*!40000 ALTER TABLE `menudefs_hs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `menudefs_is`
--

DROP TABLE IF EXISTS `menudefs_is`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `menudefs_is` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `menu_id` int(11) unsigned DEFAULT NULL,
  `parent_id` int(11) unsigned DEFAULT NULL,
  `sortpos` float(16,5) DEFAULT NULL,
  `nleft` int(11) DEFAULT '0',
  `nright` int(11) DEFAULT '0',
  `nlevel` int(11) DEFAULT '0',
  `node_or_leaf` enum('L','N') DEFAULT NULL,
  `module` varchar(50) DEFAULT NULL,
  `label_input` varchar(255) DEFAULT NULL,
  `label_enquiry` varchar(255) DEFAULT NULL,
  `url_input` varchar(255) DEFAULT NULL,
  `url_enquiry` varchar(255) DEFAULT NULL,
  `controls_input` varchar(255) DEFAULT NULL,
  `controls_enquiry` varchar(255) DEFAULT NULL,
  `inputter` varchar(50) DEFAULT NULL,
  `input_date` datetime DEFAULT NULL,
  `authorizer` varchar(50) DEFAULT NULL,
  `auth_date` datetime DEFAULT NULL,
  `record_status` char(4) DEFAULT NULL,
  `current_no` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `menudefs_is`
--

LOCK TABLES `menudefs_is` WRITE;
/*!40000 ALTER TABLE `menudefs_is` DISABLE KEYS */;
/*!40000 ALTER TABLE `menudefs_is` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `menudefs_users`
--

DROP TABLE IF EXISTS `menudefs_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `menudefs_users` (
  `id` int(11) unsigned DEFAULT NULL,
  `menu_id` int(11) unsigned NOT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `sortpos` float(16,5) DEFAULT NULL,
  `nleft` int(11) DEFAULT NULL,
  `nright` int(11) DEFAULT NULL,
  `nlevel` int(11) DEFAULT NULL,
  `node_or_leaf` enum('L','N') CHARACTER SET utf8 DEFAULT NULL,
  `module` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `label_input` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `label_enquiry` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `url_input` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `url_enquiry` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `controls_input` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `controls_enquiry` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `inputter` varchar(50) CHARACTER SET utf8 NOT NULL,
  `input_date` datetime DEFAULT NULL,
  `authorizer` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `auth_date` datetime DEFAULT NULL,
  `record_status` char(4) CHARACTER SET utf8 DEFAULT NULL,
  `current_no` int(11) DEFAULT NULL,
  PRIMARY KEY (`menu_id`,`inputter`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `menudefs_users`
--

LOCK TABLES `menudefs_users` WRITE;
/*!40000 ALTER TABLE `menudefs_users` DISABLE KEYS */;
INSERT INTO `menudefs_users` VALUES (1055,60000354,600003,600003.56250,235,236,3,'L','hndshkif','Push Handshake Inventory','magicon016.png%IMG%','hndshkif_inventory_pushhandshakeinventory','hndshkif_inventory_pushhandshakeinventory/enquirydefault','if,vw,nw,cp,in,ao,as,rj,hd,va','ls,is,hs,ex','ADMIN','2013-09-14 05:15:20','SYSAUTH','2013-09-14 05:15:20','LIVE',1),(1060,600004,6000,6000.04004,238,245,2,'N','hndshkif','Settings','','','','','','ADMIN','2013-09-14 05:15:20','SYSAUTH','2013-09-14 05:15:20','LIVE',1),(1061,60000450,600004,600004.50000,239,240,3,'L','hndshkif','Interface Configuration','magicon016.png%IMG%','hndshkif_settings_interfaceconfiguration','hndshkif_settings_interfaceconfiguration/enquirydefault','if,vw,nw,cp,in,ao,as,rj,hd,va','ls,is,hs,ex','ADMIN','2013-09-14 05:15:20','SYSAUTH','2013-09-14 05:15:20','LIVE',1),(1062,60000451,600004,600004.50000,241,242,3,'L','hndshkif','Scheduling','magicon016.png%IMG%','hndshkif_settings_scheduling','hndshkif_settings_scheduling/enquirydefault','if,vw,nw,cp,in,ao,as,rj,hd,va','ls,is,hs,ex','ADMIN','2013-09-14 05:15:20','SYSAUTH','2013-09-14 05:15:20','LIVE',1),(1064,60000453,600004,600004.50000,243,244,3,'L','hndshkif','Interface Status','magicon016.png%IMG%','hndshkif_settings_interfacestatus','hndshkif_settings_interfacestatus/enquirydefault','if,vw,nw,cp,in,ao,as,rj,hd,va','ls,is,hs,ex','ADMIN','2013-09-14 05:15:20','SYSAUTH','2013-09-14 05:15:20','LIVE',1),(1054,60000353,600003,600003.50000,233,234,3,'L','hndshkif','Get Dac Easy Inventory','magicon016.png%IMG%','hndshkif_inventory_getdaceasyinventory','hndshkif_inventory_getdaceasyinventory/enquirydefault','if,vw,nw,cp,in,ao,as,rj,hd,va','ls,is,hs,ex','ADMIN','2013-09-14 05:15:20','SYSAUTH','2013-09-14 05:15:20','LIVE',1),(1022,60000151,600001,600001.50000,205,206,3,'L','hndshkif','Downloaded Order Batches','magicon016.png%IMG%','hndshkif_orders_dlorderbatch','hndshkif_orders_dlorderbatch/enquirydefault','if,vw,nw,cp,in,ao,as,rj,hd,va','ls,is,hs,ex','ADMIN','2013-09-14 05:15:20','SYSAUTH','2013-09-14 05:15:20','LIVE',1),(1023,60000152,600001,600001.50000,207,208,3,'L','hndshkif','Downloaded Orders Report','magicon016.png%IMG%','hndshkif_orders_dlorderreport','hndshkif_orders_dlorderreport/enquirydefault','if,vw,nw,cp,in,ao,as,rj,hd,va','ls,is,hs,ex','ADMIN','2013-09-14 05:15:20','SYSAUTH','2013-09-14 05:15:20','LIVE',1),(1025,60000154,600001,600001.56250,209,210,3,'L','hndshkif','Get Handshake Orders','magicon016.png%IMG%','hndshkif_orders_gethandshakeorders','hndshkif_orders_gethandshakeorders/enquirydefault','if,vw,in,ao,as,rj,hd,va','ls,is,hs,ex','ADMIN','2013-09-14 05:15:20','SYSAUTH','2013-09-14 05:15:20','LIVE',1),(1026,60000155,600001,600001.56250,211,212,3,'L','hndshkif','Orders Import File','magicon016.png%IMG%','hndshkif_orders_ordersimportfile','hndshkif_orders_ordersimportfile/enquirydefault','if,vw,nw,cp,in,ao,as,rj,hd,va','ls,is,hs,ex','ADMIN','2013-09-14 05:15:20','SYSAUTH','2013-09-14 05:15:20','LIVE',1),(1040,600002,6000,6000.02002,214,225,2,'N','hndshkif','Customers','','','','','','ADMIN','2013-09-14 05:15:20','SYSAUTH','2013-09-14 05:15:20','LIVE',1),(1041,60000250,600002,600002.50000,215,216,3,'L','hndshkif','Customer Mapping','magicon016.png%IMG%','hndshkif_customers_customermapping','hndshkif_customers_customermapping/enquirydefault','if,vw,nw,cp,in,ao,as,rj,hd,va','ls,is,hs,ex','ADMIN','2013-09-14 05:15:20','SYSAUTH','2013-09-14 05:15:20','LIVE',1),(1042,60000251,600002,600002.50000,217,218,3,'L','hndshkif','Customer Batches','magicon016.png%IMG%','hndshkif_customers_customerbatch','hndshkif_customers_customerbatch/enquirydefault','if,vw,nw,cp,in,ao,as,rj,hd,va','ls,is,hs,ex','ADMIN','2013-09-14 05:15:20','SYSAUTH','2013-09-14 05:15:20','LIVE',1),(1043,60000252,600002,600002.50000,219,220,3,'L','hndshkif','Customer Changelog','magicon016.png%IMG%','hndshkif_customers_customerchangelog','hndshkif_customers_customerchangelog/enquirydefault','if,vw,nw,cp,in,ao,as,rj,hd,va','ls,is,hs,ex','ADMIN','2013-09-14 05:15:20','SYSAUTH','2013-09-14 05:15:20','LIVE',1),(1053,60000352,600003,600003.50000,231,232,3,'L','hndshkif','Inventory Changelog','magicon016.png%IMG%','hndshkif_inventory_inventorychangelog','hndshkif_inventory_inventorychangelog/enquirydefault','if,vw,nw,cp,in,ao,as,rj,hd,va','ls,is,hs,ex','ADMIN','2013-09-14 05:15:20','SYSAUTH','2013-09-14 05:15:20','LIVE',1),(1052,60000351,600003,600003.50000,229,230,3,'L','hndshkif','Inventory Batches','magicon016.png%IMG%','hndshkif_inventory_inventorybatch','hndshkif_inventory_inventorybatch/enquirydefault','if,vw,nw,cp,in,ao,as,rj,hd,va','ls,is,hs,ex','ADMIN','2013-09-14 05:15:20','SYSAUTH','2013-09-14 05:15:20','LIVE',1),(1050,600003,6000,6000.02979,226,237,2,'N','hndshkif','Inventory','','','','','','ADMIN','2013-09-14 05:15:20','SYSAUTH','2013-09-14 05:15:20','LIVE',1),(1051,60000350,600003,600003.50000,227,228,3,'L','hndshkif','Inventory Mapping','magicon016.png%IMG%','hndshkif_inventory_inventorymapping','hndshkif_inventory_inventorymapping/enquirydefault','if,vw,nw,cp,in,ao,as,rj,hd,va','ls,is,hs,ex','ADMIN','2013-09-14 05:15:20','SYSAUTH','2013-09-14 05:15:20','LIVE',1),(1045,60000254,600002,600002.56250,223,224,3,'L','hndshkif','Push Handshake Customers','magicon016.png%IMG%','hndshkif_customers_pushhandshakecustomers','hndshkif_customers_pushhandshakecustomers/enquirydefault','if,vw,nw,cp,in,ao,as,rj,hd,va','ls,is,hs,ex','ADMIN','2013-09-14 05:15:20','SYSAUTH','2013-09-14 05:15:20','LIVE',1),(1044,60000253,600002,600002.50000,221,222,3,'L','hndshkif','Get Dac Easy Customers','magicon016.png%IMG%','hndshkif_customers_getdaceasycustomers','hndshkif_customers_getdaceasycustomers/enquirydefault','if,vw,nw,cp,in,ao,as,rj,hd,va','ls,is,hs,ex','ADMIN','2013-09-14 05:15:20','SYSAUTH','2013-09-14 05:15:20','LIVE',1),(1024,60000153,600001,600001.50000,201,202,3,'L','hndshkif','Last Download Report','magicon016.png%IMG%','hndshkif_orders_dlorderlastreport','hndshkif_orders_dlorderlastreport/enquirydefault','if,vw,nw,cp,in,ao,as,rj,hd,va','ls,is,hs,ex','ADMIN','2013-09-14 05:15:20','SYSAUTH','2013-09-14 05:15:20','LIVE',1),(1021,60000150,600001,600001.50000,203,204,3,'L','hndshkif','Downloaded Orders','magicon016.png%IMG%','hndshkif_orders_dlorder','hndshkif_orders_dlorder/enquirydefault','if,vw','ls,ex','ADMIN','2013-09-14 05:15:20','SYSAUTH','2013-09-14 05:15:20','LIVE',1),(1020,600001,6000,6000.00977,200,213,2,'N','hndshkif','Orders','','','','','','ADMIN','2013-09-14 05:15:20','SYSAUTH','2013-09-14 05:15:20','LIVE',1),(1011,60000050,600000,600000.50000,195,196,3,'L','hndshkif','Summary','magicon016.png%IMG%','hndshkif_notifications_summary','hndshkif_notifications_summary/enquirydefault','if,vw,nw,cp,in,ao,as,rj,hd,va','ls,is,hs,ex','ADMIN','2013-09-14 05:15:20','SYSAUTH','2013-09-14 05:15:20','LIVE',1),(1012,60000051,600000,600000.50000,197,198,3,'L','hndshkif','Errors','magicon016.png%IMG%','hndshkif_notifications_summary','hndshkif_notifications_summary/enquirydefault','if,vw,nw,cp,in,ao,as,rj,hd,va','ls,is,hs,ex','ADMIN','2013-09-14 05:15:20','SYSAUTH','2013-09-14 05:15:20','LIVE',1),(59,2503,25,25.03000,98,103,2,'N','developer','Table Administration','','','','','','ADMIN','2013-09-14 05:15:20','SYSAUTH','2013-09-14 05:15:20','LIVE',1),(60,250350,2503,2503.50000,99,100,3,'L','developer','Run Table Reset','magicon016.png%IMG%','core_developer_tableresetrun','core_developer_tableresetrun/enquirydefault','if,vw,nw,cp,in,ao,as,rj,hd,va','ls,is,hs,ex','ADMIN','2013-09-14 05:15:20','SYSAUTH','2013-09-14 05:15:20','LIVE',1),(1000,6000,0,60.00000,193,246,1,'N','hndshkif','Handshake Interface','','','','','','ADMIN','2013-09-14 05:15:20','SYSAUTH','2013-09-14 05:15:20','LIVE',1),(1010,600000,6000,6000.00000,194,199,2,'N','hndshkif','Notifications','','','','','','ADMIN','2013-09-14 05:15:20','SYSAUTH','2013-09-14 05:15:20','LIVE',1),(61,250351,2503,2503.51001,101,102,3,'L','developer','Table Reset Configuration','magicon016.png%IMG%','core_developer_tableresetconfig','core_developer_tableresetconfig/enquirydefault','if,vw,nw,cp,in,ao,as,rj,hd,va','ls,is,hs,ex','ADMIN','2013-09-14 05:15:20','SYSAUTH','2013-09-14 05:15:20','LIVE',1),(425,250252,2502,2502.52002,95,96,3,'L','developer','Jasper Compile','magicon016.png%IMG%','core_developer_jaspercompile','core_developer_jaspercompile/enquirydefault','if,vw,nw,cp,in,ao,as,rj,hd,va','ls,is,hs,ex','ADMIN','2013-09-14 05:15:20','SYSAUTH','2013-09-14 05:15:20','LIVE',1),(17,2501,25,25.01000,86,89,2,'N','developer','Enquiry Administration','','','','','','ADMIN','2013-09-14 05:15:20','SYSAUTH','2013-09-14 05:15:20','LIVE',1),(56,250055,2501,2501.50000,87,88,3,'L','developer','Fixed Selection','magicon016.png%IMG%','core_developer_fixedselection','core_developer_fixedselection/enquirydefault','if,vw,nw,cp,in,ao,as,rj,hd,va','ls,is,hs,ex','ADMIN','2013-09-14 05:15:20','SYSAUTH','2013-09-14 05:15:20','LIVE',1),(19,2502,25,25.02000,90,97,2,'N','developer','Report Administration','','','','','','ADMIN','2013-09-14 05:15:20','SYSAUTH','2013-09-14 05:15:20','LIVE',1),(57,250250,2502,2502.50000,91,92,3,'L','developer','Run Report Refresh','magicon016.png%IMG%','core_developer_runreportrefresh','core_developer_runreportrefresh/enquirydefault','if,vw,nw,cp,in,ao,as,rj,hd,va','ls,is,hs,ex','ADMIN','2013-09-14 05:15:20','SYSAUTH','2013-09-14 05:15:20','LIVE',1),(58,250251,2502,2502.51001,93,94,3,'L','developer','Report Refresh Configuration','magicon016.png%IMG%','core_developer_reportrefreshconfig','core_developer_reportrefreshconfig/enquirydefault','if,vw,nw,cp,in,ao,as,rj,hd,va','ls,is,hs,ex','ADMIN','2013-09-14 05:15:20','SYSAUTH','2013-09-14 05:15:20','LIVE',1),(63,250057,2500,2500.57007,83,84,3,'L','developer','Auto Definitions','','core_developer_autodef','','vw','','ADMIN','2013-09-14 05:15:20','SYSAUTH','2013-09-14 05:15:20','LIVE',1),(55,250054,2500,2500.54004,79,80,3,'L','developer','Report Definition','magicon016.png%IMG%','core_developer_reportdef','core_developer_reportdef/enquirydefault','if,vw,nw,cp,in,ao,as,rj,hd,va','ls,is,hs,ex','ADMIN','2013-09-14 05:15:20','SYSAUTH','2013-09-14 05:15:20','LIVE',1),(62,250056,2500,2500.55005,81,82,3,'L','developer','PDF Template','magicon016.png%IMG%','core_developer_pdftemplate','core_developer_pdftemplate/enquirydefault','if,vw,nw,cp,in,ao,as,rj,hd,va','ls,is,hs,ex','ADMIN','2013-09-14 05:15:20','SYSAUTH','2013-09-14 05:15:20','LIVE',1),(50,250051,2500,2500.51001,73,74,3,'L','developer','Form Definition','magicon016.png%IMG%','core_developer_formdef','core_developer_formdef/enquirydefault','if,vw,in,ao,as,rj,hd,va','ls,is,hs,ex','ADMIN','2013-09-14 05:15:20','SYSAUTH','2013-09-14 05:15:20','LIVE',1),(53,250052,2500,2500.52002,75,76,3,'L','developer','Menu Definition','magicon016.png%IMG%','core_developer_menudef','core_developer_menudef/enquirydefault','if,vw,nw,cp,in,ao,as,rj,hd,va','ls,is,hs,ex','ADMIN','2013-09-14 05:15:20','SYSAUTH','2013-09-14 05:15:20','LIVE',1),(54,250053,2500,2500.53003,77,78,3,'L','developer','Enquiry Definition','magicon016.png%IMG%','core_developer_enqdef','core_developer_enqdef/enquirydefault','if,vw,nw,cp,in,ao,as,rj,hd,va','ls,is,hs,ex','ADMIN','2013-09-14 05:15:20','SYSAUTH','2013-09-14 05:15:20','LIVE',1),(11,1501,15,15.01000,26,29,2,'N','useradmin','Roles','','','','','','ADMIN','2013-09-14 05:15:20','SYSAUTH','2013-09-14 05:15:20','LIVE',1),(4,25,0,0.25000,69,104,1,'N','developer','Developer','','','','','','ADMIN','2013-09-14 05:15:20','SYSAUTH','2013-09-14 05:15:20','LIVE',1),(15,2500,25,25.00000,70,85,2,'N','developer','Definition','','','','','','ADMIN','2013-09-14 05:15:20','SYSAUTH','2013-09-14 05:15:20','LIVE',1),(49,250050,2500,2500.50000,71,72,3,'L','developer','Param Definition','magicon016.png%IMG%','core_developer_param','core_developer_param/enquirydefault','if,vw,nw,cp,in,ao,as,rj,hd,va','ls,is,hs,ex','ADMIN','2013-09-14 05:15:20','SYSAUTH','2013-09-14 05:15:20','LIVE',1),(51,200451,2004,2004.51001,63,64,3,'L','sysadmin','PDF','magicon016.png%IMG%','core_sysadmin_pdf','core_sysadmin_pdf/enquirydefault','if,vw,in,ao,as,rj,hd,va','ls,is,hs,ex','ADMIN','2013-09-14 05:15:20','SYSAUTH','2013-09-14 05:15:20','LIVE',1),(52,200452,2004,2004.52002,65,66,3,'L','sysadmin','CSV','magicon016.png%IMG%','core_sysadmin_csv','core_sysadmin_csv/enquirydefault','if,vw,in,ao,as,rj,hd,va','ls,is,hs,ex','ADMIN','2013-09-14 05:15:20','SYSAUTH','2013-09-14 05:15:20','LIVE',1),(32,2004,20,20.04000,60,67,2,'N','sysadmin','System Maintenance','','','','','','ADMIN','2013-09-14 05:15:20','SYSAUTH','2013-09-14 05:15:20','LIVE',1),(48,200450,2004,2004.51001,61,62,3,'L','sysadmin','Record Lock','magicon016.png%IMG%','core_sysadmin_recordlock','core_sysadmin_recordlock/enquirydefault','if,vw,de','ls','ADMIN','2013-09-14 05:15:20','SYSAUTH','2013-09-14 05:15:20','LIVE',1),(47,200351,2003,2003.51001,57,58,3,'L','sysadmin','Run EOD','magicon016.png%IMG%','core_sysadmin_runeod','core_sysadmin_runeod/enquirydefault','if,vw,nw,cp,in,ao,as,rj,hd,va','ls,is,hs,ex','ADMIN','2013-09-14 05:15:20','SYSAUTH','2013-09-14 05:15:20','LIVE',1),(31,2003,20,20.03000,54,59,2,'N','sysadmin','End Of Day','','','','','','ADMIN','2013-09-14 05:15:20','SYSAUTH','2013-09-14 05:15:20','LIVE',1),(46,200350,2003,2003.50000,55,56,3,'L','sysadmin','EOD Configuration','magicon016.png%IMG%','core_sysadmin_endofday','core_sysadmin_endofday/enquirydefault','if,vw,nw,cp,in,ao,as,rj,hd,va','ls,is,hs,ex','ADMIN','2013-09-14 05:15:20','SYSAUTH','2013-09-14 05:15:20','LIVE',1),(25,150052,1500,1500.52002,23,24,3,'L','useradmin','User Roles','magicon016.png%IMG%','core_useradmin_userrole','core_useradmin_userrole/enquirydefault','if,vw,nw,cp,in,ao,as,rj,hd,va','ls,is,hs,ex','ADMIN','2013-09-14 05:15:20','SYSAUTH','2013-09-14 05:15:20','LIVE',1),(45,200253,2002,2002.55005,51,52,3,'L','sysadmin','Recurrence','magicon016.png%IMG%','core_sysadmin_recurrence','core_sysadmin_recurrence/enquirydefault','if,vw,nw,cp,in,ao,as,rj,hd,va','ls,is,hs,ex','ADMIN','2013-09-14 05:15:20','SYSAUTH','2013-09-14 05:15:20','LIVE',1),(24,150051,1500,1500.51001,21,22,3,'L','useradmin','User Password Reset','','core_useradmin_userpasswdreset','','if,vw,iw,in,ao,as,rj,hd,va','','ADMIN','2013-09-14 05:15:20','SYSAUTH','2013-09-14 05:15:20','LIVE',1),(23,150050,1500,1500.50000,19,20,3,'L','useradmin','User','magicon016.png%IMG%','core_useradmin_useradmin','core_useradmin_useradmin/enquirydefault','if,vw,nw,cp,in,ao,as,rj,hd,va','ls,is,hs,ex','ADMIN','2013-09-14 05:15:20','SYSAUTH','2013-09-14 05:15:20','LIVE',1),(10,1500,15,15.00000,18,25,2,'N','useradmin','Users','','','','','','ADMIN','2013-09-14 05:15:20','SYSAUTH','2013-09-14 05:15:20','LIVE',1),(44,200251,2002,2002.54004,49,50,3,'L','sysadmin','Daytime','magicon016.png%IMG%','core_sysadmin_daytime','core_sysadmin_daytime/enquirydefault','if,vw,nw,cp,in,ao,as,rj,hd,va','ls,is,hs,ex','ADMIN','2013-09-14 05:15:20','SYSAUTH','2013-09-14 05:15:20','LIVE',1),(43,200250,2002,2002.53003,47,48,3,'L','sysadmin','Weekday','magicon016.png%IMG%','core_sysadmin_weekday','core_sysadmin_weekday/enquirydefault','if,vw,nw,cp,in,ao,as,rj,hd,va','ls,is,hs,ex','ADMIN','2013-09-14 05:15:20','SYSAUTH','2013-09-14 05:15:20','LIVE',1),(30,2002,20,20.02000,46,53,2,'N','sysadmin','Dates & Times','','','','','','ADMIN','2013-09-14 05:15:20','SYSAUTH','2013-09-14 05:15:20','LIVE',1),(46,200350,2003,2003.50000,55,56,3,'L','sysadmin','EOD Configuration','magicon016.png%IMG%','core_sysadmin_endofday','core_sysadmin_endofday/enquirydefault','if,vw,nw,cp,in,ao,as,rj,hd,va','ls,is,hs,ex','DUNSTAN.NESBIT','2013-09-10 06:59:18','SYSAUTH','2013-09-10 06:59:18','LIVE',1),(51,200451,2004,2004.51001,63,64,3,'L','sysadmin','PDF','magicon016.png%IMG%','core_sysadmin_pdf','core_sysadmin_pdf/enquirydefault','if,vw,in,ao,as,rj,hd,va','ls,is,hs,ex','DUNSTAN.NESBIT','2013-09-10 06:59:18','SYSAUTH','2013-09-10 06:59:18','LIVE',1),(52,200452,2004,2004.52002,65,66,3,'L','sysadmin','CSV','magicon016.png%IMG%','core_sysadmin_csv','core_sysadmin_csv/enquirydefault','if,vw,in,ao,as,rj,hd,va','ls,is,hs,ex','DUNSTAN.NESBIT','2013-09-10 06:59:18','SYSAUTH','2013-09-10 06:59:18','LIVE',1),(48,200450,2004,2004.51001,61,62,3,'L','sysadmin','Record Lock','magicon016.png%IMG%','core_sysadmin_recordlock','core_sysadmin_recordlock/enquirydefault','if,vw,de','ls','DUNSTAN.NESBIT','2013-09-10 06:59:18','SYSAUTH','2013-09-10 06:59:18','LIVE',1),(32,2004,20,20.04000,60,67,2,'N','sysadmin','System Maintenance','','','','','','DUNSTAN.NESBIT','2013-09-10 06:59:18','SYSAUTH','2013-09-10 06:59:18','LIVE',1),(47,200351,2003,2003.51001,57,58,3,'L','sysadmin','Run EOD','magicon016.png%IMG%','core_sysadmin_runeod','core_sysadmin_runeod/enquirydefault','if,vw,nw,cp,in,ao,as,rj,hd,va','ls,is,hs,ex','DUNSTAN.NESBIT','2013-09-10 06:59:18','SYSAUTH','2013-09-10 06:59:18','LIVE',1),(31,2003,20,20.03000,54,59,2,'N','sysadmin','End Of Day','','','','','','DUNSTAN.NESBIT','2013-09-10 06:59:18','SYSAUTH','2013-09-10 06:59:18','LIVE',1),(44,200251,2002,2002.54004,49,50,3,'L','sysadmin','Daytime','magicon016.png%IMG%','core_sysadmin_daytime','core_sysadmin_daytime/enquirydefault','if,vw,nw,cp,in,ao,as,rj,hd,va','ls,is,hs,ex','DUNSTAN.NESBIT','2013-09-10 06:59:18','SYSAUTH','2013-09-10 06:59:18','LIVE',1),(45,200253,2002,2002.55005,51,52,3,'L','sysadmin','Recurrence','magicon016.png%IMG%','core_sysadmin_recurrence','core_sysadmin_recurrence/enquirydefault','if,vw,nw,cp,in,ao,as,rj,hd,va','ls,is,hs,ex','DUNSTAN.NESBIT','2013-09-10 06:59:18','SYSAUTH','2013-09-10 06:59:18','LIVE',1),(30,2002,20,20.02000,46,53,2,'N','sysadmin','Dates & Times','','','','','','DUNSTAN.NESBIT','2013-09-10 06:59:18','SYSAUTH','2013-09-10 06:59:18','LIVE',1),(43,200250,2002,2002.53003,47,48,3,'L','sysadmin','Weekday','magicon016.png%IMG%','core_sysadmin_weekday','core_sysadmin_weekday/enquirydefault','if,vw,nw,cp,in,ao,as,rj,hd,va','ls,is,hs,ex','DUNSTAN.NESBIT','2013-09-10 06:59:18','SYSAUTH','2013-09-10 06:59:18','LIVE',1),(42,200151,2001,2001.51001,43,44,3,'L','sysadmin','Region','magicon016.png%IMG%','core_sysadmin_region','core_sysadmin_region/enquirydefault','if,vw,nw,cp,in,ao,as,rj,hd,va','ls,is,hs,ex','DUNSTAN.NESBIT','2013-09-10 06:59:18','SYSAUTH','2013-09-10 06:59:18','LIVE',1),(41,200150,2001,2001.50000,41,42,3,'L','sysadmin','Country','magicon016.png%IMG%','core_sysadmin_country','core_sysadmin_country/enquirydefault','if,vw,nw,cp,in,ao,as,rj,hd,va','ls,is,hs,ex','DUNSTAN.NESBIT','2013-09-10 06:59:18','SYSAUTH','2013-09-10 06:59:18','LIVE',1),(34,200051,2000,2000.51001,35,36,3,'L','sysadmin','Branch','magicon016.png%IMG%','core_sysadmin_branch','core_sysadmin_branch/enquirydefault','if,vw,nw,cp,in,ao,as,rj,hd,va','ls,is,hs,ex','DUNSTAN.NESBIT','2013-09-10 06:59:18','SYSAUTH','2013-09-10 06:59:18','LIVE',1),(35,200052,2000,2000.52002,37,38,3,'L','sysadmin','Department','magicon016.png%IMG%','core_sysadmin_department','core_sysadmin_department/enquirydefault','if,vw,nw,cp,in,ao,as,rj,hd,va','ls,is,hs,ex','DUNSTAN.NESBIT','2013-09-10 06:59:18','SYSAUTH','2013-09-10 06:59:18','LIVE',1),(13,2001,20,20.01000,40,45,2,'N','sysadmin','Countries & Regions','','','','','','DUNSTAN.NESBIT','2013-09-10 06:59:18','SYSAUTH','2013-09-10 06:59:18','LIVE',1),(33,200050,2000,2000.50000,33,34,3,'L','sysadmin','System Configuration ','magicon016.png%IMG%','core_sysadmin_sysconfig','core_sysadmin_sysconfig/enquirydefault','if,vw,nw,cp,in,ao,as,rj,hd,va','ls,is,hs,ex','DUNSTAN.NESBIT','2013-09-10 06:59:18','SYSAUTH','2013-09-10 06:59:18','LIVE',1),(37,100051,1000,1000.51001,5,6,3,'L','useraccount',' ','Inbox','','core_useraccount_message/inbox','df,ls,is,hs,ex','','DUNSTAN.NESBIT','2013-09-10 06:59:18','SYSAUTH','2013-09-10 06:59:18','LIVE',1),(38,100052,1000,1000.52002,7,8,3,'L','useraccount',' ','Drafts','','core_useraccount_message/drafts','df,ls,is,hs,ex','','DUNSTAN.NESBIT','2013-09-10 06:59:18','SYSAUTH','2013-09-10 06:59:18','LIVE',1),(39,100053,1000,1000.53003,9,10,3,'L','useraccount',' ','Sent','','core_useraccount_message/sent','df,ls,is,hs,ex','','DUNSTAN.NESBIT','2013-09-10 06:59:18','SYSAUTH','2013-09-10 06:59:18','LIVE',1),(6,1001,10,10.01000,12,15,2,'N','useraccount','User','','','','','','DUNSTAN.NESBIT','2013-09-10 06:59:18','SYSAUTH','2013-09-10 06:59:18','LIVE',1),(40,100150,1001,1001.50000,13,14,3,'L','useraccount','Change Password','magicon016.png%IMG%','core_useraccount_userchangepassword','core_useraccount_userchangepassword/enquirydefault','vw,in,as,rj,va','ls,is','DUNSTAN.NESBIT','2013-09-10 06:59:18','SYSAUTH','2013-09-10 06:59:18','LIVE',1),(12,2000,20,20.00000,32,39,2,'N','sysadmin','System Configurations','','','','','','DUNSTAN.NESBIT','2013-09-10 06:59:18','SYSAUTH','2013-09-10 06:59:18','LIVE',1),(3,20,0,0.20000,31,68,1,'N','sysadmin','System Administration','','','','','','DUNSTAN.NESBIT','2013-09-10 06:59:18','SYSAUTH','2013-09-10 06:59:18','LIVE',1),(36,100050,1000,1000.50000,3,4,3,'L','useraccount','Message','magicon016.png%IMG%','core_useraccount_message','core_useraccount_message/enquirydefault','vw,nw,cp,iw,as,rj,hd','ls,is,ex','DUNSTAN.NESBIT','2013-09-10 06:59:18','SYSAUTH','2013-09-10 06:59:18','LIVE',1),(5,1000,10,10.00000,2,11,2,'N','useraccount','Messages','','','','','','DUNSTAN.NESBIT','2013-09-10 06:59:18','SYSAUTH','2013-09-10 06:59:18','LIVE',1),(1,10,0,0.10000,1,16,1,'N','useraccount','My Account','','','','','','DUNSTAN.NESBIT','2013-09-10 06:59:18','SYSAUTH','2013-09-10 06:59:18','LIVE',1),(2,15,0,0.15000,17,30,1,'N','useradmin','User Administration','','','','','','ADMIN','2013-09-14 05:15:20','SYSAUTH','2013-09-14 05:15:20','LIVE',1),(6,1001,10,10.01000,12,15,2,'N','useraccount','User','','','','','','ADMIN','2013-09-14 05:15:20','SYSAUTH','2013-09-14 05:15:20','LIVE',1),(40,100150,1001,1001.50000,13,14,3,'L','useraccount','Change Password','magicon016.png%IMG%','core_useraccount_userchangepassword','core_useraccount_userchangepassword/enquirydefault','vw,in,as,rj,va','ls,is','ADMIN','2013-09-14 05:15:20','SYSAUTH','2013-09-14 05:15:20','LIVE',1),(39,100053,1000,1000.53003,9,10,3,'L','useraccount',' ','Sent','','core_useraccount_message/sent','df,ls,is,hs,ex','','ADMIN','2013-09-14 05:15:20','SYSAUTH','2013-09-14 05:15:20','LIVE',1),(37,100051,1000,1000.51001,5,6,3,'L','useraccount',' ','Inbox','','core_useraccount_message/inbox','df,ls,is,hs,ex','','ADMIN','2013-09-14 05:15:20','SYSAUTH','2013-09-14 05:15:20','LIVE',1),(38,100052,1000,1000.52002,7,8,3,'L','useraccount',' ','Drafts','','core_useraccount_message/drafts','df,ls,is,hs,ex','','ADMIN','2013-09-14 05:15:20','SYSAUTH','2013-09-14 05:15:20','LIVE',1),(42,200151,2001,2001.51001,43,44,3,'L','sysadmin','Region','magicon016.png%IMG%','core_sysadmin_region','core_sysadmin_region/enquirydefault','if,vw,nw,cp,in,ao,as,rj,hd,va','ls,is,hs,ex','ADMIN','2013-09-14 05:15:20','SYSAUTH','2013-09-14 05:15:20','LIVE',1),(41,200150,2001,2001.50000,41,42,3,'L','sysadmin','Country','magicon016.png%IMG%','core_sysadmin_country','core_sysadmin_country/enquirydefault','if,vw,nw,cp,in,ao,as,rj,hd,va','ls,is,hs,ex','ADMIN','2013-09-14 05:15:20','SYSAUTH','2013-09-14 05:15:20','LIVE',1),(5,1000,10,10.00000,2,11,2,'N','useraccount','Messages','','','','','','ADMIN','2013-09-14 05:15:20','SYSAUTH','2013-09-14 05:15:20','LIVE',1),(36,100050,1000,1000.50000,3,4,3,'L','useraccount','Message','magicon016.png%IMG%','core_useraccount_message','core_useraccount_message/enquirydefault','vw,nw,cp,iw,as,rj,hd','ls,is,ex','ADMIN','2013-09-14 05:15:20','SYSAUTH','2013-09-14 05:15:20','LIVE',1),(13,2001,20,20.01000,40,45,2,'N','sysadmin','Countries & Regions','','','','','','ADMIN','2013-09-14 05:15:20','SYSAUTH','2013-09-14 05:15:20','LIVE',1),(1,10,0,0.10000,1,16,1,'N','useraccount','My Account','','','','','','ADMIN','2013-09-14 05:15:20','SYSAUTH','2013-09-14 05:15:20','LIVE',1),(35,200052,2000,2000.52002,37,38,3,'L','sysadmin','Department','magicon016.png%IMG%','core_sysadmin_department','core_sysadmin_department/enquirydefault','if,vw,nw,cp,in,ao,as,rj,hd,va','ls,is,hs,ex','ADMIN','2013-09-14 05:15:20','SYSAUTH','2013-09-14 05:15:20','LIVE',1),(34,200051,2000,2000.51001,35,36,3,'L','sysadmin','Branch','magicon016.png%IMG%','core_sysadmin_branch','core_sysadmin_branch/enquirydefault','if,vw,nw,cp,in,ao,as,rj,hd,va','ls,is,hs,ex','ADMIN','2013-09-14 05:15:20','SYSAUTH','2013-09-14 05:15:20','LIVE',1),(33,200050,2000,2000.50000,33,34,3,'L','sysadmin','System Configuration ','magicon016.png%IMG%','core_sysadmin_sysconfig','core_sysadmin_sysconfig/enquirydefault','if,vw,nw,cp,in,ao,as,rj,hd,va','ls,is,hs,ex','ADMIN','2013-09-14 05:15:20','SYSAUTH','2013-09-14 05:15:20','LIVE',1),(12,2000,20,20.00000,32,39,2,'N','sysadmin','System Configurations','','','','','','ADMIN','2013-09-14 05:15:20','SYSAUTH','2013-09-14 05:15:20','LIVE',1),(3,20,0,0.20000,31,68,1,'N','sysadmin','System Administration','','','','','','ADMIN','2013-09-14 05:15:20','SYSAUTH','2013-09-14 05:15:20','LIVE',1),(28,150150,1501,1501.50000,27,28,3,'L','useradmin','Role','magicon016.png%IMG%','core_useradmin_roleadmin','core_useradmin_roleadmin/enquirydefault','if,vw,nw,cp,in,ao,as,rj,hd,va','ls,is,hs,ex','ADMIN','2013-09-14 05:15:20','SYSAUTH','2013-09-14 05:15:20','LIVE',1);
/*!40000 ALTER TABLE `menudefs_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `messages`
--

DROP TABLE IF EXISTS `messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `messages` (
  `id` int(11) unsigned NOT NULL,
  `vw` enum('Y','N') CHARACTER SET utf8 NOT NULL DEFAULT 'N',
  `recipient` varchar(50) NOT NULL,
  `sender` varchar(50) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `body` text NOT NULL,
  `inputter` varchar(50) NOT NULL,
  `input_date` datetime NOT NULL,
  `authorizer` varchar(50) NOT NULL,
  `auth_date` datetime NOT NULL,
  `record_status` char(4) NOT NULL,
  `current_no` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1001 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `messages`
--

LOCK TABLES `messages` WRITE;
/*!40000 ALTER TABLE `messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `messages_hs`
--

DROP TABLE IF EXISTS `messages_hs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `messages_hs` (
  `id` int(11) unsigned NOT NULL,
  `vw` enum('Y','N') CHARACTER SET utf8 NOT NULL DEFAULT 'N',
  `recipient` varchar(50) NOT NULL,
  `sender` varchar(50) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `body` text NOT NULL,
  `inputter` varchar(50) NOT NULL,
  `input_date` datetime NOT NULL,
  `authorizer` varchar(50) NOT NULL,
  `auth_date` datetime NOT NULL,
  `record_status` char(4) NOT NULL,
  `current_no` int(11) NOT NULL,
  PRIMARY KEY (`id`,`current_no`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `messages_hs`
--

LOCK TABLES `messages_hs` WRITE;
/*!40000 ALTER TABLE `messages_hs` DISABLE KEYS */;
/*!40000 ALTER TABLE `messages_hs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `messages_is`
--

DROP TABLE IF EXISTS `messages_is`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `messages_is` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `vw` enum('Y','N') CHARACTER SET utf8 NOT NULL DEFAULT 'N',
  `recipient` varchar(50) DEFAULT NULL,
  `sender` varchar(50) DEFAULT NULL,
  `subject` varchar(255) DEFAULT NULL,
  `body` text,
  `inputter` varchar(50) DEFAULT NULL,
  `input_date` datetime DEFAULT NULL,
  `authorizer` varchar(50) DEFAULT NULL,
  `auth_date` datetime DEFAULT NULL,
  `record_status` char(4) NOT NULL DEFAULT 'IHLD',
  `current_no` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10049 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `messages_is`
--

LOCK TABLES `messages_is` WRITE;
/*!40000 ALTER TABLE `messages_is` DISABLE KEYS */;
/*!40000 ALTER TABLE `messages_is` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ordercancels`
--

DROP TABLE IF EXISTS `ordercancels`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ordercancels` (
  `id` int(11) unsigned NOT NULL DEFAULT '0',
  `ordercancel_id` varchar(16) NOT NULL,
  `order_id` varchar(16) NOT NULL,
  `pre_cancel_status` varchar(20) NOT NULL,
  `reason` varchar(255) NOT NULL,
  `comments` text,
  `inputter` varchar(50) NOT NULL,
  `input_date` datetime NOT NULL,
  `authorizer` varchar(50) NOT NULL,
  `auth_date` datetime NOT NULL,
  `record_status` char(4) NOT NULL,
  `current_no` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_ordercancel_id` (`ordercancel_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ordercancels`
--

LOCK TABLES `ordercancels` WRITE;
/*!40000 ALTER TABLE `ordercancels` DISABLE KEYS */;
/*!40000 ALTER TABLE `ordercancels` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ordercancels_hs`
--

DROP TABLE IF EXISTS `ordercancels_hs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ordercancels_hs` (
  `id` int(11) unsigned NOT NULL DEFAULT '0',
  `ordercancel_id` varchar(16) NOT NULL,
  `order_id` varchar(16) NOT NULL,
  `pre_cancel_status` varchar(20) NOT NULL,
  `reason` varchar(255) NOT NULL,
  `comments` text,
  `inputter` varchar(50) NOT NULL,
  `input_date` datetime NOT NULL,
  `authorizer` varchar(50) NOT NULL,
  `auth_date` datetime NOT NULL,
  `record_status` char(4) NOT NULL,
  `current_no` int(11) NOT NULL,
  PRIMARY KEY (`id`,`current_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ordercancels_hs`
--

LOCK TABLES `ordercancels_hs` WRITE;
/*!40000 ALTER TABLE `ordercancels_hs` DISABLE KEYS */;
/*!40000 ALTER TABLE `ordercancels_hs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ordercancels_is`
--

DROP TABLE IF EXISTS `ordercancels_is`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ordercancels_is` (
  `id` int(11) unsigned NOT NULL DEFAULT '0',
  `ordercancel_id` varchar(16) DEFAULT NULL,
  `order_id` varchar(16) DEFAULT NULL,
  `pre_cancel_status` varchar(20) DEFAULT NULL,
  `reason` varchar(255) DEFAULT NULL,
  `comments` text,
  `inputter` varchar(50) DEFAULT NULL,
  `input_date` datetime DEFAULT NULL,
  `authorizer` varchar(50) DEFAULT NULL,
  `auth_date` datetime DEFAULT NULL,
  `record_status` char(4) DEFAULT NULL,
  `current_no` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_ordercancel_id` (`ordercancel_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ordercancels_is`
--

LOCK TABLES `ordercancels_is` WRITE;
/*!40000 ALTER TABLE `ordercancels_is` DISABLE KEYS */;
/*!40000 ALTER TABLE `ordercancels_is` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orderdetails`
--

DROP TABLE IF EXISTS `orderdetails`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `orderdetails` (
  `id` int(11) unsigned NOT NULL,
  `order_id` varchar(20) NOT NULL,
  `product_id` varchar(50) NOT NULL,
  `qty` int(11) unsigned NOT NULL,
  `unit_price` float(16,2) NOT NULL,
  `tax_percentage` float(4,2) NOT NULL,
  `taxable` enum('Y','N') NOT NULL,
  `discount_amount` float(16,2) NOT NULL,
  `discount_type` enum('DOLLAR','PERCENT') NOT NULL,
  `description` text NOT NULL,
  `description_type` enum('STANDARD','EXTENDED') NOT NULL,
  `user_text` varchar(255) DEFAULT NULL,
  `inventory_update` enum('STANDARD','RESERVE','BACKORDER','NONE') NOT NULL,
  `inputter` varchar(50) NOT NULL,
  `input_date` datetime NOT NULL,
  `authorizer` varchar(50) NOT NULL,
  `auth_date` datetime NOT NULL,
  `record_status` char(4) NOT NULL,
  `current_no` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orderdetails`
--

LOCK TABLES `orderdetails` WRITE;
/*!40000 ALTER TABLE `orderdetails` DISABLE KEYS */;
/*!40000 ALTER TABLE `orderdetails` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orderdetails_hs`
--

DROP TABLE IF EXISTS `orderdetails_hs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `orderdetails_hs` (
  `id` int(11) unsigned NOT NULL,
  `order_id` varchar(20) NOT NULL,
  `product_id` varchar(50) NOT NULL,
  `qty` int(11) unsigned NOT NULL,
  `unit_price` float(16,2) NOT NULL,
  `tax_percentage` float(4,2) NOT NULL,
  `taxable` enum('Y','N') NOT NULL,
  `discount_amount` float(16,2) NOT NULL,
  `discount_type` enum('DOLLAR','PERCENT') NOT NULL,
  `description` text,
  `description_type` enum('STANDARD','EXTENDED') NOT NULL,
  `user_text` varchar(255) DEFAULT NULL,
  `inventory_update` enum('STANDARD','RESERVE','BACKORDER','NONE') NOT NULL,
  `inputter` varchar(50) NOT NULL,
  `input_date` datetime NOT NULL,
  `authorizer` varchar(50) NOT NULL,
  `auth_date` datetime NOT NULL,
  `record_status` char(4) NOT NULL,
  `current_no` int(11) NOT NULL,
  PRIMARY KEY (`id`,`current_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orderdetails_hs`
--

LOCK TABLES `orderdetails_hs` WRITE;
/*!40000 ALTER TABLE `orderdetails_hs` DISABLE KEYS */;
/*!40000 ALTER TABLE `orderdetails_hs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orderdetails_is`
--

DROP TABLE IF EXISTS `orderdetails_is`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `orderdetails_is` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `order_id` varchar(20) DEFAULT NULL,
  `product_id` varchar(50) DEFAULT NULL,
  `qty` int(11) unsigned DEFAULT '0',
  `unit_price` float(16,2) DEFAULT '0.00',
  `tax_percentage` float(4,2) DEFAULT '0.00',
  `taxable` enum('Y','N') DEFAULT 'Y',
  `discount_amount` float(16,2) DEFAULT '0.00',
  `discount_type` enum('DOLLAR','PERCENT') DEFAULT 'DOLLAR',
  `description` text,
  `description_type` enum('STANDARD','EXTENDED') DEFAULT 'STANDARD',
  `user_text` varchar(255) DEFAULT NULL,
  `inventory_update` enum('STANDARD','RESERVE','BACKORDER','NONE') DEFAULT 'STANDARD',
  `inputter` varchar(50) DEFAULT NULL,
  `input_date` datetime DEFAULT NULL,
  `authorizer` varchar(50) DEFAULT NULL,
  `auth_date` datetime DEFAULT NULL,
  `record_status` char(4) DEFAULT NULL,
  `current_no` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orderdetails_is`
--

LOCK TABLES `orderdetails_is` WRITE;
/*!40000 ALTER TABLE `orderdetails_is` DISABLE KEYS */;
/*!40000 ALTER TABLE `orderdetails_is` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orderopens`
--

DROP TABLE IF EXISTS `orderopens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `orderopens` (
  `id` int(11) unsigned NOT NULL DEFAULT '0',
  `orderopen_id` varchar(16) NOT NULL,
  `order_id` varchar(16) NOT NULL,
  `pre_open_status` varchar(20) NOT NULL,
  `reason` varchar(255) NOT NULL,
  `comments` text,
  `inputter` varchar(50) NOT NULL,
  `input_date` datetime NOT NULL,
  `authorizer` varchar(50) NOT NULL,
  `auth_date` datetime NOT NULL,
  `record_status` char(4) NOT NULL,
  `current_no` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_orderopen_id` (`orderopen_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orderopens`
--

LOCK TABLES `orderopens` WRITE;
/*!40000 ALTER TABLE `orderopens` DISABLE KEYS */;
/*!40000 ALTER TABLE `orderopens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orderopens_hs`
--

DROP TABLE IF EXISTS `orderopens_hs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `orderopens_hs` (
  `id` int(11) unsigned NOT NULL DEFAULT '0',
  `orderopen_id` varchar(16) NOT NULL,
  `order_id` varchar(16) NOT NULL,
  `pre_open_status` varchar(20) NOT NULL,
  `reason` varchar(255) NOT NULL,
  `comments` text,
  `inputter` varchar(50) NOT NULL,
  `input_date` datetime NOT NULL,
  `authorizer` varchar(50) NOT NULL,
  `auth_date` datetime NOT NULL,
  `record_status` char(4) NOT NULL,
  `current_no` int(11) NOT NULL,
  PRIMARY KEY (`id`,`current_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orderopens_hs`
--

LOCK TABLES `orderopens_hs` WRITE;
/*!40000 ALTER TABLE `orderopens_hs` DISABLE KEYS */;
/*!40000 ALTER TABLE `orderopens_hs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orderopens_is`
--

DROP TABLE IF EXISTS `orderopens_is`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `orderopens_is` (
  `id` int(11) unsigned NOT NULL DEFAULT '0',
  `orderopen_id` varchar(16) DEFAULT NULL,
  `order_id` varchar(16) DEFAULT NULL,
  `pre_open_status` varchar(20) DEFAULT NULL,
  `reason` varchar(255) DEFAULT NULL,
  `comments` text,
  `inputter` varchar(50) DEFAULT NULL,
  `input_date` datetime DEFAULT NULL,
  `authorizer` varchar(50) DEFAULT NULL,
  `auth_date` datetime DEFAULT NULL,
  `record_status` char(4) DEFAULT NULL,
  `current_no` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_orderopen_id` (`orderopen_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orderopens_is`
--

LOCK TABLES `orderopens_is` WRITE;
/*!40000 ALTER TABLE `orderopens_is` DISABLE KEYS */;
/*!40000 ALTER TABLE `orderopens_is` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `orders` (
  `id` int(11) unsigned NOT NULL,
  `order_id` varchar(20) NOT NULL,
  `branch_id` varchar(50) NOT NULL,
  `customer_id` varchar(8) NOT NULL,
  `is_co` enum('N','Y') NOT NULL,
  `cc_id` varchar(8) DEFAULT NULL,
  `order_status` varchar(20) NOT NULL,
  `order_details` text NOT NULL,
  `order_date` date NOT NULL,
  `quotation_date` date NOT NULL,
  `invoice_date` date NOT NULL,
  `status_change_date` date NOT NULL,
  `inventory_checkout_type` enum('AUTO','MANUAL') NOT NULL,
  `inventory_update_type` enum('SALE','LOAN') DEFAULT NULL,
  `inventory_checkout_status` enum('NONE','PARTIAL','COMPLETED') NOT NULL,
  `invoice_note` varchar(256) DEFAULT NULL,
  `comments` text,
  `inputter` varchar(50) NOT NULL,
  `input_date` datetime NOT NULL,
  `authorizer` varchar(50) NOT NULL,
  `auth_date` datetime NOT NULL,
  `record_status` char(4) NOT NULL,
  `current_no` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_order_id` (`order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders`
--

LOCK TABLES `orders` WRITE;
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orders_hs`
--

DROP TABLE IF EXISTS `orders_hs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `orders_hs` (
  `id` int(11) unsigned NOT NULL,
  `order_id` varchar(20) NOT NULL,
  `branch_id` varchar(50) NOT NULL,
  `customer_id` varchar(8) NOT NULL,
  `is_co` enum('N','Y') NOT NULL,
  `cc_id` varchar(8) DEFAULT NULL,
  `order_status` varchar(20) NOT NULL,
  `order_details` text NOT NULL,
  `order_date` date NOT NULL,
  `quotation_date` date NOT NULL,
  `invoice_date` date NOT NULL,
  `status_change_date` date NOT NULL,
  `inventory_checkout_type` enum('AUTO','MANUAL') NOT NULL,
  `inventory_update_type` enum('SALE','LOAN') DEFAULT NULL,
  `inventory_checkout_status` enum('NONE','PARTIAL','COMPLETED') NOT NULL,
  `invoice_note` varchar(256) DEFAULT NULL,
  `comments` text,
  `inputter` varchar(50) NOT NULL,
  `input_date` datetime NOT NULL,
  `authorizer` varchar(50) NOT NULL,
  `auth_date` datetime NOT NULL,
  `record_status` char(4) NOT NULL,
  `current_no` int(11) NOT NULL,
  PRIMARY KEY (`id`,`current_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders_hs`
--

LOCK TABLES `orders_hs` WRITE;
/*!40000 ALTER TABLE `orders_hs` DISABLE KEYS */;
/*!40000 ALTER TABLE `orders_hs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orders_is`
--

DROP TABLE IF EXISTS `orders_is`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `orders_is` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `order_id` varchar(20) DEFAULT NULL,
  `branch_id` varchar(50) DEFAULT NULL,
  `customer_id` varchar(8) DEFAULT NULL,
  `is_co` enum('N','Y') DEFAULT 'N',
  `cc_id` varchar(8) DEFAULT NULL,
  `order_status` varchar(20) DEFAULT 'NEW',
  `order_details` text,
  `order_date` date DEFAULT NULL,
  `quotation_date` date DEFAULT NULL,
  `invoice_date` date DEFAULT '1901-12-14',
  `status_change_date` date DEFAULT NULL,
  `inventory_checkout_type` enum('AUTO','MANUAL') DEFAULT 'AUTO',
  `inventory_update_type` enum('SALE','LOAN') DEFAULT 'SALE',
  `inventory_checkout_status` enum('NONE','PARTIAL','COMPLETED') DEFAULT 'NONE',
  `invoice_note` varchar(256) DEFAULT NULL,
  `comments` text,
  `inputter` varchar(50) DEFAULT NULL,
  `input_date` datetime DEFAULT NULL,
  `authorizer` varchar(50) DEFAULT NULL,
  `auth_date` datetime DEFAULT NULL,
  `record_status` char(4) DEFAULT NULL,
  `current_no` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_order_id` (`order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders_is`
--

LOCK TABLES `orders_is` WRITE;
/*!40000 ALTER TABLE `orders_is` DISABLE KEYS */;
/*!40000 ALTER TABLE `orders_is` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `params`
--

DROP TABLE IF EXISTS `params`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `params` (
  `id` int(11) unsigned NOT NULL,
  `param_id` varchar(255) DEFAULT NULL,
  `controller` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `dflag` enum('Y','N') DEFAULT NULL,
  `formfields` text,
  `module` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `auth_mode_on` tinyint(1) NOT NULL DEFAULT '1',
  `index_field_on` tinyint(1) NOT NULL DEFAULT '1',
  `indexview` varchar(255) CHARACTER SET latin1 DEFAULT 'default_index',
  `viewview` varchar(255) CHARACTER SET latin1 DEFAULT 'default_view',
  `inputview` varchar(255) CHARACTER SET latin1 DEFAULT 'default_input',
  `authorizeview` varchar(255) CHARACTER SET latin1 DEFAULT 'default_authorize',
  `deleteview` varchar(255) CHARACTER SET latin1 DEFAULT 'default_delete',
  `enquiryview` varchar(255) CHARACTER SET latin1 DEFAULT 'default_enquiry',
  `indexfield` varchar(255) CHARACTER SET latin1 NOT NULL DEFAULT 'id' COMMENT 'name of field on indexview',
  `indexfieldvalue` varchar(255) CHARACTER SET latin1 DEFAULT NULL COMMENT 'value of field on indexview',
  `indexlabel` varchar(255) DEFAULT 'Id' COMMENT 'name of field on indexview',
  `appheader` varchar(255) CHARACTER SET latin1 DEFAULT NULL COMMENT 'name of app, usually backend table',
  `primarymodel` varchar(255) DEFAULT 'Model_SiteDB',
  `tb_live` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `tb_inau` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `tb_hist` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `errormsgfile` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `inputter` varchar(50) CHARACTER SET latin1 DEFAULT NULL,
  `input_date` datetime DEFAULT NULL,
  `authorizer` varchar(50) CHARACTER SET latin1 DEFAULT NULL,
  `auth_date` datetime DEFAULT NULL,
  `record_status` char(4) CHARACTER SET latin1 DEFAULT NULL,
  `current_no` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`,`indexfield`),
  UNIQUE KEY `id` (`id`),
  UNIQUE KEY `uniq_param_id` (`param_id`),
  KEY `controller` (`controller`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `params`
--

LOCK TABLES `params` WRITE;
/*!40000 ALTER TABLE `params` DISABLE KEYS */;
INSERT INTO `params` VALUES (1,'core_core_site','site','Y','<?xml version=\'1.0\' standalone=\'yes\'?>','core',1,1,'default_index','default_view','default_input','default_authorize','default_delete','default_enquiry','','',NULL,NULL,'Model_SiteDB',NULL,NULL,NULL,NULL,'IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(2,'core_useraccount_message','message','Y','<?xml version=\'1.0\' standalone=\'yes\'?>\r\n<formfields>\r\n	<field><name>id</name><label>Id</label><type>hidden</type><value></value><options></options><onnew>enabled</onnew><onedit>enabled</onedit></field>\r\n	<field><name>vw</name><label>Message Read</label><type>hidden</type><value></value><options></options><onnew>enabled</onnew><onedit>enabled</onedit></field>\r\n	<field>\r\n		<name>recipient</name><label>To</label><type>input</type><value></value><options>size=50 maxlength=50 onFocus=sideinfo.Update(%FIELDS%,%TABLE%,%IDFIELD%,%RETFIELD%,%FORMAT%) onKeyUp=sideinfo.Update(%FIELDS%,%TABLE%,%IDFIELD%,%RETFIELD%,%FORMAT%)</options>\r\n		<onnew>readonly_po</onnew><onedit>readonly</onedit>\r\n		<popout><enable>yes</enable><table>vw_userbranches</table><selectfields>idname,fullname</selectfields><idfield>idname</idfield></popout>\r\n		<sideinfo>\r\n			<enable>yes</enable><table>users</table><selectfields>fullname</selectfields><idfield>idname</idfield><format>*</format>\r\n		</sideinfo>		\r\n	</field>\r\n	<field><name>sender</name><label>From</label><type>input</type><value></value><options>size=50 maxlength=50</options><onnew>readonly</onnew><onedit>readonly</onedit></field>\r\n	<field><name>subject</name><label>Subject</label><type>input</type><value></value><options>size=50 maxlength=100</options><onnew>enabled</onnew><onedit>readonly</onedit></field>\r\n	<field><name>body</name><label>Message</label><type>textarea</type><value></value><options>rows=5 cols=80</options><onnew>enabled</onnew><onedit>readonly</onedit></field>\r\n</formfields>\r\n','useraccount',1,1,'default_index','default_view','default_input','default_authorize','default_delete','default_enquiry','id',NULL,'Id','Message','Model_SiteDB','messages','messages_is','messages_hs','message_error','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(3,'core_useradmin_useradmin','useradmin','Y','<?xml version=\'1.0\' standalone=\'yes\'?>\r\n<formfields>\r\n	<field><name>id</name><label>Id</label><type>hidden</type><value></value><options></options><onnew>enabled</onnew><onedit>enabled</onedit></field>\r\n	<field><name>idname</name><label>User Id</label><type>input</type><value></value><options>size=50 maxlength=50</options><onnew>enabled_po</onnew><onedit>readonly</onedit></field>\r\n	<field><name>username</name><label>Signon Name</label><type>input</type><value></value><options>size=32 maxlength=32</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\r\n	<field><name>fullname</name><label>Full Name</label><type>input</type><value></value><options>size=50 maxlength=255</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\r\n	<field><name>email</name><label>Email</label><type>input</type><value></value><options>size=50 maxlength=100</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\r\n	<field><name>enabled</name><label>Enabled</label><type>dropdown</type><value></value><options>Y,N::Y,N</options><onnew></onnew><onedit></onedit></field>\r\n	<field><name>expiry_date</name><label>Expiry Date</label><type>date</type><value>2037/12/31</value><options></options><onnew>enabled_po</onnew><onedit>enabled_po</onedit></field>\r\n	<field><name>branch_id</name><label>Branch Id</label><type>input</type><value></value><options>size=50 onFocus=sideinfo.Update(%FIELDS%,%TABLE%,%IDFIELD%,%RETFIELD%,%FORMAT%) onKeyUp=sideinfo.Update(%FIELDS%,%TABLE%,%IDFIELD%,%RETFIELD%,%FORMAT%)</options>\r\n		<onnew>readonly_po</onnew><onedit>readonly_po</onedit>\r\n		<popout><enable>yes</enable><table>branches</table><selectfields>id,branch_id,description,location,active</selectfields><idfield>branch_id</idfield></popout>\r\n		<sideinfo>\r\n			<enable>yes</enable><table>branches</table><selectfields>description</selectfields><idfield>branch_id</idfield><format>*</format>\r\n		</sideinfo>\r\n	</field>\r\n	<field><name>department_id</name><label>Department Id</label><type>input</type><value></value><options>size=50 onFocus=sideinfo.Update(%FIELDS%,%TABLE%,%IDFIELD%,%RETFIELD%,%FORMAT%) onKeyUp=sideinfo.Update(%FIELDS%,%TABLE%,%IDFIELD%,%RETFIELD%,%FORMAT%)</options>\r\n		<onnew>readonly_po</onnew><onedit>readonly_po</onedit>\r\n		<popout><enable>yes</enable><table>departments</table><selectfields>id,department_id,description</selectfields><idfield>department_id</idfield></popout>\r\n		<sideinfo>\r\n			<enable>yes</enable><table>departments</table><selectfields>description</selectfields><idfield>department_id</idfield><format>*</format>\r\n		</sideinfo>\r\n	</field>\r\n	<field><name>password</name><label>Password</label><type>hidden</type><value></value><options></options><onnew>readonly</onnew><onedit>readonly</onedit></field>\r\n	<field><name>logins</name><label>Logins</label><type>hidden</type><value></value><options></options><onnew>readonly</onnew><onedit>readonly</onedit></field>\r\n	<field><name>last_login</name><label>Last Login</label><type>hidden</type><value></value><options></options><onnew>readonly</onnew><onedit>readonly</onedit></field>\r\n</formfields>\r\n','useradmin',1,1,'default_index','default_view','default_input','default_authorize','default_delete','default_enquiry','username','','Signon Name','User Administration (User)','Model_SiteDB','users','users_is','users_hs','useradmin_error','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(4,'core_useradmin_userpasswdreset','userpasswdreset','Y','<?xml version=\'1.0\' standalone=\'yes\'?>\r\n<formfields>\r\n	<field><name>id</name><label>Id</label><type>hidden</type><value></value><options>size=0 maxlength=10</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\r\n	<field><name>idname</name><label>User Id</label><type>hidden</type><value></value><options>size=0 maxlength=10</options><onnew>readonly</onnew><onedit>readonly</onedit></field>\r\n	<field><name>username</name><label>Signon Name</label><type>hidden</type><value></value><options>size=0 maxlength=10</options><onnew>readonly</onnew><onedit>readonly</onedit></field>\r\n	<field><name>password</name><label>Password</label><type>password</type><value></value><options>size=20 maxlength=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\r\n</formfields>\r\n','useradmin',1,1,'default_index','default_view','default_input','default_authorize','default_delete','default_enquiry','username','','Signon Name','User Password Reset','Model_SiteDB','users','users_is','users_hs','userpasswdreset_error','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(5,'core_useradmin_userrole','userrole','Y','<?xml version=\'1.0\' standalone=\'yes\'?>\r\n<formfields>\r\n	<field><name>id</name><label>Id</label><type>hidden</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\r\n	<field>\r\n		<name>idname</name><label>User Id</label><type>input</type><value></value><options>size=50</options><onnew>readonly_po</onnew><onedit>readonly</onedit>\r\n		<popout><enable>yes</enable><table>vw_core_users_noroles</table><selectfields>idname,fullname</selectfields><idfield>idname</idfield></popout>\r\n	</field>\r\n	<field><name>roles</name><label>Roles</label><type>textarea</type><value></value><options>rows=5 cols=80</options><onnew>readonly</onnew><onedit>readonly</onedit></field>\r\n</formfields>\r\n','useradmin',1,1,'default_index','default_view','default_input','default_authorize','default_delete','default_enquiry','idname','','User Id','User Roles','Model_SiteDB','userroles','userroles_is','userroles_hs','userrole_error','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(6,'core_developer_param','param','Y','<?xml version=\'1.0\' standalone=\'yes\'?>\n<formfields>\n	<field><name>id</name><label>Id</label><type>hidden</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>param_id</name><label>Param Id</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\r\n	<field><name>controller</name><label>Controller</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>dflag</name><label>DFlag</label><type>dropdown</type><value></value><options>Y,N::Y,N</options><onnew></onnew><onedit></onedit></field>\r\n	<field><name>formfields</name><label>Formfields</label><type>textarea</type><value></value><options>rows=1 cols=50</options><onnew>readonly</onnew><onedit>readonly</onedit></field>\r\n	<field><name>module</name><label>Module</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>auth_mode_on</name><label>Auth Mode On</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>index_field_on</name><label>Index Field On</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>indexview</name><label>Index View</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>viewview</name><label>View View</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>inputview</name><label>Input View</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>authorizeview</name><label>Authorize View</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>deleteview</name><label>Delete View</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>enquiryview</name><label>Enquiry View</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>indexfield</name><label>Index Field</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>indexfieldvalue</name><label>Index Field Value</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>indexlabel</name><label>Index Label</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>appheader</name><label>App Header</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>primarymodel</name><label>Primary Model</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>tb_live</name><label>Table(live)</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>tb_inau</name><label>Table(inau)</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>tb_hist</name><label>Table(hist)</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>errormsgfile</name><label>Error Message File</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n</formfields>\n','developer',1,1,'default_index','default_view','default_input','default_authorize','default_delete','default_enquiry','param_id','','Param Id','Param Definition','Model_SiteDB','params','params_is','params_hs','param_error','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(7,'core_developer_formdef','formdef','Y','<?xml version=\'1.0\' standalone=\'yes\'?>\n<formfields>\n	<field><name>id</name><label>Id</label><type>hidden</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>readonly</onedit></field>\n	<field><name>param_id</name><label>Param Id</label><type>input</type><value></value><options>size=50</options><onnew>readonly</onnew><onedit>readonly</onedit></field>\r\n	<field><name>formfields</name><label>Formfields</label><type>textarea</type><value></value><options>rows=20 cols=120</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n</formfields>\n','developer',1,1,'default_index','default_view','default_input','default_authorize','default_delete','default_enquiry','controller','','Form Id','Form Definition','Model_SiteDB','params','params_is','params_hs','formdef_error','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(8,'core_developer_menudef','menudef','Y','<?xml version=\'1.0\' standalone=\'yes\'?>\n<formfields>\r\n	<field><name>id</name><label>Id</label><type>hidden</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\r\n	<field><name>menu_id</name><label>Menu Id</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\r\n	<field><name>parent_id</name><label>Parent Id</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\r\n	<field><name>sortpos</name><label>Sort Position</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\r\n	<field><name>nleft</name><label>Nleft</label><type>hidden</type><value></value><options>size=50</options><onnew>disabled</onnew><onedit>disabled</onedit></field>\r\n	<field><name>nright</name><label>Nright</label><type>hidden</type><value></value><options>size=50</options><onnew>disabled</onnew><onedit>disabled</onedit></field>\r\n	<field><name>nlevel</name><label>Nlevel</label><type>hidden</type><value></value><options>size=50</options><onnew>disabled</onnew><onedit>disabled</onedit></field>\r\n	<field><name>node_or_leaf</name><label>Node Or Leaf</label><type>dropdown</type><value></value><options>L,N::L,N</options><onnew></onnew><onedit></onedit></field>\r\n	<field><name>module</name><label>Module</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\r\n	<field><name>label_input</name><label>Label (Input)</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\r\n	<field><name>label_enquiry</name><label>Label (Enquiry)</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\r\n	<field><name>url_input</name><label>Url (Input)</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\r\n	<field><name>url_enquiry</name><label>Url (Enquiry)</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\r\n	<field><name>controls_input</name><label>Controls (Input)</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\r\n	<field><name>controls_enquiry</name><label>Controls (Enquiry)</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\r\n</formfields>','developer',1,1,'default_index','default_view','default_input','default_authorize','default_delete','default_enquiry','id','','Menu Id','Menu Definition','Model_SiteDB','menudefs','menudefs_is','menudefs_hs','menudef_error','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(9,'core_sysadmin_recordlock','recordlock','Y','<?xml version=\'1.0\' standalone=\'yes\'?>\r\n<formfields>\r\n	<field><name>id</name><label>Id</label><type>hidden</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\r\n	<field><name>idname</name><label>User Id</label><type>hidden</type><value></value><options>size=50</options><onnew>readonly</onnew><onedit>disabled</onedit></field>\r\n	<field><name>lock_table</name><label>Table</label><type>hidden</type><value></value><options>size=50</options><onnew>readonly</onnew><onedit>readonly</onedit></field>\r\n	<field><name>record_id</name><label>Locked Record</label><type>hidden</type><value></value><options>size=50</options><onnew>readonly</onnew><onedit>readonly</onedit></field>\r\n	<field><name>pre_status</name><label>Pre-Locked Status</label><type>hidden</type><value></value><options>size=50</options><onnew>readonly</onnew><onedit>readonly</onedit></field>\r\n</formfields>','sysadmin',1,1,'default_index','default_view','default_input','default_authorize','default_delete','default_enquiry','id','','Id','Record Lock','Model_SiteDB','recordlocks','recordlocks','recordlocks','recordlock_error','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(10,'core_useradmin_roleadmin','roleadmin','Y','<?xml version=\'1.0\' standalone=\'yes\'?>\n<formfields>\n	<field><name>id</name><label>Id</label><type>hidden</type><value></value><options></options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>name</name><label>Role Name</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>readonly</onedit></field>\n	<field><name>description</name><label>Description</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>securityprofile</name><label>Security Profile</label><type>textarea</type><value></value><options>rows=25 cols=120</options><onnew>readonly</onnew><onedit>readonly</onedit></field>\n</formfields>\n','useradmin',1,1,'default_index','default_view','default_input','default_authorize','default_delete','default_enquiry','name','','Role Id','Role Administration (Role)','Model_SiteDB','roles','roles_is','roles_hs','roleadmin_error','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(11,'core_sysadmin_country','country','Y','<?xml version=\'1.0\' standalone=\'yes\'?>\n<formfields>\n	<field><name>id</name><label>Id</label><type>hidden</type><value></value><options></options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>country_id</name><label>Country Id</label><type>input</type><value></value><options>size=3 maxlength=3</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>common_name</name><label>Common Name</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>formal_name</name><label>Formal Name</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>capital</name><label>Capital</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>type</name><label>Type</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>sub_type</name><label>Sub Type</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>sovereignty</name><label>Sovereignty</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>currency_code</name><label>Currency Code</label><type>input</type><value></value><options>size=3 maxlength=3</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>currency_name</name><label>Currency Name</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>telephone_code</name><label>Telephone Code</label><type>input</type><value></value><options>size=4 maxlength=4</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>iana_country_code</name><label>IANA Country Code</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n</formfields>\n','sysadmin',1,1,'default_index','default_view','default_input','default_authorize','default_delete','default_enquiry','country_id','','Country Id','Country','Model_SiteDB','countrys','countrys_is','countrys_hs','country_error','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(12,'core_sysadmin_weekday','weekday','Y','<?xml version=\'1.0\' standalone=\'yes\'?>\n<formfields>\n	<field><name>id</name><label>Id</label><type>hidden</type><value></value><options></options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>weekday_id</name><label>Weekday Id</label><type>input</type><value></value><options>size=12</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n</formfields>\n','sysadmin',1,1,'default_index','default_view','default_input','default_authorize','default_delete','default_enquiry','weekday_id','','Weekday Id','Weekday','Model_SiteDB','weekdays','weekdays_is','weekdays_hs','weekday_error','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(13,'core_sysadmin_daytime','daytime','Y','<?xml version=\'1.0\' standalone=\'yes\'?>\n<formfields>\n	<field><name>id</name><label>Id</label><type>hidden</type><value></value><options></options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>daytime_id</name><label>Daytime Id</label><type>input</type><value></value><options>size=7</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>description</name><label>Description</label><type>input</type><value></value><options>size=25</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n</formfields>\n','sysadmin',1,1,'default_index','default_view','default_input','default_authorize','default_delete','default_enquiry','daytime_id','','Daytime Id','Daytime','Model_SiteDB','daytimes','daytimes_is','daytimes_hs','daytime_error','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(14,'core_sysadmin_recurrence','recurrence','Y','<?xml version=\'1.0\' standalone=\'yes\'?>\n<formfields>\n	<field><name>id</name><label>Id</label><type>hidden</type><value></value><options></options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>recurrence_id</name><label>Recurrence Id</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>description</name><label>Description</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n</formfields>\n','sysadmin',1,1,'default_index','default_view','default_input','default_authorize','default_delete','default_enquiry','recurrence_id','','Recurrence Id','Recurrence','Model_SiteDB','recurrences','recurrences_is','recurrences_hs','recurrence_error','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(15,'core_sysadmin_branch','branch','Y','<?xml version=\'1.0\' standalone=\'yes\'?>\n<formfields>\n	<field><name>id</name><label>Id</label><type>hidden</type><value></value><options></options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>branch_id</name><label>Branch Id</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>description</name><label>Description</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>location</name><label>Location</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>region_id</name><label>Region Id</label><type>input</type><value></value><options>size=2 maxlength=2 onFocus=sideinfo.Update(%FIELDS%,%TABLE%,%IDFIELD%,%RETFIELD%,%FORMAT%) onKeyUp=sideinfo.Update(%FIELDS%,%TABLE%,%IDFIELD%,%RETFIELD%,%FORMAT%)</options>\r\n		<onnew>readonly_po</onnew><onedit>readonly_po</onedit>\r\n		<popout><enable>yes</enable><table>regions</table><selectfields>id,area,region</selectfields><idfield>id</idfield></popout>\r\n		<sideinfo>\r\n			<enable>yes</enable><table>regions</table><selectfields>area,region</selectfields><idfield>id</idfield><format>*;_*</format>\r\n		</sideinfo>\r\n	</field>\r\n	<field><name>active</name><label>Active</label><type>dropdown</type><value></value><options>Y,N::Y,N</options><onnew></onnew><onedit></onedit></field>\r\n</formfields>\n','sysadmin',1,1,'default_index','default_view','default_input','default_authorize','default_delete','default_enquiry','branch_id','','Branch Id','Branch','Model_SiteDB','branches','branches_is','branches_hs','branch_error','IMPLEMENTATION','2011-04-13 15:04:26','ADMIN','2011-04-13 15:26:21','LIVE',1),(16,'core_sysadmin_region','region','Y','<?xml version=\'1.0\' standalone=\'yes\'?>\n<formfields>\n	<field><name>id</name><label>Id</label><type>hidden</type><value></value><options></options><onnew>enabled</onnew><onedit>enabled</onedit></field>\r\n	<field><name>area</name><label>Area</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\r\n	<field><name>sub_region</name><label>Sub Region</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\r\n	<field><name>region</name><label>Region</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\r\n	<field>\r\n		<name>country_id</name><label>Country Id</label><type>input</type><value></value><options>size=2 maxlength=2 onFocus=sideinfo.Update(%FIELDS%,%TABLE%,%IDFIELD%,%RETFIELD%,%FORMAT%) onKeyUp=sideinfo.Update(%FIELDS%,%TABLE%,%IDFIELD%,%RETFIELD%,%FORMAT%)</options>\r\n		<onnew>readonly_po</onnew><onedit>readonly_po</onedit>\r\n		<popout><enable>yes</enable><table>countrys</table><selectfields>country_id,common_name,capital,currency_code</selectfields><idfield>country_id</idfield></popout>\r\n		<sideinfo>\r\n			<enable>yes</enable><table>countrys</table><selectfields>common_name</selectfields><idfield>country_id</idfield><format>*</format>\r\n		</sideinfo>		\r\n	</field>\r\n</formfields>\n','sysadmin',1,1,'default_index','default_view','default_input','default_authorize','default_delete','default_enquiry','id','','Region Id','Region','Model_SiteDB','regions','regions_is','regions_is','region_error','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(17,'core_sysadmin_department','department','Y','<?xml version=\'1.0\' standalone=\'yes\'?>\n<formfields>\n	<field><name>id</name><label>Id</label><type>hidden</type><value></value><options></options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>department_id</name><label>Department Id</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>description</name><label>Description</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n</formfields>\n','sysadmin',1,1,'default_index','default_view','default_input','default_authorize','default_delete','default_enquiry','department_id','','Department Id','Department','Model_SiteDB','departments','departments_is','departments_hs','department_error','IMPLEMENTATION','2011-04-28 03:04:31','ADMIN','2011-04-28 03:23:54','LIVE',1),(18,'core_developer_enqdef','enqdef','Y','<?xml version=\'1.0\' standalone=\'yes\'?>\n<formfields>\n	<field><name>id</name><label>Id</label><type>hidden</type><value></value><options></options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>enquirydef_id</name><label>Enquirydef Id</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\r\n	<field><name>controller</name><label>Controller</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>dflag</name><label>DFlag</label><type>dropdown</type><value></value><options>Y,N::Y,N</options><onnew></onnew><onedit></onedit></field>\r\n	<field><name>formfields</name><label>Formfields</label><type>textarea</type><value></value><options>rows=30 cols=120</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\r\n	<field><name>tablename</name><label>Tablename</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>model</name><label>Model</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>view</name><label>View</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>idfield</name><label>Id Field</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\r\n	<field><name>enqheader</name><label>Enquiry Header</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\r\n	<field><name>showfilter</name><label>Show Filter</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>printuser</name><label>Print Username</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>printdatetime</name><label>Print Datetime</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n</formfields>\n','developer',1,1,'default_index','default_view','default_input','default_authorize','default_delete','default_enquiry','enquirydef_id','','Enquirydef Id','Enquiry Definition','Model_SiteDB','enquirydefs','enquirydefs_is','enquirydefs_hs','enquirydef_error','IMPLEMENTATION','2011-04-28 03:04:09','ADMIN','2011-04-28 03:24:04','LIVE',1),(19,'core_sysadmin_pdf','pdf','Y','<?xml version=\'1.0\' standalone=\'yes\'?>\n<formfields>\n	<field><name>id</name><label>Id</label><type>hidden</type><value></value><options></options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>pdf_id</name><label>Pdf Id</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>readonly</onedit></field>\n	<field><name>controller</name><label>Controller</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>readonly</onedit></field>\n	<field><name>type</name><label>Type</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>readonly</onedit></field>\n	<field><name>html</name><label>HTML</label><type>textarea</type><value></value><options>rows=20 cols=120</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\r\n</formfields>\n','sysadmin',1,1,'default_index','default_view','default_input','default_authorize','default_delete','default_enquiry','pdf_id','','Pdf Id','Pdf','Model_SiteDB','pdfs','pdfs_is','pdfs_hs','pdf_error','IMPLEMENTATION','2011-05-03 22:05:05','ADMIN','2011-05-03 22:14:35','LIVE',1),(20,'core_sysadmin_csv','csv','Y','<?xml version=\'1.0\' standalone=\'yes\'?>\n<formfields>\n	<field><name>id</name><label>Id</label><type>hidden</type><value></value><options></options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>csv_id</name><label>Csv Id</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>readonly</onedit></field>\n	<field><name>controller</name><label>Controller</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>readonly</onedit></field>\n	<field><name>type</name><label>Type</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>readonly</onedit></field>\n	<field><name>csv</name><label>CSV</label><type>textarea</type><value></value><options>rows=20 cols=120</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n</formfields>\n','sysadmin',1,1,'default_index','default_view','default_input','default_authorize','default_delete','default_enquiry','id','','Csv Id','Csv','Model_SiteDB','csvs','csvs_is','csvs_hs','csv_error','IMPLEMENTATION','2011-05-04 20:05:05','ADMIN','2011-05-04 21:03:26','LIVE',1),(21,'core_developer_fixedselection','fixedselection','Y','<?xml version=\'1.0\' standalone=\'yes\'?>\r\n<formfields>\r\n	<field><name>id</name><label>Id</label><type>hidden</type><value></value><options></options><onnew>enabled</onnew><onedit>enabled</onedit></field>\r\n	<field><name>fixedselection_id</name><label>Controller</label><type>input</type><value></value><options>size=50</options>\r\n		<onnew>readonly_po</onnew><onedit>readonly</onedit>\r\n		<popout><enable>yes</enable><table>vw_core_fixedselections_available</table><selectfields>fixedselection_id</selectfields><idfield>fixedselection_id</idfield></popout>\r\n	</field>\r\n	<field><name>enquiry_type</name><label>Enquiry Type</label><type>dropdown</type><value></value><options>default,custom::default,custom</options><onnew></onnew><onedit></onedit></field>\r\n	<field><name>formfields</name><label>Formfields</label><type>textarea</type><value></value><options>rows=10 cols=120</options><onnew>readonly</onnew><onedit>readonly</onedit>\r\n		<sidelink>\r\n			<link><src>javascript:void(0)</src><attr>onclick=$.fixedselection_LoadForm()</attr><text>Update</text></link>\r\n		</sidelink>\r\n	</field>\r\n</formfields>\r\n','developer',1,1,'default_index','default_view','default_input','default_authorize','default_delete','default_enquiry','fixedselection_id','','Fixedselection Id','Fixed Selection','Model_SiteDB','fixedselections','fixedselections_is','fixedselections_hs','fixedselection_error','IMPLEMENTATION','2011-05-05 19:05:03','ADMIN','2011-05-05 20:02:27','LIVE',1),(22,'core_developer_tableresetconfig','tableresetconfig','Y','<?xml version=\'1.0\' standalone=\'yes\'?>\n<formfields>\n	<field><name>id</name><label>Id</label><type>hidden</type><value></value><options></options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>reset_id</name><label>Reset Id</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>reset_profile</name><label>Reset Profile</label><type>textarea</type><value></value><options>rows=10 cols=120</options><onnew>readonly</onnew><onedit>readonly</onedit>\r\n		<sidelink>\r\n			<link><src>javascript:void(0)</src><attr>onclick=tableresetconfig.LoadConfigForm()</attr><text>Configure</text></link>\r\n		</sidelink>\r\n	</field>\r\n</formfields>\r\n','developer',1,1,'default_index','default_view','default_input','default_authorize','default_delete','default_enquiry','reset_id','','Reset Id','Table Reset Configuration','Model_SiteDB','tableresetconfigs','tableresetconfigs_is','tableresetconfigs_hs','tableresetconfig_error','IMPLEMENTATION','2011-05-08 15:05:30','ADMIN','2011-05-08 16:25:35','LIVE',1),(23,'core_developer_tableresetrun','tableresetrun','Y','<?xml version=\'1.0\' standalone=\'yes\'?>\n<formfields>\n	<field><name>id</name><label>Id</label><type>hidden</type><value></value><options></options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>resetconfig_id</name><label>Resetconfig Id</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>lastrun_date</name><label>Lastrun Date</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>log</name><label>Log</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n</formfields>\n','developer',1,1,'default_index','default_view','default_input','default_authorize','default_delete','default_enquiry','resetconfig_id','','Reset Config Id','Table Reset Run','Model_SiteDB','tableresetruns','tableresetruns_is','tableresetruns_hs','tableresetrun_error','IMPLEMENTATION','2011-05-08 16:05:12','ADMIN','2011-05-08 16:25:44','LIVE',1),(24,'core_sysadmin_sysconfig','sysconfig','Y','<?xml version=\'1.0\' standalone=\'yes\'?>\n<formfields>\n	<field><name>id</name><label>Id</label><type>hidden</type><value></value><options></options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>sysconfig_id</name><label>Sysconfig Id</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>readonly</onedit></field>\n	<field><name>initialization_date</name><label>Initialization Date</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>global_authmode_on</name><label>Global Authmode On</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>global_indexfield_on</name><label>Global Indexfield On</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>app_version</name><label>App Version</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>db_version</name><label>Db Version</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>environment</name><label>Environment</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n</formfields>\n','sysadmin',1,1,'default_index','default_view','default_input','default_authorize','default_delete','default_enquiry','id','','Sysconfig Id','Sysconfig','Model_SiteDB','sysconfigs','sysconfigs_is','sysconfigs_hs','sysconfig_error','IMPLEMENTATION','2011-05-11 17:05:29','ADMIN','2011-05-11 17:35:46','LIVE',1),(25,'core_useraccount_userchangepassword','userchangepassword','Y','<?xml version=\'1.0\' standalone=\'yes\'?>\n<formfields>\n	<field><name>id</name><label>Id</label><type>hidden</type><value></value><options>size=0 maxlength=10</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>idname</name><label>User Id</label><type>hidden</type><value></value><options>size=0 maxlength=10</options><onnew>readonly</onnew><onedit>readonly</onedit></field>\n	<field><name>username</name><label>Signon Name</label><type>hidden</type><value></value><options>size=0 maxlength=10</options><onnew>readonly</onnew><onedit>readonly</onedit></field>\n	<field><name>password</name><label>Password</label><type>password</type><value></value><options>size=50 maxlength=80</options><onnew>readonly</onnew><onedit>readonly_po</onedit>\r\n		<sidelink>\r\n			<link><src>javascript:void(0)</src><attr>onclick=window.userchangepassword.LoadForm()</attr><text>Change</text></link>\r\n		</sidelink>\r\n	</field>\n</formfields>\r\n','login',1,1,'default_index','default_view','default_input','default_authorize','default_delete','default_enquiry','username','','Signon Name','User Change Password','Model_SiteDB','users','users_is','users_hs','userpasswdreset_error','IMPLEMENTATION','2011-11-14 09:34:52','ADMIN','2011-11-14 09:35:17','LIVE',1),(26,'core_developer_pdftemplate','pdftemplate','Y','<?xml version=\'1.0\' standalone=\'yes\'?>\n<formfields>\n	<field><name>id</name><label>Id</label><type>hidden</type><value></value><options></options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>template_id</name><label>Template Id</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>readonly</onedit></field>\n	<field><name>pdf_header_class</name><label>PDF Header Class</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enable</onedit></field>\r\n	<field><name>pdf_template_file</name><label>PDF Template File</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>pdf_page_orientation</name><label>PDF Page Orientation</label><type>dropdown</type><value></value><options>P,L::Portrait,Landscape</options><onnew></onnew><onedit></onedit></field>\r\n	<field><name>pdf_unit</name><label>PDF Unit</label><type>dropdown</type><value></value><options>mm,cm,in,pt::mm,cm,in,pt</options><onnew></onnew><onedit></onedit></field>\n	<field><name>pdf_page_format</name><label>PDF Page Format</label><type>input</type><value></value><options>size=30</options><onnew>readonly_po</onnew><onedit>readonly_po</onedit>\r\n		<popout><enable>yes</enable><table>_sys_pagesizes</table><selectfields>format_id,inch_width,inch_height,mm_width,mm_height</selectfields><idfield>format_id</idfield></popout>\r\n	</field>\n	<field><name>pdf_output</name><label>PDF Output</label><type>dropdown</type><value></value><options>I,D,F,FI,FD,E,S::I,D,F,FI,FD,E,S</options><onnew></onnew><onedit></onedit></field>\r\n	<field><name>pdf_margin_top</name><label>PDF Margin Top</label><type>input</type><value></value><options>size=10</options><onnew>enabled</onnew><onedit>enable</onedit></field>\r\n	<field><name>pdf_margin_right</name><label>PDF Margin Right</label><type>input</type><value></value><options>size=10</options><onnew>enabled</onnew><onedit>enable</onedit></field>\r\n	<field><name>pdf_margin_bottom</name><label>PDF Margin Botttom</label><type>input</type><value></value><options>size=10</options><onnew>enabled</onnew><onedit>enable</onedit></field>\r\n	<field><name>pdf_margin_left</name><label>PDF Margin Left</label><type>input</type><value></value><options>size=10</options><onnew>enabled</onnew><onedit>enable</onedit></field>\r\n	<field><name>pdf_font_monospaced</name><label>PDF Font Monospaced</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enable</onedit></field>\r\n	<field><name>pdf_font</name><label>PDF Font</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enable</onedit></field>\r\n	<field><name>pdf_fontstyle</name><label>PDF Font Style</label><type>input</type><value></value><options>size=10</options><onnew>enabled</onnew><onedit>enable</onedit></field>\r\n	<field><name>pdf_fontsize</name><label>PDF Font Size</label><type>input</type><value></value><options>size=10</options><onnew>enabled</onnew><onedit>enable</onedit></field>\r\n</formfields>\r\n','developer',1,1,'default_index','default_view','default_input','default_authorize','default_delete','default_enquiry','template_id','','Template Id','PDF Template','Model_SiteDB','pdftemplates','pdftemplates_is','pdftemplates_hs','pdftemplate_error','IMPLEMENTATION','2012-05-30 15:05:47','ADMIN','2012-05-30 15:17:39','LIVE',1),(27,'core_developer_reportdef','reportdef','Y','<?xml version=\'1.0\' standalone=\'yes\'?>\n<formfields>\n	<field><name>id</name><label>Id</label><type>hidden</type><value></value><options></options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>reportdef_id</name><label>Enquirydef Id</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\r\n	<field><name>controller</name><label>Controller</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\r\n	<field><name>dflag</name><label>DFlag</label><type>dropdown</type><value></value><options>Y,N::Y,N</options><onnew></onnew><onedit></onedit></field>\r\n	<field><name>formfields</name><label>Formfields</label><type>textarea</type><value></value><options>rows=30 cols=120</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>model</name><label>Model</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>view</name><label>View</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>rptheader</name><label>Report Header</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>showfilter</name><label>Show Filter</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>printuser</name><label>Print Username</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>printdatetime</name><label>Print Datetime</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n</formfields>','developer',1,1,'default_index','default_view','default_input','default_authorize','default_delete','default_enquiry','reportdef_id','','Reportdef Id','Report Definition','Model_SiteDB','reportdefs','reportdefs_is','reportdefs_hs','reportdef_error','IMPLEMENTATION','2012-07-22 21:18:53','ADMIN','2012-07-22 21:21:42','LIVE',1),(28,'core_businessadmin_batchinvoice','batchinvoice','Y','<?xml version=\'1.0\' standalone=\'yes\'?>\n<formfields>\n	<field><name>id</name><label>Id</label><type>hidden</type><value></value><options></options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>batch_id</name><label>Batch Id</label><type>input</type><value></value><options>size=20</options><onnew>readonly</onnew><onedit>readonly</onedit></field>\n	<field><name>batch_date</name><label>Batch Date</label><type>date</type><value></value><options>size=10</options><onnew>enabled_po</onnew><onedit>readonly</onedit></field>\n	<field><name>batch_description</name><label>Batch Description</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>batch_type</name><label>Batch Type</label><type>input</type><value></value><options>size=50</options><onnew>enabled_po</onnew><onedit>enabled_po</onedit>\n		<popout><enable>yes</enable><table>vw_batchtypes</table><selectfields>type</selectfields><idfield>type</idfield></popout>\n	</field>\n	<field><name>batch_details</name><label>Batch Details</label><type>subform</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit>\n		<subform>\n			<subformcontroller>batchinvoicedetail</subformcontroller>\n			<subformonnew>enabled</subformonnew>\n			<subformonedit>enabled</subformonedit> \n		</subform>\n	</field>\n	<field><name>comments</name><label>Comments</label><type>textarea</type><value></value><options>rows=2 cols=50</options><onnew></onnew><onedit></onedit></field>\n</formfields>','businessadmin',0,1,'default_index','default_view','default_input','default_authorize','default_delete','default_enquiry','batch_id','','Batch Id','Batch Invoices','Model_SiteDB','batchinvoices','batchinvoices_is','batchinvoices_hs','batchinvoice_error','IMPLEMENTATION','2012-07-24 23:46:23','ADMIN','2012-07-24 23:51:38','LIVE',1),(29,'core_businessadmin_batchinvoicedetail','batchinvoicedetail','Y','<?xml version=\'1.0\' standalone=\'yes\'?>\r\n<formfields>\r\n	<field><name>id</name><label>Id</label><type>hidden</type><value></value><options></options><onnew>readonly</onnew><onedit>readonly</onedit></field>\r\n	<field><name>batch_id</name><label>Batch Id</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\r\n	<field><name>invoice_id</name><label>Invoice Id</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\r\n	<field><name>alt_invoice_id</name><label>Alt_Invoice Id</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\r\n	<field><name>order_id</name><label>Order Id</label><type>input</type><value></value><options>size=50</options><onnew>readonly</onnew><onedit>readonly</onedit></field>\r\n	<field><name>order_date</name><label>Order Date</label><type>date</type><value></value><options>size=10 maxlength=10</options><onnew>enabled_po</onnew><onedit>readonly</onedit></field>\r\n	<field><name>first_name</name><label>First Name</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\r\n	<field><name>last_name</name><label>Last Name</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\r\n	<field><name>payment_total</name><label>Payment Total</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\r\n	<field><name>payment_type</name><label>Payment Type</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\r\n	<subformfields>\r\n		<subfield><subname>order_id</subname><sublabel>Order Id</sublabel><width>140</width><align>left</align><formatter></formatter><editor>{type:\'combobox\',options:{valueField:\'order_id\',textField:\'order_id\',url:url_orders,onSelect:batchinvoice_GetOrderData, mode:\'remote\',required:true}}</editor></subfield>\r\n		<subfield><subname>invoice_id</subname><sublabel>Invoice Id</sublabel><width>80</width><align>left</align><editor></editor></subfield>\r\n		<subfield><subname>alt_invoice_id</subname><sublabel>Alt Invoice Id</sublabel><width>80</width><align>left</align><editor>{type:\'numberbox\',options:{required:true}}</editor></subfield>\r\n		<subfield><subname>order_date</subname><sublabel>Order Date</sublabel><width>80</width><align>left</align><editor></editor></subfield>\r\n		<subfield><subname>first_name</subname><sublabel>First Name</sublabel><width>80</width><align>left</align><editor></editor></subfield>\r\n		<subfield><subname>last_name</subname><sublabel>Last Name</sublabel><width>80</width><align>left</align><editor></editor></subfield>\r\n		<subfield><subname>order_details</subname><sublabel>Order Details</sublabel><width>140</width><align>left</align><editor></editor></subfield>\r\n		<subfield><subname>extended_total</subname><sublabel>Extended</sublabel><width>50</width><align>right</align><editor></editor></subfield>\r\n		<subfield><subname>tax_total</subname><sublabel>Tax</sublabel><width>50</width><align>right</align><editor></editor></subfield>\r\n		<subfield><subname>order_total</subname><sublabel>Total</sublabel><width>50</width><align>right</align><editor></editor></subfield>\r\n		<subfield><subname>payment_total</subname><sublabel>Payments</sublabel><width>50</width><align>right</align><editor></editor></subfield>\r\n		<subfield><subname>balance</subname><sublabel>Balance</sublabel><width>50</width><align>right</align><editor></editor></subfield>\r\n		<subfield><subname>payment_type</subname><sublabel>Payment Type</sublabel><width>140</width><align>left</align><editor></editor></subfield>\r\n		<subfield><subname>batch_id</subname><sublabel>Batch Id</sublabel><width>140</width><align>left</align><editor></editor></subfield>\r\n		<subfield><subname>id</subname><sublabel>Id</sublabel><width>50</width><align>left</align><editor></editor></subfield>\r\n	</subformfields>\r\n</formfields>\r\n','businessadmin',0,1,'default_index','default_view','default_input','default_authorize','default_delete','default_enquiry','id','','Id','End Of Month Invoice Details','Model_SiteDB','batchinvoicedetails','batchinvoicedetails_is','batchinvoicedetails_hs','batchinvoicedetail_error','IMPLEMENTATION','0000-00-00 00:00:00','ADMIN','2012-07-21 21:18:51','LIVE',1),(401,'core_customer_customer','customer','Y','<?xml version=\'1.0\' standalone=\'yes\'?>\r\n<formfields>\r\n	<field><name>id</name><label>Id</label><type>hidden</type><value></value><options></options><onnew>enabled</onnew><onedit>enabled</onedit></field>\r\n	<field><name>customer_id</name><label>Customer Id</label><type>input</type><value></value><options>size=10</options><onnew>readonly</onnew><onedit>readonly</onedit></field>\r\n	<field><name>customer_type</name><label>Customer Type</label><type>dropdown</type><value></value><options>INDIVIDUAL,COMPANY::INDIVIDUAL,COMPANY</options><onnew></onnew><onedit></onedit></field>\r\n	<field><name>business_type</name><label>Business Type</label><type>input</type><value></value><options>size=50</options>\r\n		<onnew>enabled_po</onnew><onedit>enabled_po</onedit>\r\n		<popout><enable>yes</enable><table>vw_biztype</table><selectfields>business_type</selectfields><idfield>business_type</idfield></popout>\r\n	</field>\r\n	<field><name>first_name</name><label>First Name</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\r\n	<field><name>last_name</name><label>Last Name</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\r\n	<field><name>address1</name><label>Street</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\r\n	<field><name>address2</name><label>Village</label><type>input</type><value></value><options>size=50</options>\r\n		<onnew>enabled_po</onnew><onedit>enabled_po</onedit>\r\n		<popout><enable>yes</enable><table>regions</table><selectfields>area</selectfields><idfield>area</idfield></popout>\r\n	</field>\r\n	<field><name>city</name><label>City</label><type>input</type><value></value><options>size=50</options>\r\n		<onnew>enabled_po</onnew><onedit>enabled_po</onedit>\r\n		<popout><enable>yes</enable><table>regions</table><selectfields>area</selectfields><idfield>area</idfield></popout>\r\n	</field>\r\n	<field><name>region_id</name><label>Region Id</label><type>input</type><value></value><options>size=2 maxlength=2 onFocus=sideinfo.Update(%FIELDS%,%TABLE%,%IDFIELD%,%RETFIELD%,%FORMAT%) onKeyUp=sideinfo.Update(%FIELDS%,%TABLE%,%IDFIELD%,%RETFIELD%,%FORMAT%)</options>\r\n		<onnew>readonly_po</onnew><onedit>readonly_po</onedit>\r\n		<popout><enable>yes</enable><table>regions</table><selectfields>id,area,region</selectfields><idfield>id</idfield></popout>\r\n		<sideinfo>\r\n			<enable>yes</enable><table>regions</table><selectfields>area,region</selectfields><idfield>id</idfield><format>*;_*</format>\r\n		</sideinfo>\r\n	</field>\r\n	<field>\r\n		<name>country_id</name><label>Country Id</label><type>input</type><value></value><options>size=2 maxlength=2 onFocus=sideinfo.Update(%FIELDS%,%TABLE%,%IDFIELD%,%RETFIELD%,%FORMAT%) onKeyUp=sideinfo.Update(%FIELDS%,%TABLE%,%IDFIELD%,%RETFIELD%,%FORMAT%)</options>\r\n		<onnew>readonly_po</onnew><onedit>readonly_po</onedit>\r\n		<popout><enable>yes</enable><table>countrys</table><selectfields>country_id,common_name,capital,currency_code</selectfields><idfield>country_id</idfield></popout>\r\n		<sideinfo>\r\n			<enable>yes</enable><table>countrys</table><selectfields>common_name</selectfields><idfield>country_id</idfield><format>*</format>\r\n		</sideinfo>		\r\n	</field>\r\n	<field><name>date_of_birth</name><label>Date Of Birth</label><type>date</type><value></value><options>size=10 maxlength=10 onFocus=sidefunc.Update(%FUNC%,%PARAMFLD%,%SFFORMAT%) onKeyUp=sidefunc.Update(%FUNC%,%PARAMFLD%,%SFFORMAT%)</options>\r\n		<onnew>enabled_po</onnew><onedit>enabled_po</onedit>\r\n		<sidefunc><enable>yes</enable><func>dobtoage</func><idfield>date_of_birth</idfield><format>Age:_*</format></sidefunc>\r\n	</field>\r\n	<field><name>gender</name><label>Gender</label><type>dropdown</type><value></value><options>M,F,N::M,F,N</options><onnew></onnew><onedit></onedit></field>\r\n	<field><name>phone_home</name><label>Phone(Home)</label><type>input</type><value></value><options>size=7 maxlength=9</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\r\n	<field><name>phone_work</name><label>Phone(Work)</label><type>input</type><value></value><options>size=7 maxlength=9</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\r\n	<field><name>phone_mobile1</name><label>Phone Mobile 1</label><type>input</type><value></value><options>size=7 maxlength=9</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\r\n	<field><name>phone_mobile2</name><label>Phone Mobile 2</label><type>input</type><value></value><options>size=7 maxlength=9</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\r\n	<field><name>email_address</name><label>Email Address</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\r\n	<field><name>branch_id</name><label>Branch Id</label><type>input</type><value>HEAD.OFFICE</value><options>size=50 onFocus=sideinfo.Update(%FIELDS%,%TABLE%,%IDFIELD%,%RETFIELD%,%FORMAT%) onKeyUp=sideinfo.Update(%FIELDS%,%TABLE%,%IDFIELD%,%RETFIELD%,%FORMAT%)</options>\r\n		<onnew>readonly_po</onnew><onedit>readonly_po</onedit>\r\n		<popout><enable>yes</enable><table>branches</table><selectfields>id,branch_id,description,location,active</selectfields><idfield>branch_id</idfield></popout>\r\n		<sideinfo>\r\n			<enable>yes</enable><table>branches</table><selectfields>description</selectfields><idfield>branch_id</idfield><format>*</format>\r\n		</sideinfo>\r\n	</field>	\r\n	<field><name>referrer_id</name><label>Referrer Id</label><type>input</type><value></value><options>size=10 maxlength=8 onFocus=sideinfo.Update(%FIELDS%,%TABLE%,%IDFIELD%,%RETFIELD%,%FORMAT%) onKeyUp=sideinfo.Update(%FIELDS%,%TABLE%,%IDFIELD%,%RETFIELD%,%FORMAT%)</options>\r\n		<onnew>enabled_po</onnew><onedit>enabled_po</onedit>\r\n		<popout><enable>yes</enable><table>customers</table><selectfields>id,customer_id,first_name,last_name</selectfields><idfield>customer_id</idfield></popout>\r\n		<sideinfo>\r\n			<enable>yes</enable><table>customers</table><selectfields>first_name,last_name</selectfields><idfield>customer_id</idfield><format>*_*</format>\r\n		</sideinfo>\r\n	</field>\r\n	<field><name>comments</name><label>Comments</label><type>textarea</type><value></value><options>rows=2 cols=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\r\n</formfields>','customer',0,1,'default_index','default_view','default_input','default_authorize','default_delete','default_enquiry','customer_id','','Customer Id','Customer','Model_SiteDB','customers','customers_is','customers_hs','customer_error','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(402,'core_sales_product','product','Y','<?xml version=\'1.0\' standalone=\'yes\'?>\n<formfields>\n	<field><name>id</name><label>Id</label><type>hidden</type><value></value><options></options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>product_id</name><label>Product Id</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>type</name><label>Type</label><type>dropdown</type><value></value><options>STOCK,SERVICE,PACKAGE::STOCK,SERVICE,PACKAGE</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>package_items</name><label>Package Items</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>product_description</name><label>Product Description</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>extended_description</name><label>Extended Description</label><type>textarea</type><value></value><options>rows=5 cols=80</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>category</name><label>Category</label><type>input</type><value></value><options>size=50</options><onnew>enabled_po</onnew><onedit>enabled_po</onedit>\r\n		<popout><enable>yes</enable><table>vw_distinct_product_category</table><selectfields>category</selectfields><idfield>category</idfield></popout>\r\n	</field>\r\n	<field><name>sub_category</name><label>Sub Category</label><type>input</type><value></value><options>size=50</options><onnew>enabled_po</onnew><onedit>enabled_po</onedit>\r\n		<popout><enable>yes</enable><table>vw_distinct_product_subcategory</table><selectfields>sub_category</selectfields><idfield>sub_category</idfield></popout>\r\n	</field>\r\n	<field><name>unit_price</name><label>Unit Price</label><type>input</type><value></value><options>size=10</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>taxable</name><label>Taxable</label><type>dropdown</type><value></value><options>Y,N::Y,N</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>tax_percentage</name><label>Tax (%)</label><type>input</type><value></value><options>size=10</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>transfer_code</name><label>Transfer Code</label><type>input</type><value></value><options>size=20</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\r\n	<field><name>status</name><label>Status</label><type>dropdown</type><value></value><options>ACTIVE,INACTIVE,DISCONTINUED::ACTIVE,INACTIVE,DISCONTINUED</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n</formfields>','sales',0,1,'default_index','default_view','default_input','default_authorize','default_delete','default_enquiry','product_id','','Product Id','Product','Model_SiteDB','products','products_is','products_hs','product_error','IMPLEMENTATION','2011-08-29 18:08:03','ADMIN','2011-08-29 18:58:51','LIVE',1),(403,'core_sales_inventupdtype','inventupdtype','Y','<?xml version=\'1.0\' standalone=\'yes\'?>\n<formfields>\n	<field><name>id</name><label>Id</label><type>hidden</type><value></value><options></options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>update_type_id</name><label>Update Type Id</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>readonly</onedit></field>\n	<field><name>description</name><label>Description</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>stock_movement</name><label>Stock Movement</label><type>dropdown</type><value></value><options>STOCK.IN,STOCK.OUT,STOCK.RESET::STOCK.IN,STOCK.OUT,STOCK.RESET</options><onnew></onnew><onedit></onedit></field>\n	<field><name>comments</name><label>Comments</label><type>textarea</type><value></value><options>rows=2 cols=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\r\n</formfields>','sales',1,1,'default_index','default_view','default_input','default_authorize','default_delete','default_enquiry','update_type_id','','Update Type Id','Inventory Update Type','Model_SiteDB','inventupdtypes','inventupdtypes_is','inventupdtypes_hs','inventupdtype_error','IMPLEMENTATION','2011-11-18 08:40:44','ADMIN','2011-11-18 08:40:55','LIVE',4),(404,'core_sales_inventory','inventory','Y','<?xml version=\'1.0\' standalone=\'yes\'?>\n<formfields>\n	<field><name>id</name><label>Id</label><type>hidden</type><value></value><options></options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>inventory_id</name><label>Inventory Id</label><type>input</type><value></value><options>size=50</options><onnew>readonly</onnew><onedit>readonly</onedit></field>\r\n	<field><name>product_id</name><label>Product Id</label><type>input</type><value></value><options>size=25</options><onnew>readonly_po</onnew><onedit>readonly</onedit>\r\n		<popout><enable>yes</enable><table>vw_inventprod_available</table><selectfields>id,product_id,description</selectfields><idfield>product_id</idfield></popout>\r\n		<sideinfo>\r\n			<enable>yes</enable><table>products</table><selectfields>product_description</selectfields><idfield>product_id</idfield><format>*</format>\r\n		</sideinfo>\r\n	</field>\n	<field><name>branch_id</name><label>Branch Id</label><type>input</type><value></value><options>size=25</options><onnew>readonly_po</onnew><onedit>readonly</onedit>\r\n		<popout><enable>yes</enable><table>branches</table><selectfields>id,branch_id,description</selectfields><idfield>branch_id</idfield></popout>\r\n		<sideinfo>\r\n			<enable>yes</enable><table>branches</table><selectfields>description</selectfields><idfield>branch_id</idfield><format>*</format>\r\n		</sideinfo>\r\n	</field>\r\n	<field><name>qty_instock</name><label>Quantity Instock</label><type>input</type><value></value><options>size=12</options>\r\n		<onnew>readonly_po</onnew><onedit>readonly_po</onedit>\r\n		<sidelink>\r\n			<link><src>javascript:void(0)</src><attr>onclick=window.inventory.LoadForm()</attr><text>Adjust</text></link>\r\n		</sidelink>\r\n	</field>\n	<field><name>qty_diff</name><label>Difference</label><type>input</type><value></value><options>size=12</options><onnew>readonly</onnew><onedit>readonly</onedit></field>\r\n	<field><name>reorder_level</name><label>Reorder Level</label><type>input</type><value></value><options>size=12</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>last_update_type</name><label>Update Type</label><type>input</type><value></value><options>size=25 onFocus=sideinfo.Update(%FIELDS%,%TABLE%,%IDFIELD%,%RETFIELD%,%FORMAT%) onKeyUp=sideinfo.Update(%FIELDS%,%TABLE%,%IDFIELD%,%RETFIELD%,%FORMAT%)</options>\r\n		<onnew>readonly_po</onnew><onedit>readonly_po</onedit>\n		<popout><enable>yes</enable><table>inventupdtypes</table><selectfields>id,update_type_id,description,stock_movement</selectfields><idfield>update_type_id</idfield></popout>\n		<sideinfo>\n			<enable>yes</enable><table>inventupdtypes</table><selectfields>description,stock_movement</selectfields><idfield>update_type_id</idfield><format>*;_*</format>\n		</sideinfo>\n	</field>\n	<field><name>comments</name><label>Comments</label><type>textarea</type><value></value><options>rows=2 cols=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n</formfields>\r\n','sales',0,1,'default_index','default_view','default_input','default_authorize','default_delete','default_enquiry','inventory_id','','Inventory Id','Inventory','Model_SiteDB','inventorys','inventorys_is','inventorys_hs','inventory_error','IMPLEMENTATION','2011-11-18 08:49:35','ADMIN','2011-11-18 08:57:59','LIVE',1),(405,'core_sales_order','order','Y','<?xml version=\'1.0\' standalone=\'yes\'?>\n<formfields>\n	<field><name>id</name><label>Id</label><type>hidden</type><value></value><options></options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>order_id</name><label>Order Id</label><type>input</type><value></value><options>size=25</options><onnew>readonly</onnew><onedit>readonly</onedit></field>\n	<field><name>branch_id</name><label>Branch Id</label><type>input</type><value></value><options>size=25</options><onnew>readonly_po</onnew><onedit>readonly_po</onedit>\r\n		<popout><enable>yes</enable><table>branches</table><selectfields>id,branch_id,description</selectfields><idfield>branch_id</idfield></popout>\r\n	</field>\r\n	<field><name>customer_id</name><label>Customer Id</label><type>input</type><value></value><options>size=10 onFocus=sideinfo.Update(%FIELDS%,%TABLE%,%IDFIELD%,%RETFIELD%,%FORMAT%) onKeyUp=sideinfo.Update(%FIELDS%,%TABLE%,%IDFIELD%,%RETFIELD%,%FORMAT%)</options>\r\n	<onnew>readonly_po</onnew><onedit>readonly</onedit>\r\n		<popout><enable>yes</enable><table>customers</table><selectfields>id,customer_id,first_name,last_name,phone_mobile1</selectfields><idfield>customer_id</idfield></popout>\r\n		<sideinfo>\r\n			<enable>yes</enable><table>customers</table><selectfields>first_name,last_name</selectfields><idfield>customer_id</idfield><format>*_*</format>	\r\n		</sideinfo>	\r\n	</field>	\r\n	<field><name>is_co</name><label>Is Charge Order</label><type>dropdown</type><value></value><options>N,Y::N,Y</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\r\n	<field><name>cc_id</name><label>Charge Customer Id</label><type>input</type><value></value><options>size=10 onFocus=sideinfo.Update(%FIELDS%,%TABLE%,%IDFIELD%,%RETFIELD%,%FORMAT%) onKeyUp=sideinfo.Update(%FIELDS%,%TABLE%,%IDFIELD%,%RETFIELD%,%FORMAT%)</options>\r\n	<onnew>readonly_po</onnew><onedit>readonly_po</onedit>\r\n		<popout><enable>yes</enable><table>vw_active_charge_customers</table><selectfields>id,customer_id,customer_type,business_type,first_name,last_name,phone_mobile1</selectfields><idfield>customer_id</idfield></popout>\r\n		<sideinfo>\r\n			<enable>yes</enable><table>customers</table><selectfields>first_name,last_name,customer_type,business_type</selectfields><idfield>customer_id</idfield><format>*_*;_*;_*</format>\r\n		</sideinfo>\r\n	</field>\r\n	<field><name>order_status</name><label>Order Status</label><type>input</type><value></value><options>size=25</options>\r\n	<onnew>readonly_po</onnew><onedit>readonly_po</onedit>\r\n	<sidelink>\r\n		<link><src>javascript:void(0)</src><attr>onclick=order_StatusPopOut()</attr><text>%IMG%media/img/site/lubw020.png</text></link>\r\n	</sidelink>\r\n	</field>\n		<field><name>order_details</name><label>Order Details</label><type>subform</type><value></value><options></options><onnew>enabled</onnew><onedit>enabled</onedit>\r\n		<subform>\r\n			<subformcontroller>orderdetail</subformcontroller>\r\n			<subformonnew>enabled</subformonnew>\r\n			<subformonedit>enabled</subformonedit> \r\n		</subform>\r\n	</field>\n	<field><name>order_date</name><label>Order Date</label><type>date</type><value></value><options>size=10 maxlength=10</options><onnew>enabled_po</onnew><onedit>readonly</onedit></field> \r\n	<field><name>quotation_date</name><label>Quotation Date</label><type>date</type><value></value><options>size=10 maxlength=10</options><onnew>enabled_po</onnew><onedit>enabled_po</onedit></field>\r\n	<field><name>invoice_date</name><label>Invoice Date</label><type>date</type><value></value><options>size=10 maxlength=10 </options><onnew>readonly</onnew><onedit>readonly</onedit></field>\r\n	<field><name>status_change_date</name><label>Status Change Date</label><type>date</type><value></value><options>size=10 maxlength=10</options><onnew>enabled_po</onnew><onedit>enabled_po</onedit></field> \r\n	<field><name>inventory_checkout_type</name><label>Inventory Checkout</label><type>input</type><value></value><options>size=15</options><onnew>readonly_po</onnew><onedit>readonly_po</onedit>\r\n		<sidelink>\r\n			<link><src>javascript:void(0)</src><attr>onclick=order_ToggleCheckoutType()</attr><text>Change</text></link>\r\n		</sidelink>\r\n	</field>\r\n	<field><name>inventory_update_type</name><label>Inventory Update</label><type>input</type><value></value><options>size=15</options><onnew>readonly_po</onnew><onedit>readonly</onedit>\r\n		<sidelink>\r\n			<link><src>javascript:void(0)</src><attr>onclick=order_ToggleUpdateType()</attr><text>Change</text></link>\r\n		</sidelink>\r\n	</field>\r\n	<field><name>inventory_checkout_status</name><label>Checkout Status</label><type>input</type><value></value><options>size=15</options><onnew>readonly</onnew><onedit>readonly</onedit></field>\r\n	<field><name>invoice_note</name><label>Invoice Note</label><type>textarea</type><value></value><options>rows=6 cols=80 maxlength=256</options><onnew></onnew><onedit></onedit></field> \r\n	<field><name>comments</name><label>Comments</label><type>textarea</type><value></value><options>rows=2 cols=50</options><onnew></onnew><onedit></onedit></field>\r\n</formfields>','sales',0,1,'default_index','default_view','default_input','default_authorize','default_delete','default_enquiry','order_id','','Order Id','Order','Model_SiteDB','orders','orders_is','orders_hs','order_error','IMPLEMENTATION','2011-11-20 01:11:16','ADMIN','2011-11-20 01:36:25','LIVE',1),(406,'core_sales_orderdetail','orderdetail','Y','<?xml version=\'1.0\' standalone=\'yes\'?>\n<formfields>\n	<field><name>id</name><label>Id</label><type>hidden</type><value></value><options></options><onnew>readonly</onnew><onedit>readonly</onedit></field>\r\n	<field><name>order_id</name><label>Order Id</label><type>input</type><value></value><options>size=50</options><onnew>readonly</onnew><onedit>readonly</onedit></field>\r\n	<field><name>product_id</name><label>Product Id</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>qty</name><label>Qty</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>unit_price</name><label>Unit Price</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\r\n	<field><name>taxable</name><label>Taxable</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\r\n	<field><name>tax_percentage</name><label>Tax Amount</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\r\n	<field><name>discount_type</name><label>Discount Type</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\r\n	<field><name>discount_amount</name><label>Discount Amount</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\r\n	<field><name>description_type</name><label>Description Type</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\r\n	<field><name>description</name><label>Description</label><type>input</type><value></value>size=50<options></options><onnew>enabled</onnew><onedit>enabled</onedit></field><field><name>user_text</name><label>Inventory Update</label><type>input</type><value></value><options>size=60</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\r\n	<field><name>user_text</name><label>User Text</label><type>textarea</type><value></value><options>rows=2 cols=50</options><onnew></onnew><onedit></onedit></field>\r\n	<field><name>inventory_update</name><label>Inventory Update</label><type>input</type><value></value><options>size=60</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\r\n	<subformfields>\r\n		<subfield><subname>product_id</subname><sublabel>Product Id</sublabel><width>120</width><align>left</align><formatter></formatter><editor>{type:\'combobox\',options:{valueField:\'product_id\',textField:\'product_id\', url:url_products,onSelect:order_GetProductData, mode:\'remote\',required:true}}</editor></subfield>\r\n		<subfield><subname>description</subname><sublabel>Description</sublabel><width>200</width><align>left</align><editor></editor></subfield>\r\n		<subfield><subname>qty</subname><sublabel>Qty</sublabel><width>30</width><align>center</align><editor>{type:\'numberbox\',options:{required:true}}</editor></subfield>\r\n		<subfield><subname>unit_price</subname><sublabel>Unit Price</sublabel><width>70</width><align>right</align><editor></editor></subfield>\r\n		<subfield><subname>qty*unit_price:unit_total</subname><sublabel>Unit Total</sublabel><width>70</width><align>right</align><editor></editor></subfield>\r\n		<subfield><subname>discount_amount</subname><sublabel>Discount</sublabel><width>70</width><align>right</align><editor>{type:\'numberbox\',options:{required:true,precision:2}}</editor></subfield>\r\n		<subfield><subname>round(func_OrderDetailSubTotal(qty,unit_price,discount_amount,discount_type),2):extended</subname><sublabel>Extended</sublabel><width>70</width><align>right</align><editor></editor></subfield>\r\n		<subfield><subname>round(func_OrderDetailTaxTotal(qty,unit_price,discount_amount,tax_percentage,taxable,discount_type),2):tax_amount</subname><sublabel>Tax Amt</sublabel><width>50</width><align>right</align><editor></editor></subfield>\r\n		<subfield><subname>round(func_OrderDetailOrderTotal(qty,unit_price,discount_amount,tax_percentage,taxable,discount_type),2):total</subname><sublabel>Total</sublabel><width>70</width><align>right</align><editor></editor></subfield>\r\n		<subfield><subname>tax_percentage</subname><sublabel>Tax(%)</sublabel><width>50</width><align>right</align><editor></editor></subfield>\r\n		<subfield><subname>taxable</subname><sublabel>Taxable</sublabel><width>50</width><align>center</align><editor></editor></subfield>\r\n		<subfield><subname>discount_type</subname><sublabel>DiscountType</sublabel><width>50</width><align>left</align><editor>{type:\'checkbox\',options:{on:\'DOLLAR\',off:\'PERCENT\'}}</editor></subfield>\r\n		<subfield><subname>description_type</subname><sublabel>DescriptionType</sublabel><width>100</width><align>left</align><editor>{type:\'checkbox\',options:{on:\'EXTENDED\',off:\'STANDARD\'}}</editor></subfield>\r\n		<subfield><subname>user_text</subname><sublabel>User Text</sublabel><width>140</width><align>left</align><editor>{type:\'textarea\'}</editor></subfield>\r\n		<subfield><subname>order_id</subname><sublabel>Order Id</sublabel><width>140</width><align>left</align><editor></editor></subfield>\r\n		<subfield><subname>id</subname><sublabel>Id</sublabel><width>50</width><align>left</align><editor></editor></subfield>\r\n	</subformfields>\r\n</formfields>\r\n','sales',0,1,'default_index','default_view','default_input','default_authorize','default_delete','default_enquiry','id','','Orderdetail Id','Order Detail','Model_SiteDB','orderdetails','orderdetails_is','orderdetails_hs','orderdetails_error','IMPLEMENTATION','2011-11-20 21:11:56','ADMIN','2011-11-20 21:29:00','LIVE',1),(407,'core_sales_inventchkout','inventchkout','Y','<?xml version=\'1.0\' standalone=\'yes\'?>\n<formfields>\n	<field><name>id</name><label>Id</label><type>hidden</type><value></value><options></options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>order_id</name><label>Order Id</label><type>input</type><value></value><options>size=20 onFocus=sideinfo.Update(%FIELDS%,%TABLE%,%IDFIELD%,%RETFIELD%,%FORMAT%) onKeyUp=sideinfo.Update(%FIELDS%,%TABLE%,%IDFIELD%,%RETFIELD%,%FORMAT%)</options><onnew>readonly</onnew><onedit>readonly</onedit>\r\n		<sideinfo>\r\n			<enable>yes</enable><table>vw_inventchkout_sideinfo</table><selectfields>branch_id,first_name,last_name,order_status,inventory_checkout_status</selectfields><idfield>order_id</idfield><format>*;_*_*;_ORDER_STATUS:_*;_CHECKOUT_STATUS:_*</format>\r\n		</sideinfo>	\r\n	</field>\n	<field><name>checkout_details</name><label>Checkout Details</label><type>xmltable</type><value></value><options>rows=10 cols=100</options><onnew></onnew><onedit></onedit>\r\n	<subtable>\r\n		<subfield><subname>product_id</subname><sublabel>Product Id</sublabel><width>120</width><align>left</align></subfield>\r\n		<subfield><subname>description</subname><sublabel>Description</sublabel><width>200</width><align>left</align></subfield>\r\n		<subfield><subname>order_qty</subname><sublabel>Order Qty</sublabel><width>100</width><align>center</align></subfield>\r\n		<subfield><subname>filled_qty</subname><sublabel>Filled Qty</sublabel><width>100</width><align>center</align></subfield>\r\n		<subfield><subname>checkout_qty</subname><sublabel>Checkout Qty</sublabel><width>100</width><align>center</align><editor>{type:\'numberbox\',options:{required:true}}</editor></subfield>\r\n		<subfield><subname>status</subname><sublabel>Checkout Status</sublabel><width>125</width><align>left</align></subfield>\r\n	</subtable>\r\n	<sidelink>\r\n		<link><src>javascript:void(0)</src><attr>onclick=setCheckout()</attr><text>Set Checkout</text></link>\r\n	</sidelink>\r\n	</field>\n	<field><name>run</name><label>Run Inventory Update</label><type>dropdown</type><value></value><options>Y,N::Y,N</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\r\n	<field><name>comments</name><label>Comments</label><type>textarea</type><value></value><options>rows=2 cols=50</options><onnew></onnew><onedit></onedit></field>\r\n\r\n</formfields>','sales',0,1,'default_index','default_view','default_input','default_authorize','default_delete','default_enquiry','order_id','','Order Id','Inventory Checkout','Model_SiteDB','inventchkouts','inventchkouts_is','inventchkouts_hs','inventchkout_error','IMPLEMENTATION','2012-01-11 01:01:33','ADMIN','2012-01-11 01:16:51','LIVE',1),(408,'core_sales_deliverynote','deliverynote','Y','<?xml version=\'1.0\' standalone=\'yes\'?>\n<formfields>\n	<field><name>id</name><label>Id</label><type>hidden</type><value></value><options></options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>deliverynote_id</name><label>Deliverynote Id</label><type>input</type><value></value><options>size=20</options><onnew>readonly</onnew><onedit>readonly</onedit></field>\n	<field><name>order_id</name><label>Order Id</label><type>input</type><value></value><options>size=20 onFocus=sideinfo.Update(%FIELDS%,%TABLE%,%IDFIELD%,%RETFIELD%,%FORMAT%) onKeyUp=sideinfo.Update(%FIELDS%,%TABLE%,%IDFIELD%,%RETFIELD%,%FORMAT%)</options><onnew>readonly</onnew><onedit>readonly</onedit>\r\n		<sideinfo>\r\n			<enable>yes</enable><table>vw_inventchkout_sideinfo</table><selectfields>branch_id,first_name,last_name,order_status,inventory_checkout_status</selectfields><idfield>order_id</idfield><format>*;_*_*;_ORDER_STATUS:_*;_CHECKOUT_STATUS:_*</format>\r\n		</sideinfo>	\r\n	</field>	\r\n	<field><name>deliverynote_date</name><label>Deliverynote Date</label><type>date</type><value></value><options>size=10</options><onnew>readonly</onnew><onedit>readonly</onedit></field>\n	<field><name>details</name><label>Details</label><type>xmltable</type><value></value><options>rows=10 cols=100</options><onnew></onnew><onedit></onedit>\r\n		<subtable>\r\n			<subfield><subname>product_id</subname><sublabel>Product Id</sublabel><width>120</width><align>left</align></subfield>\r\n			<subfield><subname>description</subname><sublabel>Description</sublabel><width>400</width><align>left</align></subfield>\r\n			<subfield><subname>filled_qty</subname><sublabel>Quantity</sublabel><width>120</width><align>center</align></subfield>\r\n		</subtable>\r\n	</field>\r\n	<field><name>status</name><label>Status</label><type>input</type><value></value><options>size=30</options><onnew>readonly_po</onnew><onedit>readonly_po</onedit>\r\n		<sidelink>\r\n			<link><src>javascript:void(0)</src><attr>onclick=order_ToggleStatus()</attr><text>Change</text></link>\r\n		</sidelink>\r\n	</field>\n	<field><name>delivered_by</name><label>Delivered By</label><type>input</type><value></value><options>size=30</options><onnew>enabled_po</onnew><onedit>enabled_po</onedit>\r\n		<popout><enable>yes</enable><table>vw_userbranches</table><selectfields>idname,fullname</selectfields><idfield>idname</idfield></popout>\r\n	</field>\n	<field><name>delivery_date</name><label>Delivery Date</label><type>date</type><value></value><options>size=10</options><onnew>readonly_po</onnew><onedit>readonly_po</onedit></field>\n	<field><name>returned_signed_by</name><label>Returned Signed By</label><type>input</type><value></value><options>size=30</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>returned_signed_date</name><label>Returned Signed Date</label><type>date</type><value></value><options>size=10</options><onnew>readonly_po</onnew><onedit>readonly_po</onedit></field>\n	<field><name>comments</name><label>Comments</label><type>textarea</type><value></value><options>rows=2 cols=50</options><onnew></onnew><onedit></onedit></field>\r\n</formfields>','sales',0,1,'default_index','default_view','default_input','default_authorize','default_delete','default_enquiry','deliverynote_id','','Deliverynote Id','Delivery Note','Model_SiteDB','deliverynotes','deliverynotes_is','deliverynotes_hs','deliverynote_error','IMPLEMENTATION','2012-04-30 13:04:01','ADMIN','2012-04-30 13:01:24','LIVE',1),(409,'core_sales_tilluser','tilluser','Y','<?xml version=\'1.0\' standalone=\'yes\'?>\n<formfields>\n	<field><name>id</name><label>Id</label><type>hidden</type><value></value><options></options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>till_id</name><label>Till Id</label><type>input</type><value></value><options>size=50</options><onnew>readonly</onnew><onedit>readonly</onedit></field>\n	<field><name>till_user</name><label>Till User</label><type>input</type><value></value><options>size=30</options><onnew>readonly</onnew><onedit>readonly</onedit></field>\n	<field><name>till_date</name><label>Till Date</label><type>date</type><value></value><options>size=10 maxlength=10</options><onnew>readonly</onnew><onedit>readonly</onedit></field>\n	<field><name>initial_balance</name><label>Initial Balance</label><type>input</type><value></value><options>size=10 </options><onnew>enabled</onnew><onedit>readonly</onedit></field>\n	<field><name>status</name><label>Status</label><type>dropdown</type><value></value><options>OPEN,CLOSED::OPEN,CLOSED</options><onnew></onnew><onedit></onedit></field>\n	<field><name>expiry_date</name><label>Expiry Date</label><type>date</type><value></value><options>size=10 maxlength=10</options><onnew>readonly</onnew><onedit>readonly</onedit></field>	\r\n	<field><name>expiry_time</name><label>Expiry Time</label><type>input</type><value></value><options>size=10 maxlength=10</options><onnew>readonly_po</onnew><onedit>readonly</onedit>\r\n		<popout><enable>yes</enable><table>daytimes</table><selectfields>daytime_id,description</selectfields><idfield>daytime_id</idfield></popout>\r\n	</field>\n</formfields>','sales',0,1,'default_index','default_view','default_input','default_authorize','default_delete','default_enquiry','till_id','','Till_Id','Till User','Model_SiteDB','tills','tills_is','tills_hs','till_error','IMPLEMENTATION','2012-05-02 19:05:38','ADMIN','2012-05-02 19:06:25','LIVE',1),(410,'core_sales_tillmanage','tillmanage','Y','<?xml version=\'1.0\' standalone=\'yes\'?>\n<formfields>\r\n	<field><name>id</name><label>Id</label><type>hidden</type><value></value><options></options><onnew>enabled</onnew><onedit>enabled</onedit></field>\r\n	<field><name>till_id</name><label>Till Id</label><type>input</type><value></value><options>size=50</options><onnew>readonly</onnew><onedit>readonly</onedit></field>\r\n	<field><name>till_user</name><label>Till User</label><type>input</type><value></value><options>size=30</options><onnew>readonly_po</onnew><onedit>readonly</onedit>\r\n		<popout><enable>yes</enable><table>vw_userbranches</table><selectfields>idname,fullname</selectfields><idfield>idname</idfield></popout>\r\n	</field>\r\n	<field><name>till_date</name><label>Till Date</label><type>date</type><value></value><options>size=10 maxlength=10</options><onnew>readonly_po</onnew><onedit>readonly</onedit></field>\r\n	<field><name>initial_balance</name><label>Initial Balance</label><type>input</type><value></value><options>size=10 </options><onnew>enabled</onnew><onedit>readonly</onedit></field>\r\n	<field><name>status</name><label>Status</label><type>dropdown</type><value></value><options>OPEN,CLOSED::OPEN,CLOSED</options><onnew></onnew><onedit></onedit></field>\r\n	<field><name>expiry_date</name><label>Expiry Date</label><type>date</type><value></value><options>size=10 maxlength=10</options><onnew>readonly</onnew><onedit>readonly</onedit></field>\r\n	<field><name>expiry_time</name><label>Expiry Time</label><type>input</type><value></value><options>size=10 maxlength=10</options><onnew>readonly_po</onnew><onedit>readonly_po</onedit>\r\n		<popout><enable>yes</enable><table>daytimes</table><selectfields>daytime_id,description</selectfields><idfield>daytime_id</idfield></popout>	\r\n	</field>\r\n</formfields>\r\n','sales',0,1,'default_index','default_view','default_input','default_authorize','default_delete','default_enquiry','till_id','','Till_Id','Till Manage','Model_SiteDB','tills','tills_is','tills_hs','till_error','IMPLEMENTATION','2012-05-02 20:05:11','ADMIN','2012-05-02 20:02:16','LIVE',1),(411,'core_sales_tilltransaction','tilltransaction','Y','<?xml version=\'1.0\' standalone=\'yes\'?>\n<formfields>\n	<field><name>id</name><label>Id</label><type>hidden</type><value></value><options></options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>transaction_id</name><label>Transaction Id</label><type>input</type><value></value><options>size=20</options><onnew>readonly</onnew><onedit>readonly</onedit></field>\n	<field><name>till_id</name><label>Till Id</label><type>input</type><value></value><options>size=50</options><onnew>enable</onnew><onedit>readonly</onedit></field>\n	<field><name>amount</name><label>Amount</label><type>input</type><value></value><options>size=12</options><onnew>enabled</onnew><onedit>readonly</onedit></field>\n	<field><name>transaction_type</name><label>Transaction Type</label><type>dropdown</type><value></value><options>CASH,CHEQUE,DEBIT.CARD,CREDIT.CARD::CASH,CHEQUE,DEBIT.CARD,CREDIT.CARD</options><onnew></onnew><onedit></onedit></field>\n	<field><name>transaction_date</name><label>Transaction Date</label><type>input</type><value></value><options>size=12</options><onnew>readonly</onnew><onedit>readonly</onedit></field>\r\n	<field><name>movement</name><label>Movement</label><type>dropdown</type><value></value><options>IN,OUT::IN,OUT</options><onnew></onnew><onedit></onedit></field>\n	<field><name>reason</name><label>Reason</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>readonly</onedit></field>\n	<field><name>comments</name><label>Comments</label><type>textarea</type><value></value><options>rows=2 cols=50</options><onnew></onnew><onedit></onedit></field>\r\n</formfields>','sales',0,1,'default_index','default_view','default_input','default_authorize','default_delete','default_enquiry','transaction_id','','Tilltransaction Id','Till Transaction','Model_SiteDB','tilltransactions','tilltransactions_is','tilltransactions_hs','tilltransaction_error','IMPLEMENTATION','2012-05-03 16:05:10','ADMIN','2012-05-03 16:02:13','LIVE',1),(412,'core_sales_payment','payment','Y','<?xml version=\'1.0\' standalone=\'yes\'?>\n<formfields>\n	<field><name>id</name><label>Id</label><type>hidden</type><value></value><options></options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>payment_id</name><label>Payment Id</label><type>input</type><value></value><options>size=20</options><onnew>readonly</onnew><onedit>readonly</onedit></field>\n	<field><name>branch_id</name><label>Branch Id</label><type>input</type><value></value><options>size=25</options><onnew>readonly</onnew><onedit>readonly</onedit></field>\n	<field><name>till_id</name><label>Till Id</label><type>input</type><value></value><options>size=50</options><onnew>readonly</onnew><onedit>readonly</onedit></field>\n	<field><name>order_id</name><label>Order Id</label><type>input</type><value></value><options>size=20 onFocus=sideinfo.Update(%FIELDS%,%TABLE%,%IDFIELD%,%RETFIELD%,%FORMAT%) onKeyUp=sideinfo.Update(%FIELDS%,%TABLE%,%IDFIELD%,%RETFIELD%,%FORMAT%)</options><onnew>readonly_po</onnew><onedit>readonly</onedit>\r\n		<popout><enable>yes</enable><table>vw_orderbalances_nonzero</table><selectfields>order_id,order_date,first_name,last_name,order_total,payment_total,balance,order_status,branch_id</selectfields><idfield>order_id</idfield></popout>\r\n		<sideinfo>\r\n			<enable>yes</enable><table>vw_inventchkout_sideinfo</table><selectfields>branch_id,first_name,last_name,order_status,order_date</selectfields><idfield>order_id</idfield><format>*;_*_*;_ORDER_STATUS:_*;_ORDER_DATE:_*</format>\r\n		</sideinfo>\r\n	</field>\n	<field><name>amount</name><label>Amount</label><type>input</type><value></value><options>size=20</options><onnew>enabled</onnew><onedit>enabled</onedit>\r\n		<sidefunc><enable>yes</enable><func></func><idfield></idfield><format>Order_Balance:_*</format></sidefunc>\r\n	</field>\n	<field><name>payment_type</name><label>Payment Type</label><type>dropdown</type><value></value><options>CASH,CHEQUE,DEBIT.CARD,CREDIT.CARD::CASH,CHEQUE,DEBIT.CARD,CREDIT.CARD</options><onnew></onnew><onedit></onedit></field>\n	<field><name>payment_date</name><label>Payment Date</label><type>date</type><value></value><options>size=10 maxlength=10</options><onnew>enabled_po</onnew><onedit>readonly</onedit></field>\r\n	<field><name>ref_no</name><label>Ref No</label><type>input</type><value></value><options>size=20</options><onnew>enabled</onnew><onedit>readonly</onedit></field>\n	<field><name>payment_status</name><label>Payment Status</label><type>input</type><value></value><options>size=20</options><onnew>readonly</onnew><onedit>readonly</onedit></field>\n	<field><name>comments</name><label>Comments</label><type>textarea</type><value></value><options>rows=2 cols=50</options><onnew></onnew><onedit></onedit></field>\n</formfields>','sales',0,1,'default_index','default_view','default_input','default_authorize','default_delete','default_enquiry','payment_id','','Payment Id','Payment','Model_SiteDB','payments','payments_is','payments_hs','payment_error','IMPLEMENTATION','2012-05-04 09:05:31','ADMIN','2012-05-04 09:02:22','LIVE',1),(413,'core_sales_paymentcancel','paymentcancel','Y','<?xml version=\'1.0\' standalone=\'yes\'?>\n<formfields>\r\n	<field><name>id</name><label>Id</label><type>hidden</type><value></value><options></options><onnew>enabled</onnew><onedit>enabled</onedit></field>\r\n	<field><name>paymentcancel_id</name><label>Payment Cancel Id</label><type>input</type><value></value><options>size=25</options><onnew>readonly</onnew><onedit>readonly</onedit></field>\r\n	<field><name>payment_id</name><label>Payment Id</label><type>input</type><value></value><options>size=25 onFocus=sideinfo.Update(%FIELDS%,%TABLE%,%IDFIELD%,%RETFIELD%,%FORMAT%) onKeyUp=sideinfo.Update(%FIELDS%,%TABLE%,%IDFIELD%,%RETFIELD%,%FORMAT%)</options>\r\n		<onnew>readonly_po</onnew><onedit>readonly</onedit>\r\n		<popout><enable>yes</enable><table>vw_payments_valid</table><selectfields>id,payment_id,payment_date,amount,payment_type,order_id,branch_id,till_id</selectfields><idfield>payment_id</idfield></popout>\r\n		<sideinfo>\r\n			<enable>yes</enable><table>payments</table><selectfields>payment_status,amount,payment_type,order_id,till_id</selectfields><idfield>payment_id</idfield><format>*;_*;_*;_*;_*</format>\r\n		</sideinfo>\r\n	</field>	\r\n	<field><name>amount</name><label>Amount</label><type>input</type><value></value><options>size=20</options><onnew>readonly</onnew><onedit>readonly</onedit></field>\r\n	<field><name>reason</name><label>Reason</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\r\n	<field><name>comments</name><label>Comments</label><type>textarea</type><value></value><options>rows=2 cols=50</options><onnew></onnew><onedit></onedit></field>\r\n</formfields>','sales',1,1,'default_index','default_view','default_input','default_authorize','default_delete','default_enquiry','paymentcancel_id','','Payment Cancel Id','Payment Cancel Request','Model_SiteDB','paymentcancels','paymentcancels_is','paymentcancels_hs','paymentcancel_error','IMPLEMENTATION','2012-12-23 19:12:54','ADMIN','2012-12-23 19:47:49','LIVE',1),(414,'core_customer_chargeaccount','chargeaccount','Y','<?xml version=\'1.0\' standalone=\'yes\'?>\n<formfields>\n	<field><name>id</name><label>Id</label><type>hidden</type><value></value><options></options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>customer_id</name><label>Customer Id</label><type>input</type><value></value><options>size=10 onFocus=sideinfo.Update(%FIELDS%,%TABLE%,%IDFIELD%,%RETFIELD%,%FORMAT%) onKeyUp=sideinfo.Update(%FIELDS%,%TABLE%,%IDFIELD%,%RETFIELD%,%FORMAT%)</options>\r\n	<onnew>readonly_po</onnew><onedit>readonly</onedit>\r\n	<popout><enable>yes</enable><table>customers</table><selectfields>id,customer_id,customer_type,business_type,first_name,last_name,phone_mobile1</selectfields><idfield>customer_id</idfield></popout>\r\n	<sideinfo>\r\n		<enable>yes</enable><table>customers</table><selectfields>first_name,last_name,customer_type,business_type</selectfields><idfield>customer_id</idfield><format>*_*;_*;_*</format>\r\n	</sideinfo>\r\n	</field>	\r\n	<field><name>activation_date</name><label>Activation Date</label><type>date</type><value></value><options>size=12 maxlength=10</options><onnew>enabled_po</onnew><onedit>enabled</onedit></field>\n	<field><name>status_change_date</name><label>Status Change Date</label><type>date</type><value></value><options>size=12 maxlength=10</options><onnew>enabled_po</onnew><onedit>enabled_po</onedit></field>\n	<field><name>active</name><label>Active</label><type>dropdown</type><value></value><options>N,Y::N,Y</options><onnew></onnew><onedit></onedit></field>\r\n	<field><name>special_instructions</name><label>Special Instructions</label><type>textarea</type><value></value><options>rows=2 cols=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\r\n	<field><name>comments</name><label>Comments</label><type>textarea</type><value></value><options>rows=2 cols=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n</formfields>','customer',0,1,'default_index','default_view','default_input','default_authorize','default_delete','default_enquiry','customer_id','','Customer Id','Charge Account','Model_SiteDB','chargeaccounts','chargeaccounts_is','chargeaccounts_hs','chargeaccount_error','IMPLEMENTATION','2013-02-18 06:20:21','ADMIN','2013-02-18 06:20:48','LIVE',1),(415,'core_sales_inventorysalelog','inventorysalelog','Y','<?xml version=\'1.0\' standalone=\'yes\'?>\n<formfields>\n	<field><name>id</name><label>Id</label><type>hidden</type><value></value><options></options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>inventory_id</name><label>Inventory Id</label><type>input</type><value></value><options>size=50</options><onnew>readonly</onnew><onedit>readonly</onedit></field>\n	<field><name>order_id</name><label>Order Id</label><type>input</type><value></value><options>size=50</options><onnew>readonly</onnew><onedit>readonly</onedit></field>\n	<field><name>product_id</name><label>Product Id</label><type>input</type><value></value><options>size=25</options><onnew>readonly</onnew><onedit>readonly</onedit>\n		<sideinfo>\n			<enable>yes</enable><table>products</table><selectfields>product_description</selectfields><idfield>product_id</idfield><format>*</format>\n		</sideinfo>\n	</field>\n	<field><name>branch_id</name><label>Branch Id</label><type>input</type><value></value><options>size=25</options><onnew>readonly</onnew><onedit>readonly</onedit>\n		<sideinfo>\n			<enable>yes</enable><table>branches</table><selectfields>description</selectfields><idfield>branch_id</idfield><format>*</format>\n		</sideinfo>\n	</field>\n	<field><name>qty_instock</name><label>Quantity Instock</label><type>input</type><value></value><options>size=12</options><onnew>readonly</onnew><onedit>readonly</onedit></field>\n	<field><name>qty_diff</name><label>Difference</label><type>input</type><value></value><options>size=12</options><onnew>readonly</onnew><onedit>readonly</onedit></field>\n	<field><name>last_update_type</name><label>Update Type</label><type>input</type><value></value><options>size=25</options><onnew>readonly</onnew><onedit>readonly</onedit>\n		<sideinfo>\n			<enable>yes</enable><table>inventupdtypes</table><selectfields>description,stock_movement</selectfields><idfield>update_type_id</idfield><format>*;_*</format>\n		</sideinfo>\n	</field>\r\n	<field><name>update_date</name><label>Update Date</label><type>input</type><value></value><options>size=12</options><onnew>readonly</onnew><onedit>readonly</onedit></field>\r\n	<field><name>comments</name><label>Comments</label><type>textarea</type><value></value><options>rows=2 cols=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n</formfields>','sales',1,1,'default_index','default_view','default_input','default_authorize','default_delete','default_enquiry','id','','Id','Inventory Sale Log','Model_SiteDB','inventory_sale_logs','inventory_sale_logs','inventory_sale_logs','inventorysalelog_error','IMPLEMENTATION','2013-02-25 14:21:51','ADMIN','2013-02-25 14:22:14','LIVE',1),(416,'core_sales_ordercancel','ordercancel','Y','<?xml version=\'1.0\' standalone=\'yes\'?>\r\n<formfields>\r\n	<field><name>id</name><label>Id</label><type>hidden</type><value></value><options></options><onnew>enabled</onnew><onedit>enabled</onedit></field>\r\n	<field><name>ordercancel_id</name><label>Ordercancel Id</label><type>input</type><value></value><options>size=25</options><onnew>readonly</onnew><onedit>readonly</onedit></field>\r\n	<field><name>order_id</name><label>Order Id</label><type>input</type><value></value><options>size=25 onFocus=sideinfo.Update(%FIELDS%,%TABLE%,%IDFIELD%,%RETFIELD%,%FORMAT%) onKeyUp=sideinfo.Update(%FIELDS%,%TABLE%,%IDFIELD%,%RETFIELD%,%FORMAT%)</options>\r\n		<onnew>readonly_po</onnew><onedit>readonly</onedit>\r\n		<popout><enable>yes</enable><table>vw_ordercancel_candidates</table><selectfields>id,order_id,customer_id,order_status,order_date,branch_id</selectfields><idfield>order_id</idfield></popout>\r\n		<sideinfo>\r\n			<enable>yes</enable><table>orders</table><selectfields>id,order_id,customer_id,order_status,order_date,branch_id</selectfields><idfield>order_id</idfield><format>*;_*;_*;_*;_*;_*</format>\r\n		</sideinfo>\r\n	</field>	\r\n	<field><name>pre_cancel_status</name><label>Pre-Cancel Status</label><type>input</type><value></value><options>size=25</options><onnew>readonly</onnew><onedit>readonly</onedit></field>\r\n	<field><name>reason</name><label>Reason</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\r\n	<field><name>comments</name><label>Comments</label><type>textarea</type><value></value><options>rows=2 cols=50</options><onnew></onnew><onedit></onedit></field>\r\n</formfields>','sales',1,1,'default_index','default_view','default_input','default_authorize','default_delete','default_enquiry','ordercancel_id','','Ordercancel Id','Order Cancel Request','Model_SiteDB','ordercancels','ordercancels_is','ordercancels_hs','ordercancel_error','IMPLEMENTATION','2013-03-18 02:26:43','ADMIN','2013-03-18 02:27:32','LIVE',1),(417,'core_sales_orderopen','orderopen','Y','<?xml version=\'1.0\' standalone=\'yes\'?>\n<formfields>\n	<field><name>id</name><label>Id</label><type>hidden</type><value></value><options></options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>orderopen_id</name><label>Orderopen Id</label><type>input</type><value></value><options>size=25</options><onnew>readonly</onnew><onedit>readonly</onedit></field>\n	<field><name>order_id</name><label>Order Id</label><type>input</type><value></value><options>size=25 onFocus=sideinfo.Update(%FIELDS%,%TABLE%,%IDFIELD%,%RETFIELD%,%FORMAT%) onKeyUp=sideinfo.Update(%FIELDS%,%TABLE%,%IDFIELD%,%RETFIELD%,%FORMAT%)</options>\n		<onnew>readonly_po</onnew><onedit>readonly</onedit>\n		<popout><enable>yes</enable><table>vw_orderreopen_candidates</table><selectfields>id,order_id,customer_id,order_status,order_date,branch_id</selectfields><idfield>order_id</idfield></popout>\n		<sideinfo>\n			<enable>yes</enable><table>orders</table><selectfields>id,order_id,customer_id,order_status,order_date,branch_id</selectfields><idfield>order_id</idfield><format>*;_*;_*;_*;_*;_*</format>\n		</sideinfo>\n	</field>	\n	<field><name>pre_open_status</name><label>Pre-Open Status</label><type>input</type><value></value><options>size=25</options><onnew>readonly</onnew><onedit>readonly</onedit></field>\n	<field><name>reason</name><label>Reason</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>comments</name><label>Comments</label><type>textarea</type><value></value><options>rows=2 cols=50</options><onnew></onnew><onedit></onedit></field>\n</formfields>','sales',1,1,'default_index','default_view','default_input','default_authorize','default_delete','default_enquiry','orderopen_id','','Orderopen Id','Order Re-Open Request','Model_SiteDB','orderopens','orderopens_is','orderopens_hs','orderopen_error','IMPLEMENTATION','2013-03-20 17:21:32','ADMIN','2013-03-20 17:21:47','LIVE',1),(418,'core_businessadmin_bicrmonthly','bicrmonthly','Y','<?xml version=\'1.0\' standalone=\'yes\'?>\n<formfields>\n	<field><name>id</name><label>Id</label><type>hidden</type><value></value><options></options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>batchrequest_id</name><label>Batchrequest Id</label><type>input</type><value></value><options>size=50</options><onnew>readonly</onnew><onedit>readonly</onedit></field>\n	<field><name>requesttype</name><label>Request Type</label><type>dropdown</type><value></value><options>EOMCC-ALL,EOMCC-ONE::EOMCC-ALL,EOMCC-ONE</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>cc_id</name><label>Charge Customer Id</label><type>input</type><value></value><options>size=10 onFocus=sideinfo.Update(%FIELDS%,%TABLE%,%IDFIELD%,%RETFIELD%,%FORMAT%) onKeyUp=sideinfo.Update(%FIELDS%,%TABLE%,%IDFIELD%,%RETFIELD%,%FORMAT%)</options>\n	<onnew>readonly_po</onnew><onedit>readonly</onedit>\n		<popout><enable>yes</enable><table>vw_active_charge_customers</table><selectfields>id,customer_id,customer_type,business_type,first_name,last_name,phone_mobile1</selectfields><idfield>customer_id</idfield></popout>\n		<sideinfo>\n			<enable>yes</enable><table>customers</table><selectfields>first_name,last_name,customer_type,business_type</selectfields><idfield>customer_id</idfield><format>*_*;_*;_*</format>\n		</sideinfo>\n	</field>\n	<field><name>description</name><label>Description</label><type>input</type><value></value><options>size=50</options><onnew>readonly</onnew><onedit>readonly</onedit></field>\n	<field><name>start_date</name><label>Start Date</label><type>month</type><value></value><options>size=12 maxlength=10</options><onnew>enabled_po</onnew><onedit>readonly</onedit></field>\r\n	<field><name>end_date</name><label>End Date</label><type>input</type><value></value><options>size=12 maxlength=10</options><onnew>readonly</onnew><onedit>readonly</onedit></field>\n	<field><name>run</name><label>Run Request Update</label><type>dropdown</type><value></value><options>Y,N::Y,N</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>comments</name><label>Comments</label><type>textarea</type><value></value><options>rows=2 cols=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n</formfields>','businessadmin',0,1,'default_index','default_view','default_input','default_authorize','default_delete','default_enquiry','batchrequest_id','','Batchrequest Id','Batch Invoice Creation Request (Charge Monthly)','Model_SiteDB','bicrs','bicrs_is','bicrs_hs','bicr_error','IMPLEMENTATION','2013-03-29 15:22:49','ADMIN','2013-03-29 15:34:50','LIVE',1),(419,'core_businessadmin_bicrperiod','bicrperiod','Y','<?xml version=\'1.0\' standalone=\'yes\'?>\n<formfields>\n	<field><name>id</name><label>Id</label><type>hidden</type><value></value><options></options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>batchrequest_id</name><label>Batchrequest Id</label><type>input</type><value></value><options>size=50</options><onnew>readonly</onnew><onedit>readonly</onedit></field>\n	<field><name>requesttype</name><label>Request Type</label><type>dropdown</type><value></value><options>PERCC-ONE::PERCC-ONE</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>cc_id</name><label>Charge Customer Id</label><type>input</type><value></value><options>size=10 onFocus=sideinfo.Update(%FIELDS%,%TABLE%,%IDFIELD%,%RETFIELD%,%FORMAT%) onKeyUp=sideinfo.Update(%FIELDS%,%TABLE%,%IDFIELD%,%RETFIELD%,%FORMAT%)</options>\n	<onnew>readonly_po</onnew><onedit>readonly</onedit>\n		<popout><enable>yes</enable><table>vw_active_charge_customers</table><selectfields>id,customer_id,customer_type,business_type,first_name,last_name,phone_mobile1</selectfields><idfield>customer_id</idfield></popout>\n		<sideinfo>\n			<enable>yes</enable><table>customers</table><selectfields>first_name,last_name,customer_type,business_type</selectfields><idfield>customer_id</idfield><format>*_*;_*;_*</format>\n		</sideinfo>\n	</field>\n	<field><name>description</name><label>Description</label><type>input</type><value></value><options>size=50</options><onnew>enable</onnew><onedit>enable</onedit></field>\n	<field><name>start_date</name><label>Start Date</label><type>date</type><value></value><options>size=12 maxlength=10</options><onnew>enabled_po</onnew><onedit>readonly</onedit></field>\n	<field><name>end_date</name><label>End Date</label><type>date</type><value></value><options>size=12 maxlength=10</options><onnew>enabled_po</onnew><onedit>readonly</onedit></field>\n	<field><name>run</name><label>Run Request Update</label><type>dropdown</type><value></value><options>Y,N::Y,N</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>comments</name><label>Comments</label><type>textarea</type><value></value><options>rows=2 cols=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n</formfields>','businessadmin',0,1,'default_index','default_view','default_input','default_authorize','default_delete','default_enquiry','batchrequest_id','','Batchrequest Id','Batch Invoice Creation Request (Charge Period)','Model_SiteDB','bicrs','bicrs_is','bicrs_hs','bicr_error','IMPLEMENTATION','2013-03-29 15:03:17','ADMIN','2013-03-29 15:50:53','LIVE',1),(1001,'hndshkif_settings_interfaceconfiguration','interfaceconfiguration','Y','<?xml version=\'1.0\' standalone=\'yes\'?>\n<formfields>\n	<field><name>id</name><label>Id</label><type>hidden</type><value></value><options></options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>config_id</name><label>Config Id</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>readonly</onedit></field>\n	<field><name>db_server</name><label>Db Server</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>db_name</name><label>Database Name</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>db_user</name><label>Database User</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>db_password</name><label>Database Password</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>hs_apikey</name><label>Handshake API Key</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>folderc_import</name><label>DacEasy Import File Location (Current)</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>folderc_export</name><label>DacEasy Export File Location (Current)</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>foldera_import</name><label>DacEasy Import File Location (Archive)</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>foldera_export</name><label>DacEasy Export File Location (Archive)</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>comments</name><label>Comments</label><type>textarea</type><value></value><options>rows=2 cols=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n</formfields>','hndshkif',0,1,'default_index','default_view','default_input','default_authorize','default_delete','default_enquiry','config_id','','Config Id','Interface Configuration','Model_SiteDB','interfaceconfigurations','interfaceconfigurations_is','interfaceconfigurations_hs','interfaceconfiguration_error','ADMIN','2013-09-13 16:21:41','ADMIN','2013-09-13 16:23:42','LIVE',1),(1002,'hndshkif_orders_gethandshakeorders','gethandshakeorders','Y','<?xml version=\'1.0\' standalone=\'yes\'?>\r\n<formfields>\r\n	<field><name>id</name><label>Id</label><type>hidden</type><value></value><options></options><onnew>enabled</onnew><onedit>enabled</onedit></field>\r\n	<field><name>request_id</name><label>Request Id</label><type>input</type><value></value><options>size=30</options><onnew>enabled</onnew><onedit>readonly</onedit></field>\r\n	<field><name>description</name><label>Description</label><type>input</type><value></value><options>size=50</options><onnew>readonly</onnew><onedit>readonly</onedit></field>\r\n	<field><name>run</name><label>Update Orders</label><type>dropdown</type><value></value><options>N,Y::N,Y</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\r\n	<field><name>comments</name><label>Comments</label><type>textarea</type><value></value><options>rows=2 cols=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\r\n</formfields>','hndshkif',0,1,'default_index','default_view','default_input','default_authorize','default_delete','default_enquiry','request_id','','Request Id','Get Handshake Orders','Model_SiteDB','dlors','dlors_is','dlors_hs','gethandshakeorders_error','ADMIN','2013-09-14 03:51:43','ADMIN','2013-09-14 03:53:02','LIVE',1),(1003,'hndshkif_orders_dlorder','dlorder','Y','<?xml version=\'1.0\' standalone=\'yes\'?>\n<formfields>\n	<field><name>id</name><label>Id</label><type>hidden</type><value></value><options></options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>order_id</name><label>Order Id</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>batch_id</name><label>Batch Id</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>customer_id</name><label>Customer Id</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>tax_id</name><label>Tax Id</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>name</name><label>Name</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>contact</name><label>Contact</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>street</name><label>Street</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>city</name><label>City</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>country</name><label>Country</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>phone</name><label>Phone</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>paymentterms</name><label>Payment Terms</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>cdate</name><label>Creation Date</label><type>date</type><value></value><options>size=12 maxlength=10</options><onnew>enabled_po</onnew><onedit>enabled_po</onedit></field>\n	<field><name>ctime</name><label>Creation Time</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n	<field><name>orderlines</name><label>Orderlines</label><type>input</type><value></value><options>size=50</options><onnew>enabled</onnew><onedit>enabled</onedit></field>\n</formfields>','hndshkif',0,1,'default_index','default_view','default_input','default_authorize','default_delete','default_enquiry','id','','Order Id','Downloaded Orders','Model_SiteDB','dlorders','dlorders_is','dlorders_hs','dlorder_error','ADMIN','2013-09-14 05:08:51','ADMIN','2013-09-14 05:08:56','LIVE',1);
/*!40000 ALTER TABLE `params` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `params_hs`
--

DROP TABLE IF EXISTS `params_hs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `params_hs` (
  `id` int(11) unsigned NOT NULL,
  `param_id` varchar(255) DEFAULT NULL,
  `controller` varchar(255) DEFAULT NULL,
  `dflag` enum('Y','N') DEFAULT NULL,
  `formfields` text,
  `module` varchar(255) DEFAULT NULL,
  `auth_mode_on` tinyint(1) NOT NULL DEFAULT '1',
  `index_field_on` tinyint(1) NOT NULL DEFAULT '1',
  `indexview` varchar(255) DEFAULT 'default_index',
  `viewview` varchar(255) DEFAULT 'default_view',
  `inputview` varchar(255) DEFAULT 'default_input',
  `authorizeview` varchar(255) DEFAULT 'default_authorize',
  `deleteview` varchar(255) DEFAULT 'default_delete',
  `enquiryview` varchar(255) DEFAULT 'default_enquiry',
  `indexfield` varchar(255) NOT NULL DEFAULT 'id' COMMENT 'name of field on indexview',
  `indexfieldvalue` varchar(255) DEFAULT NULL COMMENT 'value of field on indexview',
  `indexlabel` varchar(255) DEFAULT 'Id' COMMENT 'name of field on indexview',
  `appheader` varchar(255) DEFAULT NULL COMMENT 'name of app usually backend table',
  `primarymodel` varchar(255) DEFAULT 'Site_Model',
  `tb_live` varchar(255) DEFAULT NULL,
  `tb_inau` varchar(255) DEFAULT NULL,
  `tb_hist` varchar(255) DEFAULT NULL,
  `errormsgfile` varchar(255) DEFAULT NULL,
  `inputter` varchar(50) NOT NULL,
  `input_date` datetime NOT NULL,
  `authorizer` varchar(50) NOT NULL,
  `auth_date` datetime NOT NULL,
  `record_status` char(4) NOT NULL,
  `current_no` int(11) NOT NULL,
  PRIMARY KEY (`id`,`current_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `params_hs`
--

LOCK TABLES `params_hs` WRITE;
/*!40000 ALTER TABLE `params_hs` DISABLE KEYS */;
/*!40000 ALTER TABLE `params_hs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `params_is`
--

DROP TABLE IF EXISTS `params_is`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `params_is` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `param_id` varchar(255) DEFAULT NULL,
  `controller` varchar(255) DEFAULT NULL,
  `dflag` enum('Y','N') DEFAULT NULL,
  `formfields` text,
  `module` varchar(255) DEFAULT NULL,
  `auth_mode_on` tinyint(1) DEFAULT '1',
  `index_field_on` tinyint(1) DEFAULT '1',
  `indexview` varchar(255) DEFAULT 'default_index',
  `viewview` varchar(255) DEFAULT 'default_view',
  `inputview` varchar(255) DEFAULT 'default_input',
  `authorizeview` varchar(255) DEFAULT 'default_authorize',
  `deleteview` varchar(255) DEFAULT 'default_delete',
  `enquiryview` varchar(255) DEFAULT 'default_enquiry',
  `indexfield` varchar(255) DEFAULT 'id' COMMENT 'name of field on indexview',
  `indexfieldvalue` varchar(255) DEFAULT NULL COMMENT 'value of field on indexview',
  `indexlabel` varchar(255) DEFAULT 'Id' COMMENT 'name of field on indexview',
  `appheader` varchar(255) DEFAULT NULL COMMENT 'name of app usually backend table',
  `primarymodel` varchar(255) DEFAULT 'Site_Model',
  `tb_live` varchar(255) DEFAULT NULL,
  `tb_inau` varchar(255) DEFAULT NULL,
  `tb_hist` varchar(255) DEFAULT NULL,
  `errormsgfile` varchar(255) DEFAULT NULL,
  `inputter` varchar(50) DEFAULT NULL,
  `input_date` datetime DEFAULT NULL,
  `authorizer` varchar(50) DEFAULT NULL,
  `auth_date` datetime DEFAULT NULL,
  `record_status` char(4) DEFAULT NULL,
  `current_no` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_controller` (`controller`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `params_is`
--

LOCK TABLES `params_is` WRITE;
/*!40000 ALTER TABLE `params_is` DISABLE KEYS */;
/*!40000 ALTER TABLE `params_is` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `paymentcancels`
--

DROP TABLE IF EXISTS `paymentcancels`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `paymentcancels` (
  `id` int(11) unsigned NOT NULL,
  `paymentcancel_id` varchar(16) NOT NULL,
  `payment_id` varchar(16) NOT NULL,
  `amount` float(16,2) NOT NULL,
  `reason` varchar(255) NOT NULL,
  `comments` text,
  `inputter` varchar(50) NOT NULL,
  `input_date` datetime NOT NULL,
  `authorizer` varchar(50) NOT NULL,
  `auth_date` datetime NOT NULL,
  `record_status` char(4) NOT NULL,
  `current_no` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_paymentcancel_id` (`paymentcancel_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `paymentcancels`
--

LOCK TABLES `paymentcancels` WRITE;
/*!40000 ALTER TABLE `paymentcancels` DISABLE KEYS */;
/*!40000 ALTER TABLE `paymentcancels` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `paymentcancels_hs`
--

DROP TABLE IF EXISTS `paymentcancels_hs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `paymentcancels_hs` (
  `id` int(11) unsigned NOT NULL,
  `paymentcancel_id` varchar(16) NOT NULL,
  `payment_id` varchar(16) NOT NULL,
  `amount` float(16,2) NOT NULL,
  `reason` varchar(255) NOT NULL,
  `comments` text,
  `inputter` varchar(50) NOT NULL,
  `input_date` datetime NOT NULL,
  `authorizer` varchar(50) NOT NULL,
  `auth_date` datetime NOT NULL,
  `record_status` char(4) NOT NULL,
  `current_no` int(11) NOT NULL,
  PRIMARY KEY (`id`,`current_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `paymentcancels_hs`
--

LOCK TABLES `paymentcancels_hs` WRITE;
/*!40000 ALTER TABLE `paymentcancels_hs` DISABLE KEYS */;
/*!40000 ALTER TABLE `paymentcancels_hs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `paymentcancels_is`
--

DROP TABLE IF EXISTS `paymentcancels_is`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `paymentcancels_is` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `paymentcancel_id` varchar(16) DEFAULT NULL,
  `payment_id` varchar(16) DEFAULT NULL,
  `amount` float(16,2) DEFAULT NULL,
  `reason` varchar(255) DEFAULT NULL,
  `comments` text,
  `inputter` varchar(50) DEFAULT NULL,
  `input_date` datetime DEFAULT NULL,
  `authorizer` varchar(50) DEFAULT NULL,
  `auth_date` datetime DEFAULT NULL,
  `record_status` char(4) DEFAULT NULL,
  `current_no` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_paymentcancel_id` (`paymentcancel_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `paymentcancels_is`
--

LOCK TABLES `paymentcancels_is` WRITE;
/*!40000 ALTER TABLE `paymentcancels_is` DISABLE KEYS */;
/*!40000 ALTER TABLE `paymentcancels_is` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payments`
--

DROP TABLE IF EXISTS `payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payments` (
  `id` int(11) unsigned NOT NULL,
  `payment_id` varchar(16) NOT NULL,
  `branch_id` varchar(50) NOT NULL,
  `till_id` varchar(59) NOT NULL,
  `order_id` varchar(16) NOT NULL,
  `amount` float(16,2) NOT NULL,
  `payment_type` enum('CASH','CHEQUE','DEBIT.CARD','CREDIT.CARD') NOT NULL,
  `payment_date` date NOT NULL,
  `ref_no` varchar(255) DEFAULT NULL,
  `payment_status` varchar(255) NOT NULL,
  `comments` text,
  `inputter` varchar(50) NOT NULL,
  `input_date` datetime NOT NULL,
  `authorizer` varchar(50) NOT NULL,
  `auth_date` datetime NOT NULL,
  `record_status` char(4) NOT NULL,
  `current_no` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_payment_id` (`payment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payments`
--

LOCK TABLES `payments` WRITE;
/*!40000 ALTER TABLE `payments` DISABLE KEYS */;
/*!40000 ALTER TABLE `payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payments_hs`
--

DROP TABLE IF EXISTS `payments_hs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payments_hs` (
  `id` int(11) unsigned NOT NULL,
  `payment_id` varchar(16) NOT NULL,
  `branch_id` varchar(50) NOT NULL,
  `till_id` varchar(59) NOT NULL,
  `order_id` varchar(16) NOT NULL,
  `amount` float(16,2) NOT NULL,
  `payment_type` enum('CASH','CHEQUE','DEBIT.CARD','CREDIT.CARD') NOT NULL,
  `payment_date` date NOT NULL,
  `ref_no` varchar(255) DEFAULT NULL,
  `payment_status` varchar(255) NOT NULL,
  `comments` text,
  `inputter` varchar(50) NOT NULL,
  `input_date` datetime NOT NULL,
  `authorizer` varchar(50) NOT NULL,
  `auth_date` datetime NOT NULL,
  `record_status` char(4) NOT NULL,
  `current_no` int(11) NOT NULL,
  PRIMARY KEY (`id`,`current_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payments_hs`
--

LOCK TABLES `payments_hs` WRITE;
/*!40000 ALTER TABLE `payments_hs` DISABLE KEYS */;
/*!40000 ALTER TABLE `payments_hs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payments_is`
--

DROP TABLE IF EXISTS `payments_is`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payments_is` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `payment_id` varchar(16) DEFAULT NULL,
  `branch_id` varchar(50) DEFAULT NULL,
  `till_id` varchar(59) DEFAULT NULL,
  `order_id` varchar(16) DEFAULT NULL,
  `amount` float(16,2) DEFAULT NULL,
  `payment_type` enum('CASH','CHEQUE','DEBIT.CARD','CREDIT.CARD') DEFAULT NULL,
  `payment_date` date DEFAULT NULL,
  `ref_no` varchar(255) DEFAULT NULL,
  `payment_status` varchar(255) DEFAULT NULL,
  `comments` text,
  `inputter` varchar(50) DEFAULT NULL,
  `input_date` datetime DEFAULT NULL,
  `authorizer` varchar(50) DEFAULT NULL,
  `auth_date` datetime DEFAULT NULL,
  `record_status` char(4) DEFAULT NULL,
  `current_no` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_payment_id` (`payment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payments_is`
--

LOCK TABLES `payments_is` WRITE;
/*!40000 ALTER TABLE `payments_is` DISABLE KEYS */;
/*!40000 ALTER TABLE `payments_is` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pdfs`
--

DROP TABLE IF EXISTS `pdfs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pdfs` (
  `id` int(11) unsigned NOT NULL,
  `pdf_id` varchar(30) NOT NULL,
  `pdf_template` varchar(50) NOT NULL,
  `controller` varchar(50) NOT NULL,
  `type` varchar(20) NOT NULL,
  `data` longtext,
  `data_type` enum('html','xml','json','csv','text') NOT NULL,
  `inputter` varchar(50) NOT NULL,
  `input_date` datetime NOT NULL,
  `authorizer` varchar(50) NOT NULL,
  `auth_date` datetime NOT NULL,
  `record_status` char(4) NOT NULL,
  `current_no` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_pdf_id` (`pdf_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pdfs`
--

LOCK TABLES `pdfs` WRITE;
/*!40000 ALTER TABLE `pdfs` DISABLE KEYS */;
/*!40000 ALTER TABLE `pdfs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pdfs_hs`
--

DROP TABLE IF EXISTS `pdfs_hs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pdfs_hs` (
  `id` int(11) unsigned NOT NULL,
  `pdf_id` varchar(30) NOT NULL,
  `pdf_template` varchar(50) NOT NULL,
  `controller` varchar(50) NOT NULL,
  `type` varchar(20) NOT NULL,
  `data` longtext,
  `data_type` enum('html','xml','json','csv','text') NOT NULL,
  `inputter` varchar(50) NOT NULL,
  `input_date` datetime NOT NULL,
  `authorizer` varchar(50) NOT NULL,
  `auth_date` datetime NOT NULL,
  `record_status` char(4) NOT NULL,
  `current_no` int(11) NOT NULL,
  PRIMARY KEY (`id`,`current_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pdfs_hs`
--

LOCK TABLES `pdfs_hs` WRITE;
/*!40000 ALTER TABLE `pdfs_hs` DISABLE KEYS */;
/*!40000 ALTER TABLE `pdfs_hs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pdfs_is`
--

DROP TABLE IF EXISTS `pdfs_is`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pdfs_is` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `pdf_id` varchar(30) DEFAULT NULL,
  `pdf_template` varchar(50) DEFAULT NULL,
  `controller` varchar(50) DEFAULT NULL,
  `type` varchar(20) DEFAULT NULL,
  `data` longtext,
  `data_type` enum('html','xml','json','csv','text') DEFAULT NULL,
  `inputter` varchar(50) DEFAULT NULL,
  `input_date` datetime DEFAULT NULL,
  `authorizer` varchar(50) DEFAULT NULL,
  `auth_date` datetime DEFAULT NULL,
  `record_status` char(4) DEFAULT NULL,
  `current_no` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_pdf_id` (`pdf_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pdfs_is`
--

LOCK TABLES `pdfs_is` WRITE;
/*!40000 ALTER TABLE `pdfs_is` DISABLE KEYS */;
/*!40000 ALTER TABLE `pdfs_is` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pdftemplates`
--

DROP TABLE IF EXISTS `pdftemplates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pdftemplates` (
  `id` int(11) unsigned NOT NULL,
  `template_id` varchar(50) NOT NULL,
  `pdf_header_class` varchar(50) NOT NULL,
  `pdf_template_file` varchar(255) NOT NULL,
  `pdf_page_orientation` enum('P','L') NOT NULL,
  `pdf_unit` enum('mm','cm','in','pt') NOT NULL,
  `pdf_page_format` varchar(50) NOT NULL,
  `pdf_output` enum('I','D','F','FI','FD','E','S') NOT NULL,
  `pdf_margin_top` float(5,2) unsigned NOT NULL,
  `pdf_margin_right` float(5,2) unsigned NOT NULL,
  `pdf_margin_bottom` float(5,2) unsigned NOT NULL,
  `pdf_margin_left` float(5,2) unsigned NOT NULL,
  `pdf_font_monospaced` varchar(50) NOT NULL,
  `pdf_font` varchar(50) NOT NULL,
  `pdf_fontstyle` varchar(3) DEFAULT NULL,
  `pdf_fontsize` int(4) unsigned NOT NULL,
  `inputter` varchar(50) NOT NULL,
  `input_date` datetime NOT NULL,
  `authorizer` varchar(50) NOT NULL,
  `auth_date` datetime NOT NULL,
  `record_status` char(4) NOT NULL,
  `current_no` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_template_id` (`template_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pdftemplates`
--

LOCK TABLES `pdftemplates` WRITE;
/*!40000 ALTER TABLE `pdftemplates` DISABLE KEYS */;
INSERT INTO `pdftemplates` VALUES (501,'INVOICE','SITEPDF','core_invoice.php','P','mm','LETTER','FI',38.00,12.00,15.00,12.00,'courier','helvetica',NULL,9,'ADMIN','2012-05-30 15:44:23','ADMIN','2012-05-30 15:44:35','LIVE',1),(502,'QUOTATION','SITEPDF','core_quotation.php','P','mm','LETTER','FI',38.00,12.00,15.00,12.00,'courier','helvetica','',9,'ADMIN','2012-07-24 16:06:16','ADMIN','2012-07-24 16:08:20','LIVE',1),(503,'BATCHINVOICESUMMARY','SITEPDF','core_batchinvoicesummary.php','L','mm','LETTER','FI',38.00,12.00,15.00,12.00,'courier','helvetica','',8,'ADMIN','2012-07-24 23:23:14','ADMIN','2012-07-24 23:23:23','LIVE',1),(504,'BATCHINVOICES','SITEPDF','core_batchinvoices.php','P','mm','LETTER','FI',38.00,12.00,15.00,12.00,'courier','helvetica','',9,'ADMIN','2012-07-24 16:09:39','ADMIN','2012-07-24 16:09:48','LIVE',1),(505,'DELIVERYNOTE','SITEPDF','core_deliverynote.php','P','mm','LETTER','FI',38.00,12.00,15.00,12.00,'courier','helvetica','',9,'ADMIN','2013-03-16 07:51:29','ADMIN','2013-03-16 07:51:37','LIVE',1);
/*!40000 ALTER TABLE `pdftemplates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pdftemplates_hs`
--

DROP TABLE IF EXISTS `pdftemplates_hs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pdftemplates_hs` (
  `id` int(11) unsigned NOT NULL,
  `template_id` varchar(50) NOT NULL,
  `pdf_header_class` varchar(50) NOT NULL,
  `pdf_template_file` varchar(255) NOT NULL,
  `pdf_page_orientation` enum('P','L') NOT NULL,
  `pdf_unit` enum('mm','cm','in','pt') NOT NULL,
  `pdf_page_format` varchar(50) NOT NULL,
  `pdf_output` enum('I','D','F','FI','FD','E','S') NOT NULL,
  `pdf_margin_top` float(5,2) unsigned NOT NULL,
  `pdf_margin_right` float(5,2) unsigned NOT NULL,
  `pdf_margin_bottom` float(5,2) unsigned NOT NULL,
  `pdf_margin_left` float(5,2) unsigned NOT NULL,
  `pdf_font_monospaced` varchar(50) NOT NULL,
  `pdf_font` varchar(50) NOT NULL,
  `pdf_fontstyle` varchar(3) DEFAULT NULL,
  `pdf_fontsize` int(4) unsigned NOT NULL,
  `inputter` varchar(50) NOT NULL,
  `input_date` datetime NOT NULL,
  `authorizer` varchar(50) NOT NULL,
  `auth_date` datetime NOT NULL,
  `record_status` char(4) NOT NULL,
  `current_no` int(11) NOT NULL,
  PRIMARY KEY (`id`,`current_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pdftemplates_hs`
--

LOCK TABLES `pdftemplates_hs` WRITE;
/*!40000 ALTER TABLE `pdftemplates_hs` DISABLE KEYS */;
/*!40000 ALTER TABLE `pdftemplates_hs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pdftemplates_is`
--

DROP TABLE IF EXISTS `pdftemplates_is`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pdftemplates_is` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `template_id` varchar(50) DEFAULT NULL,
  `pdf_header_class` varchar(50) DEFAULT 'SITEPDF',
  `pdf_template_file` varchar(255) DEFAULT NULL,
  `pdf_page_orientation` enum('P','L') DEFAULT 'P',
  `pdf_unit` enum('mm','cm','in','pt') DEFAULT 'mm',
  `pdf_page_format` varchar(50) DEFAULT 'LETTER',
  `pdf_output` enum('I','D','F','FI','FD','E','S') DEFAULT 'I',
  `pdf_margin_top` float(5,2) unsigned DEFAULT '35.00',
  `pdf_margin_right` float(5,2) unsigned DEFAULT '12.00',
  `pdf_margin_bottom` float(5,2) unsigned DEFAULT '25.00',
  `pdf_margin_left` float(5,2) unsigned DEFAULT '12.00',
  `pdf_font_monospaced` varchar(50) DEFAULT 'courier',
  `pdf_font` varchar(50) DEFAULT 'helvetica',
  `pdf_fontstyle` varchar(3) DEFAULT NULL,
  `pdf_fontsize` int(4) unsigned DEFAULT '12',
  `inputter` varchar(50) DEFAULT NULL,
  `input_date` datetime DEFAULT NULL,
  `authorizer` varchar(50) DEFAULT NULL,
  `auth_date` datetime DEFAULT NULL,
  `record_status` char(4) DEFAULT NULL,
  `current_no` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_template_id` (`template_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pdftemplates_is`
--

LOCK TABLES `pdftemplates_is` WRITE;
/*!40000 ALTER TABLE `pdftemplates_is` DISABLE KEYS */;
/*!40000 ALTER TABLE `pdftemplates_is` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `products` (
  `id` int(11) unsigned NOT NULL,
  `product_id` varchar(50) NOT NULL,
  `type` varchar(20) NOT NULL,
  `package_items` varchar(255) DEFAULT NULL,
  `product_description` varchar(255) NOT NULL,
  `extended_description` text,
  `category` varchar(50) NOT NULL,
  `sub_category` varchar(50) NOT NULL,
  `unit_price` float(15,2) NOT NULL,
  `taxable` enum('Y','N') NOT NULL,
  `tax_percentage` float(4,2) NOT NULL,
  `transfer_code` varchar(50) DEFAULT NULL,
  `status` enum('ACTIVE','INACTIVE','DISCONTINUED') NOT NULL,
  `inputter` varchar(50) NOT NULL,
  `input_date` datetime NOT NULL,
  `authorizer` varchar(50) NOT NULL,
  `auth_date` datetime NOT NULL,
  `record_status` char(4) NOT NULL,
  `current_no` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_product_id` (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products`
--

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES (501,'G10','STOCK','','GPS Tracking System - G10','- Add on GPS tracking unit\n- Pinpoint GPS vehicle location (street, area, landmark)\n- Immobilization\n- Listen in to vehicle\n- Text alerts\n- Vehicle remote shutdown','TRACKING','TRACKER.ONLY',1895.00,'Y',15.00,'','ACTIVE','ADMIN','2011-09-08 20:29:43','ADMIN','2011-11-18 10:34:53','LIVE',2);
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products_hs`
--

DROP TABLE IF EXISTS `products_hs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `products_hs` (
  `id` int(11) unsigned NOT NULL,
  `product_id` varchar(50) NOT NULL,
  `type` varchar(20) NOT NULL,
  `package_items` varchar(255) DEFAULT NULL,
  `product_description` varchar(255) NOT NULL,
  `extended_description` text,
  `category` varchar(50) NOT NULL,
  `sub_category` varchar(50) NOT NULL,
  `unit_price` float(15,2) NOT NULL,
  `taxable` enum('Y','N') NOT NULL,
  `tax_percentage` float(4,2) NOT NULL,
  `transfer_code` varchar(50) DEFAULT NULL,
  `status` enum('ACTIVE','INACTIVE','DISCONTINUED') NOT NULL,
  `inputter` varchar(50) NOT NULL,
  `input_date` datetime NOT NULL,
  `authorizer` varchar(50) NOT NULL,
  `auth_date` datetime NOT NULL,
  `record_status` char(4) NOT NULL,
  `current_no` int(11) NOT NULL,
  PRIMARY KEY (`id`,`current_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products_hs`
--

LOCK TABLES `products_hs` WRITE;
/*!40000 ALTER TABLE `products_hs` DISABLE KEYS */;
/*!40000 ALTER TABLE `products_hs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products_is`
--

DROP TABLE IF EXISTS `products_is`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `products_is` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `product_id` varchar(50) DEFAULT NULL,
  `type` varchar(20) DEFAULT NULL,
  `package_items` varchar(255) DEFAULT NULL,
  `product_description` varchar(255) DEFAULT NULL,
  `extended_description` text,
  `category` varchar(50) DEFAULT NULL,
  `sub_category` varchar(50) DEFAULT NULL,
  `unit_price` float(15,2) DEFAULT '0.00',
  `taxable` enum('Y','N') DEFAULT 'Y',
  `tax_percentage` float(4,2) DEFAULT '15.00',
  `transfer_code` varchar(50) DEFAULT NULL,
  `status` enum('ACTIVE','INACTIVE','DISCONTINUED') DEFAULT 'ACTIVE',
  `inputter` varchar(50) DEFAULT NULL,
  `input_date` datetime DEFAULT NULL,
  `authorizer` varchar(50) DEFAULT NULL,
  `auth_date` datetime DEFAULT NULL,
  `record_status` char(4) DEFAULT NULL,
  `current_no` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_product_id` (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products_is`
--

LOCK TABLES `products_is` WRITE;
/*!40000 ALTER TABLE `products_is` DISABLE KEYS */;
/*!40000 ALTER TABLE `products_is` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recordlocks`
--

DROP TABLE IF EXISTS `recordlocks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `recordlocks` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `idname` varchar(50) DEFAULT NULL,
  `lock_table` varchar(255) NOT NULL,
  `record_id` int(11) NOT NULL,
  `pre_status` varchar(4) DEFAULT NULL,
  `inputter` varchar(50) DEFAULT NULL,
  `input_date` datetime DEFAULT NULL,
  `authorizer` varchar(50) DEFAULT NULL,
  `auth_date` datetime DEFAULT NULL,
  `record_status` char(4) DEFAULT NULL,
  `current_no` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=14287 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recordlocks`
--

LOCK TABLES `recordlocks` WRITE;
/*!40000 ALTER TABLE `recordlocks` DISABLE KEYS */;
/*!40000 ALTER TABLE `recordlocks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recurrences`
--

DROP TABLE IF EXISTS `recurrences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `recurrences` (
  `id` int(11) unsigned NOT NULL,
  `recurrence_id` varchar(50) NOT NULL,
  `description` varchar(255) NOT NULL,
  `inputter` varchar(50) NOT NULL,
  `input_date` datetime NOT NULL,
  `authorizer` varchar(50) NOT NULL,
  `auth_date` datetime NOT NULL,
  `record_status` char(4) NOT NULL,
  `current_no` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_recurrence_id` (`recurrence_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recurrences`
--

LOCK TABLES `recurrences` WRITE;
/*!40000 ALTER TABLE `recurrences` DISABLE KEYS */;
INSERT INTO `recurrences` VALUES (0,'ADHOC','Adhoc / Random','IMPLEMENTATION','2010-08-28 00:00:00','ADMIN','2010-08-28 00:00:00','LIVE',1),(1,'SECBYSEC','Second By Second','IMPLEMENTATION','2010-08-28 00:00:00','ADMIN','2010-08-28 00:00:00','LIVE',1),(2,'MINBYMIN','Minute By Minute','IMPLEMENTATION','2010-08-28 00:00:00','ADMIN','2010-08-28 00:00:00','LIVE',1),(3,'HALFHOUR','Every 30 minutes','IMPLEMENTATION','2010-08-28 00:00:00','ADMIN','2010-08-28 00:00:00','LIVE',1),(4,'HOURLY','Every Hour','IMPLEMENTATION','2010-08-28 00:00:00','ADMIN','2010-08-28 00:00:00','LIVE',1),(5,'BI HOURLY','Every 2 Hours','IMPLEMENTATION','2010-08-28 00:00:00','ADMIN','2010-08-28 00:00:00','LIVE',1),(6,'TRIHOURLY','Every 3 Hours','IMPLEMENTATION','2010-08-28 00:00:00','ADMIN','2010-08-28 00:00:00','LIVE',1),(7,'FOURHOURLY','Every 4 Hours','IMPLEMENTATION','2010-08-28 00:00:00','ADMIN','2010-08-28 00:00:00','LIVE',1),(8,'FIVEHOURLY','Every 5 Hours','IMPLEMENTATION','2010-08-28 00:00:00','ADMIN','2010-08-28 00:00:00','LIVE',1),(9,'SIXHOURLY','Every  6 Hours','IMPLEMENTATION','2010-08-28 00:00:00','ADMIN','2010-08-28 00:00:00','LIVE',1),(10,'EIGHTHOURLY','Every  8 Hours','IMPLEMENTATION','2010-08-28 00:00:00','ADMIN','2010-08-28 00:00:00','LIVE',1),(11,'TWELVEHOURLY','Every  12 Hours','IMPLEMENTATION','2010-08-28 00:00:00','ADMIN','2010-08-28 00:00:00','LIVE',1),(12,'DAILY','Daily','IMPLEMENTATION','2010-08-28 00:00:00','ADMIN','2010-08-28 00:00:00','LIVE',1),(13,'WEEKLY','Weekly','IMPLEMENTATION','2010-08-28 00:00:00','ADMIN','2010-08-28 00:00:00','LIVE',1),(14,'MONTHLY','Monthly','IMPLEMENTATION','2010-08-28 00:00:00','ADMIN','2010-08-28 00:00:00','LIVE',1),(15,'52DAYS','52 Days','IMPLEMENTATION','2010-08-28 00:00:00','ADMIN','2010-08-28 00:00:00','LIVE',1),(16,'QTRYEARLY','3 Months','IMPLEMENTATION','2010-08-28 00:00:00','ADMIN','2010-08-28 00:00:00','LIVE',1),(17,'SEMIANNUAL','6 Months','IMPLEMENTATION','2010-08-28 00:00:00','ADMIN','2010-08-28 00:00:00','LIVE',1),(18,'YEARLY','Yearly / Annual','IMPLEMENTATION','2010-08-28 00:00:00','ADMIN','2010-08-28 00:00:00','LIVE',1),(19,'BIYEARLY','2 Years','IMPLEMENTATION','2010-08-28 00:00:00','ADMIN','2010-08-28 00:00:00','LIVE',1),(20,'FIRSTTHU','Every 1st Thursday of The Month','IMPLEMENTATION','2010-08-28 00:00:00','ADMIN','2010-08-28 00:00:00','LIVE',1),(21,'SECONDTHU','Every 2nd Thursday of The Month','IMPLEMENTATION','2010-08-28 00:00:00','ADMIN','2010-08-28 00:00:00','LIVE',1),(22,'THIRDTHU','Every 3rd Thursday of The Month','IMPLEMENTATION','2010-08-28 00:00:00','ADMIN','2010-08-28 00:00:00','LIVE',1);
/*!40000 ALTER TABLE `recurrences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recurrences_hs`
--

DROP TABLE IF EXISTS `recurrences_hs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `recurrences_hs` (
  `id` int(11) unsigned NOT NULL,
  `recurrence_id` varchar(50) NOT NULL,
  `description` varchar(255) NOT NULL,
  `inputter` varchar(50) NOT NULL,
  `input_date` datetime NOT NULL,
  `authorizer` varchar(50) NOT NULL,
  `auth_date` datetime NOT NULL,
  `record_status` char(4) NOT NULL,
  `current_no` int(11) NOT NULL,
  PRIMARY KEY (`id`,`current_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recurrences_hs`
--

LOCK TABLES `recurrences_hs` WRITE;
/*!40000 ALTER TABLE `recurrences_hs` DISABLE KEYS */;
/*!40000 ALTER TABLE `recurrences_hs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recurrences_is`
--

DROP TABLE IF EXISTS `recurrences_is`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `recurrences_is` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `recurrence_id` varchar(50) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `inputter` varchar(50) DEFAULT NULL,
  `input_date` datetime DEFAULT NULL,
  `authorizer` varchar(50) DEFAULT NULL,
  `auth_date` datetime DEFAULT NULL,
  `record_status` char(4) DEFAULT NULL,
  `current_no` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_recurrence_id` (`recurrence_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recurrences_is`
--

LOCK TABLES `recurrences_is` WRITE;
/*!40000 ALTER TABLE `recurrences_is` DISABLE KEYS */;
/*!40000 ALTER TABLE `recurrences_is` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `regions`
--

DROP TABLE IF EXISTS `regions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `regions` (
  `id` int(11) unsigned NOT NULL,
  `area` varchar(255) NOT NULL,
  `sub_region` varchar(255) NOT NULL,
  `region` varchar(255) NOT NULL,
  `country_id` varchar(2) NOT NULL,
  `inputter` varchar(50) NOT NULL,
  `input_date` datetime NOT NULL,
  `authorizer` varchar(50) NOT NULL,
  `auth_date` datetime NOT NULL,
  `record_status` char(4) NOT NULL,
  `current_no` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `regions`
--

LOCK TABLES `regions` WRITE;
/*!40000 ALTER TABLE `regions` DISABLE KEYS */;
INSERT INTO `regions` VALUES (501,'Aranguez','Barataria/San Juan','Trinidad','TT','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(502,'Arima','Arima','Trinidad','TT','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(503,'Arouca','Arouca/Maloney','Trinidad','TT','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(504,'Barataria','Barataria/San Juan','Trinidad','TT','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(505,'Barrackpore','.','Trinidad','TT','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(506,'Bayshore','.','Trinidad','TT','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(507,'Belmont','.','Trinidad','TT','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(508,'Brazil','.','Trinidad','TT','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(509,'California','Couva South','Trinidad','TT','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(510,'Carapichaima','Couva North','Trinidad','TT','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(511,'Carenage','Caroni Central','Trinidad','TT','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(512,'Caroni','.','Trinidad','TT','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(513,'Cascade','.','Trinidad','TT','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(514,'Cedros','.','Trinidad','TT','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(515,'Chaguanas','Chaguanas West','Trinidad','TT','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(516,'Chaguaramas','Diego Martin West','Trinidad','TT','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(517,'Champs Fleurs','.','Trinidad','TT','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(518,'Claxton Bay','Couva South','Trinidad','TT','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(519,'Cocorite','.','Trinidad','TT','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(520,'Cocoyea Village','.','Trinidad','TT','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(521,'Couva','Couva North','Trinidad','TT','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(522,'Cross Crossing','.','Trinidad','TT','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(523,'Cumana','.','Trinidad','TT','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(524,'Cumuto','.','Trinidad','TT','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(525,'Cunupia','Caroni East','Trinidad','TT','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(526,'Curepe','.','Trinidad','TT','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(527,'D\'Abadie','D’Abadie/O’Meara','Trinidad','TT','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(528,'Debe','.','Trinidad','TT','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(529,'Diego Martin','.','Trinidad','TT','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(530,'Duncan Village','.','Trinidad','TT','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(531,'El Dorado','.','Trinidad','TT','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(532,'El Socorro','.','Trinidad','TT','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(533,'Flanagin','.','Trinidad','TT','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(534,'Freeport','.','Trinidad','TT','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(535,'Fullarton','.','Trinidad','TT','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(536,'Fyzabad','.','Trinidad','TT','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(537,'Gasparillo','.','Trinidad','TT','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(538,'Glencoe','.','Trinidad','TT','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(539,'Gonzales','.','Trinidad','TT','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(540,'Goodwood Park','.','Trinidad','TT','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(541,'Gran Couva','.','Trinidad','TT','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(542,'Guaico','.','Trinidad','TT','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(543,'Guayaguayare','.','Trinidad','TT','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(544,'Gulf View','.','Trinidad','TT','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(545,'La Brea','.','Trinidad','TT','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(546,'La Romaine','.','Trinidad','TT','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(547,'Laventille','.','Trinidad','TT','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(548,'Macoya','.','Trinidad','TT','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(549,'Manzanilla','.','Trinidad','TT','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(550,'Marabella','.','Trinidad','TT','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(551,'Maracas','.','Trinidad','TT','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(552,'Maraval','.','Trinidad','TT','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(553,'Mayaro','.','Trinidad','TT','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(554,'Moruga','.','Trinidad','TT','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(555,'Morvant','.','Trinidad','TT','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(556,'Mount Hope','.','Trinidad','TT','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(557,'New Grant','.','Trinidad','TT','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(558,'Oropouche','.','Trinidad','TT','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(559,'Palmiste','.','Trinidad','TT','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(560,'Palmyra','.','Trinidad','TT','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(561,'Palo Seco','.','Trinidad','TT','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(562,'Paramaribo','.','Trinidad','TT','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(563,'Penal','.','Trinidad','TT','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(564,'Petit Valley','.','Trinidad','TT','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(565,'Phillipine','.','Trinidad','TT','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(566,'Piarco','.','Trinidad','TT','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(567,'Pierreville','.','Trinidad','TT','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(568,'Pleasantville','.','Trinidad','TT','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(569,'Point Fortin','.','Trinidad','TT','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(570,'Point Lisas','.','Trinidad','TT','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(571,'Pointe-a-Pierre','.','Trinidad','TT','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(572,'Port of Spain','.','Trinidad','TT','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(573,'Princes Town','.','Trinidad','TT','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(574,'Pt. Cumana','.','Trinidad','TT','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(575,'Pt. Lisas','.','Trinidad','TT','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(576,'Rio Claro','.','Trinidad','TT','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(577,'Rousillac','.','Trinidad','TT','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(578,'Salybia','.','Trinidad','TT','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(579,'San Fernando','.','Trinidad','TT','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(580,'San Francique','.','Trinidad','TT','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(581,'San Juan','Barataria/San Juan','Trinidad','TT','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(582,'Sangre Grande','.','Trinidad','TT','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(583,'Santa Cruz','.','Trinidad','TT','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(584,'Santa Flora','.','Trinidad','TT','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(585,'Signal Hill','.','Trinidad','TT','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(586,'Siparia','.','Trinidad','TT','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(587,'South Oropouche','.','Trinidad','TT','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(588,'St. Ann\'s','.','Trinidad','TT','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(589,'St. Augustine','.','Trinidad','TT','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(590,'St. Clair','.','Trinidad','TT','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(591,'St. Georges','.','Trinidad','TT','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(592,'St. James','.','Trinidad','TT','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(593,'St. Joseph','.','Trinidad','TT','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(594,'Ste. Madeleine','.','Trinidad','TT','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(595,'Tabaquite','.','Trinidad','TT','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(596,'Tableland','.','Trinidad','TT','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(597,'Tacarigua','.','Trinidad','TT','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(598,'Toco','.','Trinidad','TT','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(599,'Trincity','.','Trinidad','TT','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(600,'Tunapuna','.','Trinidad','TT','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(601,'Valencia','.','Trinidad','TT','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(602,'Valsayn','.','Trinidad','TT','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(603,'Vistabella','.','Trinidad','TT','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(604,'Westmoorings','.','Trinidad','TT','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(605,'Whim','.','Trinidad','TT','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(606,'Williamsville','.','Trinidad','TT','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(607,'Woodbrook','.','Trinidad','TT','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(608,'Lambeau','.','Tobago','TT','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(609,'Lowlands','.','Tobago','TT','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(610,'Bon Accord','.','Tobago','TT','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(611,'Carnbee','.','Tobago','TT','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(612,'Crown Point','.','Tobago','TT','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(613,'Mt. Lambert','.','Tobago','TT','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(614,'Mt. St George','.','Tobago','TT','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(615,'Plymouth','.','Tobago','TT','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(616,'Roxborough','.','Tobago','TT','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(617,'Scarborough','.','Tobago','TT','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(618,'Charlotteville','.','Tobago','TT','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(619,'Canaan','.','Tobago','TT','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(620,'Moriah','.','Tobago','TT','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(621,'Maloney','Arouca/Maloney','Trinidad','TT','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(622,'Enterprise','Chaguanas East','Trinidad','TT','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1),(623,'Piparo','Tabaquite','Trinidad','TT','IMPLEMENTATION','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','LIVE',1);
/*!40000 ALTER TABLE `regions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `regions_hs`
--

DROP TABLE IF EXISTS `regions_hs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `regions_hs` (
  `id` int(11) unsigned NOT NULL,
  `area` varchar(255) NOT NULL,
  `sub_region` varchar(255) NOT NULL,
  `region` varchar(255) NOT NULL,
  `country_id` varchar(2) NOT NULL,
  `inputter` varchar(50) NOT NULL,
  `input_date` datetime NOT NULL,
  `authorizer` varchar(50) NOT NULL,
  `auth_date` datetime NOT NULL,
  `record_status` char(4) NOT NULL,
  `current_no` int(11) NOT NULL,
  PRIMARY KEY (`id`,`current_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `regions_hs`
--

LOCK TABLES `regions_hs` WRITE;
/*!40000 ALTER TABLE `regions_hs` DISABLE KEYS */;
/*!40000 ALTER TABLE `regions_hs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `regions_is`
--

DROP TABLE IF EXISTS `regions_is`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `regions_is` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `area` varchar(255) DEFAULT NULL,
  `sub_region` varchar(255) DEFAULT NULL,
  `region` varchar(255) DEFAULT NULL,
  `country_id` varchar(2) DEFAULT NULL,
  `inputter` varchar(50) DEFAULT NULL,
  `input_date` datetime DEFAULT NULL,
  `authorizer` varchar(50) DEFAULT NULL,
  `auth_date` datetime DEFAULT NULL,
  `record_status` char(4) DEFAULT NULL,
  `current_no` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `regions_is`
--

LOCK TABLES `regions_is` WRITE;
/*!40000 ALTER TABLE `regions_is` DISABLE KEYS */;
/*!40000 ALTER TABLE `regions_is` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reportdefs`
--

DROP TABLE IF EXISTS `reportdefs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reportdefs` (
  `id` int(11) unsigned NOT NULL,
  `reportdef_id` varchar(255) DEFAULT NULL,
  `controller` varchar(255) NOT NULL,
  `dflag` enum('Y','N') DEFAULT NULL,
  `formfields` text,
  `model` varchar(255) NOT NULL,
  `view` varchar(255) NOT NULL,
  `rptheader` varchar(255) NOT NULL,
  `showfilter` tinyint(1) NOT NULL,
  `printuser` tinyint(1) NOT NULL,
  `printdatetime` tinyint(1) NOT NULL,
  `inputter` varchar(50) NOT NULL,
  `input_date` datetime NOT NULL,
  `authorizer` varchar(50) NOT NULL,
  `auth_date` datetime NOT NULL,
  `record_status` char(4) NOT NULL,
  `current_no` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `controller` (`controller`),
  KEY `uniq_reportdef_id` (`reportdef_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reportdefs`
--

LOCK TABLES `reportdefs` WRITE;
/*!40000 ALTER TABLE `reportdefs` DISABLE KEYS */;
INSERT INTO `reportdefs` VALUES (401,'core_report_batchinvoices','batchinvoices_rpt','Y','<?xml version=\'1.0\' standalone=\'yes\'?>\n<formfields>\n<field>\n<name>batch_id</name><label>Batch Id</label><type>input</type><value></value><options>size=50</options>\n<popout><enable>yes</enable><table>batchinvoices</table><selectfields>batch_id,batch_type,batch_description,batch_date</selectfields><idfield>batch_id</idfield></popout>\n</field>\n</formfields>','site','report/default_report','Batch Invoices',1,1,1,'ADMIN','2012-07-25 01:01:50','ADMIN','2012-07-25 01:02:37','LIVE',1),(402,'core_report_sales','sales_rpt','Y','<?xml version=\'1.0\' standalone=\'yes\'?>\r\n<formfields>\r\n	<field><name>branch_id</name><label>Branch Id</label><type>input</type><value></value><options>size=25</options>\r\n		<popout><enable>yes</enable><table>branches</table><selectfields>id,branch_id,description,location,active</selectfields><idfield>branch_id</idfield></popout>\r\n	</field>\r\n	<field><name>start_date</name><label>Start Date</label><type>date</type><value></value><options>size=12 maxlength=10</options></field>\r\n	<field><name>end_date</name><label>End Date</label><type>date</type><value></value><options>size=12 maxlength=10</options></field>\r\n</formfields>','site','report/default_report','Sales Report',1,1,1,'DUNSTAN.NESBIT','2012-11-07 09:00:00','DUNSTAN.NESBIT','2012-11-07 09:00:00','LIVE',1),(403,'core_report_receivables','receivables_rpt','Y','<?xml version=\'1.0\' standalone=\'yes\'?>\r\n<formfields>\r\n	<field><name>branch_id</name><label>Branch Id</label><type>input</type><value></value><options>size=25</options>\r\n		<popout><enable>yes</enable><table>branches</table><selectfields>id,branch_id,description,location,active</selectfields><idfield>branch_id</idfield></popout>\r\n	</field>\r\n	<field><name>start_date</name><label>Start Date</label><type>date</type><value></value><options>size=12 maxlength=10</options></field>\r\n	<field><name>end_date</name><label>End Date</label><type>date</type><value></value><options>size=12 maxlength=10</options></field>\r\n</formfields>','site','report/default_report','Outstanding Balances (Receivables)',1,1,1,'DUNSTAN.NESBIT','2012-11-07 09:00:00','DUNSTAN.NESBIT','2012-11-07 09:00:00','LIVE',1),(404,'core_report_quotations','quotations_rpt','Y','<?xml version=\'1.0\' standalone=\'yes\'?>\r\n<formfields>\r\n	<field><name>branch_id</name><label>Branch Id</label><type>input</type><value></value><options>size=25</options>\r\n		<popout><enable>yes</enable><table>branches</table><selectfields>id,branch_id,description,location,active</selectfields><idfield>branch_id</idfield></popout>\r\n	</field>\r\n	<field><name>order_status</name><label>Order Status</label><type>dropdown</type><value></value><options>QUOTATION,QUOTATION.EXPIRED,ZERO.CHARGE::QUOTATION,QUOTATION.EXPIRED,ZERO.CHARGE</options></field>\r\n	<field><name>start_date</name><label>Start Date</label><type>date</type><value></value><options>size=12 maxlength=10</options></field>\r\n	<field><name>end_date</name><label>End Date</label><type>date</type><value></value><options>size=12 maxlength=10</options></field>\r\n</formfields>','site','report/default_report','Quotations',1,1,1,'DUNSTAN.NESBIT','2012-11-07 09:00:00','DUNSTAN.NESBIT','2012-11-07 09:00:00','LIVE',1),(405,'core_report_stockreorder','stockreorder_rpt','Y','<?xml version=\'1.0\' standalone=\'yes\'?>\r\n<formfields>\r\n	<field><name>branch_id</name><label>Branch Id</label><type>input</type><value></value><options>size=25</options>\r\n		<popout><enable>yes</enable><table>branches</table><selectfields>id,branch_id,description,location,active</selectfields><idfield>branch_id</idfield></popout>\r\n	</field>\r\n</formfields>\r\n','site','report/default_report','Stock Reorder',1,1,1,'DUNSTAN.NESBIT','2012-11-07 09:00:00','DUNSTAN.NESBIT','2012-11-07 09:00:00','LIVE',1),(406,'core_report_till','till_rpt','Y','<?xml version=\'1.0\' standalone=\'yes\'?>\r\n<formfields>\r\n	<field><name>till_owner</name><label>Till Owner</label><type>input</type><value></value><options>size=25</options>\r\n		<popout><enable>yes</enable><table>users</table><selectfields>id,idname,fullname</selectfields><idfield>idname</idfield></popout>\r\n	</field>\r\n	<field><name>start_date</name><label>Start Date</label><type>date</type><value></value><options>size=12 maxlength=10</options></field>\r\n	<field><name>end_date</name><label>End Date</label><type>date</type><value></value><options>size=12 maxlength=10</options></field>\r\n</formfields>','site','report/default_report','Till',1,1,1,'DUNSTAN.NESBIT','2012-11-07 09:00:00','DUNSTAN.NESBIT','2012-11-07 09:00:00','LIVE',1),(407,'core_report_chkoutstatus','chkoutstatus_rpt','Y','<?xml version=\'1.0\' standalone=\'yes\'?>\r\n<formfields>\r\n	<field><name>branch_id</name><label>Branch Id</label><type>input</type><value></value><options>size=25</options>\r\n		<popout><enable>yes</enable><table>branches</table><selectfields>id,branch_id,description,location,active</selectfields><idfield>branch_id</idfield></popout>\r\n	</field>\r\n	<field><name>checkout_status</name><label>Checkout Status</label><type>dropdown</type><value></value><options>NONE,PARTIAL,COMPLETED::NONE,PARTIAL,COMPLETED</options></field>\r\n	<field><name>start_date</name><label>Start Date</label><type>date</type><value></value><options>size=12 maxlength=10</options></field>\r\n	<field><name>end_date</name><label>End Date</label><type>date</type><value></value><options>size=12 maxlength=10</options></field>\r\n</formfields>','site','report/default_report','Inventory Checkout Status',1,1,1,'DUNSTAN.NESBIT','2012-11-07 09:00:00','DUNSTAN.NESBIT','2012-11-07 09:00:00','LIVE',1);
/*!40000 ALTER TABLE `reportdefs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reportdefs_hs`
--

DROP TABLE IF EXISTS `reportdefs_hs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reportdefs_hs` (
  `id` int(11) unsigned NOT NULL,
  `reportdef_id` varchar(255) DEFAULT NULL,
  `controller` varchar(255) NOT NULL,
  `dflag` enum('Y','N') DEFAULT NULL,
  `formfields` text,
  `model` varchar(255) NOT NULL,
  `view` varchar(255) NOT NULL,
  `rptheader` varchar(255) NOT NULL,
  `showfilter` tinyint(1) NOT NULL,
  `printuser` tinyint(1) NOT NULL,
  `printdatetime` tinyint(1) NOT NULL,
  `inputter` varchar(50) NOT NULL,
  `input_date` datetime NOT NULL,
  `authorizer` varchar(50) NOT NULL,
  `auth_date` datetime NOT NULL,
  `record_status` char(4) NOT NULL,
  `current_no` int(11) NOT NULL,
  PRIMARY KEY (`id`,`current_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reportdefs_hs`
--

LOCK TABLES `reportdefs_hs` WRITE;
/*!40000 ALTER TABLE `reportdefs_hs` DISABLE KEYS */;
/*!40000 ALTER TABLE `reportdefs_hs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reportdefs_is`
--

DROP TABLE IF EXISTS `reportdefs_is`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reportdefs_is` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `reportdef_id` varchar(255) DEFAULT NULL,
  `controller` varchar(255) DEFAULT NULL,
  `dflag` enum('Y','N') DEFAULT NULL,
  `formfields` text,
  `model` varchar(255) DEFAULT NULL,
  `view` varchar(255) DEFAULT NULL,
  `rptheader` varchar(255) DEFAULT NULL,
  `showfilter` tinyint(1) DEFAULT NULL,
  `printuser` tinyint(1) DEFAULT NULL,
  `printdatetime` tinyint(1) DEFAULT NULL,
  `inputter` varchar(50) DEFAULT NULL,
  `input_date` datetime DEFAULT NULL,
  `authorizer` varchar(50) DEFAULT NULL,
  `auth_date` datetime DEFAULT NULL,
  `record_status` char(4) DEFAULT NULL,
  `current_no` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_controller` (`controller`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reportdefs_is`
--

LOCK TABLES `reportdefs_is` WRITE;
/*!40000 ALTER TABLE `reportdefs_is` DISABLE KEYS */;
/*!40000 ALTER TABLE `reportdefs_is` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `roles` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL,
  `description` varchar(255) NOT NULL,
  `securityprofile` longtext,
  `inputter` varchar(50) DEFAULT NULL,
  `input_date` datetime DEFAULT NULL,
  `authorizer` varchar(50) DEFAULT NULL,
  `auth_date` datetime DEFAULT NULL,
  `record_status` char(4) DEFAULT NULL,
  `current_no` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=1015 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'login','Newly created user, default role, very limted access including My Messages(DO NOT REMOVE)','<?xml version=\'1.0\' standalone=\'yes\'?>\n<securityprofile>\n<menu><menu_id>10</menu_id><controls_input></controls_input><controls_enquiry></controls_enquiry></menu>\n<menu><menu_id>1000</menu_id><controls_input></controls_input><controls_enquiry></controls_enquiry></menu>\n<menu><menu_id>100050</menu_id><controls_input>vw,nw,cp,iw,as,rj,hd</controls_input><controls_enquiry>ls,is,ex</controls_enquiry></menu>\n<menu><menu_id>100051</menu_id><controls_input>df,ls,is,hs,ex</controls_input><controls_enquiry></controls_enquiry></menu>\n<menu><menu_id>100052</menu_id><controls_input>df,ls,is,hs,ex</controls_input><controls_enquiry></controls_enquiry></menu>\n<menu><menu_id>100053</menu_id><controls_input>df,ls,is,hs,ex</controls_input><controls_enquiry></controls_enquiry></menu>\n<menu><menu_id>1001</menu_id><controls_input></controls_input><controls_enquiry></controls_enquiry></menu>\n<menu><menu_id>100150</menu_id><controls_input>vw,in,as,rj,va</controls_input><controls_enquiry>ls,is</controls_enquiry></menu>\n</securityprofile>\n','SYSINPUT','2012-12-30 10:03:48','SYSINAU','2012-12-30 10:03:48','LIVE',1),(2,'useradmin_super','Can access all Useradmin components only.','<?xml version=\'1.0\' standalone=\'yes\'?>\n<securityprofile>\n<menu><menu_id>15</menu_id><controls_input></controls_input><controls_enquiry></controls_enquiry></menu>\n<menu><menu_id>1500</menu_id><controls_input></controls_input><controls_enquiry></controls_enquiry></menu>\n<menu><menu_id>150050</menu_id><controls_input>if,vw,nw,cp,in,ao,as,rj,hd,va</controls_input><controls_enquiry>ls,is,hs,ex</controls_enquiry></menu>\n<menu><menu_id>150051</menu_id><controls_input>if,vw,iw,in,ao,as,rj,hd,va</controls_input><controls_enquiry></controls_enquiry></menu>\n<menu><menu_id>150052</menu_id><controls_input>if,vw,nw,cp,in,ao,as,rj,hd,va</controls_input><controls_enquiry>ls,is,hs,ex</controls_enquiry></menu>\n<menu><menu_id>1501</menu_id><controls_input></controls_input><controls_enquiry></controls_enquiry></menu>\n<menu><menu_id>150150</menu_id><controls_input>if,vw,nw,cp,in,ao,as,rj,hd,va</controls_input><controls_enquiry>ls,is,hs,ex</controls_enquiry></menu>\n</securityprofile>\n','SYSINPUT','2012-12-30 10:03:49','SYSINAU','2012-12-30 10:03:49','LIVE',1),(3,'sysadmin_super','Can access all System Administration components only.','<?xml version=\'1.0\' standalone=\'yes\'?>\n<securityprofile>\n<menu><menu_id>20</menu_id><controls_input></controls_input><controls_enquiry></controls_enquiry></menu>\n<menu><menu_id>2000</menu_id><controls_input></controls_input><controls_enquiry></controls_enquiry></menu>\n<menu><menu_id>200050</menu_id><controls_input>if,vw,nw,cp,in,ao,as,rj,hd,va</controls_input><controls_enquiry>ls,is,hs,ex</controls_enquiry></menu>\n<menu><menu_id>200051</menu_id><controls_input>if,vw,nw,cp,in,ao,as,rj,hd,va</controls_input><controls_enquiry>ls,is,hs,ex</controls_enquiry></menu>\n<menu><menu_id>200052</menu_id><controls_input>if,vw,nw,cp,in,ao,as,rj,hd,va</controls_input><controls_enquiry>ls,is,hs,ex</controls_enquiry></menu>\n<menu><menu_id>2001</menu_id><controls_input></controls_input><controls_enquiry></controls_enquiry></menu>\n<menu><menu_id>200150</menu_id><controls_input>if,vw,nw,cp,in,ao,as,rj,hd,va</controls_input><controls_enquiry>ls,is,hs,ex</controls_enquiry></menu>\n<menu><menu_id>200151</menu_id><controls_input>if,vw,nw,cp,in,ao,as,rj,hd,va</controls_input><controls_enquiry>ls,is,hs,ex</controls_enquiry></menu>\n<menu><menu_id>2002</menu_id><controls_input></controls_input><controls_enquiry></controls_enquiry></menu>\n<menu><menu_id>200250</menu_id><controls_input>if,vw,nw,cp,in,ao,as,rj,hd,va</controls_input><controls_enquiry>ls,is,hs,ex</controls_enquiry></menu>\n<menu><menu_id>200251</menu_id><controls_input>if,vw,nw,cp,in,ao,as,rj,hd,va</controls_input><controls_enquiry>ls,is,hs,ex</controls_enquiry></menu>\n<menu><menu_id>200253</menu_id><controls_input>if,vw,nw,cp,in,ao,as,rj,hd,va</controls_input><controls_enquiry>ls,is,hs,ex</controls_enquiry></menu>\n<menu><menu_id>2003</menu_id><controls_input></controls_input><controls_enquiry></controls_enquiry></menu>\n<menu><menu_id>200350</menu_id><controls_input>if,vw,nw,cp,in,ao,as,rj,hd,va</controls_input><controls_enquiry>ls,is,hs,ex</controls_enquiry></menu>\n<menu><menu_id>200351</menu_id><controls_input>if,vw,nw,cp,in,ao,as,rj,hd,va</controls_input><controls_enquiry>ls,is,hs,ex</controls_enquiry></menu>\n<menu><menu_id>2004</menu_id><controls_input></controls_input><controls_enquiry></controls_enquiry></menu>\n<menu><menu_id>200450</menu_id><controls_input>if,vw,de</controls_input><controls_enquiry>ls</controls_enquiry></menu>\n<menu><menu_id>200451</menu_id><controls_input>if,vw,in,ao,as,rj,hd,va</controls_input><controls_enquiry>ls,is,hs,ex</controls_enquiry></menu>\n<menu><menu_id>200452</menu_id><controls_input>if,vw,in,ao,as,rj,hd,va</controls_input><controls_enquiry>ls,is,hs,ex</controls_enquiry></menu>\n</securityprofile>\n','SYSINPUT','2012-12-30 10:03:49','SYSINAU','2012-12-30 10:03:49','LIVE',1),(4,'developer_super','Can access all Developer components only.','<?xml version=\'1.0\' standalone=\'yes\'?>\n<securityprofile>\n<menu><menu_id>25</menu_id><controls_input></controls_input><controls_enquiry></controls_enquiry></menu>\n<menu><menu_id>2500</menu_id><controls_input></controls_input><controls_enquiry></controls_enquiry></menu>\n<menu><menu_id>250050</menu_id><controls_input>if,vw,nw,cp,in,ao,as,rj,hd,va</controls_input><controls_enquiry>ls,is,hs,ex</controls_enquiry></menu>\n<menu><menu_id>250051</menu_id><controls_input>if,vw,in,ao,as,rj,hd,va</controls_input><controls_enquiry>ls,is,hs,ex</controls_enquiry></menu>\n<menu><menu_id>250052</menu_id><controls_input>if,vw,nw,cp,in,ao,as,rj,hd,va</controls_input><controls_enquiry>ls,is,hs,ex</controls_enquiry></menu>\n<menu><menu_id>250053</menu_id><controls_input>if,vw,nw,cp,in,ao,as,rj,hd,va</controls_input><controls_enquiry>ls,is,hs,ex</controls_enquiry></menu>\n<menu><menu_id>250054</menu_id><controls_input>if,vw,nw,cp,in,ao,as,rj,hd,va</controls_input><controls_enquiry>ls,is,hs,ex</controls_enquiry></menu>\n<menu><menu_id>250056</menu_id><controls_input>if,vw,nw,cp,in,ao,as,rj,hd,va</controls_input><controls_enquiry>ls,is,hs,ex</controls_enquiry></menu>\n<menu><menu_id>250057</menu_id><controls_input>vw</controls_input><controls_enquiry></controls_enquiry></menu>\n<menu><menu_id>2501</menu_id><controls_input></controls_input><controls_enquiry></controls_enquiry></menu>\n<menu><menu_id>250055</menu_id><controls_input>if,vw,nw,cp,in,ao,as,rj,hd,va</controls_input><controls_enquiry>ls,is,hs,ex</controls_enquiry></menu>\n<menu><menu_id>2502</menu_id><controls_input></controls_input><controls_enquiry></controls_enquiry></menu>\n<menu><menu_id>250250</menu_id><controls_input>if,vw,nw,cp,in,ao,as,rj,hd,va</controls_input><controls_enquiry>ls,is,hs,ex</controls_enquiry></menu>\n<menu><menu_id>250251</menu_id><controls_input>if,vw,nw,cp,in,ao,as,rj,hd,va</controls_input><controls_enquiry>ls,is,hs,ex</controls_enquiry></menu>\n<menu><menu_id>250252</menu_id><controls_input>if,vw,nw,cp,in,ao,as,rj,hd,va</controls_input><controls_enquiry>ls,is,hs,ex</controls_enquiry></menu>\n<menu><menu_id>2503</menu_id><controls_input></controls_input><controls_enquiry></controls_enquiry></menu>\n<menu><menu_id>250350</menu_id><controls_input>if,vw,nw,cp,in,ao,as,rj,hd,va</controls_input><controls_enquiry>ls,is,hs,ex</controls_enquiry></menu>\n<menu><menu_id>250351</menu_id><controls_input>if,vw,nw,cp,in,ao,as,rj,hd,va</controls_input><controls_enquiry>ls,is,hs,ex</controls_enquiry></menu>\n</securityprofile>\n','SYSINPUT','2012-12-30 10:03:49','SYSINAU','2012-12-30 10:03:49','LIVE',1),(1001,'customer_super','Can access all Customer components only.','<?xml version=\'1.0\' standalone=\'yes\'?>\n<securityprofile>\n<menu><menu_id>5010</menu_id><controls_input></controls_input><controls_enquiry></controls_enquiry></menu>\n<menu><menu_id>501050</menu_id><controls_input>if,vw,nw,cp,in,ao,as,rj,hd,va</controls_input><controls_enquiry>ls,is,hs,ex</controls_enquiry></menu>\n<menu><menu_id>501051</menu_id><controls_input>if,vw,nw,cp,in,ao,as,rj,hd,va</controls_input><controls_enquiry>ls,is,hs,ex</controls_enquiry></menu>\n</securityprofile>\n','SYSINPUT','2012-12-30 10:03:49','SYSINAU','2012-12-30 10:03:49','LIVE',1),(1004,'sales_super','Can access all Sales components only.','<?xml version=\'1.0\' standalone=\'yes\'?>\n<securityprofile>\n<menu><menu_id>5040</menu_id><controls_input></controls_input><controls_enquiry></controls_enquiry></menu>\n<menu><menu_id>504000</menu_id><controls_input></controls_input><controls_enquiry></controls_enquiry></menu>\n<menu><menu_id>50400050</menu_id><controls_input>if,vw,nw,cp,in,ao,as,rj,hd,va</controls_input><controls_enquiry>ls,is,hs,ex</controls_enquiry></menu>\n<menu><menu_id>50400051</menu_id><controls_input>if,vw,nw,cp,in,ao,as,rj,hd,va</controls_input><controls_enquiry>ls,is,hs,ex</controls_enquiry></menu>\n<menu><menu_id>50400052</menu_id><controls_input>if,vw,nw,cp,in,ao,as,rj,hd,va</controls_input><controls_enquiry>ls,is,hs,ex</controls_enquiry></menu>\n<menu><menu_id>50400053</menu_id><controls_input>if,vw</controls_input><controls_enquiry>ls,is,ex</controls_enquiry></menu>\n<menu><menu_id>504001</menu_id><controls_input></controls_input><controls_enquiry></controls_enquiry></menu>\n<menu><menu_id>50400150</menu_id><controls_input>vw,nw</controls_input><controls_enquiry></controls_enquiry></menu>\n<menu><menu_id>50400151</menu_id><controls_input>if,vw,nw,cp,in,ao,as,rj,hd,va</controls_input><controls_enquiry>ls,is,hs,ex</controls_enquiry></menu>\n<menu><menu_id>50400152</menu_id><controls_input>if,vw,nw,in,ao,as,rj,hd,va</controls_input><controls_enquiry>ls,is,hs,ex</controls_enquiry></menu>\n<menu><menu_id>50400153</menu_id><controls_input>if,vw,in,ao,as,rj,hd,va</controls_input><controls_enquiry>ls,is,hs,ex</controls_enquiry></menu>\n<menu><menu_id>50400154</menu_id><controls_input>if,vw,in,ao,as,rj,hd,va</controls_input><controls_enquiry>ls,is,hs,ex</controls_enquiry></menu>\n<menu><menu_id>504002</menu_id><controls_input></controls_input><controls_enquiry></controls_enquiry></menu>\n<menu><menu_id>50400250</menu_id><controls_input>if,vw,nw,in,ao,as,rj,hd,va</controls_input><controls_enquiry>ls,is,hs,ex</controls_enquiry></menu>\n<menu><menu_id>50400251</menu_id><controls_input>if,vw,nw,in,ao,as,rj,hd,va</controls_input><controls_enquiry>ls,is,hs,ex</controls_enquiry></menu>\n<menu><menu_id>50400252</menu_id><controls_input>if,vw,nw,in,ao,as,rj,hd,va</controls_input><controls_enquiry>ls,is,hs,ex</controls_enquiry></menu>\n<menu><menu_id>504003</menu_id><controls_input></controls_input><controls_enquiry></controls_enquiry></menu>\n<menu><menu_id>50400350</menu_id><controls_input>if,vw,nw,iw,ao,as,rj,hd,va</controls_input><controls_enquiry>ls,is,hs,ex</controls_enquiry></menu>\n<menu><menu_id>50400351</menu_id><controls_input>if,vw,nw,iw,ao,as,rj,hd,va</controls_input><controls_enquiry>ls,is,hs,ex</controls_enquiry></menu>\n<menu><menu_id>50400352</menu_id><controls_input>if,vw,nw,iw,ao,as,rj,hd,va</controls_input><controls_enquiry>ls,is,hs,ex</controls_enquiry></menu>\n</securityprofile>\n','SYSINPUT','2012-12-30 10:03:49','SYSINAU','2012-12-30 10:03:49','LIVE',1),(1005,'enquiry_super','Can access all Enquiry components only.','<?xml version=\'1.0\' standalone=\'yes\'?>\n<securityprofile>\n<menu><menu_id>5090</menu_id><controls_input></controls_input><controls_enquiry></controls_enquiry></menu>\n<menu><menu_id>509000</menu_id><controls_input></controls_input><controls_enquiry></controls_enquiry></menu>\n<menu><menu_id>509001</menu_id><controls_input></controls_input><controls_enquiry></controls_enquiry></menu>\n<menu><menu_id>50900150</menu_id><controls_input>vw,pr</controls_input><controls_enquiry>df,ex</controls_enquiry></menu>\n<menu><menu_id>50900151</menu_id><controls_input>vw,pr</controls_input><controls_enquiry>df,ex</controls_enquiry></menu>\n</securityprofile>\n','SYSINPUT','2012-12-30 10:03:49','SYSINAU','2012-12-30 10:03:49','LIVE',1),(1006,'report_super','Can access all Report components only.','<?xml version=\'1.0\' standalone=\'yes\'?>\n<securityprofile>\n<menu><menu_id>5100</menu_id><controls_input></controls_input><controls_enquiry></controls_enquiry></menu>\n<menu><menu_id>510000</menu_id><controls_input></controls_input><controls_enquiry></controls_enquiry></menu>\n<menu><menu_id>51000050</menu_id><controls_input>vw,pr</controls_input><controls_enquiry></controls_enquiry></menu>\n<menu><menu_id>51000051</menu_id><controls_input>vw,pr</controls_input><controls_enquiry></controls_enquiry></menu>\n<menu><menu_id>51000056</menu_id><controls_input>vw,pr</controls_input><controls_enquiry></controls_enquiry></menu>\n<menu><menu_id>51000052</menu_id><controls_input>vw,pr</controls_input><controls_enquiry></controls_enquiry></menu>\n<menu><menu_id>51000053</menu_id><controls_input>vw,pr</controls_input><controls_enquiry></controls_enquiry></menu>\n<menu><menu_id>51000054</menu_id><controls_input>vw,pr</controls_input><controls_enquiry></controls_enquiry></menu>\n<menu><menu_id>51000055</menu_id><controls_input>vw,pr</controls_input><controls_enquiry></controls_enquiry></menu>\n<menu><menu_id>510001</menu_id><controls_input></controls_input><controls_enquiry></controls_enquiry></menu>\n</securityprofile>\n','SYSINPUT','2012-12-30 10:03:49','SYSINAU','2012-12-30 10:03:49','LIVE',1),(1007,'businessadmin_super','Can access all Business Administration components only.','<?xml version=\'1.0\' standalone=\'yes\'?>\n<securityprofile>\n<menu><menu_id>5020</menu_id><controls_input></controls_input><controls_enquiry></controls_enquiry></menu>\n<menu><menu_id>502000</menu_id><controls_input></controls_input><controls_enquiry></controls_enquiry></menu>\n<menu><menu_id>502001</menu_id><controls_input></controls_input><controls_enquiry></controls_enquiry></menu>\n<menu><menu_id>50200150</menu_id><controls_input>if,vw,nw,in,ao,as,rj,hd,va</controls_input><controls_enquiry>ls,is,hs,ex</controls_enquiry></menu>\n<menu><menu_id>50200151</menu_id><controls_input>if,vw,nw,in,ao,as,rj,hd,va</controls_input><controls_enquiry>ls,is,hs,ex</controls_enquiry></menu>\n<menu><menu_id>50200152</menu_id><controls_input>if,vw,nw,in,ao,as,rj,hd,va</controls_input><controls_enquiry>ls,is,hs,ex</controls_enquiry></menu>\n</securityprofile>\n','SYSINPUT','2012-12-30 10:03:49','SYSINAU','2012-12-30 10:03:49','LIVE',1),(1014,'hndshkif_super','Can access all Hndshkif_super components only.','<?xml version=\'1.0\' standalone=\'yes\'?>\n<securityprofile>\n<menu><menu_id>6000</menu_id><controls_input></controls_input><controls_enquiry></controls_enquiry></menu>\n<menu><menu_id>600000</menu_id><controls_input></controls_input><controls_enquiry></controls_enquiry></menu>\n<menu><menu_id>60000050</menu_id><controls_input>if,vw,nw,cp,in,ao,as,rj,hd,va</controls_input><controls_enquiry>ls,is,hs,ex</controls_enquiry></menu>\n<menu><menu_id>60000051</menu_id><controls_input>if,vw,nw,cp,in,ao,as,rj,hd,va</controls_input><controls_enquiry>ls,is,hs,ex</controls_enquiry></menu>\n<menu><menu_id>600001</menu_id><controls_input></controls_input><controls_enquiry></controls_enquiry></menu>\n<menu><menu_id>60000153</menu_id><controls_input>if,vw,nw,cp,in,ao,as,rj,hd,va</controls_input><controls_enquiry>ls,is,hs,ex</controls_enquiry></menu>\n<menu><menu_id>60000150</menu_id><controls_input>if,vw</controls_input><controls_enquiry>ls,ex</controls_enquiry></menu>\n<menu><menu_id>60000151</menu_id><controls_input>if,vw,nw,cp,in,ao,as,rj,hd,va</controls_input><controls_enquiry>ls,is,hs,ex</controls_enquiry></menu>\n<menu><menu_id>60000152</menu_id><controls_input>if,vw,nw,cp,in,ao,as,rj,hd,va</controls_input><controls_enquiry>ls,is,hs,ex</controls_enquiry></menu>\n<menu><menu_id>60000154</menu_id><controls_input>if,vw,in,ao,as,rj,hd,va</controls_input><controls_enquiry>ls,is,hs,ex</controls_enquiry></menu>\n<menu><menu_id>60000155</menu_id><controls_input>if,vw,nw,cp,in,ao,as,rj,hd,va</controls_input><controls_enquiry>ls,is,hs,ex</controls_enquiry></menu>\n<menu><menu_id>600002</menu_id><controls_input></controls_input><controls_enquiry></controls_enquiry></menu>\n<menu><menu_id>60000250</menu_id><controls_input>if,vw,nw,cp,in,ao,as,rj,hd,va</controls_input><controls_enquiry>ls,is,hs,ex</controls_enquiry></menu>\n<menu><menu_id>60000251</menu_id><controls_input>if,vw,nw,cp,in,ao,as,rj,hd,va</controls_input><controls_enquiry>ls,is,hs,ex</controls_enquiry></menu>\n<menu><menu_id>60000252</menu_id><controls_input>if,vw,nw,cp,in,ao,as,rj,hd,va</controls_input><controls_enquiry>ls,is,hs,ex</controls_enquiry></menu>\n<menu><menu_id>60000253</menu_id><controls_input>if,vw,nw,cp,in,ao,as,rj,hd,va</controls_input><controls_enquiry>ls,is,hs,ex</controls_enquiry></menu>\n<menu><menu_id>60000254</menu_id><controls_input>if,vw,nw,cp,in,ao,as,rj,hd,va</controls_input><controls_enquiry>ls,is,hs,ex</controls_enquiry></menu>\n<menu><menu_id>600003</menu_id><controls_input></controls_input><controls_enquiry></controls_enquiry></menu>\n<menu><menu_id>60000350</menu_id><controls_input>if,vw,nw,cp,in,ao,as,rj,hd,va</controls_input><controls_enquiry>ls,is,hs,ex</controls_enquiry></menu>\n<menu><menu_id>60000351</menu_id><controls_input>if,vw,nw,cp,in,ao,as,rj,hd,va</controls_input><controls_enquiry>ls,is,hs,ex</controls_enquiry></menu>\n<menu><menu_id>60000352</menu_id><controls_input>if,vw,nw,cp,in,ao,as,rj,hd,va</controls_input><controls_enquiry>ls,is,hs,ex</controls_enquiry></menu>\n<menu><menu_id>60000353</menu_id><controls_input>if,vw,nw,cp,in,ao,as,rj,hd,va</controls_input><controls_enquiry>ls,is,hs,ex</controls_enquiry></menu>\n<menu><menu_id>60000354</menu_id><controls_input>if,vw,nw,cp,in,ao,as,rj,hd,va</controls_input><controls_enquiry>ls,is,hs,ex</controls_enquiry></menu>\n<menu><menu_id>600004</menu_id><controls_input></controls_input><controls_enquiry></controls_enquiry></menu>\n<menu><menu_id>60000450</menu_id><controls_input>if,vw,nw,cp,in,ao,as,rj,hd,va</controls_input><controls_enquiry>ls,is,hs,ex</controls_enquiry></menu>\n<menu><menu_id>60000451</menu_id><controls_input>if,vw,nw,cp,in,ao,as,rj,hd,va</controls_input><controls_enquiry>ls,is,hs,ex</controls_enquiry></menu>\n<menu><menu_id>60000453</menu_id><controls_input>if,vw,nw,cp,in,ao,as,rj,hd,va</controls_input><controls_enquiry>ls,is,hs,ex</controls_enquiry></menu>\n</securityprofile>\n','SYSINPUT','2013-09-10 06:21:56','SYSINAU','2013-09-10 06:21:56','LIVE',1);
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles_hs`
--

DROP TABLE IF EXISTS `roles_hs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `roles_hs` (
  `id` int(11) unsigned NOT NULL,
  `name` varchar(32) NOT NULL,
  `description` varchar(255) NOT NULL,
  `securityprofile` longtext NOT NULL,
  `inputter` varchar(50) NOT NULL,
  `input_date` datetime NOT NULL,
  `authorizer` varchar(50) NOT NULL,
  `auth_date` datetime NOT NULL,
  `record_status` char(4) NOT NULL,
  `current_no` int(11) NOT NULL,
  PRIMARY KEY (`id`,`current_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles_hs`
--

LOCK TABLES `roles_hs` WRITE;
/*!40000 ALTER TABLE `roles_hs` DISABLE KEYS */;
/*!40000 ALTER TABLE `roles_hs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles_is`
--

DROP TABLE IF EXISTS `roles_is`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `roles_is` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(32) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `securityprofile` longtext,
  `inputter` varchar(50) DEFAULT NULL,
  `input_date` datetime DEFAULT NULL,
  `authorizer` varchar(50) DEFAULT NULL,
  `auth_date` datetime DEFAULT NULL,
  `record_status` char(4) DEFAULT NULL,
  `current_no` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles_is`
--

LOCK TABLES `roles_is` WRITE;
/*!40000 ALTER TABLE `roles_is` DISABLE KEYS */;
/*!40000 ALTER TABLE `roles_is` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles_users`
--

DROP TABLE IF EXISTS `roles_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `roles_users` (
  `user_id` int(10) unsigned NOT NULL,
  `role_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`user_id`,`role_id`),
  KEY `fk_role_id` (`role_id`),
  CONSTRAINT `roles_users_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  CONSTRAINT `roles_users_ibfk_2` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles_users`
--

LOCK TABLES `roles_users` WRITE;
/*!40000 ALTER TABLE `roles_users` DISABLE KEYS */;
INSERT INTO `roles_users` VALUES (1,1),(2,1),(1002,1),(1,2),(1,3),(2,3),(1002,3),(1,4),(1,1014),(2,1014),(1002,1014);
/*!40000 ALTER TABLE `roles_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sysconfigs`
--

DROP TABLE IF EXISTS `sysconfigs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sysconfigs` (
  `id` int(11) unsigned NOT NULL,
  `sysconfig_id` varchar(50) NOT NULL,
  `initialization_date` date NOT NULL,
  `global_authmode_on` enum('1','0') DEFAULT '1',
  `global_indexfield_on` enum('1','0') DEFAULT '1',
  `app_version` varchar(20) NOT NULL,
  `db_version` varchar(20) NOT NULL,
  `environment` varchar(50) NOT NULL,
  `inputter` varchar(50) NOT NULL,
  `input_date` datetime NOT NULL,
  `authorizer` varchar(50) NOT NULL,
  `auth_date` datetime NOT NULL,
  `record_status` char(4) NOT NULL,
  `current_no` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_sysconfig_id` (`sysconfig_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sysconfigs`
--

LOCK TABLES `sysconfigs` WRITE;
/*!40000 ALTER TABLE `sysconfigs` DISABLE KEYS */;
INSERT INTO `sysconfigs` VALUES (1,'SYSTEM','2011-08-12','1','1','20121030-01','20121030-01','LIVE','ADMIN','2013-01-31 18:22:28','ADMIN','2013-01-31 18:23:00','LIVE',2);
/*!40000 ALTER TABLE `sysconfigs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sysconfigs_hs`
--

DROP TABLE IF EXISTS `sysconfigs_hs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sysconfigs_hs` (
  `id` int(11) unsigned NOT NULL,
  `sysconfig_id` varchar(50) NOT NULL,
  `initialization_date` date NOT NULL,
  `global_authmode_on` enum('1','0') DEFAULT '1',
  `global_indexfield_on` enum('1','0') DEFAULT '1',
  `app_version` varchar(20) NOT NULL,
  `db_version` varchar(20) NOT NULL,
  `environment` varchar(50) NOT NULL,
  `inputter` varchar(50) NOT NULL,
  `input_date` datetime NOT NULL,
  `authorizer` varchar(50) NOT NULL,
  `auth_date` datetime NOT NULL,
  `record_status` char(4) NOT NULL,
  `current_no` int(11) NOT NULL,
  PRIMARY KEY (`id`,`current_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sysconfigs_hs`
--

LOCK TABLES `sysconfigs_hs` WRITE;
/*!40000 ALTER TABLE `sysconfigs_hs` DISABLE KEYS */;
INSERT INTO `sysconfigs_hs` VALUES (1,'SYSTEM','2011-08-12','1','1','20121030-01','20121030-01','LIVE','ADMIN','2010-08-12 00:00:00','ADMIN','2010-08-12 00:00:00','HIST',1);
/*!40000 ALTER TABLE `sysconfigs_hs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sysconfigs_is`
--

DROP TABLE IF EXISTS `sysconfigs_is`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sysconfigs_is` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `sysconfig_id` varchar(50) DEFAULT NULL,
  `initialization_date` date DEFAULT NULL,
  `global_authmode_on` enum('1','0') DEFAULT '1',
  `global_indexfield_on` enum('1','0') DEFAULT '1',
  `app_version` varchar(20) DEFAULT NULL,
  `db_version` varchar(20) DEFAULT NULL,
  `environment` varchar(50) DEFAULT NULL,
  `inputter` varchar(50) DEFAULT NULL,
  `input_date` datetime DEFAULT NULL,
  `authorizer` varchar(50) DEFAULT NULL,
  `auth_date` datetime DEFAULT NULL,
  `record_status` char(4) DEFAULT NULL,
  `current_no` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_sysconfig_id` (`sysconfig_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sysconfigs_is`
--

LOCK TABLES `sysconfigs_is` WRITE;
/*!40000 ALTER TABLE `sysconfigs_is` DISABLE KEYS */;
/*!40000 ALTER TABLE `sysconfigs_is` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tableresetconfigs`
--

DROP TABLE IF EXISTS `tableresetconfigs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tableresetconfigs` (
  `id` int(11) unsigned NOT NULL,
  `reset_id` varchar(255) NOT NULL,
  `reset_profile` text NOT NULL,
  `inputter` varchar(50) NOT NULL,
  `input_date` datetime NOT NULL,
  `authorizer` varchar(50) NOT NULL,
  `auth_date` datetime NOT NULL,
  `record_status` char(4) NOT NULL,
  `current_no` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_reset_id` (`reset_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tableresetconfigs`
--

LOCK TABLES `tableresetconfigs` WRITE;
/*!40000 ALTER TABLE `tableresetconfigs` DISABLE KEYS */;
/*!40000 ALTER TABLE `tableresetconfigs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tableresetconfigs_hs`
--

DROP TABLE IF EXISTS `tableresetconfigs_hs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tableresetconfigs_hs` (
  `id` int(11) unsigned NOT NULL,
  `reset_id` varchar(255) NOT NULL,
  `reset_profile` text NOT NULL,
  `inputter` varchar(50) NOT NULL,
  `input_date` datetime NOT NULL,
  `authorizer` varchar(50) NOT NULL,
  `auth_date` datetime NOT NULL,
  `record_status` char(4) NOT NULL,
  `current_no` int(11) NOT NULL,
  PRIMARY KEY (`id`,`current_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tableresetconfigs_hs`
--

LOCK TABLES `tableresetconfigs_hs` WRITE;
/*!40000 ALTER TABLE `tableresetconfigs_hs` DISABLE KEYS */;
/*!40000 ALTER TABLE `tableresetconfigs_hs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tableresetconfigs_is`
--

DROP TABLE IF EXISTS `tableresetconfigs_is`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tableresetconfigs_is` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `reset_id` varchar(255) DEFAULT NULL,
  `reset_profile` text,
  `inputter` varchar(50) DEFAULT NULL,
  `input_date` datetime DEFAULT NULL,
  `authorizer` varchar(50) DEFAULT NULL,
  `auth_date` datetime DEFAULT NULL,
  `record_status` char(4) DEFAULT NULL,
  `current_no` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_reset_id` (`reset_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tableresetconfigs_is`
--

LOCK TABLES `tableresetconfigs_is` WRITE;
/*!40000 ALTER TABLE `tableresetconfigs_is` DISABLE KEYS */;
/*!40000 ALTER TABLE `tableresetconfigs_is` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tableresetruns`
--

DROP TABLE IF EXISTS `tableresetruns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tableresetruns` (
  `id` int(11) unsigned NOT NULL,
  `resetconfig_id` varchar(255) NOT NULL,
  `lastrun_date` varchar(255) NOT NULL,
  `log` varchar(255) NOT NULL,
  `inputter` varchar(50) NOT NULL,
  `input_date` datetime NOT NULL,
  `authorizer` varchar(50) NOT NULL,
  `auth_date` datetime NOT NULL,
  `record_status` char(4) NOT NULL,
  `current_no` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_resetconfig_id` (`resetconfig_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tableresetruns`
--

LOCK TABLES `tableresetruns` WRITE;
/*!40000 ALTER TABLE `tableresetruns` DISABLE KEYS */;
/*!40000 ALTER TABLE `tableresetruns` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tableresetruns_hs`
--

DROP TABLE IF EXISTS `tableresetruns_hs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tableresetruns_hs` (
  `id` int(11) unsigned NOT NULL,
  `resetconfig_id` varchar(255) NOT NULL,
  `lastrun_date` varchar(255) NOT NULL,
  `log` varchar(255) NOT NULL,
  `inputter` varchar(50) NOT NULL,
  `input_date` datetime NOT NULL,
  `authorizer` varchar(50) NOT NULL,
  `auth_date` datetime NOT NULL,
  `record_status` char(4) NOT NULL,
  `current_no` int(11) NOT NULL,
  PRIMARY KEY (`id`,`current_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tableresetruns_hs`
--

LOCK TABLES `tableresetruns_hs` WRITE;
/*!40000 ALTER TABLE `tableresetruns_hs` DISABLE KEYS */;
/*!40000 ALTER TABLE `tableresetruns_hs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tableresetruns_is`
--

DROP TABLE IF EXISTS `tableresetruns_is`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tableresetruns_is` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `resetconfig_id` varchar(255) DEFAULT NULL,
  `lastrun_date` varchar(255) DEFAULT NULL,
  `log` varchar(255) DEFAULT NULL,
  `inputter` varchar(50) DEFAULT NULL,
  `input_date` datetime DEFAULT NULL,
  `authorizer` varchar(50) DEFAULT NULL,
  `auth_date` datetime DEFAULT NULL,
  `record_status` char(4) DEFAULT NULL,
  `current_no` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_resetconfig_id` (`resetconfig_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tableresetruns_is`
--

LOCK TABLES `tableresetruns_is` WRITE;
/*!40000 ALTER TABLE `tableresetruns_is` DISABLE KEYS */;
/*!40000 ALTER TABLE `tableresetruns_is` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tills`
--

DROP TABLE IF EXISTS `tills`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tills` (
  `id` int(11) unsigned NOT NULL,
  `till_id` varchar(59) NOT NULL,
  `till_user` varchar(50) NOT NULL,
  `till_date` date NOT NULL,
  `initial_balance` float(16,2) NOT NULL,
  `status` enum('OPEN','SUSPENDED','CLOSED') NOT NULL,
  `expiry_date` date NOT NULL,
  `expiry_time` time NOT NULL,
  `inputter` varchar(50) NOT NULL,
  `input_date` datetime NOT NULL,
  `authorizer` varchar(50) NOT NULL,
  `auth_date` datetime NOT NULL,
  `record_status` char(4) NOT NULL,
  `current_no` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_till_id` (`till_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tills`
--

LOCK TABLES `tills` WRITE;
/*!40000 ALTER TABLE `tills` DISABLE KEYS */;
/*!40000 ALTER TABLE `tills` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tills_hs`
--

DROP TABLE IF EXISTS `tills_hs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tills_hs` (
  `id` int(11) unsigned NOT NULL,
  `till_id` varchar(59) NOT NULL,
  `till_user` varchar(50) NOT NULL,
  `till_date` date NOT NULL,
  `initial_balance` float(16,2) NOT NULL,
  `status` enum('OPEN','SUSPENDED','CLOSED') NOT NULL,
  `expiry_date` date NOT NULL,
  `expiry_time` time NOT NULL,
  `inputter` varchar(50) NOT NULL,
  `input_date` datetime NOT NULL,
  `authorizer` varchar(50) NOT NULL,
  `auth_date` datetime NOT NULL,
  `record_status` char(4) NOT NULL,
  `current_no` int(11) NOT NULL,
  PRIMARY KEY (`id`,`current_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tills_hs`
--

LOCK TABLES `tills_hs` WRITE;
/*!40000 ALTER TABLE `tills_hs` DISABLE KEYS */;
/*!40000 ALTER TABLE `tills_hs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tills_is`
--

DROP TABLE IF EXISTS `tills_is`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tills_is` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `till_id` varchar(59) DEFAULT NULL,
  `till_user` varchar(50) DEFAULT NULL,
  `till_date` date DEFAULT NULL,
  `initial_balance` float(16,2) DEFAULT '0.00',
  `status` enum('OPEN','SUSPENDED','CLOSED') DEFAULT 'OPEN',
  `expiry_date` date DEFAULT NULL,
  `expiry_time` time DEFAULT NULL,
  `inputter` varchar(50) DEFAULT NULL,
  `input_date` datetime DEFAULT NULL,
  `authorizer` varchar(50) DEFAULT NULL,
  `auth_date` datetime DEFAULT NULL,
  `record_status` char(4) DEFAULT NULL,
  `current_no` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_till_id` (`till_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tills_is`
--

LOCK TABLES `tills_is` WRITE;
/*!40000 ALTER TABLE `tills_is` DISABLE KEYS */;
/*!40000 ALTER TABLE `tills_is` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tilltransactions`
--

DROP TABLE IF EXISTS `tilltransactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tilltransactions` (
  `id` int(11) unsigned NOT NULL,
  `transaction_id` varchar(16) NOT NULL,
  `till_id` varchar(59) NOT NULL,
  `amount` float(16,2) NOT NULL,
  `transaction_type` enum('CASH','CHEQUE','DEBIT.CARD','CREDIT.CARD') NOT NULL,
  `transaction_date` date NOT NULL,
  `movement` enum('IN','OUT') NOT NULL,
  `reason` varchar(255) NOT NULL,
  `comments` text,
  `inputter` varchar(50) NOT NULL,
  `input_date` datetime NOT NULL,
  `authorizer` varchar(50) NOT NULL,
  `auth_date` datetime NOT NULL,
  `record_status` char(4) NOT NULL,
  `current_no` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_transaction_id` (`transaction_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tilltransactions`
--

LOCK TABLES `tilltransactions` WRITE;
/*!40000 ALTER TABLE `tilltransactions` DISABLE KEYS */;
/*!40000 ALTER TABLE `tilltransactions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tilltransactions_hs`
--

DROP TABLE IF EXISTS `tilltransactions_hs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tilltransactions_hs` (
  `id` int(11) unsigned NOT NULL,
  `transaction_id` varchar(16) NOT NULL,
  `till_id` varchar(59) NOT NULL,
  `amount` float(16,2) NOT NULL,
  `transaction_type` enum('CASH','CHEQUE','DEBIT.CARD','CREDIT.CARD') NOT NULL,
  `transaction_date` date NOT NULL,
  `movement` enum('IN','OUT') NOT NULL,
  `reason` varchar(255) NOT NULL,
  `comments` text,
  `inputter` varchar(50) NOT NULL,
  `input_date` datetime NOT NULL,
  `authorizer` varchar(50) NOT NULL,
  `auth_date` datetime NOT NULL,
  `record_status` char(4) NOT NULL,
  `current_no` int(11) NOT NULL,
  PRIMARY KEY (`id`,`current_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tilltransactions_hs`
--

LOCK TABLES `tilltransactions_hs` WRITE;
/*!40000 ALTER TABLE `tilltransactions_hs` DISABLE KEYS */;
/*!40000 ALTER TABLE `tilltransactions_hs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tilltransactions_is`
--

DROP TABLE IF EXISTS `tilltransactions_is`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tilltransactions_is` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `transaction_id` varchar(16) DEFAULT NULL,
  `till_id` varchar(59) DEFAULT NULL,
  `amount` float(16,2) DEFAULT '0.00',
  `transaction_type` enum('CASH','CHEQUE','DEBIT.CARD','CREDIT.CARD') DEFAULT NULL,
  `transaction_date` date DEFAULT NULL,
  `movement` enum('IN','OUT') DEFAULT NULL,
  `reason` varchar(255) DEFAULT NULL,
  `comments` text,
  `inputter` varchar(50) DEFAULT NULL,
  `input_date` datetime DEFAULT NULL,
  `authorizer` varchar(50) DEFAULT NULL,
  `auth_date` datetime DEFAULT NULL,
  `record_status` char(4) DEFAULT NULL,
  `current_no` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_transaction_id` (`transaction_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tilltransactions_is`
--

LOCK TABLES `tilltransactions_is` WRITE;
/*!40000 ALTER TABLE `tilltransactions_is` DISABLE KEYS */;
/*!40000 ALTER TABLE `tilltransactions_is` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_tokens`
--

DROP TABLE IF EXISTS `user_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_tokens` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL,
  `user_agent` varchar(40) NOT NULL,
  `token` varchar(32) NOT NULL,
  `created` int(10) unsigned NOT NULL,
  `expires` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_token` (`token`),
  KEY `fk_user_id` (`user_id`),
  CONSTRAINT `user_tokens_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_tokens`
--

LOCK TABLES `user_tokens` WRITE;
/*!40000 ALTER TABLE `user_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userroles`
--

DROP TABLE IF EXISTS `userroles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userroles` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `idname` varchar(50) NOT NULL,
  `roles` text,
  `inputter` varchar(50) NOT NULL,
  `input_date` datetime NOT NULL,
  `authorizer` varchar(50) NOT NULL,
  `auth_date` datetime NOT NULL,
  `record_status` char(4) NOT NULL,
  `current_no` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_idname` (`idname`)
) ENGINE=InnoDB AUTO_INCREMENT=1003 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userroles`
--

LOCK TABLES `userroles` WRITE;
/*!40000 ALTER TABLE `userroles` DISABLE KEYS */;
INSERT INTO `userroles` VALUES (1,'ADMIN','useradmin_super,sysadmin_super,developer_super,hndshkif_super','ADMIN','2013-09-10 06:49:21','ADMIN','2013-09-10 06:50:08','LIVE',3),(1002,'DUNSTAN.NESBIT','sysadmin_super,hndshkif_super','ADMIN','2013-09-10 07:01:01','ADMIN','2013-09-10 07:01:08','LIVE',3);
/*!40000 ALTER TABLE `userroles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userroles_hs`
--

DROP TABLE IF EXISTS `userroles_hs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userroles_hs` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `idname` varchar(50) NOT NULL,
  `roles` text,
  `inputter` varchar(50) NOT NULL,
  `input_date` datetime NOT NULL,
  `authorizer` varchar(50) NOT NULL,
  `auth_date` datetime NOT NULL,
  `record_status` char(4) NOT NULL,
  `current_no` int(11) NOT NULL,
  PRIMARY KEY (`id`,`current_no`)
) ENGINE=MyISAM AUTO_INCREMENT=10002 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userroles_hs`
--

LOCK TABLES `userroles_hs` WRITE;
/*!40000 ALTER TABLE `userroles_hs` DISABLE KEYS */;
INSERT INTO `userroles_hs` VALUES (1,'ADMIN','useradmin_super,sysadmin_super,developer_super,customer_super,sales_super,enquiry_super,report_super,businessadmin_super','ADMIN','2011-04-29 15:26:25','ADMIN','2011-04-29 15:26:40','HIST',1),(2,'DUNSTAN.NESBIT','useradmin_super,sysadmin_super,developer_super,customer_super,sales_super,enquiry_super,report_super,businessadmin_super','DUNSTAN.NESBIT','2012-07-26 14:05:41','DUNSTAN.NESBIT','2012-07-26 14:05:48','HIST',1),(1,'ADMIN','useradmin_super,sysadmin_super,developer_super,customer_super,sales_super,enquiry_super,report_super,businessadmin_super,hndshkif_super','ADMIN','2013-09-10 06:47:20','ADMIN','2013-09-10 06:47:27','HIST',2),(1002,'DUNSTAN.NESBIT','sysadmin_super,hndshkif_super','ADMIN','2013-09-10 06:47:56','ADMIN','2013-09-10 06:48:02','HIST',2);
/*!40000 ALTER TABLE `userroles_hs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userroles_is`
--

DROP TABLE IF EXISTS `userroles_is`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userroles_is` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `idname` varchar(50) DEFAULT NULL,
  `roles` text,
  `inputter` varchar(50) DEFAULT NULL,
  `input_date` datetime DEFAULT NULL,
  `authorizer` varchar(50) DEFAULT NULL,
  `auth_date` datetime DEFAULT NULL,
  `record_status` char(4) DEFAULT 'IHLD',
  `current_no` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1011 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userroles_is`
--

LOCK TABLES `userroles_is` WRITE;
/*!40000 ALTER TABLE `userroles_is` DISABLE KEYS */;
/*!40000 ALTER TABLE `userroles_is` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `idname` varchar(50) NOT NULL DEFAULT '',
  `username` varchar(32) NOT NULL DEFAULT '',
  `fullname` varchar(255) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `enabled` enum('Y','N') DEFAULT 'Y',
  `expiry_date` date DEFAULT '2037-12-31',
  `branch_id` varchar(50) DEFAULT NULL,
  `department_id` varchar(50) DEFAULT NULL,
  `password` char(65) DEFAULT NULL,
  `logins` int(10) unsigned DEFAULT '0',
  `last_login` int(10) unsigned DEFAULT '0',
  `inputter` varchar(50) DEFAULT NULL,
  `input_date` datetime DEFAULT NULL,
  `authorizer` varchar(50) DEFAULT NULL,
  `auth_date` datetime DEFAULT NULL,
  `record_status` char(4) DEFAULT NULL,
  `current_no` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_username` (`username`),
  UNIQUE KEY `uniq_idname` (`idname`)
) ENGINE=InnoDB AUTO_INCREMENT=1003 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'ADMIN','admin','Administrator','admin@halaya.com','Y','2037-12-31','HEAD.OFFICE','SYSTEM','28d7a4c88f8a0572012651e93d8cfde80e065b44ae931fcc22dc7c658262baec',578,1379102590,'ADMIN','2013-01-13 20:25:51','ADMIN','2013-01-13 20:26:09','LIVE',10),(2,'IMPLEMENTATION','implementation','Implementation','implementation@halaya.com','Y','2037-12-31','HEAD.OFFICE','SYSTEM','28d7a4c88f8a0572012651e93d8cfde80e065b44ae931fcc22dc7c658262baec',20,1301580113,'ADMIN','2011-01-21 12:57:20','ADMIN','2011-01-21 12:57:56','LIVE',1),(1002,'DUNSTAN.NESBIT','dnesbit','Dunstan Nesbit','dunstan.nesbit@gmail.com','Y','2037-12-31','HEAD.OFFICE','INFORMATION.TECHNOLOGY','28d7a4c88f8a0572012651e93d8cfde80e065b44ae931fcc22dc7c658262baec',122,1378810423,'ADMIN','2011-08-10 12:12:54','ADMIN','2011-08-10 12:13:06','LIVE',2);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users_hs`
--

DROP TABLE IF EXISTS `users_hs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users_hs` (
  `id` int(11) unsigned NOT NULL,
  `idname` varchar(50) NOT NULL DEFAULT '',
  `username` varchar(32) NOT NULL DEFAULT '',
  `fullname` varchar(255) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `enabled` enum('Y','N') NOT NULL DEFAULT 'Y',
  `expiry_date` date NOT NULL DEFAULT '2037-12-31',
  `branch_id` varchar(50) NOT NULL,
  `department_id` varchar(50) NOT NULL,
  `password` char(64) DEFAULT NULL,
  `logins` int(10) unsigned NOT NULL DEFAULT '0',
  `last_login` int(10) unsigned NOT NULL,
  `inputter` varchar(50) NOT NULL,
  `input_date` datetime NOT NULL,
  `authorizer` varchar(50) NOT NULL,
  `auth_date` datetime NOT NULL,
  `record_status` char(4) NOT NULL,
  `current_no` int(11) NOT NULL,
  PRIMARY KEY (`id`,`current_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users_hs`
--

LOCK TABLES `users_hs` WRITE;
/*!40000 ALTER TABLE `users_hs` DISABLE KEYS */;
/*!40000 ALTER TABLE `users_hs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users_is`
--

DROP TABLE IF EXISTS `users_is`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users_is` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `idname` varchar(50) DEFAULT NULL,
  `username` varchar(32) DEFAULT NULL,
  `fullname` varchar(255) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `enabled` enum('Y','N') NOT NULL DEFAULT 'Y',
  `expiry_date` date NOT NULL DEFAULT '2037-12-31',
  `branch_id` varchar(50) DEFAULT NULL,
  `department_id` varchar(50) DEFAULT NULL,
  `password` char(64) DEFAULT NULL,
  `logins` int(10) unsigned DEFAULT '0',
  `last_login` int(10) unsigned DEFAULT '0',
  `inputter` varchar(50) DEFAULT NULL,
  `input_date` datetime DEFAULT NULL,
  `authorizer` varchar(50) DEFAULT NULL,
  `auth_date` datetime DEFAULT NULL,
  `record_status` char(4) NOT NULL DEFAULT 'IHLD',
  `current_no` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users_is`
--

LOCK TABLES `users_is` WRITE;
/*!40000 ALTER TABLE `users_is` DISABLE KEYS */;
/*!40000 ALTER TABLE `users_is` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `vw_active_charge_customers`
--

DROP TABLE IF EXISTS `vw_active_charge_customers`;
/*!50001 DROP VIEW IF EXISTS `vw_active_charge_customers`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `vw_active_charge_customers` (
  `id` tinyint NOT NULL,
  `customer_id` tinyint NOT NULL,
  `customer_type` tinyint NOT NULL,
  `business_type` tinyint NOT NULL,
  `first_name` tinyint NOT NULL,
  `last_name` tinyint NOT NULL,
  `phone_mobile1` tinyint NOT NULL,
  `activation_date` tinyint NOT NULL,
  `status_change_date` tinyint NOT NULL,
  `active` tinyint NOT NULL,
  `special_instructions` tinyint NOT NULL,
  `comments` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `vw_batchorders_lookup`
--

DROP TABLE IF EXISTS `vw_batchorders_lookup`;
/*!50001 DROP VIEW IF EXISTS `vw_batchorders_lookup`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `vw_batchorders_lookup` (
  `invoice_id` tinyint NOT NULL,
  `order_id` tinyint NOT NULL,
  `order_date` tinyint NOT NULL,
  `first_name` tinyint NOT NULL,
  `order_details` tinyint NOT NULL,
  `last_name` tinyint NOT NULL,
  `extended_total` tinyint NOT NULL,
  `tax_total` tinyint NOT NULL,
  `order_total` tinyint NOT NULL,
  `payment_total` tinyint NOT NULL,
  `balance` tinyint NOT NULL,
  `payment_type` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `vw_batchtypes`
--

DROP TABLE IF EXISTS `vw_batchtypes`;
/*!50001 DROP VIEW IF EXISTS `vw_batchtypes`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `vw_batchtypes` (
  `type` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `vw_biztype`
--

DROP TABLE IF EXISTS `vw_biztype`;
/*!50001 DROP VIEW IF EXISTS `vw_biztype`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `vw_biztype` (
  `business_type` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `vw_core_fixedselections_available`
--

DROP TABLE IF EXISTS `vw_core_fixedselections_available`;
/*!50001 DROP VIEW IF EXISTS `vw_core_fixedselections_available`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `vw_core_fixedselections_available` (
  `fixedselection_id` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `vw_core_users_noroles`
--

DROP TABLE IF EXISTS `vw_core_users_noroles`;
/*!50001 DROP VIEW IF EXISTS `vw_core_users_noroles`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `vw_core_users_noroles` (
  `idname` tinyint NOT NULL,
  `fullname` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `vw_deliverynotes`
--

DROP TABLE IF EXISTS `vw_deliverynotes`;
/*!50001 DROP VIEW IF EXISTS `vw_deliverynotes`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `vw_deliverynotes` (
  `id` tinyint NOT NULL,
  `deliverynote_id` tinyint NOT NULL,
  `invoice_id` tinyint NOT NULL,
  `order_id` tinyint NOT NULL,
  `branch_id` tinyint NOT NULL,
  `customer_id` tinyint NOT NULL,
  `is_co` tinyint NOT NULL,
  `cc_id` tinyint NOT NULL,
  `first_name` tinyint NOT NULL,
  `last_name` tinyint NOT NULL,
  `customer_type` tinyint NOT NULL,
  `address1` tinyint NOT NULL,
  `address2` tinyint NOT NULL,
  `city` tinyint NOT NULL,
  `phone_mobile1` tinyint NOT NULL,
  `phone_home` tinyint NOT NULL,
  `phone_work` tinyint NOT NULL,
  `order_date` tinyint NOT NULL,
  `quotation_date` tinyint NOT NULL,
  `invoice_date` tinyint NOT NULL,
  `order_status` tinyint NOT NULL,
  `inventory_checkout_status` tinyint NOT NULL,
  `inventory_update_type` tinyint NOT NULL,
  `inputter` tinyint NOT NULL,
  `input_date` tinyint NOT NULL,
  `invoice_note` tinyint NOT NULL,
  `deliverynote_date` tinyint NOT NULL,
  `details` tinyint NOT NULL,
  `status` tinyint NOT NULL,
  `delivered_by` tinyint NOT NULL,
  `delivery_date` tinyint NOT NULL,
  `returned_signed_by` tinyint NOT NULL,
  `returned_signed_date` tinyint NOT NULL,
  `comments` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `vw_distinct_product_category`
--

DROP TABLE IF EXISTS `vw_distinct_product_category`;
/*!50001 DROP VIEW IF EXISTS `vw_distinct_product_category`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `vw_distinct_product_category` (
  `category` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `vw_distinct_product_subcategory`
--

DROP TABLE IF EXISTS `vw_distinct_product_subcategory`;
/*!50001 DROP VIEW IF EXISTS `vw_distinct_product_subcategory`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `vw_distinct_product_subcategory` (
  `sub_category` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `vw_estimator_products`
--

DROP TABLE IF EXISTS `vw_estimator_products`;
/*!50001 DROP VIEW IF EXISTS `vw_estimator_products`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `vw_estimator_products` (
  `product_id` tinyint NOT NULL,
  `product_description` tinyint NOT NULL,
  `TYPE` tinyint NOT NULL,
  `taxable` tinyint NOT NULL,
  `unit_price` tinyint NOT NULL,
  `total_price` tinyint NOT NULL,
  `category` tinyint NOT NULL,
  `sub_category` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `vw_inventchkout_sideinfo`
--

DROP TABLE IF EXISTS `vw_inventchkout_sideinfo`;
/*!50001 DROP VIEW IF EXISTS `vw_inventchkout_sideinfo`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `vw_inventchkout_sideinfo` (
  `id` tinyint NOT NULL,
  `order_id` tinyint NOT NULL,
  `branch_id` tinyint NOT NULL,
  `customer_id` tinyint NOT NULL,
  `first_name` tinyint NOT NULL,
  `last_name` tinyint NOT NULL,
  `order_date` tinyint NOT NULL,
  `order_status` tinyint NOT NULL,
  `inventory_checkout_status` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `vw_inventory_checkout_status`
--

DROP TABLE IF EXISTS `vw_inventory_checkout_status`;
/*!50001 DROP VIEW IF EXISTS `vw_inventory_checkout_status`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `vw_inventory_checkout_status` (
  `branch_id` tinyint NOT NULL,
  `customer_id` tinyint NOT NULL,
  `customer_name` tinyint NOT NULL,
  `order_id` tinyint NOT NULL,
  `order_status` tinyint NOT NULL,
  `order_details` tinyint NOT NULL,
  `checkout_details` tinyint NOT NULL,
  `checkout_status` tinyint NOT NULL,
  `order_date` tinyint NOT NULL,
  `order_total` tinyint NOT NULL,
  `payment_total` tinyint NOT NULL,
  `balance` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `vw_inventprod_available`
--

DROP TABLE IF EXISTS `vw_inventprod_available`;
/*!50001 DROP VIEW IF EXISTS `vw_inventprod_available`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `vw_inventprod_available` (
  `id` tinyint NOT NULL,
  `product_id` tinyint NOT NULL,
  `description` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `vw_nonpackageproducts`
--

DROP TABLE IF EXISTS `vw_nonpackageproducts`;
/*!50001 DROP VIEW IF EXISTS `vw_nonpackageproducts`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `vw_nonpackageproducts` (
  `id` tinyint NOT NULL,
  `product_id` tinyint NOT NULL,
  `type` tinyint NOT NULL,
  `package_items` tinyint NOT NULL,
  `product_description` tinyint NOT NULL,
  `extended_description` tinyint NOT NULL,
  `category` tinyint NOT NULL,
  `sub_category` tinyint NOT NULL,
  `unit_price` tinyint NOT NULL,
  `taxable` tinyint NOT NULL,
  `tax_percentage` tinyint NOT NULL,
  `status` tinyint NOT NULL,
  `inputter` tinyint NOT NULL,
  `input_date` tinyint NOT NULL,
  `authorizer` tinyint NOT NULL,
  `auth_date` tinyint NOT NULL,
  `record_status` tinyint NOT NULL,
  `current_no` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `vw_orderbalances`
--

DROP TABLE IF EXISTS `vw_orderbalances`;
/*!50001 DROP VIEW IF EXISTS `vw_orderbalances`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `vw_orderbalances` (
  `id` tinyint NOT NULL,
  `order_id` tinyint NOT NULL,
  `branch_id` tinyint NOT NULL,
  `customer_id` tinyint NOT NULL,
  `is_co` tinyint NOT NULL,
  `cc_id` tinyint NOT NULL,
  `first_name` tinyint NOT NULL,
  `last_name` tinyint NOT NULL,
  `customer_type` tinyint NOT NULL,
  `address1` tinyint NOT NULL,
  `address2` tinyint NOT NULL,
  `city` tinyint NOT NULL,
  `phone_mobile1` tinyint NOT NULL,
  `phone_home` tinyint NOT NULL,
  `phone_work` tinyint NOT NULL,
  `order_details` tinyint NOT NULL,
  `payment_type` tinyint NOT NULL,
  `order_date` tinyint NOT NULL,
  `quotation_date` tinyint NOT NULL,
  `invoice_date` tinyint NOT NULL,
  `order_status` tinyint NOT NULL,
  `inventory_checkout_status` tinyint NOT NULL,
  `inventory_update_type` tinyint NOT NULL,
  `inputter` tinyint NOT NULL,
  `input_date` tinyint NOT NULL,
  `invoice_note` tinyint NOT NULL,
  `comments` tinyint NOT NULL,
  `current_no` tinyint NOT NULL,
  `discount_total` tinyint NOT NULL,
  `extended_total` tinyint NOT NULL,
  `tax_total` tinyint NOT NULL,
  `order_total` tinyint NOT NULL,
  `payment_total` tinyint NOT NULL,
  `balance` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `vw_orderbalances_nonzero`
--

DROP TABLE IF EXISTS `vw_orderbalances_nonzero`;
/*!50001 DROP VIEW IF EXISTS `vw_orderbalances_nonzero`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `vw_orderbalances_nonzero` (
  `order_id` tinyint NOT NULL,
  `branch_id` tinyint NOT NULL,
  `customer_id` tinyint NOT NULL,
  `first_name` tinyint NOT NULL,
  `last_name` tinyint NOT NULL,
  `order_date` tinyint NOT NULL,
  `order_status` tinyint NOT NULL,
  `order_total` tinyint NOT NULL,
  `payment_total` tinyint NOT NULL,
  `balance` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `vw_orderbalances_ss`
--

DROP TABLE IF EXISTS `vw_orderbalances_ss`;
/*!50001 DROP VIEW IF EXISTS `vw_orderbalances_ss`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `vw_orderbalances_ss` (
  `id` tinyint NOT NULL,
  `order_id` tinyint NOT NULL,
  `branch_id` tinyint NOT NULL,
  `customer_id` tinyint NOT NULL,
  `first_name` tinyint NOT NULL,
  `last_name` tinyint NOT NULL,
  `customer_type` tinyint NOT NULL,
  `address1` tinyint NOT NULL,
  `address2` tinyint NOT NULL,
  `city` tinyint NOT NULL,
  `phone_mobile1` tinyint NOT NULL,
  `phone_home` tinyint NOT NULL,
  `phone_work` tinyint NOT NULL,
  `order_details` tinyint NOT NULL,
  `payment_type` tinyint NOT NULL,
  `order_date` tinyint NOT NULL,
  `quotation_date` tinyint NOT NULL,
  `invoice_date` tinyint NOT NULL,
  `order_status` tinyint NOT NULL,
  `inventory_checkout_status` tinyint NOT NULL,
  `inventory_update_type` tinyint NOT NULL,
  `inputter` tinyint NOT NULL,
  `input_date` tinyint NOT NULL,
  `invoice_note` tinyint NOT NULL,
  `comments` tinyint NOT NULL,
  `current_no` tinyint NOT NULL,
  `unit_total` tinyint NOT NULL,
  `discount_total` tinyint NOT NULL,
  `extended_total` tinyint NOT NULL,
  `tax_total` tinyint NOT NULL,
  `order_total` tinyint NOT NULL,
  `payment_total` tinyint NOT NULL,
  `balance` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `vw_ordercancel_candidates`
--

DROP TABLE IF EXISTS `vw_ordercancel_candidates`;
/*!50001 DROP VIEW IF EXISTS `vw_ordercancel_candidates`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `vw_ordercancel_candidates` (
  `id` tinyint NOT NULL,
  `order_id` tinyint NOT NULL,
  `customer_id` tinyint NOT NULL,
  `order_status` tinyint NOT NULL,
  `order_date` tinyint NOT NULL,
  `branch_id` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `vw_orderreopen_candidates`
--

DROP TABLE IF EXISTS `vw_orderreopen_candidates`;
/*!50001 DROP VIEW IF EXISTS `vw_orderreopen_candidates`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `vw_orderreopen_candidates` (
  `id` tinyint NOT NULL,
  `order_id` tinyint NOT NULL,
  `customer_id` tinyint NOT NULL,
  `order_status` tinyint NOT NULL,
  `order_date` tinyint NOT NULL,
  `branch_id` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `vw_orders`
--

DROP TABLE IF EXISTS `vw_orders`;
/*!50001 DROP VIEW IF EXISTS `vw_orders`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `vw_orders` (
  `id` tinyint NOT NULL,
  `order_id` tinyint NOT NULL,
  `branch_id` tinyint NOT NULL,
  `customer_id` tinyint NOT NULL,
  `is_co` tinyint NOT NULL,
  `cc_id` tinyint NOT NULL,
  `first_name` tinyint NOT NULL,
  `last_name` tinyint NOT NULL,
  `customer_type` tinyint NOT NULL,
  `address1` tinyint NOT NULL,
  `address2` tinyint NOT NULL,
  `city` tinyint NOT NULL,
  `phone_mobile1` tinyint NOT NULL,
  `phone_home` tinyint NOT NULL,
  `phone_work` tinyint NOT NULL,
  `order_details` tinyint NOT NULL,
  `order_date` tinyint NOT NULL,
  `quotation_date` tinyint NOT NULL,
  `invoice_date` tinyint NOT NULL,
  `order_status` tinyint NOT NULL,
  `inventory_checkout_status` tinyint NOT NULL,
  `inventory_update_type` tinyint NOT NULL,
  `inputter` tinyint NOT NULL,
  `input_date` tinyint NOT NULL,
  `invoice_note` tinyint NOT NULL,
  `comments` tinyint NOT NULL,
  `current_no` tinyint NOT NULL,
  `unit_total` tinyint NOT NULL,
  `discount_total` tinyint NOT NULL,
  `extended_total` tinyint NOT NULL,
  `tax_total` tinyint NOT NULL,
  `order_total` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `vw_orderstatus`
--

DROP TABLE IF EXISTS `vw_orderstatus`;
/*!50001 DROP VIEW IF EXISTS `vw_orderstatus`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `vw_orderstatus` (
  `id` tinyint NOT NULL,
  `order_status_id` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `vw_payments`
--

DROP TABLE IF EXISTS `vw_payments`;
/*!50001 DROP VIEW IF EXISTS `vw_payments`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `vw_payments` (
  `order_id` tinyint NOT NULL,
  `payment_type` tinyint NOT NULL,
  `payment_total` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `vw_payments_till`
--

DROP TABLE IF EXISTS `vw_payments_till`;
/*!50001 DROP VIEW IF EXISTS `vw_payments_till`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `vw_payments_till` (
  `order_id` tinyint NOT NULL,
  `till_id` tinyint NOT NULL,
  `tender_type` tinyint NOT NULL,
  `payment_type` tinyint NOT NULL,
  `payment_total` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `vw_payments_valid`
--

DROP TABLE IF EXISTS `vw_payments_valid`;
/*!50001 DROP VIEW IF EXISTS `vw_payments_valid`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `vw_payments_valid` (
  `id` tinyint NOT NULL,
  `payment_id` tinyint NOT NULL,
  `payment_date` tinyint NOT NULL,
  `amount` tinyint NOT NULL,
  `payment_type` tinyint NOT NULL,
  `order_id` tinyint NOT NULL,
  `branch_id` tinyint NOT NULL,
  `till_id` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `vw_tillmovements`
--

DROP TABLE IF EXISTS `vw_tillmovements`;
/*!50001 DROP VIEW IF EXISTS `vw_tillmovements`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `vw_tillmovements` (
  `till_id` tinyint NOT NULL,
  `tillmovements_type_totals` tinyint NOT NULL,
  `tillmovement_total` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `vw_tillpayments`
--

DROP TABLE IF EXISTS `vw_tillpayments`;
/*!50001 DROP VIEW IF EXISTS `vw_tillpayments`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `vw_tillpayments` (
  `till_id` tinyint NOT NULL,
  `till_owner` tinyint NOT NULL,
  `till_date` tinyint NOT NULL,
  `payment_type_totals` tinyint NOT NULL,
  `initial_balance` tinyint NOT NULL,
  `payment_total` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `vw_tillpayments_groups`
--

DROP TABLE IF EXISTS `vw_tillpayments_groups`;
/*!50001 DROP VIEW IF EXISTS `vw_tillpayments_groups`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `vw_tillpayments_groups` (
  `till_id` tinyint NOT NULL,
  `payment_type` tinyint NOT NULL,
  `payment_total` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `vw_tillpayments_types`
--

DROP TABLE IF EXISTS `vw_tillpayments_types`;
/*!50001 DROP VIEW IF EXISTS `vw_tillpayments_types`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `vw_tillpayments_types` (
  `till_id` tinyint NOT NULL,
  `tender_type` tinyint NOT NULL,
  `amount` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `vw_tills`
--

DROP TABLE IF EXISTS `vw_tills`;
/*!50001 DROP VIEW IF EXISTS `vw_tills`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `vw_tills` (
  `till_id` tinyint NOT NULL,
  `till_owner` tinyint NOT NULL,
  `till_date` tinyint NOT NULL,
  `payment_type_totals` tinyint NOT NULL,
  `tillmovements_type_totals` tinyint NOT NULL,
  `initial_balance` tinyint NOT NULL,
  `payment_total` tinyint NOT NULL,
  `tillmovement_total` tinyint NOT NULL,
  `till_balance` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `vw_tilltransactions`
--

DROP TABLE IF EXISTS `vw_tilltransactions`;
/*!50001 DROP VIEW IF EXISTS `vw_tilltransactions`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `vw_tilltransactions` (
  `till_id` tinyint NOT NULL,
  `tender_type` tinyint NOT NULL,
  `payment_type` tinyint NOT NULL,
  `payment_total` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `vw_tilltransactions_groups`
--

DROP TABLE IF EXISTS `vw_tilltransactions_groups`;
/*!50001 DROP VIEW IF EXISTS `vw_tilltransactions_groups`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `vw_tilltransactions_groups` (
  `till_id` tinyint NOT NULL,
  `payment_type` tinyint NOT NULL,
  `payment_total` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `vw_tilltransactions_types`
--

DROP TABLE IF EXISTS `vw_tilltransactions_types`;
/*!50001 DROP VIEW IF EXISTS `vw_tilltransactions_types`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `vw_tilltransactions_types` (
  `till_id` tinyint NOT NULL,
  `tender_type` tinyint NOT NULL,
  `amount` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `vw_userbranches`
--

DROP TABLE IF EXISTS `vw_userbranches`;
/*!50001 DROP VIEW IF EXISTS `vw_userbranches`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `vw_userbranches` (
  `id` tinyint NOT NULL,
  `idname` tinyint NOT NULL,
  `username` tinyint NOT NULL,
  `fullname` tinyint NOT NULL,
  `email` tinyint NOT NULL,
  `enabled` tinyint NOT NULL,
  `expiry_date` tinyint NOT NULL,
  `branch_id` tinyint NOT NULL,
  `department_id` tinyint NOT NULL,
  `description` tinyint NOT NULL,
  `location` tinyint NOT NULL,
  `region_id` tinyint NOT NULL,
  `active` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `weekdays`
--

DROP TABLE IF EXISTS `weekdays`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `weekdays` (
  `id` int(11) unsigned NOT NULL,
  `weekday_id` varchar(21) NOT NULL,
  `description` varchar(255) NOT NULL,
  `inputter` varchar(50) NOT NULL,
  `input_date` datetime NOT NULL,
  `authorizer` varchar(50) NOT NULL,
  `auth_date` datetime NOT NULL,
  `record_status` char(4) NOT NULL,
  `current_no` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_weekday_id` (`weekday_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `weekdays`
--

LOCK TABLES `weekdays` WRITE;
/*!40000 ALTER TABLE `weekdays` DISABLE KEYS */;
INSERT INTO `weekdays` VALUES (0,'NODAY','No day Assigned','IMPLEMENTATAION','2010-08-28 00:00:00','ADMIN','2010-08-28 00:00:00','LIVE',1),(1,'SUNDAY','Sunday','IMPLEMENTATION','2010-08-28 00:00:00','ADMIN','2010-08-28 00:00:00','LIVE',1),(2,'MONDAY','Monday','IMPLEMENTATION','2010-08-28 00:00:00','ADMIN','2010-08-28 00:00:00','LIVE',1),(3,'TUESDAY','Tuesday','IMPLEMENTATION','2010-08-28 00:00:00','ADMIN','2010-08-28 00:00:00','LIVE',1),(4,'WEDNESDAY','Wednesday','IMPLEMENTATION','2010-08-28 00:00:00','ADMIN','2010-08-28 00:00:00','LIVE',1),(5,'THURSDAY','Thursday','IMPLEMENTATION','2010-08-28 00:00:00','ADMIN','2010-08-28 00:00:00','LIVE',1),(6,'FRIDAY','Friday','IMPLEMENTATION','2010-08-28 00:00:00','ADMIN','2010-08-28 00:00:00','LIVE',1),(7,'SATURDAY','Saturday','IMPLEMENTATION','2010-08-28 00:00:00','ADMIN','2010-08-28 00:00:00','LIVE',1),(8,'MONWED','Monday,Wednesday','IMPLEMENTATION','2010-08-28 00:00:00','ADMIN','2010-08-28 00:00:00','LIVE',1),(9,'TUETHU','Tuesday,Thursday','IMPLEMENTATION','2010-08-28 00:00:00','ADMIN','2010-08-28 00:00:00','LIVE',1),(10,'FRISAT','Friday,Saturday','IMPLEMENTATION','2010-08-28 00:00:00','ADMIN','2010-08-28 00:00:00','LIVE',1),(11,'MON-FRI','Monday - Friday','IMPLEMENTATION','2010-08-28 00:00:00','ADMIN','2010-08-28 00:00:00','LIVE',1);
/*!40000 ALTER TABLE `weekdays` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `weekdays_hs`
--

DROP TABLE IF EXISTS `weekdays_hs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `weekdays_hs` (
  `id` int(11) unsigned NOT NULL,
  `weekday_id` varchar(21) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `inputter` varchar(50) NOT NULL,
  `input_date` datetime NOT NULL,
  `authorizer` varchar(50) NOT NULL,
  `auth_date` datetime NOT NULL,
  `record_status` char(4) NOT NULL,
  `current_no` int(11) NOT NULL,
  PRIMARY KEY (`id`,`current_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `weekdays_hs`
--

LOCK TABLES `weekdays_hs` WRITE;
/*!40000 ALTER TABLE `weekdays_hs` DISABLE KEYS */;
/*!40000 ALTER TABLE `weekdays_hs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `weekdays_is`
--

DROP TABLE IF EXISTS `weekdays_is`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `weekdays_is` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `weekday_id` varchar(21) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `inputter` varchar(50) DEFAULT NULL,
  `input_date` datetime DEFAULT NULL,
  `authorizer` varchar(50) DEFAULT NULL,
  `auth_date` datetime DEFAULT NULL,
  `record_status` char(4) DEFAULT NULL,
  `current_no` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_weekday_id` (`weekday_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `weekdays_is`
--

LOCK TABLES `weekdays_is` WRITE;
/*!40000 ALTER TABLE `weekdays_is` DISABLE KEYS */;
/*!40000 ALTER TABLE `weekdays_is` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'hndshkif'
--
/*!50003 DROP FUNCTION IF EXISTS `func_CalculateExtendedPrice` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
CREATE DEFINER=`dbuser`@`localhost` FUNCTION `func_CalculateExtendedPrice`(unit_price FLOAT, tax_percentage FLOAT, taxable VARCHAR(1)) RETURNS float(16,2)
BEGIN
	DECLARE ret FLOAT;		
	DECLARE tax_amount FLOAT;		
	IF taxable = 'Y' THEN
	    SET tax_amount = unit_price * (tax_percentage/100);
	ELSE
	    SET tax_amount ='0';
        END IF;
	set ret = unit_price + tax_amount;
	return (ret);
    END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `func_CalculateTotalPrice` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
CREATE DEFINER=`dbuser`@`localhost` FUNCTION `func_CalculateTotalPrice`(unit_price FLOAT, tax_percentage FLOAT, taxable VARCHAR(1)) RETURNS float(16,2)
BEGIN
	DECLARE ret FLOAT;		
	DECLARE tax_amount FLOAT;		
	IF taxable = 'Y' THEN
	    SET tax_amount = unit_price * (tax_percentage/100);
	ELSE
	    SET tax_amount ='0';
        END IF;
	set ret = unit_price + tax_amount;
	return (ret);
    END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `func_DuplicateTelbookPhoneNo` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
CREATE DEFINER=`dbuser`@`localhost` FUNCTION `func_DuplicateTelbookPhoneNo`(var INT(7)) RETURNS char(1) CHARSET latin1
    READS SQL DATA
BEGIN
	DECLARE ret CHAR(1);
	DECLARE rcount int(11);
	SELECT count(telno) into rcount from telbooks where telno = var;
	IF rcount > 0 THEN
	    SET ret='Y';
	ELSE
	    SET ret='N';
        END IF;
        RETURN(ret);
    END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `func_GETAGE` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
CREATE DEFINER=`dbuser`@`localhost` FUNCTION `func_GETAGE`(dob DATE) RETURNS int(11)
    DETERMINISTIC
BEGIN
	DECLARE age INT;
	SELECT DATE_FORMAT(NOW(), '%Y') - DATE_FORMAT(dob, '%Y') - (DATE_FORMAT(NOW(), '00-%m-%d') < DATE_FORMAT(dob, '00-%m-%d')) into age;
	RETURN age;
    END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `func_IdAlpha` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
CREATE DEFINER=`dbuser`@`%` FUNCTION `func_IdAlpha`(vehicle_id VARCHAR(7)) RETURNS varchar(3) CHARSET latin1
    DETERMINISTIC
BEGIN
 	DECLARE ret VARCHAR(3);
	DECLARE idlen INT;		
	SELECT CHAR_LENGTH(vehicle_id) into idlen; 
	
	IF idlen < 7 THEN
		SET ret='SH';
          ELSE
		SELECT SUBSTRING(vehicle_id,0,3) into ret;
		
        END IF;
        RETURN(ret);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `func_OrderCheckoutStatusReadable` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
CREATE DEFINER=`dbuser`@`localhost` FUNCTION `func_OrderCheckoutStatusReadable`(xml TEXT) RETURNS text CHARSET latin1
    DETERMINISTIC
BEGIN
	DECLARE i INT DEFAULT 1;
	DECLARE ctotal int DEFAULT 0; 
	DECLARE ret TEXT DEFAULT "";
	declare product_id VARCHAR(50) DEFAULT "";
	DECLARE order_qty text DEFAULT "";
	DECLARE filled_qty text DEFAULT "";
	DECLARE checkout_qty text DEFAULT "";
	DECLARE cstatus TEXT DEFAULT "";
	SET ctotal = ExtractValue(xml,'count(/formfields/rows/row)');
	WHILE i <= ctotal DO
		SET product_id 	= concat('/formfields/rows/row[',i,']/product_id');
		SET order_qty  	= CONCAT('/formfields/rows/row[',i,']/order_qty');
		SET filled_qty 	= CONCAT('/formfields/rows/row[',i,']/filled_qty');
		SET checkout_qty = CONCAT('/formfields/rows/row[',i,']/checkout_qty');
		SET cstatus 	= CONCAT('/formfields/rows/row[',i,']/status');
		SET ret = CONCAT(ret,ExtractValue(xml,product_id),";STATUS=",ExtractValue(xml,cstatus),"; Total=",ExtractValue(xml,order_qty),";Filled=",ExtractValue(xml,filled_qty),";Pending=",ExtractValue(xml,checkout_qty)," ");
		SET i = i+1;
	END WHILE;
	RETURN ret;
    END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `func_OrderDetailDiscountTotal` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
CREATE DEFINER=`dbuser`@`localhost` FUNCTION `func_OrderDetailDiscountTotal`(qty FLOAT, unit_price FLOAT, discount_amount FLOAT, discount_type VARCHAR(10)) RETURNS float(16,2)
BEGIN
	DECLARE ret FLOAT;		
	IF discount_type = 'PERCENT' THEN
	    set discount_amount = (qty*unit_price) * (discount_amount / 100);
	END IF;
	set ret = discount_amount;
	return (ret);
    END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `func_OrderDetailOrderTotal` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
CREATE DEFINER=`dbuser`@`localhost` FUNCTION `func_OrderDetailOrderTotal`(qty FLOAT, unit_price FLOAT, discount_amount FLOAT, tax_percentage FLOAT, taxable varchar(1), discount_type VARCHAR(10)) RETURNS float(16,2)
BEGIN
	DECLARE ret FLOAT;		
	DECLARE tax_amount FLOAT;		
	IF discount_type = 'PERCENT' THEN
	    set discount_amount = (qty*unit_price) * (discount_amount / 100);
	END IF;
	IF taxable = 'Y' THEN
	    SET tax_amount = ((qty*unit_price)-discount_amount) * (tax_percentage/ 100);
	ELSE
	    SET tax_amount ='0.00';
	END IF;
	set ret = (qty*unit_price) - discount_amount + tax_amount;
	return (ret);
    END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `func_OrderDetailSubTotal` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
CREATE DEFINER=`dbuser`@`localhost` FUNCTION `func_OrderDetailSubTotal`(qty FLOAT, unit_price FLOAT, discount_amount FLOAT, discount_type VARCHAR(10)) RETURNS float(16,2)
BEGIN
	DECLARE ret FLOAT;		
	IF discount_type = 'PERCENT' THEN
	    set discount_amount = (qty*unit_price) * (discount_amount / 100);
	END IF;
	set ret = (qty*unit_price) - discount_amount;
	return (ret);
    END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `func_OrderDetailTaxTotal` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
CREATE DEFINER=`dbuser`@`localhost` FUNCTION `func_OrderDetailTaxTotal`(qty FLOAT, unit_price FLOAT, discount_amount FLOAT, tax_percentage FLOAT, taxable VARCHAR(1), discount_type VARCHAR(10)) RETURNS float(16,2)
BEGIN
	DECLARE ret FLOAT;		
	DECLARE tax_amount FLOAT;		
	IF discount_type = 'PERCENT' THEN
	    set discount_amount = (qty*unit_price) * (discount_amount / 100);
	END IF;
	IF taxable = 'Y' THEN
	    SET tax_amount = ((qty*unit_price)-discount_amount) * (tax_percentage/ 100);
	ELSE
	    SET tax_amount ='0.00';
	END IF;
	set ret = tax_amount;
	return (ret);
    END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `func_OrderDetailUnitTotal` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
CREATE DEFINER=`dbuser`@`localhost` FUNCTION `func_OrderDetailUnitTotal`(qty FLOAT, unit_price FLOAT) RETURNS float(16,2)
BEGIN
	DECLARE ret FLOAT;
	set ret = (qty*unit_price);
	return (ret);
    END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `func_SetNullToBlank` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
CREATE DEFINER=`dbuser`@`%` FUNCTION `func_SetNullToBlank`(var VARCHAR(100)) RETURNS varchar(100) CHARSET latin1
    DETERMINISTIC
BEGIN
	DECLARE ret VARCHAR(100);
	IF ISNULL(var) THEN
             SET ret="";
          ELSE
             SET ret=var;
        END IF;
        RETURN(ret);
    END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `func_SetNullToZero` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
CREATE DEFINER=`dbuser`@`%` FUNCTION `func_SetNullToZero`(var VARCHAR(20)) RETURNS float(16,2)
    DETERMINISTIC
BEGIN
	DECLARE ret FLOAT(16,2);
	IF var=null THEN
             SET ret='0.00';
          ELSE
             SET ret=var;
        END IF;
        RETURN(ret);
    END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `func_SetToBlankCo` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
CREATE DEFINER=`dbuser`@`%` FUNCTION `func_SetToBlankCo`(var VARCHAR(255)) RETURNS varchar(255) CHARSET latin1
BEGIN
	DECLARE ret VARCHAR(255);
	IF var='CO.' THEN
             SET ret='';
          ELSE
             SET ret=var;
        END IF;
        RETURN(ret);
    END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `func_SetToBlankZero` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
CREATE DEFINER=`dbuser`@`%` FUNCTION `func_SetToBlankZero`(var INT(11)) RETURNS varchar(255) CHARSET latin1
BEGIN
	DECLARE ret VARCHAR(255);
	IF var=0 THEN
             SET ret='';
          ELSE
             SET ret=var;
        END IF;
        RETURN(ret);
    END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_AddAuditFields` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
CREATE DEFINER=`dbuser`@`localhost` PROCEDURE `sp_AddAuditFields`(IN tablename varchar(100), IN opt char(1))
BEGIN
	IF opt = 'I' THEN
		SET @qry = CONCAT("ALTER TABLE ",tablename," ADD COLUMN inputter varchar(50) NULL DEFAULT NULL");
	ELSEIF opt = 'L' THEN
		SET @qry = CONCAT("ALTER TABLE ",tablename," ADD COLUMN inputter varchar(50) NOT NULL DEFAULT ''");
	END IF;
 	PREPARE stmt FROM @qry;
 	EXECUTE stmt;
 	
 	IF opt = 'I' THEN
		SET @qry = CONCAT("ALTER TABLE ",tablename," ADD COLUMN input_date datetime NULL DEFAULT NULL");
	ELSEIF opt = 'L' THEN
		SET @qry = CONCAT("ALTER TABLE ",tablename," ADD COLUMN input_date datetime NOT NULL DEFAULT ''");
	END IF;
 	PREPARE stmt FROM @qry;
 	EXECUTE stmt;
		
	if opt = 'I' THEN
		SET @qry = CONCAT("ALTER TABLE ",tablename," ADD COLUMN authorizer varchar(50) NULL DEFAULT NULL");
	elseIF opt = 'L' THEN
		SET @qry = CONCAT("ALTER TABLE ",tablename," ADD COLUMN authorizer varchar(50) NOT NULL DEFAULT ''");
	end if;
 	PREPARE stmt FROM @qry;
 	EXECUTE stmt;
 	
 	IF opt = 'I' THEN
		SET @qry = CONCAT("ALTER TABLE ",tablename," ADD COLUMN auth_date datetime NULL DEFAULT NULL");
	ELSEIF opt = 'L' THEN
		SET @qry = CONCAT("ALTER TABLE ",tablename," ADD COLUMN auth_date datetime NOT NULL DEFAULT ''");
	END IF;
 	PREPARE stmt FROM @qry;
 	EXECUTE stmt;
 	
 	IF opt = 'I' THEN
		SET @qry = CONCAT("ALTER TABLE ",tablename," ADD COLUMN record_status char(4) NULL DEFAULT NULL");
	ELSEIF opt = 'L' THEN
		SET @qry = CONCAT("ALTER TABLE ",tablename," ADD COLUMN record_status char(4) NOT NULL DEFAULT ''");
	END IF;
 	PREPARE stmt FROM @qry;
 	EXECUTE stmt;
 	
 	IF opt = 'I' THEN
		SET @qry = CONCAT("ALTER TABLE ",tablename," ADD COLUMN current_no int(11) NULL DEFAULT NULL");
	ELSEIF opt = 'L' THEN
		SET @qry = CONCAT("ALTER TABLE ",tablename," ADD COLUMN current_no int(11) NOT NULL DEFAULT ''");
	END IF;
 	PREPARE stmt FROM @qry;
 	EXECUTE stmt;
 	DEALLOCATE PREPARE stmt;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_CopyRecord` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
CREATE DEFINER=`dbuser`@`localhost` PROCEDURE `sp_CopyRecord`(IN tablename VARCHAR(255), alt_id_fld VARCHAR(255), src INT(11), dest int(11), alt_dest VARCHAR(255) )
BEGIN
	DROP table IF EXISTS `tmp`;
	SET @qry = CONCAT('CREATE TEMPORARY TABLE tmp SELECT * FROM ',tablename,' WHERE id=',src);
	PREPARE stmt FROM @qry;
 	EXECUTE stmt;
	
	IF alt_id_fld is not null THEN
		SET @qry = CONCAT('UPDATE tmp SET ',alt_id_fld,'="',alt_dest,'" WHERE id=',src);
		PREPARE stmt FROM @qry; 
		EXECUTE stmt;
	END IF;
		
	SET @qry = CONCAT('UPDATE tmp SET id=',dest,' WHERE id=',src);
	PREPARE stmt FROM @qry; 
	EXECUTE stmt;
		
	SET @qry = CONCAT('INSERT INTO ',tablename,' SELECT * FROM tmp WHERE id=',dest);
	PREPARE stmt FROM @qry; 
	EXECUTE stmt;
	DROP TABLE tmp;
	DEALLOCATE PREPARE stmt;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_ENQ_contacttest` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
CREATE DEFINER=`dbuser`@`localhost` PROCEDURE `sp_ENQ_contacttest`()
BEGIN
	DROP TABLE IF EXISTS `tt_contacttest`;
	CREATE TEMPORARY TABLE tt_contacttest 
	(
		contact_id VARCHAR(50) DEFAULT NULL,
		first_name VARCHAR(255) DEFAULT NULL,
		last_name VARCHAR(255) DEFAULT NULL
	) ENGINE=MEMORY;
	INSERT INTO tt_contacttest SELECT contact_id,first_name,last_name FROM contacts;
    END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_t` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
CREATE DEFINER=`dbuser`@`localhost` PROCEDURE `sp_t`(IN opt CHAR(1))
BEGIN
DECLARE resetid INT DEFAULT 0;
IF opt = 'Y' THEN
select * from contacts;
END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Final view structure for view `vw_active_charge_customers`
--

/*!50001 DROP TABLE IF EXISTS `vw_active_charge_customers`*/;
/*!50001 DROP VIEW IF EXISTS `vw_active_charge_customers`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`dbuser`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vw_active_charge_customers` AS (select `chargeaccounts`.`id` AS `id`,`chargeaccounts`.`customer_id` AS `customer_id`,`customers`.`customer_type` AS `customer_type`,`customers`.`business_type` AS `business_type`,`customers`.`first_name` AS `first_name`,`customers`.`last_name` AS `last_name`,`customers`.`phone_mobile1` AS `phone_mobile1`,`chargeaccounts`.`activation_date` AS `activation_date`,`chargeaccounts`.`status_change_date` AS `status_change_date`,`chargeaccounts`.`active` AS `active`,`chargeaccounts`.`special_instructions` AS `special_instructions`,`chargeaccounts`.`comments` AS `comments` from (`chargeaccounts` join `customers` on((`chargeaccounts`.`customer_id` = `customers`.`customer_id`))) where (`chargeaccounts`.`active` = 'Y')) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vw_batchorders_lookup`
--

/*!50001 DROP TABLE IF EXISTS `vw_batchorders_lookup`*/;
/*!50001 DROP VIEW IF EXISTS `vw_batchorders_lookup`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`dbuser`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vw_batchorders_lookup` AS (select `vw_orderbalances`.`id` AS `invoice_id`,`vw_orderbalances`.`order_id` AS `order_id`,`vw_orderbalances`.`order_date` AS `order_date`,`vw_orderbalances`.`first_name` AS `first_name`,`vw_orderbalances`.`order_details` AS `order_details`,`vw_orderbalances`.`last_name` AS `last_name`,`vw_orderbalances`.`extended_total` AS `extended_total`,`vw_orderbalances`.`tax_total` AS `tax_total`,`vw_orderbalances`.`order_total` AS `order_total`,`vw_orderbalances`.`payment_total` AS `payment_total`,`vw_orderbalances`.`balance` AS `balance`,`vw_orderbalances`.`payment_type` AS `payment_type` from `vw_orderbalances` where ((`vw_orderbalances`.`order_status` <> 'ORDER.CANCELLED') and (`vw_orderbalances`.`order_status` <> 'QUOTATION'))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vw_batchtypes`
--

/*!50001 DROP TABLE IF EXISTS `vw_batchtypes`*/;
/*!50001 DROP VIEW IF EXISTS `vw_batchtypes`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`dbuser`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vw_batchtypes` AS (select distinct `batchinvoices`.`batch_type` AS `type` from `batchinvoices` order by `batchinvoices`.`batch_type`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vw_biztype`
--

/*!50001 DROP TABLE IF EXISTS `vw_biztype`*/;
/*!50001 DROP VIEW IF EXISTS `vw_biztype`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`dbuser`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vw_biztype` AS (select distinct `customers`.`business_type` AS `business_type` from `customers` order by `customers`.`business_type`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vw_core_fixedselections_available`
--

/*!50001 DROP TABLE IF EXISTS `vw_core_fixedselections_available`*/;
/*!50001 DROP VIEW IF EXISTS `vw_core_fixedselections_available`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`dbuser`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vw_core_fixedselections_available` AS select `params`.`controller` AS `fixedselection_id` from `params` where ((`params`.`controller` <> 'site') and (`params`.`dflag` = 'Y') and (not(`params`.`controller` in (select `fixedselections`.`fixedselection_id` AS `fixedselection_id` from `fixedselections`)))) union select `enquirydefs`.`controller` AS `fixedselection_id` from `enquirydefs` where ((`enquirydefs`.`dflag` = 'Y') and (not(`enquirydefs`.`controller` in (select `fixedselections`.`fixedselection_id` AS `fixedselection_id` from `fixedselections`)))) order by `fixedselection_id` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vw_core_users_noroles`
--

/*!50001 DROP TABLE IF EXISTS `vw_core_users_noroles`*/;
/*!50001 DROP VIEW IF EXISTS `vw_core_users_noroles`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`dbuser`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vw_core_users_noroles` AS (select `users`.`idname` AS `idname`,`users`.`fullname` AS `fullname` from `users` where ((not(`users`.`idname` in (select `userroles`.`idname` AS `idname` from `userroles`))) and (`users`.`branch_id` <> '_SYSTEM'))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vw_deliverynotes`
--

/*!50001 DROP TABLE IF EXISTS `vw_deliverynotes`*/;
/*!50001 DROP VIEW IF EXISTS `vw_deliverynotes`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`dbuser`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vw_deliverynotes` AS (select `d`.`id` AS `id`,`d`.`deliverynote_id` AS `deliverynote_id`,`o`.`id` AS `invoice_id`,`o`.`order_id` AS `order_id`,`o`.`branch_id` AS `branch_id`,`o`.`customer_id` AS `customer_id`,`o`.`is_co` AS `is_co`,`o`.`cc_id` AS `cc_id`,`c`.`first_name` AS `first_name`,`c`.`last_name` AS `last_name`,`c`.`customer_type` AS `customer_type`,`c`.`address1` AS `address1`,`c`.`address2` AS `address2`,`c`.`city` AS `city`,`c`.`phone_mobile1` AS `phone_mobile1`,`c`.`phone_home` AS `phone_home`,`c`.`phone_work` AS `phone_work`,`o`.`order_date` AS `order_date`,`o`.`quotation_date` AS `quotation_date`,`o`.`invoice_date` AS `invoice_date`,`o`.`order_status` AS `order_status`,`o`.`inventory_checkout_status` AS `inventory_checkout_status`,`o`.`inventory_update_type` AS `inventory_update_type`,`o`.`inputter` AS `inputter`,`o`.`input_date` AS `input_date`,`o`.`invoice_note` AS `invoice_note`,`d`.`deliverynote_date` AS `deliverynote_date`,`d`.`details` AS `details`,`d`.`status` AS `status`,`d`.`delivered_by` AS `delivered_by`,`d`.`delivery_date` AS `delivery_date`,`d`.`returned_signed_by` AS `returned_signed_by`,`d`.`returned_signed_date` AS `returned_signed_date`,`d`.`comments` AS `comments` from ((`orders` `o` join `deliverynotes` `d` on((`o`.`order_id` = `d`.`order_id`))) join `customers` `c` on((`o`.`customer_id` = `c`.`customer_id`)))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vw_distinct_product_category`
--

/*!50001 DROP TABLE IF EXISTS `vw_distinct_product_category`*/;
/*!50001 DROP VIEW IF EXISTS `vw_distinct_product_category`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`dbuser`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vw_distinct_product_category` AS (select distinct `products`.`category` AS `category` from `products`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vw_distinct_product_subcategory`
--

/*!50001 DROP TABLE IF EXISTS `vw_distinct_product_subcategory`*/;
/*!50001 DROP VIEW IF EXISTS `vw_distinct_product_subcategory`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`dbuser`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vw_distinct_product_subcategory` AS (select distinct `products`.`sub_category` AS `sub_category` from `products`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vw_estimator_products`
--

/*!50001 DROP TABLE IF EXISTS `vw_estimator_products`*/;
/*!50001 DROP VIEW IF EXISTS `vw_estimator_products`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`dbuser`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vw_estimator_products` AS (select `products`.`product_id` AS `product_id`,`products`.`product_description` AS `product_description`,`products`.`type` AS `TYPE`,`products`.`taxable` AS `taxable`,`products`.`unit_price` AS `unit_price`,`func_CalculateTotalPrice`(`products`.`unit_price`,`products`.`tax_percentage`,`products`.`taxable`) AS `total_price`,`products`.`category` AS `category`,`products`.`sub_category` AS `sub_category` from `products` where (`products`.`status` = 'ACTIVE')) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vw_inventchkout_sideinfo`
--

/*!50001 DROP TABLE IF EXISTS `vw_inventchkout_sideinfo`*/;
/*!50001 DROP VIEW IF EXISTS `vw_inventchkout_sideinfo`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`dbuser`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vw_inventchkout_sideinfo` AS select `orders`.`id` AS `id`,`orders`.`order_id` AS `order_id`,`orders`.`branch_id` AS `branch_id`,`orders`.`customer_id` AS `customer_id`,`customers`.`first_name` AS `first_name`,`customers`.`last_name` AS `last_name`,`orders`.`order_date` AS `order_date`,`orders`.`order_status` AS `order_status`,`orders`.`inventory_checkout_status` AS `inventory_checkout_status` from (`orders` join `customers` on((`orders`.`customer_id` = `customers`.`customer_id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vw_inventory_checkout_status`
--

/*!50001 DROP TABLE IF EXISTS `vw_inventory_checkout_status`*/;
/*!50001 DROP VIEW IF EXISTS `vw_inventory_checkout_status`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`dbuser`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vw_inventory_checkout_status` AS (select `vw_orderbalances`.`branch_id` AS `branch_id`,`vw_orderbalances`.`customer_id` AS `customer_id`,if((`vw_orderbalances`.`first_name` = 'Co.'),`vw_orderbalances`.`last_name`,concat(`vw_orderbalances`.`first_name`,' ',`vw_orderbalances`.`last_name`)) AS `customer_name`,`vw_orderbalances`.`order_id` AS `order_id`,`vw_orderbalances`.`order_status` AS `order_status`,`vw_orderbalances`.`order_details` AS `order_details`,`func_OrderCheckoutStatusReadable`(`inventchkouts`.`checkout_details`) AS `checkout_details`,`vw_orderbalances`.`inventory_checkout_status` AS `checkout_status`,`vw_orderbalances`.`order_date` AS `order_date`,`vw_orderbalances`.`order_total` AS `order_total`,`vw_orderbalances`.`payment_total` AS `payment_total`,`vw_orderbalances`.`balance` AS `balance` from (`vw_orderbalances` join `inventchkouts` on((convert(`vw_orderbalances`.`order_id` using utf8) = `inventchkouts`.`order_id`)))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vw_inventprod_available`
--

/*!50001 DROP TABLE IF EXISTS `vw_inventprod_available`*/;
/*!50001 DROP VIEW IF EXISTS `vw_inventprod_available`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`dbuser`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vw_inventprod_available` AS (select `products`.`id` AS `id`,`products`.`product_id` AS `product_id`,`products`.`product_description` AS `description` from `products` where (`products`.`type` = 'STOCK')) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vw_nonpackageproducts`
--

/*!50001 DROP TABLE IF EXISTS `vw_nonpackageproducts`*/;
/*!50001 DROP VIEW IF EXISTS `vw_nonpackageproducts`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`dbuser`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vw_nonpackageproducts` AS (select `products`.`id` AS `id`,`products`.`product_id` AS `product_id`,`products`.`type` AS `type`,`products`.`package_items` AS `package_items`,`products`.`product_description` AS `product_description`,`products`.`extended_description` AS `extended_description`,`products`.`category` AS `category`,`products`.`sub_category` AS `sub_category`,`products`.`unit_price` AS `unit_price`,`products`.`taxable` AS `taxable`,`products`.`tax_percentage` AS `tax_percentage`,`products`.`status` AS `status`,`products`.`inputter` AS `inputter`,`products`.`input_date` AS `input_date`,`products`.`authorizer` AS `authorizer`,`products`.`auth_date` AS `auth_date`,`products`.`record_status` AS `record_status`,`products`.`current_no` AS `current_no` from `products` where (`products`.`type` <> 'PACKAGE')) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vw_orderbalances`
--

/*!50001 DROP TABLE IF EXISTS `vw_orderbalances`*/;
/*!50001 DROP VIEW IF EXISTS `vw_orderbalances`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`dbuser`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vw_orderbalances` AS (select `o`.`id` AS `id`,`o`.`order_id` AS `order_id`,`o`.`branch_id` AS `branch_id`,`o`.`customer_id` AS `customer_id`,`o`.`is_co` AS `is_co`,`o`.`cc_id` AS `cc_id`,`o`.`first_name` AS `first_name`,`o`.`last_name` AS `last_name`,`o`.`customer_type` AS `customer_type`,`o`.`address1` AS `address1`,`o`.`address2` AS `address2`,`o`.`city` AS `city`,`o`.`phone_mobile1` AS `phone_mobile1`,`o`.`phone_home` AS `phone_home`,`o`.`phone_work` AS `phone_work`,`o`.`order_details` AS `order_details`,`p`.`payment_type` AS `payment_type`,`o`.`order_date` AS `order_date`,`o`.`quotation_date` AS `quotation_date`,`o`.`invoice_date` AS `invoice_date`,`o`.`order_status` AS `order_status`,`o`.`inventory_checkout_status` AS `inventory_checkout_status`,`o`.`inventory_update_type` AS `inventory_update_type`,`o`.`inputter` AS `inputter`,`o`.`input_date` AS `input_date`,`o`.`invoice_note` AS `invoice_note`,`o`.`comments` AS `comments`,`o`.`current_no` AS `current_no`,`o`.`discount_total` AS `discount_total`,`o`.`extended_total` AS `extended_total`,`o`.`tax_total` AS `tax_total`,`o`.`order_total` AS `order_total`,`p`.`payment_total` AS `payment_total`,(`o`.`order_total` - `p`.`payment_total`) AS `balance` from (`vw_orders` `o` join `vw_payments` `p` on((`o`.`order_id` = `p`.`order_id`)))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vw_orderbalances_nonzero`
--

/*!50001 DROP TABLE IF EXISTS `vw_orderbalances_nonzero`*/;
/*!50001 DROP VIEW IF EXISTS `vw_orderbalances_nonzero`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`dbuser`@`l ocalhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vw_orderbalances_nonzero` AS (select `vw_orderbalances`.`order_id` AS `order_id`,`vw_orderbalances`.`branch_id` AS `branch_id`,`vw_orderbalances`.`customer_id` AS `customer_id`,`vw_orderbalances`.`first_name` AS `first_name`,`vw_orderbalances`.`last_name` AS `last_name`,`vw_orderbalances`.`order_date` AS `order_date`,`vw_orderbalances`.`order_status` AS `order_status`,`vw_orderbalances`.`order_total` AS `order_total`,`vw_orderbalances`.`payment_total` AS `payment_total`,`vw_orderbalances`.`balance` AS `balance` from `vw_orderbalances` where ((`vw_orderbalances`.`balance` > 0) and (`vw_orderbalances`.`order_status` <> 'ORDER.CANCELLED'))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vw_orderbalances_ss`
--

/*!50001 DROP TABLE IF EXISTS `vw_orderbalances_ss`*/;
/*!50001 DROP VIEW IF EXISTS `vw_orderbalances_ss`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`dbuser`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `vw_orderbalances_ss` AS (select `orders`.`id` AS `id`,`orders`.`order_id` AS `order_id`,`orders`.`branch_id` AS `branch_id`,`orders`.`customer_id` AS `customer_id`,`customers`.`first_name` AS `first_name`,`customers`.`last_name` AS `last_name`,`customers`.`customer_type` AS `customer_type`,`customers`.`address1` AS `address1`,`customers`.`address2` AS `address2`,`customers`.`city` AS `city`,`customers`.`phone_mobile1` AS `phone_mobile1`,`customers`.`phone_home` AS `phone_home`,`customers`.`phone_work` AS `phone_work`,(select group_concat(`orderdetails`.`product_id`,'(',`orderdetails`.`qty`,')' separator ';') AS `aa` from `orderdetails` where (`orders`.`order_id` = `orderdetails`.`order_id`)) AS `order_details`,(select coalesce(group_concat(`payments`.`payment_type`,'(',`payments`.`amount`,')' separator ';'),'') AS `ba` from `payments` where ((`orders`.`order_id` = `payments`.`order_id`) and (`payments`.`payment_status` = 'VALID'))) AS `payment_type`,`orders`.`order_date` AS `order_date`,`orders`.`quotation_date` AS `quotation_date`,`orders`.`invoice_date` AS `invoice_date`,`orders`.`order_status` AS `order_status`,`orders`.`inventory_checkout_status` AS `inventory_checkout_status`,`orders`.`inventory_update_type` AS `inventory_update_type`,`orders`.`inputter` AS `inputter`,`orders`.`input_date` AS `input_date`,`orders`.`invoice_note` AS `invoice_note`,`orders`.`comments` AS `comments`,`orders`.`current_no` AS `current_no`,(select coalesce(sum(`func_OrderDetailUnitTotal`(`orderdetails`.`qty`,`orderdetails`.`unit_price`)),0) AS `ab` from `orderdetails` where (`orderdetails`.`order_id` = `orders`.`order_id`)) AS `unit_total`,(select coalesce(sum(`func_OrderDetailDiscountTotal`(`orderdetails`.`qty`,`orderdetails`.`unit_price`,`orderdetails`.`discount_amount`,`orderdetails`.`discount_type`)),0) AS `ac` from `orderdetails` where (`orderdetails`.`order_id` = `orders`.`order_id`)) AS `discount_total`,(select coalesce(sum(`func_OrderDetailSubTotal`(`orderdetails`.`qty`,`orderdetails`.`unit_price`,`orderdetails`.`discount_amount`,`orderdetails`.`discount_type`)),0) AS `ad` from `orderdetails` where (`orderdetails`.`order_id` = `orders`.`order_id`)) AS `extended_total`,(select coalesce(sum(`func_OrderDetailTaxTotal`(`orderdetails`.`qty`,`orderdetails`.`unit_price`,`orderdetails`.`discount_amount`,`orderdetails`.`tax_percentage`,`orderdetails`.`taxable`,`orderdetails`.`discount_type`)),0) AS `ae` from `orderdetails` where (`orderdetails`.`order_id` = `orders`.`order_id`)) AS `tax_total`,(select coalesce(sum(`func_OrderDetailOrderTotal`(`orderdetails`.`qty`,`orderdetails`.`unit_price`,`orderdetails`.`discount_amount`,`orderdetails`.`tax_percentage`,`orderdetails`.`taxable`,`orderdetails`.`discount_type`)),0) AS `af` from `orderdetails` where (`orderdetails`.`order_id` = `orders`.`order_id`)) AS `order_total`,(select coalesce(sum(`payments`.`amount`),0) AS `ag` from `payments` where ((`payments`.`order_id` = `orders`.`order_id`) and (`payments`.`payment_status` = 'VALID'))) AS `payment_total`,((select coalesce(sum(`func_OrderDetailOrderTotal`(`orderdetails`.`qty`,`orderdetails`.`unit_price`,`orderdetails`.`discount_amount`,`orderdetails`.`tax_percentage`,`orderdetails`.`taxable`,`orderdetails`.`discount_type`)),0) AS `ah` from `orderdetails` where (`orderdetails`.`order_id` = `orders`.`order_id`)) - (select coalesce(sum(`payments`.`amount`),0) AS `ai` from `payments` where ((`payments`.`order_id` = `orders`.`order_id`) and (`payments`.`payment_status` = 'VALID')))) AS `balance` from (`orders` join `customers` on((`orders`.`customer_id` = `customers`.`customer_id`)))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vw_ordercancel_candidates`
--

/*!50001 DROP TABLE IF EXISTS `vw_ordercancel_candidates`*/;
/*!50001 DROP VIEW IF EXISTS `vw_ordercancel_candidates`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`dbuser`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vw_ordercancel_candidates` AS (select `orders`.`id` AS `id`,`orders`.`order_id` AS `order_id`,`orders`.`customer_id` AS `customer_id`,`orders`.`order_status` AS `order_status`,`orders`.`order_date` AS `order_date`,`orders`.`branch_id` AS `branch_id` from `orders` where ((`orders`.`order_status` <> 'NEW') and (`orders`.`order_status` <> 'QUOTATION') and (`orders`.`order_status` <> 'QUOTATION.EXPIRED') and (`orders`.`order_status` <> 'ORDER.CANCELLED') and (`orders`.`order_status` <> 'REOPENED'))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vw_orderreopen_candidates`
--

/*!50001 DROP TABLE IF EXISTS `vw_orderreopen_candidates`*/;
/*!50001 DROP VIEW IF EXISTS `vw_orderreopen_candidates`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`dbuser`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vw_orderreopen_candidates` AS (select `orders`.`id` AS `id`,`orders`.`order_id` AS `order_id`,`orders`.`customer_id` AS `customer_id`,`orders`.`order_status` AS `order_status`,`orders`.`order_date` AS `order_date`,`orders`.`branch_id` AS `branch_id` from `orders` where ((`orders`.`order_status` <> 'NEW') and (`orders`.`order_status` <> 'QUOTATION') and (`orders`.`order_status` <> 'ORDER.CANCELLED') and (`orders`.`order_status` <> 'INVOICE.PART.PAID') and (`orders`.`order_status` <> 'INVOICE.FULL.PAID') and (`orders`.`order_status` <> 'REOPENED'))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vw_orders`
--

/*!50001 DROP TABLE IF EXISTS `vw_orders`*/;
/*!50001 DROP VIEW IF EXISTS `vw_orders`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`dbuser`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vw_orders` AS (select `orders`.`id` AS `id`,`orders`.`order_id` AS `order_id`,`orders`.`branch_id` AS `branch_id`,`orders`.`customer_id` AS `customer_id`,`orders`.`is_co` AS `is_co`,`orders`.`cc_id` AS `cc_id`,`customers`.`first_name` AS `first_name`,`customers`.`last_name` AS `last_name`,`customers`.`customer_type` AS `customer_type`,`customers`.`address1` AS `address1`,`customers`.`address2` AS `address2`,`customers`.`city` AS `city`,`customers`.`phone_mobile1` AS `phone_mobile1`,`customers`.`phone_home` AS `phone_home`,`customers`.`phone_work` AS `phone_work`,group_concat(`orderdetails`.`product_id`,'(',`orderdetails`.`qty`,')' separator '; ') AS `order_details`,`orders`.`order_date` AS `order_date`,`orders`.`quotation_date` AS `quotation_date`,`orders`.`invoice_date` AS `invoice_date`,`orders`.`order_status` AS `order_status`,`orders`.`inventory_checkout_status` AS `inventory_checkout_status`,`orders`.`inventory_update_type` AS `inventory_update_type`,`orders`.`inputter` AS `inputter`,`orders`.`input_date` AS `input_date`,`orders`.`invoice_note` AS `invoice_note`,`orders`.`comments` AS `comments`,`orders`.`current_no` AS `current_no`,coalesce(sum(`func_OrderDetailUnitTotal`(`orderdetails`.`qty`,`orderdetails`.`unit_price`)),0) AS `unit_total`,coalesce(sum(`func_OrderDetailDiscountTotal`(`orderdetails`.`qty`,`orderdetails`.`unit_price`,`orderdetails`.`discount_amount`,`orderdetails`.`discount_type`)),0) AS `discount_total`,coalesce(sum(`func_OrderDetailSubTotal`(`orderdetails`.`qty`,`orderdetails`.`unit_price`,`orderdetails`.`discount_amount`,`orderdetails`.`discount_type`)),0) AS `extended_total`,coalesce(sum(`func_OrderDetailTaxTotal`(`orderdetails`.`qty`,`orderdetails`.`unit_price`,`orderdetails`.`discount_amount`,`orderdetails`.`tax_percentage`,`orderdetails`.`taxable`,`orderdetails`.`discount_type`)),0) AS `tax_total`,coalesce(sum(`func_OrderDetailOrderTotal`(`orderdetails`.`qty`,`orderdetails`.`unit_price`,`orderdetails`.`discount_amount`,`orderdetails`.`tax_percentage`,`orderdetails`.`taxable`,`orderdetails`.`discount_type`)),0) AS `order_total` from ((`orders` join `customers` on((`orders`.`customer_id` = `customers`.`customer_id`))) left join `orderdetails` on((`orders`.`order_id` = `orderdetails`.`order_id`))) group by `orders`.`order_id`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vw_orderstatus`
--

/*!50001 DROP TABLE IF EXISTS `vw_orderstatus`*/;
/*!50001 DROP VIEW IF EXISTS `vw_orderstatus`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`dbuser`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vw_orderstatus` AS (select `_sys_orderstatus`.`id` AS `id`,`_sys_orderstatus`.`order_status_id` AS `order_status_id` from `_sys_orderstatus` where (`_sys_orderstatus`.`progession_id` <= 5)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vw_payments`
--

/*!50001 DROP TABLE IF EXISTS `vw_payments`*/;
/*!50001 DROP VIEW IF EXISTS `vw_payments`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`dbuser`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vw_payments` AS (select `orders`.`order_id` AS `order_id`,coalesce(group_concat(distinct if((`payments`.`payment_status` <> 'CANCELLED'),`payments`.`payment_type`,NULL),'(',`payments`.`amount`,')' separator '; '),'') AS `payment_type`,sum(if((`payments`.`payment_status` = 'VALID'),`payments`.`amount`,0)) AS `payment_total` from (`orders` left join `payments` on((`orders`.`order_id` = `payments`.`order_id`))) group by `orders`.`order_id`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vw_payments_till`
--

/*!50001 DROP TABLE IF EXISTS `vw_payments_till`*/;
/*!50001 DROP VIEW IF EXISTS `vw_payments_till`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`dbuser`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vw_payments_till` AS (select `orders`.`order_id` AS `order_id`,`payments`.`till_id` AS `till_id`,`payments`.`payment_type` AS `tender_type`,coalesce(group_concat(distinct if((`payments`.`payment_status` <> 'CANCELLED'),`payments`.`payment_type`,NULL),'(',`payments`.`amount`,')' separator '; '),'') AS `payment_type`,sum(if((`payments`.`payment_status` = 'VALID'),`payments`.`amount`,0)) AS `payment_total` from (`orders` left join `payments` on((`orders`.`order_id` = `payments`.`order_id`))) group by `orders`.`order_id`,`payments`.`till_id`,`payments`.`payment_type`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vw_payments_valid`
--

/*!50001 DROP TABLE IF EXISTS `vw_payments_valid`*/;
/*!50001 DROP VIEW IF EXISTS `vw_payments_valid`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`dbuser`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vw_payments_valid` AS (select `payments`.`id` AS `id`,`payments`.`payment_id` AS `payment_id`,`payments`.`payment_date` AS `payment_date`,`payments`.`amount` AS `amount`,`payments`.`payment_type` AS `payment_type`,`payments`.`order_id` AS `order_id`,`payments`.`branch_id` AS `branch_id`,`payments`.`till_id` AS `till_id` from `payments` where (`payments`.`payment_status` = 'VALID')) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vw_tillmovements`
--

/*!50001 DROP TABLE IF EXISTS `vw_tillmovements`*/;
/*!50001 DROP VIEW IF EXISTS `vw_tillmovements`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`dbuser`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vw_tillmovements` AS (select `vw_tilltransactions_groups`.`till_id` AS `till_id`,group_concat(`vw_tilltransactions_groups`.`payment_type` separator '; ') AS `tillmovements_type_totals`,sum(`vw_tilltransactions_groups`.`payment_total`) AS `tillmovement_total` from `vw_tilltransactions_groups` group by `vw_tilltransactions_groups`.`till_id`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vw_tillpayments`
--

/*!50001 DROP TABLE IF EXISTS `vw_tillpayments`*/;
/*!50001 DROP VIEW IF EXISTS `vw_tillpayments`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`dbuser`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `vw_tillpayments` AS (select `tills`.`till_id` AS `till_id`,`tills`.`till_user` AS `till_owner`,`tills`.`till_date` AS `till_date`,group_concat(`vw_tillpayments_groups`.`payment_type` separator '; ') AS `payment_type_totals`,`tills`.`initial_balance` AS `initial_balance`,sum(`vw_tillpayments_groups`.`payment_total`) AS `payment_total` from (`tills` join `vw_tillpayments_groups` on((`tills`.`till_id` = convert(`vw_tillpayments_groups`.`till_id` using utf8)))) group by `tills`.`till_date`,`tills`.`till_user`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vw_tillpayments_groups`
--

/*!50001 DROP TABLE IF EXISTS `vw_tillpayments_groups`*/;
/*!50001 DROP VIEW IF EXISTS `vw_tillpayments_groups`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`dbuser`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vw_tillpayments_groups` AS (select `vw_tillpayments_types`.`till_id` AS `till_id`,group_concat(`vw_tillpayments_types`.`tender_type`,'(',`vw_tillpayments_types`.`amount`,')' separator '; ') AS `payment_type`,sum(`vw_tillpayments_types`.`amount`) AS `payment_total` from `vw_tillpayments_types` group by `vw_tillpayments_types`.`till_id`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vw_tillpayments_types`
--

/*!50001 DROP TABLE IF EXISTS `vw_tillpayments_types`*/;
/*!50001 DROP VIEW IF EXISTS `vw_tillpayments_types`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`dbuser`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vw_tillpayments_types` AS (select `vw_payments_till`.`till_id` AS `till_id`,`vw_payments_till`.`tender_type` AS `tender_type`,sum(`vw_payments_till`.`payment_total`) AS `amount` from `vw_payments_till` group by `vw_payments_till`.`tender_type`,`vw_payments_till`.`till_id`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vw_tills`
--

/*!50001 DROP TABLE IF EXISTS `vw_tills`*/;
/*!50001 DROP VIEW IF EXISTS `vw_tills`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`dbuser`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vw_tills` AS (select `vw_tillpayments`.`till_id` AS `till_id`,`vw_tillpayments`.`till_owner` AS `till_owner`,`vw_tillpayments`.`till_date` AS `till_date`,`vw_tillpayments`.`payment_type_totals` AS `payment_type_totals`,`vw_tillmovements`.`tillmovements_type_totals` AS `tillmovements_type_totals`,`vw_tillpayments`.`initial_balance` AS `initial_balance`,`vw_tillpayments`.`payment_total` AS `payment_total`,`vw_tillmovements`.`tillmovement_total` AS `tillmovement_total`,(`vw_tillpayments`.`payment_total` + `vw_tillmovements`.`tillmovement_total`) AS `till_balance` from (`vw_tillpayments` join `vw_tillmovements` on((`vw_tillpayments`.`till_id` = convert(`vw_tillmovements`.`till_id` using utf8)))) order by `vw_tillpayments`.`till_date`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vw_tilltransactions`
--

/*!50001 DROP TABLE IF EXISTS `vw_tilltransactions`*/;
/*!50001 DROP VIEW IF EXISTS `vw_tilltransactions`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`dbuser`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `vw_tilltransactions` AS (select `tilltransactions`.`till_id` AS `till_id`,`tilltransactions`.`transaction_type` AS `tender_type`,group_concat(distinct `tilltransactions`.`transaction_type`,'(',if((`tilltransactions`.`movement` = 'IN'),`tilltransactions`.`amount`,(`tilltransactions`.`amount` * -(1))),')' separator '; ') AS `payment_type`,sum(if((`tilltransactions`.`movement` = 'IN'),`tilltransactions`.`amount`,(`tilltransactions`.`amount` * -(1)))) AS `payment_total` from `tilltransactions` group by `tilltransactions`.`till_id`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vw_tilltransactions_groups`
--

/*!50001 DROP TABLE IF EXISTS `vw_tilltransactions_groups`*/;
/*!50001 DROP VIEW IF EXISTS `vw_tilltransactions_groups`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`dbuser`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vw_tilltransactions_groups` AS (select `vw_tilltransactions_types`.`till_id` AS `till_id`,group_concat(`vw_tilltransactions_types`.`tender_type`,'(',`vw_tilltransactions_types`.`amount`,')' separator '; ') AS `payment_type`,sum(`vw_tilltransactions_types`.`amount`) AS `payment_total` from `vw_tilltransactions_types` group by `vw_tilltransactions_types`.`till_id`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vw_tilltransactions_types`
--

/*!50001 DROP TABLE IF EXISTS `vw_tilltransactions_types`*/;
/*!50001 DROP VIEW IF EXISTS `vw_tilltransactions_types`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`dbuser`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vw_tilltransactions_types` AS (select `vw_tilltransactions`.`till_id` AS `till_id`,`vw_tilltransactions`.`tender_type` AS `tender_type`,sum(`vw_tilltransactions`.`payment_total`) AS `amount` from `vw_tilltransactions` group by `vw_tilltransactions`.`tender_type`,`vw_tilltransactions`.`till_id`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vw_userbranches`
--

/*!50001 DROP TABLE IF EXISTS `vw_userbranches`*/;
/*!50001 DROP VIEW IF EXISTS `vw_userbranches`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`dbuser`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vw_userbranches` AS select `users`.`id` AS `id`,`users`.`idname` AS `idname`,`users`.`username` AS `username`,`users`.`fullname` AS `fullname`,`users`.`email` AS `email`,`users`.`enabled` AS `enabled`,`users`.`expiry_date` AS `expiry_date`,`users`.`branch_id` AS `branch_id`,`users`.`department_id` AS `department_id`,`branches`.`description` AS `description`,`branches`.`location` AS `location`,`branches`.`region_id` AS `region_id`,`branches`.`active` AS `active` from (`users` join `branches` on((`users`.`branch_id` = `branches`.`branch_id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2013-09-14  5:50:16
